/**
 * Snaplevel — vertical tab navigation (admin views).
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var tabs  = document.querySelectorAll( '.snap-vtabs-nav .snap-vtab' );
		var panes = document.querySelectorAll( '.snap-tab-pane' );
		if ( ! tabs.length ) {
			return;
		}

		tabs.forEach( function ( tab ) {
			tab.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var target = this.getAttribute( 'data-tab' );
				if ( ! target ) {
					return;
				}

				tabs.forEach( function ( t ) {
					t.classList.remove( 'is-active' );
				} );
				this.classList.add( 'is-active' );

				var url = new URL( window.location.href );
				url.searchParams.set( 'sub', target );
				window.history.replaceState( {}, '', url );

				panes.forEach( function ( pane ) {
					pane.style.display = pane.id === 'tab-' + target ? 'block' : 'none';
				} );
			} );
		} );
	} );
} )();