/**
 * Snaplevel — Site Audit admin view.
 * Requires: window.SNAP_AUDIT localized config.
 */
( function ( $ ) {
	'use strict';

	var CFG         = window.SNAP_AUDIT || {};
	var nonce       = CFG.nonce || '';
	var ajaxurl     = CFG.ajaxurl || '';
	var restUrl     = CFG.restUrl || '';
	var restNonce   = CFG.restNonce || '';
	var scans       = {};
	var TOTAL_TESTS = CFG.totalTests || 7;
	var largeImages = CFG.largeImages || 0;
	var fixTotals   = { meta: 0, images: 0, links: 0 };

	function fmt( template ) {
		var args = Array.prototype.slice.call( arguments, 1 );
		return template.replace( /%(\d+)\$[sd]/g, function ( _, n ) {
			return args[ parseInt( n, 10 ) - 1 ];
		} );
	}

	initLargeImages();

	function pill( cls, text ) {
		return '<span class="snap-pill ' + cls + '">' + text + '</span>';
	}

	function initLargeImages() {
		var status = largeImages > 0 ? 'fail' : 'pass';
		var badge  = largeImages > 0
			? pill( 'snap-pill-red', largeImages + ' ' + CFG.i18n.found )
			: pill( 'snap-pill-green', CFG.i18n.allClear );
		setItemStatus( 'large-images', status, badge );
		scans['large-images'] = { status: status, count: largeImages };
		recalcScore();
	}

	$( '.icw-audit-tab' ).on( 'click', function ( e ) {
		e.preventDefault();
		$( '.icw-audit-tab' ).removeClass( 'is-active' );
		$( this ).addClass( 'is-active' );

		var filter = $( this ).data( 'filter' );
		$( '.icw-audit-item' ).each( function () {
			if ( filter === 'all' ) {
				$( this ).show();
				return;
			}
			var status = $( this ).data( 'status' );
			$( this ).toggle(
				status === filter
				|| ( filter === 'warning' && status === 'warn' )
				|| ( filter === 'passed' && status === 'pass' )
				|| ( filter === 'failed' && status === 'fail' )
			);
		} );
	} );

	$( '#snap-ai-fix' ).on( 'click', function () {
		var $btn = $( this );
		var $st  = $( '#snap-ai-fix-status' );
		$btn.prop( 'disabled', true );
		fixTotals = { meta: 0, images: 0, links: 0 };
		$st.text( CFG.i18n.phase1 );
		fixMetaStep( $btn, $st );
	} );

	function fixMetaStep( $btn, $st ) {
		$.ajax( {
			url: restUrl + '/ai/fix-meta',
			method: 'POST',
			beforeSend: function ( xhr ) {
				xhr.setRequestHeader( 'X-WP-Nonce', restNonce );
			}
		} ).done( function ( res ) {
			fixTotals.meta += ( res.fixed || [] ).length;
			if ( ! res.done ) {
				$st.text( fmt( CFG.i18n.phase1Progress, fixTotals.meta, res.remaining ) );
				fixMetaStep( $btn, $st );
				return;
			}
			$st.text( CFG.i18n.phase2 );
			fixImagesStep( $btn, $st );
		} ).fail( function () {
			$st.text( CFG.i18n.phase2Skip );
			fixImagesStep( $btn, $st );
		} );
	}

	function fixImagesStep( $btn, $st ) {
		$.post( ajaxurl, { action: 'icw_bulk_compress_next', nonce: nonce }, function ( res ) {
			if ( res.success && res.data && ! res.data.done ) {
				fixTotals.images++;
				$st.text( fmt( CFG.i18n.phase2Progress, fixTotals.images, res.data.filename || '', res.data.saved_pct || 0 ) );
				fixImagesStep( $btn, $st );
				return;
			}
			$st.text( CFG.i18n.phase3 );
			fixLinksStep( $btn, $st, 0 );
		} ).fail( function () {
			$st.text( CFG.i18n.phase3Skip );
			fixLinksStep( $btn, $st, 0 );
		} );
	}

	function fixLinksStep( $btn, $st, offset ) {
		$.ajax( {
			url: restUrl + '/audit/fix-links',
			method: 'POST',
			data: { offset: offset },
			beforeSend: function ( xhr ) {
				xhr.setRequestHeader( 'X-WP-Nonce', restNonce );
			}
		} ).done( function ( res ) {
			fixTotals.links += res.fixed_links || 0;
			if ( ! res.done ) {
				$st.text( fmt( CFG.i18n.phase3Progress, res.next_offset, res.total, fixTotals.links ) );
				fixLinksStep( $btn, $st, res.next_offset );
				return;
			}
			finishFix( $btn, $st );
		} ).fail( function () {
			finishFix( $btn, $st );
		} );
	}

	function finishFix( $btn, $st ) {
		$btn.prop( 'disabled', false );
		$st.html(
			'<span style="color:var(--snap-score-good);font-weight:600;">✓ '
			+ fmt( CFG.i18n.doneSummary, fixTotals.meta, fixTotals.images, fixTotals.links )
			+ '</span>'
		);
		scans = {};
		initLargeImages();
		$( '.icw-btn-scan' ).each( function () {
			$( this ).click();
		} );
	}

	$( '#icw-run-full-audit, #icw-restart-audit' ).on( 'click', function ( e ) {
		e.preventDefault();
		scans = {};
		initLargeImages();
		$( '.icw-btn-scan' ).each( function () {
			$( this ).click();
		} );
	} );

	$( document ).on( 'click', '.icw-btn-scan', function () {
		var $btn   = $( this );
		var action = $btn.data( 'action' );
		var target = $btn.data( 'target' );
		$btn.prop( 'disabled', true ).text( CFG.i18n.scanning );
		$( '#result-' + target ).hide().html( '' );
		setItemStatus( target, 'loading', pill( 'snap-pill-gray', CFG.i18n.scanning ) );

		$.post( ajaxurl, { action: action, nonce: nonce }, function ( res ) {
			$btn.prop( 'disabled', false ).text( CFG.i18n.rescan );
			if ( ! res.success ) {
				setItemStatus( target, 'fail', pill( 'snap-pill-red', CFG.i18n.error ) );
				return;
			}
			renderResult( target, res.data );
		} ).fail( function () {
			$btn.prop( 'disabled', false ).text( CFG.i18n.rescan );
			setItemStatus( target, 'fail', pill( 'snap-pill-red', CFG.i18n.serverError ) );
		} );
	} );

	function renderResult( target, data ) {
		var html   = '';
		var status = 'pass';
		var count  = 0;

		if ( target === 'orphans' ) {
			count  = data.orphans ? data.orphans.length : 0;
			status = count > 0 ? 'fail' : 'pass';
			if ( count > 0 ) {
				html = buildTable(
					[ CFG.i18n.pageTitle, 'URL' ],
					data.orphans.map( function ( r ) {
						return [ r.title, '<a href="' + r.url + '" target="_blank">' + r.url + '</a>' ];
					} )
				);
			}
		} else if ( target === 'sitemap' ) {
			count  = data.redirects ? data.redirects.length : 0;
			status = count > 0 ? 'warn' : 'pass';
			if ( count > 0 ) {
				html = buildTable(
					[ 'Sitemap URL', 'Code', CFG.i18n.redirectsTo ],
					data.redirects.map( function ( r ) {
						return [ r.url, r.code, r.to || '—' ];
					} )
				);
			}
		} else if ( target === 'slow' ) {
			if ( data.pages ) {
				data.pages.forEach( function ( p ) {
					if ( p.slow ) {
						count++;
					}
				} );
				status = count > 0 ? 'warn' : 'pass';
				html = buildTable(
					[ 'URL', CFG.i18n.responseTime, 'Status' ],
					data.pages.map( function ( p ) {
						return [
							p.url,
							p.time,
							p.slow
								? '<span style="color:var(--snap-score-bad);font-weight:600;">Slow</span>'
								: '<span style="color:var(--snap-score-good);font-weight:600;">OK</span>'
						];
					} )
				);
			}
		} else if ( target === 'redirects' ) {
			count  = data.links ? data.links.length : 0;
			status = count > 0 ? 'warn' : 'pass';
			if ( count > 0 ) {
				html = buildTable(
					[ CFG.i18n.foundOn, CFG.i18n.redirectedLink, 'Code' ],
					data.links.map( function ( r ) {
						return [ r.title, r.link, r.code ];
					} )
				);
			}
		} else if ( target === 'css' ) {
			count  = data.css ? data.css.length : 0;
			status = count > 0 ? 'warn' : 'pass';
			if ( count > 0 ) {
				html = buildTable(
					[ CFG.i18n.cssFile, CFG.i18n.fileSize ],
					data.css.map( function ( c ) {
						return [ c.file, c.size ];
					} )
				);
			}
		} else if ( target === 'meta' ) {
			count  = data.changes ? data.changes.length : 0;
			status = count > 0 ? 'warn' : 'pass';
			if ( count > 0 ) {
				html = '<ul style="margin:0;padding-left:20px;color:var(--snap-text-secondary);">'
					+ data.changes.map( function ( c ) {
						return '<li>' + c + '</li>';
					} ).join( '' )
					+ '</ul>';
			}
		}

		var badgeClass = status === 'pass' ? 'snap-pill-green' : ( status === 'warn' ? 'snap-pill-amber' : 'snap-pill-red' );
		var badgeText  = status === 'pass' ? CFG.i18n.passed : ( count + ' ' + CFG.i18n.found );
		setItemStatus( target, status, pill( badgeClass, badgeText ) );
		scans[target] = { status: status, count: count };

		if ( html ) {
			$( '#result-' + target ).html( html ).slideDown( 200 );
		} else {
			$( '#result-' + target ).html(
				'<p style="color:var(--snap-score-good);font-weight:600;margin:0;">✓ ' + CFG.i18n.noIssues + '</p>'
			).slideDown( 200 );
		}

		recalcScore();
	}

	function buildTable( headers, rows ) {
		var html = '<div class="snap-table-wrap" style="border:1px solid var(--snap-border-light);border-radius:6px;overflow:hidden;"><table class="snap-table"><thead><tr>'
			+ headers.map( function ( h ) {
				return '<th>' + h + '</th>';
			} ).join( '' )
			+ '</tr></thead><tbody>';
		rows.forEach( function ( row ) {
			html += '<tr>' + row.map( function ( c ) {
				return '<td>' + c + '</td>';
			} ).join( '' ) + '</tr>';
		} );
		return html + '</tbody></table></div>';
	}

	function setItemStatus( target, status, badgeHtml ) {
		var $item = $( '#audit-' + target );
		$item.attr( 'data-status', status );
		$item.find( '.icw-audit-status-dot' ).removeClass( 'pass fail warn loading' ).addClass( status );
		$( '#badge-' + target ).html( badgeHtml );
	}

	function recalcScore() {
		var total = Object.keys( scans ).length;
		if ( ! total ) {
			return;
		}
		var passed = 0;
		var warned = 0;
		var failed = 0;
		Object.values( scans ).forEach( function ( s ) {
			if ( s.status === 'pass' ) {
				passed++;
			} else if ( s.status === 'warn' ) {
				warned++;
			} else {
				failed++;
			}
		} );

		var score   = Math.round( ( ( passed + warned * 0.5 ) / TOTAL_TESTS ) * 100 );
		var color   = score >= 81 ? 'var(--snap-score-good)' : ( score >= 51 ? 'var(--snap-score-ok)' : 'var(--snap-score-bad)' );
		var maxDash = 402;
		var offset  = maxDash - ( maxDash * score / 100 );

		$( '#icw-gauge-score' ).text( score ).css( 'color', color );
		$( '#icw-gauge-arc' ).css( { stroke: color } ).attr( 'stroke-dashoffset', offset );

		var barMax = Math.max( passed, warned, failed, 1 );
		$( '#bar-passed' ).css( 'width', ( passed / barMax * 100 ) + '%' );
		$( '#bar-warnings' ).css( 'width', ( warned / barMax * 100 ) + '%' );
		$( '#bar-failed' ).css( 'width', ( failed / barMax * 100 ) + '%' );
		$( '#count-passed' ).text( passed );
		$( '#count-warnings' ).text( warned );
		$( '#count-failed' ).text( failed );
	}
} )( jQuery );