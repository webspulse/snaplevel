/**
 * Snaplevel Onboarding Wizard — full-screen setup.
 * Steps: Welcome → Connect AI (Claude or ChatGPT) → Import → Your Site → Train AI → Ready.
 * Skippable, resumable (step persisted via REST).
 */
/* global SNAP, wp */
( function () {
	'use strict';

	var root = document.getElementById( 'snap-wizard-app' );
	if ( ! root || ! window.SNAP ) { return; }

	var apiFetch = wp.apiFetch;
	var state = { step: 0, siteType: '', hasKey: !! SNAP.hasKey, provider: 'anthropic' };

	var STEPS = [
		{ id: 'welcome', label: 'Start' },
		{ id: 'ai', label: 'Connect AI' },
		{ id: 'import', label: 'Import' },
		{ id: 'sitetype', label: 'Your Site' },
		{ id: 'train', label: 'Train AI Teammate' },
		{ id: 'done', label: 'Ready' }
	];

	var PROVIDERS = {
		anthropic: { name: 'Claude (Anthropic)', sub: 'console.anthropic.com', placeholder: 'sk-ant-…' },
		openai:    { name: 'ChatGPT (OpenAI)',   sub: 'platform.openai.com',   placeholder: 'sk-…' },
		gemini:    { name: 'Google Gemini',      sub: 'aistudio.google.com',   placeholder: 'AIza…' },
		deepseek:  { name: 'DeepSeek',           sub: 'platform.deepseek.com', placeholder: 'sk-…' },
		mistral:   { name: 'Mistral AI',         sub: 'console.mistral.ai',    placeholder: '…' }
	};

	function h( tag, attrs, children ) {
		var node = document.createElement( tag );
		attrs = attrs || {};
		Object.keys( attrs ).forEach( function ( k ) {
			if ( k === 'class' ) { node.className = attrs[ k ]; }
			else if ( k.indexOf( 'on' ) === 0 ) { node.addEventListener( k.slice( 2 ), attrs[ k ] ); }
			else if ( k === 'checked' || k === 'disabled' ) { if ( attrs[ k ] ) { node[ k ] = true; } }
			else { node.setAttribute( k, attrs[ k ] ); }
		} );
		( children || [] ).forEach( function ( c ) {
			if ( c === null || c === undefined ) { return; }
			node.appendChild( typeof c === 'string' ? document.createTextNode( c ) : c );
		} );
		return node;
	}

	function persist( extra ) {
		var data = { step: state.step };
		if ( extra ) { Object.keys( extra ).forEach( function ( k ) { data[ k ] = extra[ k ]; } ); }
		apiFetch( { path: '/snaplevel/v1/wizard', method: 'POST', data: data } ).catch( function () {} );
	}

	function go( step ) {
		state.step = Math.max( 0, Math.min( STEPS.length - 1, step ) );
		persist();
		render();
	}

	function skip() {
		persist( { skipped: true } );
		window.location.href = SNAP.adminUrl + 'admin.php?page=icw-dashboard';
	}

	function finish() {
		state.step = STEPS.length - 1;
		persist( { done: true } );
		window.location.href = SNAP.adminUrl + 'admin.php?page=icw-dashboard';
	}

	function stepsBar() {
		return h( 'div', { class: 'snap-wizard-steps' }, STEPS.map( function ( s, i ) {
			return h( 'div', { class: 'snap-wizard-step' + ( i <= state.step ? ' is-done' : '' ) }, [
				h( 'div', { class: 'snap-wizard-step-dot' } ),
				h( 'div', { class: 'snap-wizard-step-label' }, [ s.label ] )
			] );
		} ) );
	}

	function actions( opts ) {
		opts = opts || {};
		return h( 'div', { class: 'snap-wizard-actions' }, [
			h( 'button', { class: 'snap-btn snap-btn-secondary', onclick: opts.onBack || function () { go( state.step - 1 ); } },
				[ state.step === 0 ? 'Skip setup' : 'Back' ] ),
			h( 'button', { class: 'snap-btn snap-btn-primary', onclick: opts.onNext || function () { go( state.step + 1 ); } },
				[ opts.nextLabel || 'Continue →' ] )
		] );
	}

	// ── Steps ────────────────────────────────────────────────────────────────

	function stepWelcome() {
		var card = h( 'div', { class: 'snap-card', style: 'text-align:center' }, [
			h( 'h1', null, [ 'Copilot just looked at your site.' ] ),
			h( 'p', { style: 'font-size:14px;color:#434960;max-width:460px;margin:0 auto 12px' }, [
				'No config yet. Here is what it found in seconds.'
			] ),
			h( 'div', { class: 'snap-scan-loading', style: 'padding:24px 0' }, [
				h( 'div', { class: 'snap-spinner', style: 'margin:0 auto 12px' } ),
				h( 'p', { class: 'snap-muted' }, [ 'Scanning your site...' ] )
			] )
		] );

		apiFetch( { path: '/snaplevel/v1/wizard/quick-scan' } ).then( function ( res ) {
			var loading = card.querySelector( '.snap-scan-loading' );
			if ( loading ) { loading.remove(); }

			var results = h( 'div', { style: 'max-width:480px;margin:0 auto' } );

			// Empty site
			if ( ! res.posts_count ) {
				results.appendChild( h( 'div', { style: 'padding:16px 0' }, [
					h( 'p', { style: 'font-size:14px;color:#434960' }, [ 'Your site is brand new. Let\'s connect AI so you\'re ready when you publish.' ] )
				] ) );
				results.appendChild( h( 'div', { style: 'display:flex;gap:12px;justify-content:center;margin-top:16px' }, [
					h( 'button', { class: 'snap-btn snap-btn-secondary', onclick: skip }, [ 'Skip setup' ] ),
					h( 'button', { class: 'snap-btn snap-btn-ai', onclick: function () { go( 1 ); } }, [ 'Connect AI →' ] )
				] ) );
				card.appendChild( results );
				return;
			}

			// Site with content - show scan results
			var stats = [];
			stats.push( h( 'div', { class: 'snap-scan-stat' }, [
				h( 'div', { style: 'font-size:28px;font-weight:700;color:#4338CA' }, [ String( res.posts_count ) ] ),
				h( 'div', { style: 'font-size:12px;color:#6B7280' }, [ 'published posts' ] )
			] ) );
			if ( res.missing_meta > 0 ) {
				stats.push( h( 'div', { class: 'snap-scan-stat' }, [
					h( 'div', { style: 'font-size:28px;font-weight:700;color:#D85A30' }, [ String( res.missing_meta ) ] ),
					h( 'div', { style: 'font-size:12px;color:#6B7280' }, [ 'missing descriptions' ] )
				] ) );
			}
			if ( res.missing_alt > 0 ) {
				stats.push( h( 'div', { class: 'snap-scan-stat' }, [
					h( 'div', { style: 'font-size:28px;font-weight:700;color:#BA7517' }, [ String( res.missing_alt ) ] ),
					h( 'div', { style: 'font-size:12px;color:#6B7280' }, [ 'images without alt text' ] )
				] ) );
			}
			if ( ! res.missing_meta && ! res.missing_alt ) {
				stats.push( h( 'div', { class: 'snap-scan-stat' }, [
					h( 'div', { style: 'font-size:28px;font-weight:700;color:#16A34A' }, [ '✓' ] ),
					h( 'div', { style: 'font-size:12px;color:#6B7280' }, [ 'looking good so far' ] )
				] ) );
			}

			results.appendChild( h( 'div', { style: 'display:flex;gap:24px;justify-content:center;padding:20px 0 24px' }, stats ) );

			// Detected plugin notice
			if ( res.detected_plugin ) {
				var pluginName = res.detected_plugin === 'yoast' ? 'Yoast SEO' : res.detected_plugin === 'rankmath' ? 'Rank Math' : 'All in One SEO';
				results.appendChild( h( 'p', { style: 'font-size:12px;color:#6B7280;margin:0 0 16px;background:#F3F4F6;padding:8px 12px;border-radius:6px' }, [
					'We found ' + pluginName + ' data. We\'ll import it in the next step.'
				] ) );
			}

			// Live fix demo (the magic moment)
			if ( res.sample_post && res.missing_meta > 0 && state.hasKey ) {
				var fixArea = h( 'div', { style: 'text-align:left;background:#F9FAFB;border:1px solid #E5E7EB;border-radius:8px;padding:16px;margin:12px 0' } );
				fixArea.appendChild( h( 'p', { style: 'font-size:13px;font-weight:600;margin:0 0 4px' }, [ '"' + res.sample_post.title + '"' ] ) );
				fixArea.appendChild( h( 'p', { style: 'font-size:12px;color:#6B7280;margin:0 0 12px' }, [ 'This post is missing a meta description. Want AI to write one now?' ] ) );

				var fixStatus = h( 'div', null, [] );
				var fixBtn = h( 'button', { class: 'snap-btn snap-btn-ai snap-btn-sm', onclick: function () {
					fixBtn.disabled = true;
					fixBtn.innerHTML = '<span class="snap-spinner snap-spinner-sm"></span> Writing...';
					apiFetch( {
						path: '/snaplevel/v1/ai/generate',
						method: 'POST',
						data: { task: 'meta_description', post_id: res.sample_post.id, context: {} }
					} ).then( function ( aiRes ) {
						fixBtn.style.display = 'none';
						var desc = aiRes && aiRes.data && aiRes.data.options && aiRes.data.options[ 0 ] ? aiRes.data.options[ 0 ] : '';
						if ( desc ) {
							fixStatus.innerHTML = '';
							fixStatus.appendChild( h( 'div', { style: 'background:#F0FDF4;border:1px solid #BBF7D0;border-radius:6px;padding:10px 12px;margin-top:8px' }, [
								h( 'p', { style: 'font-size:11px;color:#16A34A;font-weight:600;margin:0 0 4px' }, [ '✓ Done. Here\'s the result:' ] ),
								h( 'p', { style: 'font-size:12px;color:#374151;margin:0;line-height:1.5' }, [ desc ] )
							] ) );
						} else {
							fixStatus.appendChild( h( 'p', { style: 'font-size:12px;color:#D85A30' }, [ 'No result returned. Your AI is connected though.' ] ) );
						}
					} ).catch( function () {
						fixBtn.disabled = false;
						fixBtn.textContent = '✦ Try again';
						fixStatus.appendChild( h( 'p', { style: 'font-size:12px;color:#D85A30' }, [ 'Failed. Check your API key.' ] ) );
					} );
				} }, [ '✦ Fix it with AI' ] );

				fixArea.appendChild( fixBtn );
				fixArea.appendChild( fixStatus );
				results.appendChild( fixArea );
			}

			results.appendChild( h( 'div', { style: 'display:flex;gap:12px;justify-content:center;margin-top:20px' }, [
				h( 'button', { class: 'snap-btn snap-btn-secondary', onclick: skip }, [ 'Skip setup' ] ),
				h( 'button', { class: 'snap-btn snap-btn-ai', onclick: function () { go( 1 ); } }, [ 'Continue setup →' ] )
			] ) );

			card.appendChild( results );
		} ).catch( function () {
			var loading = card.querySelector( '.snap-scan-loading' );
			if ( loading ) {
				loading.innerHTML = '';
				loading.appendChild( h( 'p', { class: 'snap-muted' }, [ 'Could not scan. No worries, let\'s continue.' ] ) );
				loading.appendChild( h( 'div', { style: 'display:flex;gap:12px;justify-content:center;margin-top:16px' }, [
					h( 'button', { class: 'snap-btn snap-btn-secondary', onclick: skip }, [ 'Skip setup' ] ),
					h( 'button', { class: 'snap-btn snap-btn-ai', onclick: function () { go( 1 ); } }, [ 'Continue setup →' ] )
				] ) );
			}
		} );

		return card;
	}

	function stepAI() {
		var key = '';

		var input = h( 'input', {
			class: 'snap-input', type: 'password', style: 'max-width:none',
			placeholder: state.hasKey ? 'A key is already saved — leave blank to keep it' : PROVIDERS[ state.provider ].placeholder,
			autocomplete: 'new-password'
		} );
		input.addEventListener( 'input', function () { key = input.value; } );

		var keyLabel = h( 'label', null, [ PROVIDERS[ state.provider ].name + ' API key' ] );
		var keyHelp  = h( 'div', { class: 'snap-help' }, [ 'Get a key at ' + PROVIDERS[ state.provider ].sub ] );

		var pick = h( 'div', { class: 'snap-provider-pick', style: 'max-width:none' }, Object.keys( PROVIDERS ).map( function ( id ) {
			var btn = h( 'button', {
				type: 'button',
				class: state.provider === id ? 'is-selected' : '',
				onclick: function () {
					state.provider = id;
					pick.querySelectorAll( 'button' ).forEach( function ( b ) { b.classList.remove( 'is-selected' ); } );
					btn.classList.add( 'is-selected' );
					keyLabel.textContent = PROVIDERS[ id ].name + ' API key';
					keyHelp.textContent = 'Get a key at ' + PROVIDERS[ id ].sub;
					input.placeholder = PROVIDERS[ id ].placeholder;
				}
			}, [
				PROVIDERS[ id ].name,
				h( 'span', { class: 'snap-provider-sub' }, [ PROVIDERS[ id ].sub ] )
			] );
			return btn;
		} ) );

		var status = h( 'p', { class: 'snap-muted' }, [] );
		var testBtn = h( 'button', { class: 'snap-btn snap-btn-ai', onclick: function () {
			if ( ! key && ! state.hasKey ) { status.textContent = 'Paste your API key first.'; return; }
			testBtn.disabled = true;
			testBtn.innerHTML = '<span class="snap-spinner"></span> Testing connection…';
			apiFetch( { path: '/snaplevel/v1/ai/test', method: 'POST', data: { provider: state.provider, api_key: key } } )
				.then( function ( res ) {
					testBtn.disabled = false;
					testBtn.textContent = '✦ Test connection';
					state.hasKey = true;
					status.innerHTML = '';
					status.appendChild( h( 'span', { class: 'snap-badge snap-badge-green' }, [ '✓ ' + ( res.message || 'Connected' ) ] ) );
				} )
				.catch( function ( err ) {
					testBtn.disabled = false;
					testBtn.textContent = '✦ Test connection';
					status.innerHTML = '';
					status.appendChild( h( 'span', { class: 'snap-badge snap-badge-red' }, [ ( err && err.message ) || 'Connection failed.' ] ) );
				} );
		} }, [ '✦ Test connection' ] );

		return h( 'div', { class: 'snap-card' }, [
			h( 'h2', null, [ 'Connect your AI' ] ),
			h( 'p', null, [ 'Snaplevel writes titles, descriptions, schema, and alt text with AI. Pick your provider — both work with every feature. You bring your own key and pay the provider directly, with full cost visibility inside Snaplevel.' ] ),
			pick,
			h( 'p', { class: 'snap-muted', style: 'font-size:12px' }, [ 'Privacy: post content is sent to your chosen provider only when you press an AI button. Keys are stored encrypted.' ] ),
			h( 'div', { class: 'snap-field' }, [ keyLabel, input, keyHelp ] ),
			testBtn,
			status,
			actions( { nextLabel: state.hasKey ? 'Continue →' : 'Continue without AI →' } )
		] );
	}

	function stepImport() {
		var card = h( 'div', { class: 'snap-card' }, [
			h( 'h2', null, [ 'Import your existing SEO data' ] ),
			h( 'div', { class: 'snap-skeleton', style: 'height:60px' } )
		] );

		apiFetch( { path: '/snaplevel/v1/import/detect' } ).then( function ( res ) {
			card.innerHTML = '';
			card.appendChild( h( 'h2', null, [ 'Import your existing SEO data' ] ) );

			var any = false;
			[ 'yoast', 'rankmath' ].forEach( function ( source ) {
				var info = res[ source ];
				if ( ! info.available ) { return; }
				any = true;
				var status = h( 'p', { class: 'snap-muted' }, [] );
				var btn = h( 'button', { class: 'snap-btn snap-btn-primary snap-btn-sm', onclick: function () {
					btn.disabled = true;
					var imported = 0;
					function step( offset ) {
						apiFetch( { path: '/snaplevel/v1/import/run', method: 'POST', data: { source: source, offset: offset } } )
							.then( function ( r ) {
								imported += r.imported;
								status.textContent = 'Importing… ' + Math.min( r.next_offset, r.total ) + '/' + r.total;
								if ( ! r.done ) { step( r.next_offset ); }
								else {
									status.innerHTML = '';
									status.appendChild( h( 'span', { class: 'snap-badge snap-badge-green' }, [ '✓ Imported ' + imported + ' posts' ] ) );
								}
							} )
							.catch( function () { btn.disabled = false; status.textContent = 'Import failed — retry from Tools later.'; } );
					}
					step( 0 );
				} }, [ 'Import from ' + info.name ] );

				card.appendChild( h( 'div', { style: 'display:flex;align-items:center;gap:12px;margin:12px 0' }, [
					btn,
					h( 'span', { class: 'snap-muted' }, [ String( info.posts ) + ' posts found' ] )
				] ) );
				card.appendChild( status );
			} );

			if ( ! any ) {
				card.appendChild( h( 'p', { class: 'snap-muted' }, [ 'No Yoast or Rank Math data found. Nothing to import — you are starting clean.' ] ) );
			}

			card.appendChild( actions() );
		} ).catch( function () {
			card.appendChild( h( 'p', { class: 'snap-notice snap-notice-error' }, [ 'Could not check for importable data.' ] ) );
			card.appendChild( actions() );
		} );

		return card;
	}

	function stepSiteType() {
		var types = [
			{ id: 'blog', icon: '📝', label: 'Blog', desc: 'Articles and content' },
			{ id: 'business', icon: '🏢', label: 'Business', desc: 'Services and pages' },
			{ id: 'shop', icon: '🛒', label: 'Shop', desc: 'WooCommerce store' }
		];
		var grid = h( 'div', { class: 'snap-site-type' }, types.map( function ( t ) {
			var btn = h( 'button', {
				class: state.siteType === t.id ? 'is-selected' : '',
				onclick: function () {
					state.siteType = t.id;
					grid.querySelectorAll( 'button' ).forEach( function ( b ) { b.classList.remove( 'is-selected' ); } );
					btn.classList.add( 'is-selected' );
				}
			}, [
				h( 'div', { style: 'font-size:20px;margin-bottom:4px' }, [ t.icon ] ),
				h( 'div', null, [ t.label ] ),
				h( 'div', { class: 'snap-muted', style: 'font-weight:400;font-size:12px' }, [ t.desc ] )
			] );
			return btn;
		} ) );

		var biz = { name: '', owner: '', tagline: '', purpose: '' };
		function bizField( label, key, placeholder, rows ) {
			var input = rows
				? h( 'textarea', { class: 'snap-textarea', rows: String( rows ), placeholder: placeholder } )
				: h( 'input', { class: 'snap-input', type: 'text', placeholder: placeholder, style: 'max-width:none' } );
			input.addEventListener( 'input', function () { biz[ key ] = input.value; } );
			return h( 'div', { class: 'snap-field' }, [ h( 'label', null, [ label ] ), input ] );
		}

		var bizBox = h( 'div', { style: 'margin-top:20px;padding-top:20px;border-top:1px solid var(--snap-border-light)' }, [
			h( 'h2', { style: 'font-size:1.1em' }, [ 'Tell the AI about this site' ] ),
			h( 'p', { class: 'snap-muted', style: 'margin-top:0' }, [ 'Used for schema, titles, descriptions and every AI generation. All optional, all editable later.' ] ),
			h( 'div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:14px' }, [
				bizField( 'Business / site name', 'name', 'e.g. AutoGenCRM' ),
				bizField( 'Owner / author name', 'owner', 'e.g. Muhammad Waseem' )
			] ),
			bizField( 'Tagline', 'tagline', 'One line that says what you do' ),
			bizField( 'Purpose & audience', 'purpose', 'What does this site sell or teach? Who is it for? What makes it different?', 3 )
		] );

		return h( 'div', { class: 'snap-card' }, [
			h( 'h2', null, [ 'What kind of site is this?' ] ),
			h( 'p', { class: 'snap-muted' }, [ 'This sets sensible meta and schema defaults. You can change everything later.' ] ),
			grid,
			bizBox,
			actions( { onNext: function () {
				var payload = { business: biz };
				if ( state.siteType ) { payload.site_type = state.siteType; }
				if ( biz.name ) { payload.schema = { site_type: state.siteType === 'blog' ? 'person' : 'organization', name: biz.name }; }
				apiFetch( { path: '/snaplevel/v1/settings', method: 'POST', data: payload } ).catch( function () {} );

				var doc = [];
				if ( biz.name ) { doc.push( 'Business name: ' + biz.name ); }
				if ( biz.owner ) { doc.push( 'Owner: ' + biz.owner ); }
				if ( biz.tagline ) { doc.push( 'Tagline: ' + biz.tagline ); }
				if ( biz.purpose ) { doc.push( 'Purpose & audience: ' + biz.purpose ); }
				if ( state.siteType ) { doc.push( 'Site type: ' + state.siteType ); }
				if ( doc.length ) {
					apiFetch( { path: '/snaplevel/v1/training', method: 'POST', data: { id: 0, title: 'Business profile', content: doc.join( '\n' ) } } ).catch( function () {} );
				}
				go( state.step + 1 );
			} } )
		] );
	}

	function stepTrain() {
		var content = '';
		var area = h( 'textarea', { class: 'snap-textarea', rows: '8', placeholder: 'Who are you? What do you sell? Who are your customers? What tone do you write in? Paste anything — website copy, brochures, product lists, FAQs…' } );
		area.addEventListener( 'input', function () { content = area.value; } );
		var status = h( 'p', { class: 'snap-muted' }, [] );

		return h( 'div', { class: 'snap-card' }, [
			h( 'h2', null, [ 'Train the AI on your business' ] ),
			h( 'p', null, [ 'This is what makes Snaplevel different. Everything you paste here is used in every AI generation, so titles, descriptions, and schema sound like your business — not generic AI. You can add up to 100,000 words later in the AI Training screen.' ] ),
			h( 'div', { class: 'snap-field' }, [ area ] ),
			status,
			actions( { onNext: function () {
				if ( content.trim() ) {
					status.textContent = 'Saving…';
					apiFetch( { path: '/snaplevel/v1/training', method: 'POST', data: { id: 0, title: 'About this business', content: content } } )
						.then( function () { go( state.step + 1 ); } )
						.catch( function ( err ) { status.textContent = ( err && err.message ) || 'Save failed.'; } );
				} else {
					go( state.step + 1 );
				}
			}, nextLabel: 'Save & continue →' } )
		] );
	}

	function stepDone() {
		return h( 'div', { class: 'snap-card', style: 'text-align:center' }, [
			h( 'h1', null, [ '🎉 You are set' ] ),
			h( 'p', { style: 'max-width:440px;margin:0 auto' }, [
				'Snaplevel is configured. Open any post to see the SEO sidebar with one-click AI for the title, description, keywords, and schema — or hit "Fix with AI" and review the result.'
			] ),
			h( 'div', { style: 'display:flex;gap:12px;justify-content:center;margin-top:24px' }, [
				h( 'button', { class: 'snap-btn snap-btn-secondary', onclick: function () { persist( { done: true } ); window.location.href = SNAP.adminUrl + 'admin.php?page=snap-training'; } }, [ 'Add more AI training' ] ),
				h( 'button', { class: 'snap-btn snap-btn-ai', onclick: finish }, [ 'Go to dashboard →' ] )
			] )
		] );
	}

	// ── Render ───────────────────────────────────────────────────────────────

	function render() {
		root.innerHTML = '';
		var wrap = h( 'div', { class: 'snap-wizard' } );
		wrap.appendChild( stepsBar() );
		switch ( STEPS[ state.step ].id ) {
			case 'ai': wrap.appendChild( stepAI() ); break;
			case 'import': wrap.appendChild( stepImport() ); break;
			case 'sitetype': wrap.appendChild( stepSiteType() ); break;
			case 'train': wrap.appendChild( stepTrain() ); break;
			case 'done': wrap.appendChild( stepDone() ); break;
			default: wrap.appendChild( stepWelcome() );
		}
		root.appendChild( wrap );
	}

	apiFetch( { path: '/snaplevel/v1/wizard' } ).then( function ( res ) {
		if ( res && res.wizard && ! res.wizard.done ) {
			state.step = Math.min( parseInt( res.wizard.step, 10 ) || 0, STEPS.length - 1 );
		}
		state.hasKey = !! res.hasKey;
		state.provider = PROVIDERS[ res.provider ] ? res.provider : 'anthropic';
		state.siteType = res.site_type || '';
		render();
	} ).catch( render );
} )();
