/**
 * Snaplevel — Redirections admin view.
 * Requires: window.SNAP_REDIRECTIONS localized config.
 */
( function () {
	'use strict';
	var CFG       = window.SNAP_REDIRECTIONS || {};
	var nonce     = CFG.nonce || '';
	var ajaxurl   = CFG.ajaxurl || '';
	var restUrl   = CFG.restUrl || '';
	var restNonce = CFG.restNonce || '';

	function post( action, data ) {
		var body = new FormData();
		body.append( 'action', action );
		body.append( 'nonce', nonce );
		Object.keys( data || {} ).forEach( function ( k ) { body.append( k, data[ k ] ); } );
		return window.fetch( ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' } )
			.then( function ( r ) { return r.json(); } )
			.then( function ( j ) { if ( ! j.success ) { throw new Error( j.data || 'Request failed.' ); } return j.data; } );
	}

	// Tabs.
	document.querySelectorAll( '[data-rtab]' ).forEach( function ( tab ) {
		tab.addEventListener( 'click', function () {
			document.querySelectorAll( '[data-rtab]' ).forEach( function ( t ) { t.classList.remove( 'is-active' ); } );
			tab.classList.add( 'is-active' );
			document.querySelectorAll( '[data-rtab-panel]' ).forEach( function ( p ) {
				p.style.display = p.dataset.rtabPanel === tab.dataset.rtab ? '' : 'none';
			} );
		} );
	} );

	// Add redirect.
	var addBtn = document.getElementById( 'snap-r-add' );
	if ( addBtn ) {
		addBtn.addEventListener( 'click', function () {
			var msg = document.getElementById( 'snap-r-msg' );
			msg.textContent = '';
			addBtn.disabled = true;
			post( 'snap_redirect_save', {
				source:   document.getElementById( 'snap-r-source' ).value,
				target:   document.getElementById( 'snap-r-target' ).value,
				type:     document.getElementById( 'snap-r-type' ).value,
				is_regex: document.getElementById( 'snap-r-regex' ).checked ? 1 : ''
			} ).then( function () {
				window.location.reload();
			} ).catch( function ( err ) {
				addBtn.disabled = false;
				msg.textContent = err.message;
				msg.style.color = '#B91C1C';
			} );
		} );
	}

	// Delete.
	document.querySelectorAll( '.snap-r-del' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			if ( ! window.confirm( CFG.i18n.confirmDelete ) ) { return; }
			post( 'snap_redirect_delete', { id: btn.dataset.id } ).then( function () {
				var row = btn.closest( 'tr' );
				if ( row ) { row.remove(); }
			} ).catch( function ( err ) { window.alert( err.message ); } );
		} );
	} );

	// URL tester.
	var testerBtn = document.getElementById( 'snap-r-tester-btn' );
	if ( testerBtn ) {
		testerBtn.addEventListener( 'click', function () {
			var box = document.getElementById( 'snap-r-tester' );
			box.style.display = box.style.display === 'none' ? '' : 'none';
		} );
		document.getElementById( 'snap-r-tester-run' ).addEventListener( 'click', function () {
			var out = document.getElementById( 'snap-r-tester-result' );
			out.textContent = '…';
			post( 'snap_redirect_test', { url: document.getElementById( 'snap-r-tester-url' ).value } ).then( function ( d ) {
				if ( d.matched ) {
					out.textContent = '✓ ' + d.path + ' → ' + ( d.target || '(' + d.type + ')' ) + '  [' + d.type + ( d.regex ? ', regex' : '' ) + ']';
					out.style.color = '#15803D';
				} else {
					out.textContent = CFG.i18n.noMatch + ': ' + d.path;
					out.style.color = '';
				}
			} ).catch( function ( err ) { out.textContent = err.message; } );
		} );
	}

	// 404 monitor actions.
	document.querySelectorAll( '.snap-404-redirect' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var target = window.prompt( CFG.i18n.redirectTo, '/' );
			if ( null === target || '' === target.trim() ) { return; }
			post( 'snap_redirect_save', { source: btn.dataset.url, target: target.trim(), type: 301, from_404: 1 } )
				.then( function () { window.location.reload(); } )
				.catch( function ( err ) { window.alert( err.message ); } );
		} );
	} );
	document.querySelectorAll( '.snap-404-dismiss' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			post( 'snap_404_dismiss', { id: btn.dataset.id } ).then( function () {
				var row = btn.closest( 'tr' );
				if ( row ) { row.remove(); }
			} );
		} );
	} );
	var clearBtn = document.getElementById( 'snap-404-clear' );
	if ( clearBtn ) {
		clearBtn.addEventListener( 'click', function () {
			if ( ! window.confirm( CFG.i18n.confirmClear ) ) { return; }
			post( 'snap_404_clear', {} ).then( function () { window.location.reload(); } );
		} );
	}

	// Auto-redirect deleted posts toggle.
	var autoCb = document.getElementById( 'snap-auto-deleted' );
	if ( autoCb ) {
		autoCb.addEventListener( 'change', function () {
			window.fetch( restUrl + '/settings', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': restNonce },
				body: JSON.stringify( { redirections: { auto_deleted: autoCb.checked } } )
			} );
		} );
	}
} )();
