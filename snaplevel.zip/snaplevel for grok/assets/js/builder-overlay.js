/**
 * Snaplevel Builder Integration — native top-bar / toolbar icon only.
 * Single branded icon (using original plugin icon) injected into Elementor header and Bricks toolbar.
 * Live status dot + tooltip from real post meta.
 * Opens the premium docked side panel (Snaplevel popup with full metabox + AI tools).
 * No floating buttons anywhere. Pure Snaplevel branding.
 */
( function ( $ ) {
	'use strict';

	var CFG = window.SNAP_BUILDER_OVERLAY || {};
	var popupUrl = CFG.popupUrl || '';
	var postId = CFG.postId || 0;
	var wpRest = CFG.restUrl || '/wp-json/wp/v2/posts/';
	var nonce = CFG.nonce || '';

	// Standalone panel open/close (no dependency on any floating btn)
	var overlay, frame, closeBtn, wrap;

	function initPanelElements() {
		overlay  = document.getElementById( 'snap-el-overlay' );
		frame    = document.getElementById( 'snap-el-frame' );
		closeBtn = document.getElementById( 'snap-el-close' );
		wrap     = document.getElementById( 'snap-el-frame-wrap' );
		if ( ! overlay || ! frame || ! closeBtn || ! wrap ) return false;

		closeBtn.addEventListener( 'click', closePanel );
		overlay.addEventListener( 'click', function ( e ) {
			if ( e.target === overlay || e.target === wrap ) closePanel();
		} );
		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && overlay.classList.contains( 'is-open' ) ) closePanel();
		} );
		return true;
	}

	function openPanel() {
		if ( ! initPanelElements() ) return;
		if ( ! frame.src && popupUrl ) { frame.src = popupUrl; }
		overlay.classList.add( 'is-open' );
		setTimeout( function () { try { frame.focus(); } catch (e) {} }, 180 );
	}

	function closePanel() {
		if ( overlay ) overlay.classList.remove( 'is-open' );
	}

	// --- Native injection + tooltip + status (branded Snaplevel only) ---
	var tooltipCleanup = null;

	function createSnapTooltip( targetEl, text ) {
		if ( ! targetEl || ! text ) return null;
		var wrapper = document.createElement( 'div' );
		wrapper.className = 'snap-builder-root';
		var tip = document.createElement( 'div' );
		tip.className = 'snap-builder-tooltip';
		tip.textContent = text;
		var arrow = document.createElement( 'div' );
		arrow.className = 'snap-builder-tooltip-arrow';
		tip.appendChild( arrow );
		wrapper.appendChild( tip );
		document.body.appendChild( wrapper );

		function position() {
			var r = targetEl.getBoundingClientRect();
			tip.style.top = ( r.bottom + 10 ) + 'px';
			tip.style.left = ( r.left + r.width / 2 ) + 'px';
		}
		function show() { position(); tip.style.opacity = '1'; tip.style.visibility = 'visible'; }
		function hide() { tip.style.opacity = '0'; setTimeout( function () { tip.style.visibility = 'hidden'; }, 120 ); }

		var tShow, tHide;
		targetEl.addEventListener( 'mouseenter', function () { clearTimeout( tHide ); tShow = setTimeout( show, 160 ); } );
		targetEl.addEventListener( 'mouseleave', function () { clearTimeout( tShow ); tHide = setTimeout( hide, 80 ); } );
		targetEl.addEventListener( 'focus', show );
		targetEl.addEventListener( 'blur', hide );

		return function cleanup() {
			clearTimeout( tShow ); clearTimeout( tHide );
			if ( wrapper.parentNode ) wrapper.parentNode.removeChild( wrapper );
		};
	}

	function getStatusFromMeta( meta ) {
		var title = ( meta && meta._snap_title ) ? String( meta._snap_title ).trim() : '';
		var desc = ( meta && meta._snap_desc ) ? String( meta._snap_desc ).trim() : '';
		var kw = ( meta && meta._snap_focus_kw ) ? String( meta._snap_focus_kw ).trim() : '';
		var issues = 0;
		if ( ! title ) issues++;
		if ( ! desc ) issues++;
		if ( ! kw ) issues++;
		var suggestions = 3 - issues; // rough
		if ( issues === 0 ) return { status: 'good', label: 'Perfect — title + desc + keyword set. ' + suggestions + ' AI improvements available' };
		if ( issues === 1 ) return { status: 'ok', label: issues + ' issue • ' + suggestions + ' AI suggestions ready' };
		return { status: 'bad', label: issues + ' issues • Copilot has quick fixes ready' };
	}

	function fetchStatusAndUpdate( indicator, btnForTooltip ) {
		if ( ! postId ) return;
		// Use WP REST to read the snap meta fields (registered show_in_rest)
		fetch( wpRest + postId + '?_fields=meta', { headers: { 'X-WP-Nonce': nonce } } )
			.then( function ( r ) { return r.ok ? r.json() : null; } )
			.then( function ( data ) {
				if ( ! data || ! data.meta ) return;
				var s = getStatusFromMeta( data.meta );
				if ( indicator ) {
					indicator.className = 'snap-status-dot snap-status-' + s.status;
					indicator.title = s.label;
				}
				if ( btnForTooltip && tooltipCleanup ) { tooltipCleanup(); tooltipCleanup = null; }
				if ( btnForTooltip ) {
					tooltipCleanup = createSnapTooltip( btnForTooltip, s.label );
				}
			} )
			.catch( function () {} );
	}

	function createStatusDot() {
		var dot = document.createElement( 'span' );
		dot.className = 'snap-status-dot snap-status-ok';
		dot.style.cssText = 'position:absolute;top:2px;right:2px;width:7px;height:7px;border-radius:50%;border:1px solid #fff;';
		return dot;
	}

	function injectElementorNative() {
		// Target Elementor v2 top bar (and fallbacks). Single icon only.
		// Clean any previous to guarantee exactly 1
		$( '.snap-builder-el-btn' ).remove();

		var $top = $( '#elementor-editor-wrapper-v2 header .MuiGrid-root:nth-child(3) .MuiStack-root, #elementor-panel-header, .elementor-editor-header' );
		if ( ! $top.length ) {
			setTimeout( injectElementorNative, 800 );
			return;
		}
		if ( $( '.snap-builder-el-btn' ).length ) return;

		var $wrap = $( '<div class="snap-builder-root snap-builder-el-btn" style="position:relative;display:inline-flex;margin:0 4px;"></div>' );
		var $btn = $( '<button type="button" class="snap-builder-btn" aria-label="Snaplevel SEO" style="all:unset;display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:6px;cursor:pointer;color:#1a73e8;background:transparent;"></button>' );

		// Use original plugin icon (scaled from assets/images/icon.svg, colored for toolbar)
		$btn.html( '<svg width="16" height="16" viewBox="0 0 256 256"><rect width="256" height="256" rx="56" fill="currentColor"/><g transform="translate(33 33) scale(6.24)"><path fill="#fff" d="M16.109,13.997l-4.312-4.479L1.426,20.058L0,18.656L11.812,6.651l4.354,4.522l7.49-7.172l-2.146-2.145h5.603v5.601 L25.07,5.415L16.109,13.997z M4.962,28.606h6.75v-9.5h-6.75V28.606z M14.337,28.606h6.75v-12.5h-6.75V28.606z M23.712,9.856v18.75 h6.75V9.856H23.712z"/></g></svg>' );

		var dot = createStatusDot();
		$wrap.append( $btn );
		$wrap.append( dot );

		var $first = $top.children().first();
		if ( $first.length ) $first.after( $wrap );
		else $top.append( $wrap );

		$btn.on( 'click', function () {
			openPanel(); // direct, no floating btn dependency
		} );

		fetchStatusAndUpdate( dot, $btn[ 0 ] );

		if ( window.wp && wp.data && wp.data.subscribe ) {
			wp.data.subscribe( function () { fetchStatusAndUpdate( dot, $btn[ 0 ] ); } );
		} else {
			setTimeout( function () { fetchStatusAndUpdate( dot, $btn[ 0 ] ); }, 2200 );
		}
	}

	function injectBricksNative() {
		var toolbar = $( '#bricks-toolbar .right, #bricks-toolbar .end, .bricks-toolbar .right' );
		if ( ! toolbar.length ) {
			setTimeout( injectBricksNative, 700 );
			return;
		}
		// Clean any previous
		$( '.snap-builder-el-btn, #snap-bricks-toolbar-btn' ).remove();
		if ( $( '#snap-bricks-toolbar-btn' ).length || $( '.snap-builder-el-btn' ).length ) return;

		var $li = $( '<li id="snap-bricks-toolbar-btn" class="snap-builder-root snap-builder-el-btn" style="display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;position:relative;cursor:pointer;" title="Snaplevel SEO"></li>' );

		// Original plugin icon for consistency (single icon on toolbar)
		$li.html( '<span style="display:inline-flex;color:#1a73e8;"><svg width="16" height="16" viewBox="0 0 256 256"><rect width="256" height="256" rx="56" fill="currentColor"/><g transform="translate(33 33) scale(6.24)"><path fill="#fff" d="M16.109,13.997l-4.312-4.479L1.426,20.058L0,18.656L11.812,6.651l4.354,4.522l7.49-7.172l-2.146-2.145h5.603v5.601 L25.07,5.415L16.109,13.997z M4.962,28.606h6.75v-9.5h-6.75V28.606z M14.337,28.606h6.75v-12.5h-6.75V28.606z M23.712,9.856v18.75 h6.75V9.856H23.712z"/></g></svg></span>' );

		var dot = createStatusDot();
		$li.append( dot );

		var insertion = toolbar.children().eq( 2 );
		if ( insertion.length ) insertion.after( $li );
		else toolbar.append( $li );

		$li.on( 'click', function () {
			openPanel(); // direct open
		} );

		fetchStatusAndUpdate( dot, $li[ 0 ] );
	}

	// Bootstrap: native injections only (no floating)
	$( function () {
		// Pre-init panel elements so open works immediately
		initPanelElements();

		// Elementor native header button (the only icon)
		if ( document.getElementById( 'elementor-editor-wrapper-v2' ) || window.elementor ) {
			injectElementorNative();
		}
		// Bricks native toolbar (the only icon)
		if ( document.getElementById( 'bricks-toolbar' ) || ( window.bricks && window.bricks.isBuilder ) ) {
			injectBricksNative();
		}

		// Safety retry for late Elementor DOM
		setTimeout( function () {
			if ( document.getElementById( 'elementor-editor-wrapper-v2' ) && ! $( '.snap-builder-el-btn' ).length ) injectElementorNative();
		}, 1400 );
	} );

} )( jQuery );
