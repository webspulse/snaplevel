/**
 * Snaplevel — Image SEO settings toggles.
 * Requires: window.SNAP_IMAGE_SEO localized config.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var cfg = window.SNAP_IMAGE_SEO || {};
		if ( ! cfg.restUrl || ! cfg.nonce ) {
			return;
		}

		document.querySelectorAll( '.snap-imgseo-toggle' ).forEach( function ( cb ) {
			cb.addEventListener( 'change', function () {
				var payload = { image_seo: {} };
				payload.image_seo[ cb.dataset.key ] = cb.checked;
				window.fetch( cfg.restUrl + '/settings', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': cfg.nonce
					},
					body: JSON.stringify( payload )
				} ).then( function () {
					var msg = document.getElementById( 'snap-imgseo-msg' );
					if ( msg ) {
						msg.textContent = cfg.i18n.saved || '';
					}
				} );
			} );
		} );
	} );
} )();