/**
 * Snaplevel — Gutenberg editor sidebar.
 *
 * Copilot (AI opportunities + one-click fixes) is PRIMARY HERO at top.
 * Score pill and traditional checklist are SECONDARY / collapsed.
 * Calm AI-assistant design: opportunity cards first, not Rank Math score/checklist clone.
 * Traditional signals in optional accordion only.
 */
/* global wp, SNAP_SIDEBAR */
( function () {
	'use strict';

	if ( ! window.wp || ! wp.plugins || ! wp.element ) {
		return;
	}

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useState = wp.element.useState;
	var registerPlugin = wp.plugins.registerPlugin;
	var editPost = wp.editPost || {};
	var PluginSidebar = editPost.PluginSidebar || ( wp.editor && wp.editor.PluginSidebar );
	var PluginSidebarMoreMenuItem = editPost.PluginSidebarMoreMenuItem || ( wp.editor && wp.editor.PluginSidebarMoreMenuItem );
	var useSelect = wp.data.useSelect;
	var useDispatch = wp.data.useDispatch;
	var apiFetch = wp.apiFetch;
	var components = wp.components;
	var PanelBody = components.PanelBody;
	var TextControl = components.TextControl;
	var TextareaControl = components.TextareaControl;
	var SelectControl = components.SelectControl;
	var CheckboxControl = components.CheckboxControl;
	var Button = components.Button;
	var Spinner = components.Spinner;
	var __ = wp.i18n.__;

	var CFG = window.SNAP_SIDEBAR || {};

	// Spec colors (traffic-light system).
	var COLOR = {
		primary: '#1a73e8',  // Google 2026 blue to match design-system
		good: '#1e8e3e',
		ok: '#f9ab00',
		bad: '#d93025',
		secondary: '#5f6368'
	};

	if ( ! PluginSidebar ) {
		return;
	}

	// ── Helpers ──────────────────────────────────────────────────────────────

	function stripTags( html ) {
		var div = document.createElement( 'div' );
		div.innerHTML = html || '';
		return div.textContent || '';
	}

	function countWords( text ) {
		var m = ( text || '' ).trim().match( /\S+/g );
		return m ? m.length : 0;
	}

	function hasKw( text, kw ) {
		if ( ! kw ) { return false; }
		return ( text || '' ).toLowerCase().indexOf( kw.toLowerCase() ) !== -1;
	}

	function generate( task, postId, keyword ) {
		return apiFetch( {
			path: '/snaplevel/v1/ai/generate',
			method: 'POST',
			data: { task: task, post_id: postId, context: { focus_keyword: keyword || '' } }
		} );
	}

	/** Spec thresholds: 0–50 bad, 51–80 ok, 81–100 good. */
	function scoreState( score ) {
		if ( score >= 81 ) { return 'good'; }
		if ( score >= 51 ) { return 'ok'; }
		return 'bad';
	}

	// ── Deterministic checks (free, instant, no tokens) — now secondary / optional ──────────────────────

	function runChecks( data ) {
		var kw = ( data.keyword || '' ).trim();
		var text = stripTags( data.content );
		var words = countWords( text );
		var titleText = data.seoTitle || data.postTitle || '';
		var checks = [];

		function add( group, id, pass, label, hint ) {
			checks.push( { group: group, id: id, pass: !! pass, label: label, hint: hint || '' } );
		}

		add( 'basic', 'kw_set', kw.length > 0, __( 'Focus keyword is set', 'snaplevel' ) );
		add( 'basic', 'kw_title', hasKw( titleText, kw ), __( 'Keyword in SEO title', 'snaplevel' ) );
		add( 'basic', 'kw_desc', hasKw( data.seoDesc, kw ), __( 'Keyword in meta description', 'snaplevel' ) );
		add( 'basic', 'kw_intro', hasKw( text.slice( 0, Math.max( 300, text.length * 0.1 ) ), kw ), __( 'Keyword in the first paragraph', 'snaplevel' ) );
		add( 'basic', 'content_length', words >= 600, __( 'Content is 600+ words', 'snaplevel' ), words + ' ' + __( 'words', 'snaplevel' ) );
		add( 'basic', 'desc_length', ( data.seoDesc || '' ).length >= 120 && ( data.seoDesc || '' ).length <= 156,
			__( 'Meta description 120–156 characters', 'snaplevel' ), ( data.seoDesc || '' ).length + ' ' + __( 'chars', 'snaplevel' ) );

		add( 'additional', 'kw_url', hasKw( ( data.slug || '' ).replace( /-/g, ' ' ), kw ), __( 'Keyword in URL', 'snaplevel' ) );
		var density = 0;
		if ( kw && words > 0 ) {
			var occurrences = ( text.toLowerCase().split( kw.toLowerCase() ).length - 1 );
			density = ( occurrences * countWords( kw ) / words ) * 100;
		}
		add( 'additional', 'kw_density', density >= 0.5 && density <= 2.5, __( 'Keyword density 0.5–2.5%', 'snaplevel' ), density ? density.toFixed( 1 ) + '%' : '' );
		add( 'additional', 'links', /<a[^>]+href=["'][^"']*/i.test( data.content || '' ), __( 'Post contains links', 'snaplevel' ) );
		var imgs = ( data.content || '' ).match( /<img[^>]*>/gi ) || [];
		var imgsWithAlt = imgs.filter( function ( i ) { return /alt=["'][^"']+["']/i.test( i ); } );
		add( 'additional', 'img_alt', imgs.length === 0 || imgsWithAlt.length === imgs.length,
			__( 'All images have alt text', 'snaplevel' ), imgs.length ? imgsWithAlt.length + '/' + imgs.length : __( 'no images', 'snaplevel' ) );
		add( 'additional', 'schema', !! data.schema, __( 'Schema markup present', 'snaplevel' ) );

		add( 'title', 'title_length', titleText.length > 0 && titleText.length <= 60,
			__( 'SEO title under 60 characters', 'snaplevel' ), titleText.length + ' ' + __( 'chars', 'snaplevel' ) );
		add( 'title', 'kw_start', kw && titleText.toLowerCase().indexOf( kw.toLowerCase() ) !== -1 &&
			titleText.toLowerCase().indexOf( kw.toLowerCase() ) <= Math.floor( titleText.length / 2 ),
			__( 'Keyword near the start of the title', 'snaplevel' ) );

		var paragraphs = ( data.content || '' ).split( /<\/p>/i ).length - 1;
		var headings = ( ( data.content || '' ).match( /<h[2-4][^>]*>/gi ) || [] ).length;
		add( 'readability', 'subheadings', words < 300 || headings > 0, __( 'Uses subheadings', 'snaplevel' ) );
		add( 'readability', 'paragraphs', paragraphs === 0 || ( words / Math.max( paragraphs, 1 ) ) < 150, __( 'Paragraphs are short', 'snaplevel' ) );

		var passed = checks.filter( function ( c ) { return c.pass; } ).length;
		var score = checks.length ? Math.round( ( passed / checks.length ) * 100 ) : 0;

		return { checks: checks, score: score };
	}

	// ── Small components ─────────────────────────────────────────────────────

	/** Score pill — secondary / details only. Copilot opportunities are the hero experience. */
	function ScorePill( props ) {
		return el( 'span', { 
			className: 'snap-score-pill is-' + scoreState( props.score ),
			style: { fontSize: '10px', opacity: 0.5, cursor: 'pointer', height: '26px', alignSelf: 'center' },
			title: 'Traditional signals (optional details). Copilot opportunities are the primary view above.'
		}, props.score + ' / 100' );
	}

	function aiBtnStyle() {
		return {
			width: '100%', justifyContent: 'center', marginBottom: '10px',
			background: COLOR.primary, color: '#fff',
			borderRadius: '3px', border: 0, fontWeight: 600,
			transition: 'all .3s ease-in-out'
		};
	}

	function OptionsList( props ) {
		if ( ! props.options ) { return null; }
		return el( 'div', { style: { marginBottom: '10px' } }, props.options.map( function ( opt, i ) {
			return el( 'button', {
				key: i, type: 'button', className: 'snap-ai-option',
				onClick: function () { props.onPick( opt ); }
			}, opt );
		} ) );
	}

	/** Generic AI button that fetches options and lets the user pick one. */
	function AIGenerate( props ) {
		var s = useState( { busy: false, options: null, error: '' } );
		var st = s[ 0 ]; var set = s[ 1 ];

		if ( ! CFG.canUseAI ) { return null; }
		if ( ! CFG.hasKey ) {
			return el( 'p', { style: { fontSize: '11px', color: COLOR.secondary, margin: '2px 0 10px' } },
				__( 'Connect AI in Snaplevel → Settings to enable AI.', 'snaplevel' ) );
		}

		function run() {
			set( { busy: true, options: null, error: '' } );
			generate( props.task, props.postId, props.keyword ).then( function ( res ) {
				var opts = props.extract( res );
				if ( opts && opts.length === 1 ) {
					props.onPick( opts[ 0 ] );
					set( { busy: false, options: null, error: '' } );
					return;
				}
				set( { busy: false, options: opts, error: opts ? '' : __( 'Nothing returned. Try again.', 'snaplevel' ) } );
			} ).catch( function ( err ) {
				set( { busy: false, options: null, error: ( err && err.message ) || __( 'AI request failed.', 'snaplevel' ) } );
			} );
		}

		return el( 'div', null,
			el( Button, { style: aiBtnStyle(), disabled: st.busy, onClick: run },
				st.busy ? el( Fragment, null, el( Spinner, null ), ' ', __( 'Generating…', 'snaplevel' ) ) : '✦ ' + props.label ),
			st.error ? el( 'p', { style: { color: COLOR.bad, fontSize: '11px' } }, st.error ) : null,
			el( OptionsList, { options: st.options, onPick: function ( v ) { props.onPick( v ); set( { busy: false, options: null, error: '' } ); } } )
		);
	}

	/** Google-exact SERP preview (spec 6.7 + 3.6): Arial, #1a0dab, 600px. */
	function SnippetPreview( props ) {
		var title = props.seoTitle || props.postTitle || '';
		title = title.replace( /%title%/g, props.postTitle ).replace( /%sitename%/g, CFG.siteName || '' ).replace( /%sep%/g, CFG.separator || '–' );
		var url = ( CFG.siteUrl || '' ).replace( /\/$/, '' ) + '/' + ( props.slug || '' );
		var desc = props.seoDesc || stripTags( props.content ).slice( 0, 156 );
		return el( 'div', { className: 'snap-serp' },
			el( 'div', { className: 'snap-serp-url' }, url ),
			el( 'div', { className: 'snap-serp-title' }, title ),
			el( 'div', { className: 'snap-serp-desc' }, desc )
		);
	}

	/** Grouped accordion checks with green check / red cross bullets. */
	function CheckList( props ) {
		var groups = {
			basic: __( 'Basic SEO', 'snaplevel' ),
			additional: __( 'Additional', 'snaplevel' ),
			title: __( 'Title Readability', 'snaplevel' ),
			readability: __( 'Content Readability', 'snaplevel' )
		};
		return el( Fragment, null, Object.keys( groups ).map( function ( g ) {
			var items = props.checks.filter( function ( c ) { return c.group === g; } );
			if ( ! items.length ) { return null; }
			var passed = items.filter( function ( c ) { return c.pass; } ).length;
			return el( PanelBody, {
				key: g,
				title: groups[ g ] + ' (' + passed + '/' + items.length + ')',
				initialOpen: false
			},
				items.map( function ( c ) {
					return el( 'div', { key: c.id, style: { display: 'flex', gap: '8px', alignItems: 'baseline', marginBottom: '7px' } },
						el( 'span', { style: { color: c.pass ? COLOR.good : COLOR.bad, fontWeight: 700 } }, c.pass ? '✓' : '✕' ),
						el( 'span', { style: { fontSize: '12px' } },
							c.label, c.hint ? el( 'span', { style: { color: COLOR.secondary } }, ' — ' + c.hint ) : null )
					);
				} )
			);
		} ) );
	}

	// ── Tabs (General / Schema / Advanced, spec 7.5) ─────────────────────────

	function Tabs( props ) {
		var tabs = [
			{ id: 'general', label: __( 'General', 'snaplevel' ) },
			{ id: 'social', label: __( 'Social', 'snaplevel' ) },
			{ id: 'schema', label: __( 'Schema', 'snaplevel' ) },
			{ id: 'advanced', label: __( 'Advanced', 'snaplevel' ) }
		];
		return el( 'div', { style: { display: 'flex', borderBottom: '1px solid #b5bfc9', margin: '0 0 14px' } },
			tabs.map( function ( t ) {
				var active = props.tab === t.id;
				return el( 'button', {
					key: t.id, type: 'button',
					onClick: function () { props.setTab( t.id ); },
					style: {
						flex: 1, height: '47px', padding: '0 6px', background: 'none', cursor: 'pointer',
						border: 0, borderBottom: active ? '2px solid ' + COLOR.primary : '2px solid transparent',
						color: active ? COLOR.primary : '#5b6065', fontWeight: 600, fontSize: '12px',
						transition: 'all .3s ease-in-out'
					}
				}, t.label );
			} )
		);
	}

	// ── Schema tab ───────────────────────────────────────────────────────────

	function SchemaTab( props ) {
		var s = useState( { busy: false, error: '' } );
		var st = s[ 0 ]; var set = s[ 1 ];

		var parsed = null;
		if ( props.schema ) {
			try { parsed = JSON.parse( props.schema ); } catch ( e ) { parsed = null; }
		}

		function run() {
			set( { busy: true, error: '' } );
			generate( 'schema', props.postId, props.keyword ).then( function ( res ) {
				if ( res && res.data && res.data.jsonld ) {
					props.setSchema( JSON.stringify( res.data.jsonld ) );
					set( { busy: false, error: '' } );
				} else {
					set( { busy: false, error: __( 'No schema returned. Try again.', 'snaplevel' ) } );
				}
			} ).catch( function ( err ) {
				set( { busy: false, error: ( err && err.message ) || __( 'AI request failed.', 'snaplevel' ) } );
			} );
		}

		return el( 'div', { style: { padding: '0 16px 16px' } },
			el( 'p', { style: { fontSize: '12px', color: COLOR.secondary } },
				__( 'AI reads this post and builds the right schema.org markup — Article, Product, FAQ, Recipe, HowTo and more. It detects the type automatically.', 'snaplevel' ) ),
			CFG.hasKey ? el( Button, { style: aiBtnStyle(), disabled: st.busy, onClick: run },
				st.busy ? el( Fragment, null, el( Spinner, null ), ' ', __( 'Analyzing post…', 'snaplevel' ) ) : '✦ ' + __( 'Generate schema with AI', 'snaplevel' ) ) : null,
			st.error ? el( 'p', { style: { color: COLOR.bad, fontSize: '11px' } }, st.error ) : null,
			parsed ? el( 'div', null,
				el( 'div', { style: { margin: '8px 0' } },
					el( 'span', { className: 'snap-badge snap-badge-green' }, '✓ ' + ( parsed['@type'] || 'Schema' ) + ' ' + __( 'active', 'snaplevel' ) ) ),
				el( 'pre', { style: { fontSize: '10px', background: '#f8f9fa', border: '1px solid #dadfe4', borderRadius: '3px', padding: '10px', maxHeight: '220px', overflow: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word' } },
					JSON.stringify( parsed, null, 2 ) ),
				el( Button, { variant: 'secondary', isSecondary: true, isDestructive: true, onClick: function () { props.setSchema( '' ); } }, __( 'Remove schema', 'snaplevel' ) )
			) : el( 'p', { style: { fontSize: '12px', color: COLOR.secondary } }, __( 'No schema on this post yet.', 'snaplevel' ) )
		);
	}

	// ── Social tab (Open Graph + X cards) ────────────────────────────────────

	function pickImage( title, onSelect ) {
		if ( ! window.wp || ! wp.media ) { return; }
		var frame = wp.media( { title: title, multiple: false, library: { type: 'image' } } );
		frame.on( 'select', function () {
			var att = frame.state().get( 'selection' ).first().toJSON();
			onSelect( att.sizes && att.sizes.large ? att.sizes.large.url : att.url );
		} );
		frame.open();
	}

	/** Live share-card preview (Facebook or X styling). */
	function ShareCard( props ) {
		var isX = 'x' === props.platform;
		var host = ( CFG.siteUrl || '' ).replace( /^https?:\/\//, '' ).replace( /\/.*$/, '' );
		return el( 'div', { style: { border: '1px solid #E5E7EB', borderRadius: isX ? '14px' : '10px', overflow: 'hidden', background: '#fff', marginBottom: '12px' } },
			el( 'div', { style: {
				height: '130px',
				background: props.image ? '#F3F4F6 url(' + props.image + ') center/cover no-repeat' : '#F3F4F6',
				display: 'flex', alignItems: 'center', justifyContent: 'center',
				color: '#9CA3AF', fontSize: '11px'
			} }, props.image ? null : __( 'No image set', 'snaplevel' ) ),
			el( 'div', { style: { padding: '8px 10px', background: isX ? '#fff' : '#F0F2F5' } },
				! isX ? el( 'div', { style: { fontSize: '10px', color: '#65676B', textTransform: 'uppercase' } }, host ) : null,
				el( 'div', { style: { fontWeight: 600, fontSize: '12px', color: '#0F1419', lineHeight: 1.3 } }, props.title || '' ),
				el( 'div', { style: { fontSize: '11px', color: '#65676B', lineHeight: 1.35, maxHeight: '30px', overflow: 'hidden' } }, props.desc || '' ),
				isX ? el( 'div', { style: { fontSize: '10px', color: '#536471', marginTop: '2px' } }, host ) : null
			)
		);
	}

	function SocialTab( props ) {
		var meta = props.meta;
		var setMeta = props.setMeta;

		var baseTitle = props.seoTitle || props.postTitle || '';
		var baseDesc = props.seoDesc || stripTags( props.content ).slice( 0, 156 );
		var ogTitle = meta._snap_og_title || '';
		var ogDesc = meta._snap_og_desc || '';
		var ogImage = meta._snap_og_image || '';
		var twTitle = meta._snap_tw_title || '';
		var twDesc = meta._snap_tw_desc || '';
		var twImage = meta._snap_tw_image || '';

		var effOgTitle = ogTitle || baseTitle;
		var effOgDesc = ogDesc || baseDesc;
		var effOgImage = ogImage || props.featuredImage || '';

		function imageRow( label, value, key ) {
			return el( 'div', { style: { marginBottom: '12px' } },
				el( 'label', { style: { display: 'block', fontWeight: 600, fontSize: '11px', marginBottom: '4px', textTransform: 'uppercase' } }, label ),
				el( 'div', { style: { display: 'flex', gap: '6px' } },
					el( Button, { variant: 'secondary', isSecondary: true, onClick: function () {
						pickImage( __( 'Select social image', 'snaplevel' ), function ( url ) { setMeta( key, url ); } );
					} }, value ? __( 'Change image', 'snaplevel' ) : __( 'Choose image', 'snaplevel' ) ),
					value ? el( Button, { variant: 'secondary', isSecondary: true, isDestructive: true, onClick: function () { setMeta( key, '' ); } }, __( 'Remove', 'snaplevel' ) ) : null
				)
			);
		}

		return el( 'div', { style: { padding: '0 16px 16px' } },
			el( 'p', { style: { fontSize: '11px', color: COLOR.secondary, margin: '0 0 10px' } },
				__( 'Empty fields inherit from the General tab (and X inherits from Facebook). Previews update live.', 'snaplevel' ) ),

			el( PanelBody, { title: __( 'Facebook · LinkedIn · WhatsApp', 'snaplevel' ), initialOpen: true },
				el( ShareCard, { platform: 'fb', title: effOgTitle, desc: effOgDesc, image: effOgImage } ),
				el( TextControl, {
					label: __( 'Social Title', 'snaplevel' ),
					value: ogTitle,
					placeholder: baseTitle,
					onChange: function ( v ) { setMeta( '_snap_og_title', v ); }
				} ),
				el( TextareaControl, {
					label: __( 'Social Description', 'snaplevel' ),
					rows: 2,
					value: ogDesc,
					placeholder: baseDesc,
					onChange: function ( v ) { setMeta( '_snap_og_desc', v ); }
				} ),
				imageRow( __( 'Social Image (1200×630)', 'snaplevel' ), ogImage, '_snap_og_image' )
			),

			el( PanelBody, { title: __( 'X (Twitter)', 'snaplevel' ), initialOpen: false },
				el( ShareCard, { platform: 'x', title: twTitle || effOgTitle, desc: twDesc || effOgDesc, image: twImage || effOgImage } ),
				el( SelectControl, {
					label: __( 'Card Type', 'snaplevel' ),
					value: meta._snap_tw_card || '',
					options: [
						{ label: __( 'Large image (default)', 'snaplevel' ), value: '' },
						{ label: __( 'Summary (small image)', 'snaplevel' ), value: 'summary' }
					],
					onChange: function ( v ) { setMeta( '_snap_tw_card', v ); }
				} ),
				el( TextControl, {
					label: __( 'X Title', 'snaplevel' ),
					value: twTitle,
					placeholder: effOgTitle,
					onChange: function ( v ) { setMeta( '_snap_tw_title', v ); }
				} ),
				el( TextareaControl, {
					label: __( 'X Description', 'snaplevel' ),
					rows: 2,
					value: twDesc,
					placeholder: effOgDesc,
					onChange: function ( v ) { setMeta( '_snap_tw_desc', v ); }
				} ),
				imageRow( __( 'X Image', 'snaplevel' ), twImage, '_snap_tw_image' )
			)
		);
	}

	// ── Fix with AI ──────────────────────────────────────────────────────────

	function FixWithAI( props ) {
		var s = useState( { busy: false, step: '', done: false, error: '' } );
		var st = s[ 0 ]; var set = s[ 1 ];

		if ( ! CFG.hasKey || ! CFG.canUseAI ) { return null; }

		function run() {
			set( { busy: true, step: __( 'Finding keywords…', 'snaplevel' ), done: false, error: '' } );

			var keywordPromise = props.keyword
				? Promise.resolve( props.keyword )
				: generate( 'focus_keywords', props.postId, '' ).then( function ( res ) {
					var kw = res && res.data && res.data.keywords && res.data.keywords[ 0 ] ? res.data.keywords[ 0 ].keyword : '';
					if ( kw ) { props.setMeta( '_snap_focus_kw', kw ); }
					return kw;
				} );

			keywordPromise.then( function ( kw ) {
				set( { busy: true, step: __( 'Writing title…', 'snaplevel' ), done: false, error: '' } );
				return generate( 'seo_title', props.postId, kw ).then( function ( res ) {
					if ( res && res.data && res.data.options && res.data.options[ 0 ] ) {
						props.setMeta( '_snap_title', res.data.options[ 0 ] );
					}
					set( { busy: true, step: __( 'Writing description…', 'snaplevel' ), done: false, error: '' } );
					return generate( 'meta_description', props.postId, kw );
				} ).then( function ( res ) {
					if ( res && res.data && res.data.options && res.data.options[ 0 ] ) {
						props.setMeta( '_snap_desc', res.data.options[ 0 ] );
					}
					set( { busy: false, step: '', done: true, error: '' } );
				} );
			} ).catch( function ( err ) {
				set( { busy: false, step: '', done: false, error: ( err && err.message ) || __( 'AI request failed.', 'snaplevel' ) } );
			} );
		}

		return el( 'div', { style: { padding: '0 16px 8px' } },
			el( Button, { style: aiBtnStyle(), disabled: st.busy, onClick: run },
				st.busy ? el( Fragment, null, el( Spinner, null ), ' ', st.step ) : '⚡ ' + __( 'Fix with AI — keyword, title & description', 'snaplevel' ) ),
			st.done ? el( 'p', { style: { color: COLOR.good, fontSize: '11px', fontWeight: 600 } }, '✓ ' + __( 'Done. Review the fields below, then update the post.', 'snaplevel' ) ) : null,
			st.error ? el( 'p', { style: { color: COLOR.bad, fontSize: '11px' } }, st.error ) : null
		);
	}

	// ── Copilot Panel ────────────────────────────────────────────────────────

	function CopilotPanel( props ) {
		var s = useState( { status: 'ready', opportunities: null, readiness: '', error: '', fixing: {} } );
		var st = s[ 0 ]; var set = s[ 1 ];

		if ( ! CFG.copilotEnabled || ! CFG.canUseAI || ! CFG.hasKey ) { return null; }

		function analyze() {
			set( { status: 'analyzing', opportunities: null, readiness: '', error: '', fixing: {} } );
			apiFetch( {
				path: '/snaplevel/v1/copilot/analyze',
				method: 'POST',
				data: { post_id: props.postId }
			} ).then( function ( res ) {
				var analysis = res && res.analysis ? res.analysis : null;
				if ( analysis ) {
					var opps = analysis.opportunities || [];
					set( {
						status: opps.length > 0 ? 'opportunities' : 'clear',
						opportunities: opps,
						readiness: analysis.readiness || '',
						error: '',
						fixing: {}
					} );
				} else {
					set( { status: 'ready', opportunities: null, readiness: '', error: __( 'Analysis failed. Try again.', 'snaplevel' ), fixing: {} } );
				}
			} ).catch( function ( err ) {
				set( { status: 'ready', opportunities: null, readiness: '', error: ( err && err.message ) || __( 'Request failed.', 'snaplevel' ), fixing: {} } );
			} );
		}

		function fixOne( opp ) {
			if ( ! opp.fixable || opp.fix_task === 'none' ) { return; }
			var newFixing = Object.assign( {}, st.fixing );
			newFixing[ opp.id ] = 'busy';
			set( Object.assign( {}, st, { fixing: newFixing } ) );

			generate( opp.fix_task, props.postId, props.keyword ).then( function ( res ) {
				var value = '';
				if ( res && res.data ) {
					if ( res.data.options && res.data.options[ 0 ] ) {
						value = res.data.options[ 0 ];
					} else if ( res.data.keywords && res.data.keywords[ 0 ] ) {
						value = res.data.keywords[ 0 ].keyword;
					}
				}
				if ( value ) {
					var metaKey = { meta_description: '_snap_desc', seo_title: '_snap_title', focus_keywords: '_snap_focus_kw' }[ opp.fix_task ] || '';
					if ( metaKey ) { props.setMeta( metaKey, value ); }
				}
				var updated = Object.assign( {}, st.fixing );
				updated[ opp.id ] = value ? 'done' : 'error';
				set( Object.assign( {}, st, { fixing: updated } ) );
			} ).catch( function () {
				var updated = Object.assign( {}, st.fixing );
				updated[ opp.id ] = 'error';
				set( Object.assign( {}, st, { fixing: updated } ) );
			} );
		}

		function fixAll() {
			var fixable = ( st.opportunities || [] ).filter( function ( o ) { return o.fixable && o.fix_task !== 'none'; } );
			if ( ! fixable.length ) { return; }

			var chain = Promise.resolve();
			fixable.forEach( function ( opp ) {
				chain = chain.then( function () {
					return new Promise( function ( resolve ) {
						fixOne( opp );
						setTimeout( resolve, 800 );
					} );
				} );
			} );
		}

		// Ready state
		if ( st.status === 'ready' ) {
			return el( 'div', { className: 'snap-copilot-panel' },
				el( 'div', { className: 'snap-copilot-header' },
					el( 'span', { style: { fontWeight: 700, fontSize: '14px', color: COLOR.primary } }, '✦ ' + __( 'Copilot — Snaplevel AI', 'snaplevel' ) )
				),
				st.error ? el( 'p', { style: { color: COLOR.bad, fontSize: '12px', padding: '0 16px' } }, st.error ) : null,
				el( 'div', { style: { padding: '0 16px 16px' } },
					el( 'p', { style: { fontSize: '12px', color: COLOR.secondary, margin: '0 0 12px' } },
						__( 'Your AI assistant. Scans content and surfaces concrete opportunities with one-click fixes.', 'snaplevel' ) ),
					el( Button, {
						className: 'snap-copilot-fix-btn',
						style: { width: '100%', justifyContent: 'center', background: COLOR.primary, color: '#fff', borderRadius: '6px', border: 0, fontWeight: 600, padding: '10px 16px' },
						onClick: analyze
					}, '✦ ' + __( 'Find opportunities', 'snaplevel' ) )
				)
			);
		}

		// Analyzing state
		if ( st.status === 'analyzing' ) {
			return el( 'div', { className: 'snap-copilot-panel' },
				el( 'div', { className: 'snap-copilot-header' },
					el( 'span', { style: { fontWeight: 700, fontSize: '14px', color: COLOR.primary } }, '✦ ' + __( 'Copilot — Snaplevel AI', 'snaplevel' ) )
				),
				el( 'div', { className: 'snap-copilot-spinner', style: { padding: '24px 16px', textAlign: 'center' } },
					el( Spinner, null ),
					el( 'p', { style: { fontSize: '12px', color: COLOR.secondary, marginTop: '8px' } }, __( 'AI is finding opportunities...', 'snaplevel' ) )
				)
			);
		}

		// All-clear state
		if ( st.status === 'clear' ) {
			return el( 'div', { className: 'snap-copilot-panel' },
				el( 'div', { className: 'snap-copilot-header' },
					el( 'span', { style: { fontWeight: 700, fontSize: '14px', color: COLOR.primary } }, '✦ ' + __( 'Copilot — Snaplevel AI', 'snaplevel' ) )
				),
				el( 'div', { className: 'snap-copilot-success', style: { padding: '20px 16px', textAlign: 'center' } },
					el( 'div', { style: { fontSize: '24px', marginBottom: '8px' } }, '✓' ),
					el( 'p', { style: { fontWeight: 600, fontSize: '13px', margin: '0 0 4px' } }, __( 'All clear — no opportunities', 'snaplevel' ) ),
					el( 'p', { style: { fontSize: '12px', color: COLOR.secondary, margin: 0 } }, __( 'Your content is well-optimized. Re-check anytime.', 'snaplevel' ) )
				),
				el( 'div', { style: { padding: '8px 16px 16px', textAlign: 'center' } },
					el( Button, { variant: 'tertiary', onClick: analyze, style: { fontSize: '12px' } }, __( 'Re-analyze', 'snaplevel' ) )
				)
			);
		}

		// Opportunities state
		var fixable = ( st.opportunities || [] ).filter( function ( o ) { return o.fixable && o.fix_task !== 'none'; } );
		var allFixed = fixable.length > 0 && fixable.every( function ( o ) { return st.fixing[ o.id ] === 'done'; } );

		return el( 'div', { className: 'snap-copilot-panel' },
			el( 'div', { className: 'snap-copilot-header', style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' } },
				el( 'span', { style: { fontWeight: 700, fontSize: '14px', color: COLOR.primary } }, '✦ ' + __( 'Copilot', 'snaplevel' ) ),
				el( 'span', { className: 'snap-copilot-readiness', style: { fontSize: '11px', color: COLOR.secondary } },
					st.readiness === 'good' ? '● ' + __( 'Good', 'snaplevel' ) :
					st.readiness === 'needs_work' ? '● ' + __( 'Needs work', 'snaplevel' ) :
					'● ' + __( 'Not started', 'snaplevel' ) )
			),

			fixable.length > 1 && ! allFixed ? el( 'div', { style: { padding: '0 16px 8px' } },
				el( Button, {
					className: 'snap-copilot-fix-all',
					style: { width: '100%', justifyContent: 'center', background: COLOR.primary, color: '#fff', borderRadius: '6px', border: 0, fontWeight: 600, padding: '8px 14px', fontSize: '12px' },
					onClick: fixAll
				}, '⚡ ' + __( 'Fix all opportunities with AI', 'snaplevel' ) + ' (' + fixable.length + ')' )
			) : null,

			allFixed ? el( 'div', { style: { padding: '8px 16px', textAlign: 'center' } },
				el( 'p', { style: { color: COLOR.good, fontWeight: 600, fontSize: '12px', margin: 0 } }, '✓ ' + __( 'All fixes applied. Review and update your post.', 'snaplevel' ) )
			) : null,

			el( 'div', { style: { padding: '0 16px 16px' } },
				( st.opportunities || [] ).map( function ( opp ) {
					var fixStatus = st.fixing[ opp.id ] || '';
					var dotColor = opp.category === 'meta' || opp.category === 'title' ? '#D85A30' : '#BA7517';

					return el( 'div', { key: opp.id, className: 'snap-copilot-card', style: { marginBottom: '10px', padding: '10px 12px', border: '1px solid #E5E7EB', borderRadius: '8px', background: fixStatus === 'done' ? '#F0FDF4' : '#fff' } },
						el( 'div', { style: { display: 'flex', alignItems: 'flex-start', gap: '8px' } },
							el( 'span', { className: 'snap-copilot-dot', style: { width: '8px', height: '8px', borderRadius: '50%', background: fixStatus === 'done' ? COLOR.good : dotColor, marginTop: '4px', flexShrink: 0 } } ),
							el( 'div', { style: { flex: 1 } },
								el( 'div', { style: { fontWeight: 600, fontSize: '12px', lineHeight: 1.4 } }, opp.title ),
								el( 'div', { style: { fontSize: '11px', color: COLOR.secondary, marginTop: '2px', lineHeight: 1.4 } }, opp.reason )
							)
						),
						opp.fixable && opp.fix_task !== 'none' && fixStatus !== 'done' ? el( 'div', { style: { marginTop: '8px', paddingLeft: '16px' } },
							el( Button, {
								variant: 'secondary',
								disabled: fixStatus === 'busy',
								onClick: function () { fixOne( opp ); },
								style: { fontSize: '11px', padding: '4px 10px', borderRadius: '4px' }
							}, fixStatus === 'busy' ? el( Fragment, null, el( Spinner, { style: { width: '12px', height: '12px' } } ), ' ', __( 'Fixing...', 'snaplevel' ) ) : '✦ ' + __( 'Fix with AI', 'snaplevel' ) )
						) : null,
						fixStatus === 'done' ? el( 'div', { style: { marginTop: '6px', paddingLeft: '16px', fontSize: '11px', color: COLOR.good, fontWeight: 600 } }, '✓ ' + __( 'Fixed', 'snaplevel' ) ) : null,
						fixStatus === 'error' ? el( 'div', { style: { marginTop: '6px', paddingLeft: '16px', fontSize: '11px', color: COLOR.bad } }, __( 'Failed. Try again.', 'snaplevel' ) ) : null
					);
				} )
			),

			el( 'div', { style: { padding: '0 16px 12px', textAlign: 'center' } },
				el( Button, { variant: 'tertiary', onClick: analyze, style: { fontSize: '11px' } }, __( 'Re-analyze', 'snaplevel' ) )
			)
		);
	}

	// ── Sidebar ──────────────────────────────────────────────────────────────

	function Sidebar() {
		var tabState = useState( 'general' );
		var tab = tabState[ 0 ]; var setTab = tabState[ 1 ];

		var data = useSelect( function ( select ) {
			var editor = select( 'core/editor' );
			var mediaId = editor.getEditedPostAttribute( 'featured_media' );
			var media = mediaId ? select( 'core' ).getMedia( mediaId ) : null;
			return {
				postId: editor.getCurrentPostId(),
				postTitle: editor.getEditedPostAttribute( 'title' ) || '',
				slug: editor.getEditedPostAttribute( 'slug' ) || '',
				content: editor.getEditedPostAttribute( 'content' ) || '',
				meta: editor.getEditedPostAttribute( 'meta' ) || {},
				featuredImage: media && media.source_url ? media.source_url : ''
			};
		}, [] );

		var dispatch = useDispatch( 'core/editor' );

		function setMeta( key, value ) {
			var update = {};
			update[ key ] = value;
			dispatch.editPost( { meta: update } );
		}

		var meta = data.meta;
		var seoTitle = meta._snap_title || '';
		var seoDesc = meta._snap_desc || '';
		var keyword = meta._snap_focus_kw || '';
		var robots = meta._snap_robots || '';
		var schema = meta._snap_schema || '';

		var result = runChecks( {
			content: data.content, postTitle: data.postTitle, slug: data.slug,
			seoTitle: seoTitle, seoDesc: seoDesc, keyword: keyword, schema: schema
		} );

		return el( Fragment, null,
			PluginSidebarMoreMenuItem ? el( PluginSidebarMoreMenuItem, { target: 'snap-sidebar' }, 'Snaplevel SEO' ) : null,
			el( PluginSidebar, { name: 'snap-sidebar', title: 'Snaplevel SEO', icon: 'superhero-alt' },

				el( 'div', { style: { padding: '10px 16px 0' } },
					el( Tabs, { tab: tab, setTab: setTab } )
				),

				'general' === tab ? el( Fragment, null,
					// Copilot is the HERO: AI opportunities first, calm cards, primary focus.
					el( CopilotPanel, { postId: data.postId, keyword: keyword, setMeta: setMeta } ),
					el( FixWithAI, { postId: data.postId, keyword: keyword, setMeta: setMeta } ),

					// Core editable fields (after Copilot opportunities).
					el( 'div', { style: { padding: '0 16px' } },
						el( 'label', { style: { display: 'block', fontWeight: 600, fontSize: '12px', marginBottom: '6px' } }, __( 'Focus Keyword', 'snaplevel' ) ),
						el( 'div', { style: { display: 'flex', alignItems: 'stretch', marginBottom: '6px' } },
							el( 'input', {
								type: 'text',
								value: keyword,
								placeholder: __( 'e.g. best trail running shoes', 'snaplevel' ),
								onChange: function ( e ) { setMeta( '_snap_focus_kw', e.target.value ); },
								style: {
									flex: 1, minWidth: 0, padding: '8px 10px', height: '37px',
									border: '1px solid #dadfe4',
									borderRadius: '3px', fontSize: '13px'
								}
							} )
						),
						el( AIGenerate, {
							task: 'focus_keywords',
							label: __( 'Suggest keywords', 'snaplevel' ),
							postId: data.postId,
							keyword: '',
							extract: function ( res ) {
								return res && res.data && res.data.keywords
									? res.data.keywords.map( function ( k ) { return k.keyword + '  ·  ' + k.intent; } )
									: null;
							},
							onPick: function ( v ) { setMeta( '_snap_focus_kw', v.split( '  ·  ' )[ 0 ] ); }
						} )
					),

					// URL slug editor with live preview.
					el( 'div', { style: { padding: '0 16px', marginBottom: '8px' } },
						el( TextControl, {
							label: __( 'URL Slug', 'snaplevel' ),
							value: data.slug,
							help: ( CFG.siteUrl || '' ).replace( /\/$/, '' ) + '/' + ( data.slug || '' ) + '/',
							onChange: function ( v ) {
								dispatch.editPost( { slug: v.toLowerCase().replace( /[^a-z0-9\s_-]/g, '' ).replace( /[\s_]+/g, '-' ).replace( /-{2,}/g, '-' ) } );
							}
						} )
					),

					el( PanelBody, { title: __( 'SEO Title & Description', 'snaplevel' ), initialOpen: true },
						el( TextControl, {
							label: __( 'SEO Title', 'snaplevel' ),
							help: seoTitle.length + '/60',
							value: seoTitle,
							placeholder: data.postTitle,
							onChange: function ( v ) { setMeta( '_snap_title', v ); }
						} ),
						el( AIGenerate, {
							task: 'seo_title',
							label: __( 'Generate title', 'snaplevel' ),
							postId: data.postId,
							keyword: keyword,
							extract: function ( res ) { return res && res.data ? res.data.options : null; },
							onPick: function ( v ) { setMeta( '_snap_title', v ); }
						} ),
						el( TextareaControl, {
							label: __( 'Meta Description', 'snaplevel' ),
							help: seoDesc.length + '/156',
							rows: 3,
							value: seoDesc,
							onChange: function ( v ) { setMeta( '_snap_desc', v ); }
						} ),
						el( AIGenerate, {
							task: 'meta_description',
							label: __( 'Generate description', 'snaplevel' ),
							postId: data.postId,
							keyword: keyword,
							extract: function ( res ) { return res && res.data ? res.data.options : null; },
							onPick: function ( v ) { setMeta( '_snap_desc', v ); }
						} )
					),

					// SERP preview (supportive, after primary fields + AI).
					el( 'div', { style: { padding: '0 16px 12px' } },
						el( SnippetPreview, { seoTitle: seoTitle, seoDesc: seoDesc, postTitle: data.postTitle, slug: data.slug, content: data.content } )
					),

					// Traditional deterministic checklist + score: SECONDARY, collapsed. Old pattern challenged — Copilot cards above are primary AI assistant view.
					el( PanelBody, {
						title: __( 'Traditional SEO signals (optional)', 'snaplevel' ),
						initialOpen: false
					},
						el( 'div', { style: { padding: '0 0 8px', fontSize: '11px', color: COLOR.secondary, marginBottom: '8px' } },
							__( 'These are the old instant checks (no AI). Copilot opportunities (top) are the main focus.', 'snaplevel' )
						),
						el( CheckList, { checks: result.checks } ),
						el( 'div', { style: { marginTop: '8px' } }, el( ScorePill, { score: result.score } ) )
					)
				) : null,

				'social' === tab ? el( SocialTab, {
					meta: meta,
					setMeta: setMeta,
					postTitle: data.postTitle,
					content: data.content,
					seoTitle: seoTitle,
					seoDesc: seoDesc,
					featuredImage: data.featuredImage
				} ) : null,

				'schema' === tab ? el( SchemaTab, {
					postId: data.postId,
					keyword: keyword,
					schema: schema,
					setSchema: function ( v ) { setMeta( '_snap_schema', v ); }
				} ) : null,

				'advanced' === tab ? el( 'div', { style: { padding: '0 16px 16px' } },
					el( 'label', { style: { display: 'block', fontWeight: 600, fontSize: '12px', margin: '8px 0' } }, __( 'Robots Meta', 'snaplevel' ) ),
					[
						{ id: 'noindex', label: __( 'No Index — hide from search results', 'snaplevel' ) },
						{ id: 'nofollow', label: __( 'No Follow — don’t follow links', 'snaplevel' ) },
						{ id: 'noimageindex', label: __( 'No Image Index', 'snaplevel' ) },
						{ id: 'nosnippet', label: __( 'No Snippet', 'snaplevel' ) }
					].map( function ( d ) {
						var list = robots.split( ',' ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
						return el( CheckboxControl, {
							key: d.id,
							label: d.label,
							checked: list.indexOf( d.id ) !== -1,
							onChange: function ( on ) {
								var next = list.filter( function ( s ) { return s !== d.id; } );
								if ( on ) { next.push( d.id ); }
								setMeta( '_snap_robots', next.join( ',' ) );
							}
						} );
					} ),
					el( TextControl, {
						label: __( 'Canonical URL', 'snaplevel' ),
						help: __( 'Empty = default permalink.', 'snaplevel' ),
						value: meta._snap_canonical || '',
						onChange: function ( v ) { setMeta( '_snap_canonical', v ); }
					} ),
					el( TextControl, {
						label: __( 'Breadcrumb Title', 'snaplevel' ),
						help: __( 'Shorter title for breadcrumb trails. Empty = post title.', 'snaplevel' ),
						value: meta._snap_breadcrumb_title || '',
						placeholder: data.postTitle,
						onChange: function ( v ) { setMeta( '_snap_breadcrumb_title', v ); }
					} )
				) : null
			)
		);
	}

	registerPlugin( 'snaplevel-seo', { render: Sidebar } );
} )();
