/**
 * ICW Admin JS — tabs, toast notifications, bulk compress, single actions.
 */
(function ($) {
    'use strict';

    if (typeof ICW === 'undefined') return;

    const ajax = (action, data) =>
        $.post(ICW.ajaxurl, Object.assign({ action, nonce: ICW.nonce }, data));

    // ── Toast system ─────────────────────────────────────────────────────────

    let $toastContainer;

    function initToasts() {
        $toastContainer = $('<div id="icw-toast-container"></div>').appendTo('body');
    }

    function toast(msg, type, duration) {
        type     = type     || 'info';
        duration = duration || 3500;

        const icons = {
            success: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#34d399" stroke-width="2"/><path d="M8 12l3 3 5-5" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            error:   '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#f87171" stroke-width="2"/><path d="M15 9l-6 6M9 9l6 6" stroke="#f87171" stroke-width="2" stroke-linecap="round"/></svg>',
            warning: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="#fbbf24" stroke-width="2"/><path d="M12 9v4m0 4h.01" stroke="#fbbf24" stroke-width="2" stroke-linecap="round"/></svg>',
            info:    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#93c5fd" stroke-width="2"/><path d="M12 16v-4m0-4h.01" stroke="#93c5fd" stroke-width="2" stroke-linecap="round"/></svg>',
        };

        const $t = $(
            '<div class="icw-toast icw-toast--' + type + '">' +
            '<span class="icw-toast-icon">' + (icons[type] || '') + '</span>' +
            '<span>' + escHtml(msg) + '</span>' +
            '</div>'
        ).appendTo($toastContainer);

        requestAnimationFrame(function () {
            $t.addClass('is-visible');
        });

        setTimeout(function () {
            $t.removeClass('is-visible');
            setTimeout(function () { $t.remove(); }, 300);
        }, duration);
    }

    // ── Tab system ───────────────────────────────────────────────────────────

    function initTabs() {
        var defaultTab = (ICW.defaultTab && ICW.defaultTab !== '') ? ICW.defaultTab : 'overview';
        var hash = window.location.hash.replace('#icw-', '');
        var startTab = (['overview', 'settings', 'system'].indexOf(hash) !== -1) ? hash : defaultTab;

        activateTab(startTab);

        $(document).on('click', '.icw-tab', function () {
            var tab = $(this).data('tab');
            activateTab(tab);
            window.history.replaceState(null, '', '#icw-' + tab);
        });
    }

    function activateTab(tab) {
        $('.icw-tab').removeClass('is-active').attr('aria-selected', 'false');
        $('.icw-tab-panel').removeClass('is-active');

        var $btn = $('.icw-tab[data-tab="' + tab + '"]');
        var $panel = $('#panel-' + tab);

        if ($btn.length && $panel.length) {
            $btn.addClass('is-active').attr('aria-selected', 'true');
            $panel.addClass('is-active');
        } else {
            // fallback to overview
            $('.icw-tab[data-tab="overview"]').addClass('is-active');
            $('#panel-overview').addClass('is-active');
        }
    }

    // ── Quality slider ───────────────────────────────────────────────────────

    $(document).on('input', '#icw-quality', function () {
        $('#icw-quality-val').val(this.value).text(this.value);
    });

    // ── Save settings ────────────────────────────────────────────────────────

    $(document).on('click', '#icw-save-settings', function () {
        var $btn = $(this);
        var $msg = $('#icw-settings-msg');

        var settings = {
            quality:            $('#icw-quality').val(),
            compress_originals: $('#icw-compress-originals').is(':checked') ? 1 : 0,
            convert_to_webp:    $('#icw-convert-webp').is(':checked')       ? 1 : 0,
            backup_originals:   $('#icw-backup').is(':checked')             ? 1 : 0,
            auto_on_upload:     $('#icw-auto').is(':checked')               ? 1 : 0,
            openai_api_key:     $('#icw-openai-key').val(),
            ai_keywords:        $('#icw-ai-keywords').val(),
        };

        $btn.prop('disabled', true);
        ajax('icw_save_settings', { settings: settings }).done(function (res) {
            if (res.success) {
                toast(ICW.i18n.settings_saved, 'success');
                $msg.text(ICW.i18n.settings_saved).removeClass('hidden is-error');
            } else {
                toast((res.data || ICW.i18n.error), 'error');
                $msg.text(res.data || ICW.i18n.error).addClass('is-error').removeClass('hidden');
            }
            setTimeout(function () { $msg.addClass('hidden'); }, 3000);
        }).always(function () {
            $btn.prop('disabled', false);
        });
    });

    // ── Single compress ──────────────────────────────────────────────────────

    $(document).on('click', '.icw-compress-btn, .icw-recompress-btn', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var id   = $btn.data('id');

        $btn.prop('disabled', true).text(ICW.i18n.compressing);

        ajax('icw_compress_single', { attachment_id: id }).done(function (res) {
            if (res.success) {
                toast('Saved ' + res.data.savings_fmt + ' (' + res.data.savings_pct + '%)', 'success');
                var $cell = $btn.closest('td.column-icw_status');
                if ($cell.length) {
                    $cell.html(res.data.html_badge);
                }
                var $panelStatus = $btn.closest('#icw-attachment-panel').find('.icw-panel-status');
                if ($panelStatus.length) {
                    $panelStatus.text('Saved ' + res.data.savings_fmt + ' · WebP ×' + res.data.webp_sizes);
                }
                refreshStats();
            } else {
                toast((ICW.i18n.error + ': ' + (res.data || '')), 'error');
                $btn.prop('disabled', false).text('Compress');
            }
        }).fail(function () {
            toast(ICW.i18n.error + ': Network error', 'error');
            $btn.prop('disabled', false).text('Compress');
        });
    });

    // ── Single restore ───────────────────────────────────────────────────────

    $(document).on('click', '.icw-restore-btn', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var id   = $btn.data('id');

        $btn.prop('disabled', true).text(ICW.i18n.restoring);

        ajax('icw_restore_single', { attachment_id: id }).done(function (res) {
            if (res.success) {
                toast('Image restored from backup.', 'success');
                var $cell = $btn.closest('td.column-icw_status');
                if ($cell.length) {
                    $cell.html('<button class="button button-small icw-compress-btn" data-id="' + id + '">Compress</button>');
                }
                var $panelStatus = $btn.closest('#icw-attachment-panel').find('.icw-panel-status');
                if ($panelStatus.length) {
                    $panelStatus.text('Restored.');
                }
                refreshStats();
            } else {
                toast(ICW.i18n.error + ': ' + (res.data || ''), 'error');
                $btn.prop('disabled', false).text('Restore');
            }
        }).fail(function () {
            toast(ICW.i18n.error + ': Network error', 'error');
            $btn.prop('disabled', false).text('Restore');
        });
    });

    // ── Delete WebP ──────────────────────────────────────────────────────────

    $(document).on('click', '.icw-delete-webp-btn', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var id   = $btn.data('id');
        $btn.text('Deleting…').prop('disabled', true);

        ajax('icw_delete_webp', { attachment_id: id }).done(function (res) {
            if (res.success) {
                toast('Deleted ' + res.data.deleted + ' WebP file(s).', 'success');
                $btn.remove();
            } else {
                toast(ICW.i18n.error, 'error');
                $btn.text('Del WebP').prop('disabled', false);
            }
        }).fail(function () {
            $btn.text('Del WebP').prop('disabled', false);
        });
    });

    // ── Bulk compress ────────────────────────────────────────────────────────

    var bulkRunning = false;
    var bulkStop    = false;

    $(document).on('click', '#icw-bulk-btn, #icw-bulk-all-btn', function () {
        if (bulkRunning) {
            bulkStop = true;
            $('#icw-bulk-btn').prop('disabled', true).text('Stopping…');
            return;
        }

        var recompressAll = $(this).is('#icw-bulk-all-btn');
        var confirmMsg    = recompressAll ? ICW.i18n.confirm_bulk_all : ICW.i18n.confirm_bulk;
        if (!confirm(confirmMsg)) return;

        bulkRunning = true;
        bulkStop    = false;

        $('#icw-bulk-btn').text(ICW.i18n.bulk_stop);
        $('#icw-bulk-all-btn').prop('disabled', true);
        $('#icw-bulk-status').removeClass('hidden');
        $('#icw-bulk-log').removeClass('hidden').empty();
        setBulkBar(0, ICW.i18n.bulk_running, '');

        ajax('icw_bulk_get_ids', { only_unprocessed: recompressAll ? 0 : 1 }).done(function (res) {
            if (!res.success || !res.data.ids.length) {
                finishBulk('No images to process.');
                return;
            }

            var ids   = res.data.ids;
            var total = ids.length;
            var done  = 0;
            var saved = 0;
            var errs  = 0;

            function processNext() {
                if (bulkStop || done >= total) {
                    var msg = bulkStop
                        ? 'Stopped. ' + done + ' of ' + total + ' processed.'
                        : ICW.i18n.bulk_done + ' ' + done + ' processed, ' + errs + ' errors, ' + formatBytes(saved) + ' saved.';
                    finishBulk(msg);
                    if (!bulkStop) {
                        toast(done + ' images processed. ' + formatBytes(saved) + ' saved.', 'success', 5000);
                    }
                    return;
                }

                var id = ids[done];
                ajax('icw_bulk_compress', { attachment_id: id }).done(function (r) {
                    done++;
                    var pct = Math.round(done / total * 100);

                    if (r.success) {
                        saved += Math.max(0, r.savings_bytes || 0);
                        logEntry('#' + id + ' ✔ -' + r.savings_pct + '% \xb7 WebP \xd7' + r.webp_sizes, 'icw-log-ok');
                    } else {
                        errs++;
                        logEntry('#' + id + ' ✖ ' + (r.message || 'Error'), 'icw-log-err');
                    }

                    setBulkBar(
                        pct,
                        done + ' / ' + total + ' — ' + pct + '%',
                        formatBytes(saved) + ' saved \xb7 ' + errs + ' errors'
                    );
                    processNext();
                }).fail(function () {
                    done++; errs++;
                    logEntry('#' + id + ' ✖ Network error', 'icw-log-err');
                    processNext();
                });
            }

            processNext();
        }).fail(function () {
            finishBulk('Failed to fetch image list.');
            toast('Could not start bulk compression.', 'error');
        });
    });

    function setBulkBar(pct, label, detail) {
        $('#icw-bulk-bar-inner').css('width', pct + '%');
        $('#icw-bulk-label').text(label);
        $('#icw-bulk-detail').text(detail);
    }

    function finishBulk(msg) {
        bulkRunning = false;
        bulkStop    = false;
        setBulkBar(100, msg, '');
        $('#icw-bulk-btn').text(ICW.i18n.bulk_start).prop('disabled', false);
        $('#icw-bulk-all-btn').prop('disabled', false);
        refreshStats();
    }

    function logEntry(text, cls) {
        var $log = $('#icw-bulk-log');
        $log.append('<div class="' + (cls || '') + '">' + escHtml(text) + '</div>');
        $log.scrollTop($log[0].scrollHeight);
    }

    // ── Refresh stats ─────────────────────────────────────────────────────────

    function refreshStats() {
        ajax('icw_get_stats').done(function (res) {
            if (!res.success) return;
            var d = res.data;
            animateCount($('#icw-stat-total'),       parseInt(d.total,       10));
            animateCount($('#icw-stat-processed'),   parseInt(d.processed,   10));
            animateCount($('#icw-stat-unprocessed'), parseInt(d.unprocessed, 10));
            $('#icw-stat-saved').text(d.saved_fmt);
            $('#icw-progress-bar').css('width', d.processed_pct + '%');
        });
    }

    function animateCount($el, target) {
        var start = parseInt($el.text().replace(/[^0-9]/g, ''), 10) || 0;
        if (start === target) return;
        var steps    = 20;
        var interval = 300 / steps;
        var step     = 0;

        var timer = setInterval(function () {
            step++;
            var value = Math.round(start + (target - start) * (step / steps));
            $el.text(value);
            if (step >= steps) {
                clearInterval(timer);
                $el.text(target);
            }
        }, interval);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    function formatBytes(bytes) {
        if (bytes < 1024)    return bytes + ' B';
        if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / 1048576).toFixed(2) + ' MB';
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // ── API key visibility toggle ─────────────────────────────────────────────

    $(document).on('click', '.icw-show-key-btn', function () {
        var $input = $(this).siblings('.icw-apikey-input');
        var type = $input.attr('type') === 'password' ? 'text' : 'password';
        $input.attr('type', type);
        $(this).toggleClass('is-visible');
    });

    // ═══════════════════════════════════════════════════════════════════════════
    // ── UNUSED IMAGES PAGE ────────────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    var unusedIds    = [];
    var unusedOffset = 0;
    var unusedLimit  = 24;

    function initUnusedImages() {
        // The unused-images.php view has its own inline <script> that handles
        // all scan/trash functionality. If that page is loaded, we must NOT
        // bind duplicate handlers here or we get double AJAX calls.
        if ($('#icw-unused-page').length) return;
    }

    function runScan() {
        $('#icw-scan-btn').prop('disabled', true).html(
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" class="icw-spin"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2" stroke-dasharray="56" stroke-dashoffset="14"/></svg> ' + escHtml(ICW.i18n.scanning)
        );
        $('#icw-scan-status').removeClass('hidden');
        $('#icw-unused-results').addClass('hidden');
        unusedIds    = [];
        unusedOffset = 0;

        ajax('icw_scan_unused', { offset: 0, limit: unusedLimit }).done(function (res) {
            $('#icw-scan-status').addClass('hidden');
            $('#icw-scan-btn').prop('disabled', false).html(
                '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="8" stroke="currentColor" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg> ' + 'Scan for Unused Images'
            );

            if (!res.success) {
                toast(res.data || ICW.i18n.error, 'error');
                return;
            }

            unusedIds = res.data.unused_ids || [];
            var total = res.data.total;
            var items = res.data.items || [];

            $('#icw-unused-total').text(total);
            $('#icw-unused-results').removeClass('hidden');
            $('#icw-unused-grid').empty();

            if (total === 0) {
                $('#icw-unused-empty').removeClass('hidden');
                $('#icw-bulk-trash-btn, #icw-trash-all-btn, #icw-select-all-wrap').addClass('hidden');
                $('#icw-load-more-wrap').addClass('hidden');
            } else {
                $('#icw-unused-empty').addClass('hidden');
                $('#icw-trash-all-btn, #icw-select-all-wrap').removeClass('hidden');
                renderUnusedItems(items);
                unusedOffset = items.length;

                if (unusedOffset < total) {
                    $('#icw-load-more-wrap').removeClass('hidden');
                } else {
                    $('#icw-load-more-wrap').addClass('hidden');
                }
            }
        }).fail(function () {
            $('#icw-scan-status').addClass('hidden');
            $('#icw-scan-btn').prop('disabled', false);
            toast(ICW.i18n.error + ': Network error', 'error');
        });
    }

    function loadMoreUnused() {
        var $btn = $('#icw-load-more-btn').prop('disabled', true).text('Loading…');
        ajax('icw_scan_unused', { offset: unusedOffset, limit: unusedLimit }).done(function (res) {
            $btn.prop('disabled', false).text('Load More');
            if (!res.success) return;
            var items = res.data.items || [];
            renderUnusedItems(items);
            unusedOffset += items.length;
            if (unusedOffset >= unusedIds.length) {
                $('#icw-load-more-wrap').addClass('hidden');
            }
        }).fail(function () {
            $btn.prop('disabled', false).text('Load More');
        });
    }

    function renderUnusedItems(items) {
        var tpl = $('#icw-unused-item-tpl').html() || '';
        var $grid = $('#icw-unused-grid');

        items.forEach(function (item) {
            var html = tpl
                .replace(/\{\{id\}\}/g,       item.id)
                .replace(/\{\{thumb\}\}/g,    escHtml(item.thumb || ''))
                .replace(/\{\{title\}\}/g,    escHtml(item.title || '(no title)'))
                .replace(/\{\{mime\}\}/g,     escHtml(item.mime  || ''))
                .replace(/\{\{filesize\}\}/g, escHtml(item.filesize || '—'))
                .replace(/\{\{date\}\}/g,     escHtml(item.date  || ''))
                .replace(/\{\{url\}\}/g,      escHtml(item.url   || '#'));
            $grid.append(html);
        });
    }

    function getSelectedIds() {
        var ids = [];
        $('.icw-unused-check:checked').each(function () {
            ids.push(parseInt($(this).data('id'), 10));
        });
        return ids;
    }

    function updateSelectionUI() {
        var ids = getSelectedIds();
        var count = ids.length;
        if (count > 0) {
            $('#icw-bulk-trash-btn').prop('disabled', false).removeClass('hidden');
            $('#icw-selected-count').text(count).removeClass('hidden');
        } else {
            $('#icw-bulk-trash-btn').prop('disabled', true).addClass('hidden');
            $('#icw-selected-count').addClass('hidden');
        }
    }

    function trashOne(id, $btn) {
        $btn.prop('disabled', true).html('<svg width="12" height="12" viewBox="0 0 24 24" fill="none" class="icw-spin"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2" stroke-dasharray="56" stroke-dashoffset="14"/></svg>');

        ajax('icw_trash_one_unused', { attachment_id: id }).done(function (res) {
            if (res.success) {
                var $item = $('.icw-unused-item[data-id="' + id + '"]');
                $item.addClass('icw-item-trashed');
                setTimeout(function () { $item.remove(); }, 400);

                unusedIds = unusedIds.filter(function (v) { return v !== id; });
                var total = parseInt($('#icw-unused-total').text(), 10) - 1;
                $('#icw-unused-total').text(Math.max(0, total));
                toast('Image moved to Trash.', 'success');

                if (total <= 0) {
                    $('#icw-unused-empty').removeClass('hidden');
                    $('#icw-bulk-trash-btn, #icw-trash-all-btn, #icw-select-all-wrap').addClass('hidden');
                }
            } else {
                toast((res.data || ICW.i18n.error), 'error');
                $btn.prop('disabled', false).html('<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>');
            }
        }).fail(function () {
            toast(ICW.i18n.error + ': Network error', 'error');
            $btn.prop('disabled', false);
        });
    }

    function bulkTrash(ids) {
        if (!ids.length) return;

        var total = ids.length;
        var done  = 0;
        var errs  = 0;

        var $trashAllBtn = $('#icw-trash-all-btn, #icw-bulk-trash-btn');
        $trashAllBtn.prop('disabled', true);

        function trashNext() {
            if (!ids.length) {
                $trashAllBtn.prop('disabled', false);
                toast(done + ' image(s) moved to Trash' + (errs ? ' (' + errs + ' errors)' : '') + '.', errs ? 'warning' : 'success');
                updateSelectionUI();
                return;
            }

            var id = ids.shift();
            ajax('icw_trash_one_unused', { attachment_id: id }).done(function (res) {
                if (res.success) {
                    done++;
                    var $item = $('.icw-unused-item[data-id="' + id + '"]');
                    $item.addClass('icw-item-trashed');
                    setTimeout(function () { $item.remove(); }, 300);
                    unusedIds = unusedIds.filter(function (v) { return v !== id; });
                    var current = parseInt($('#icw-unused-total').text(), 10) - 1;
                    $('#icw-unused-total').text(Math.max(0, current));
                } else {
                    errs++;
                }
                trashNext();
            }).fail(function () {
                errs++;
                trashNext();
            });
        }

        trashNext();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ── AI ALT TEXT PAGE ──────────────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    var altOffset    = 0;
    var altLimit     = 12;
    var altTotal     = 0;
    var altBulkStop  = false;
    var altBulkRun   = false;

    function initAltText() {
        if (!$('#icw-alt-page').length) return;

        $(document).on('click', '#icw-load-images-btn', function () {
            altOffset = 0;
            altTotal  = 0;
            $('#icw-alt-grid').empty();
            $('#icw-alt-results').addClass('hidden');
            loadAltImages(true);
        });

        $(document).on('change', '#icw-only-missing', function () {
            altOffset = 0;
            altTotal  = 0;
            $('#icw-alt-grid').empty();
            $('#icw-alt-results').addClass('hidden');
            loadAltImages(true);
        });

        $(document).on('click', '#icw-alt-load-more-btn', function () {
            loadAltImages(false);
        });

        $(document).on('click', '.icw-generate-btn', function () {
            var id  = parseInt($(this).data('id'), 10);
            var $el = $('#icw-alt-item-' + id);
            generateOne(id, $el, false);
        });

        $(document).on('input', '.icw-alt-input, .icw-alt-textarea', function () {
            var $item = $(this).closest('.icw-alt-item');
            $item.find('.icw-save-alt-btn').prop('disabled', false);
        });

        $(document).on('click', '.icw-save-alt-btn', function () {
            var id  = parseInt($(this).data('id'), 10);
            var $el = $('#icw-alt-item-' + id);
            saveAlt(id, $el, $(this));
        });

        $(document).on('click', '#icw-bulk-generate-btn', function () {
            if (altBulkRun) {
                altBulkStop = true;
                return;
            }
            startBulkGenerate();
        });

        $(document).on('click', '#icw-alt-bulk-stop-btn', function () {
            altBulkStop = true;
            $(this).text('Stopping…');
        });
    }

    function loadAltImages(reset) {
        var onlyMissing = $('#icw-only-missing').is(':checked') ? 1 : 0;
        var $btn = $('#icw-load-images-btn').prop('disabled', true).text('Loading…');

        ajax('icw_get_images_for_alt', {
            offset:       altOffset,
            limit:        altLimit,
            only_missing: onlyMissing,
        }).done(function (res) {
            $btn.prop('disabled', false).text('Load Images');
            if (!res.success) {
                toast(res.data || ICW.i18n.error, 'error');
                return;
            }

            var items = res.data.items || [];
            altTotal = res.data.total || 0;

            if (reset) {
                altOffset = 0;
                $('#icw-alt-grid').empty();
            }

            if (altTotal === 0 && reset) {
                $('#icw-alt-results').removeClass('hidden');
                $('#icw-alt-empty').removeClass('hidden');
                $('#icw-alt-load-more-wrap').addClass('hidden');
                $('#icw-bulk-generate-btn').addClass('hidden');
                $('#icw-alt-showing').text(0);
                $('#icw-alt-total').text(0);
                return;
            }

            $('#icw-alt-empty').addClass('hidden');
            $('#icw-alt-results').removeClass('hidden');
            $('#icw-bulk-generate-btn').removeClass('hidden');

            renderAltItems(items);
            altOffset += items.length;

            $('#icw-alt-showing').text(altOffset);
            $('#icw-alt-total').text(altTotal);

            if (altOffset < altTotal) {
                $('#icw-alt-load-more-wrap').removeClass('hidden');
            } else {
                $('#icw-alt-load-more-wrap').addClass('hidden');
            }
        }).fail(function () {
            $btn.prop('disabled', false).text('Load Images');
            toast(ICW.i18n.error + ': Network error', 'error');
        });
    }

    function renderAltItems(items) {
        var tpl  = $('#icw-alt-item-tpl').html() || '';
        var $grid = $('#icw-alt-grid');

        items.forEach(function (item) {
            var hasAlt     = item.current_alt && item.current_alt.trim() !== '';
            var statusCls  = item.generated ? 'generated' : (hasAlt ? 'has-alt' : 'missing');
            var statusLbl  = item.generated ? 'AI Generated' : (hasAlt ? 'Has Alt' : 'Missing Alt');

            var html = tpl
                .replace(/\{\{id\}\}/g,           item.id)
                .replace(/\{\{thumb\}\}/g,         escHtml(item.thumb || ''))
                .replace(/\{\{title\}\}/g,         escHtml(item.title || '(no title)'))
                .replace(/\{\{current_alt\}\}/g,   escHtml(item.current_alt || ''))
                .replace(/\{\{status_class\}\}/g,  statusCls)
                .replace(/\{\{status_label\}\}/g,  statusLbl);

            $grid.append(html);
        });
    }

    function generateOne(id, $el, autoSave) {
        var $genBtn  = $el.find('.icw-generate-btn');
        var $saveBtn = $el.find('.icw-save-alt-btn');

        $genBtn.prop('disabled', true).html(
            '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" class="icw-spin"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2" stroke-dasharray="56" stroke-dashoffset="14"/></svg> ' + escHtml(ICW.i18n.generating)
        );

        return ajax('icw_generate_alt_text', {
            attachment_id: id,
            auto_save:     autoSave ? 1 : 0,
        }).done(function (res) {
            $genBtn.prop('disabled', false).html(
                '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Generate'
            );

            if (res.success) {
                var d = res.data;
                $el.find('.icw-field-alt').val(d.alt || '');
                $el.find('.icw-field-title').val(d.title || '');
                $el.find('.icw-field-caption').val(d.caption || '');
                $el.find('.icw-field-description').val(d.description || '');

                if (d.saved) {
                    $el.find('.icw-alt-status-chip')
                        .attr('class', 'icw-alt-status-chip icw-alt-status-generated')
                        .text('AI Generated');
                    $saveBtn.prop('disabled', true);
                } else {
                    $saveBtn.prop('disabled', false);
                }
                if (!autoSave) {
                    toast('Alt text generated. Review and save.', 'success');
                }
            } else {
                toast(res.data || ICW.i18n.error, 'error');
            }
        }).fail(function () {
            $genBtn.prop('disabled', false).html(
                '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Generate'
            );
        });
    }

    function saveAlt(id, $el, $saveBtn) {
        $saveBtn.prop('disabled', true).text('Saving…');

        var data = {
            attachment_id: id,
            alt:           $el.find('.icw-field-alt').val(),
            title:         $el.find('.icw-field-title').val(),
            caption:       $el.find('.icw-field-caption').val(),
            description:   $el.find('.icw-field-description').val(),
        };

        ajax('icw_save_image_meta', data).done(function (res) {
            if (res.success) {
                $saveBtn.text('Saved!');
                setTimeout(function () {
                    $saveBtn.prop('disabled', true).html(
                        '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><polyline points="17 21 17 13 7 13 7 21" stroke="currentColor" stroke-width="2"/><polyline points="7 3 7 8 15 8" stroke="currentColor" stroke-width="2"/></svg> Save'
                    );
                }, 2000);
                $el.find('.icw-alt-status-chip')
                    .attr('class', 'icw-alt-status-chip icw-alt-status-generated')
                    .text('AI Generated');
                toast('Image metadata saved.', 'success');
            } else {
                toast(res.data || ICW.i18n.error, 'error');
                $saveBtn.prop('disabled', false).html(
                    '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><polyline points="17 21 17 13 7 13 7 21" stroke="currentColor" stroke-width="2"/><polyline points="7 3 7 8 15 8" stroke="currentColor" stroke-width="2"/></svg> Save'
                );
            }
        }).fail(function () {
            toast(ICW.i18n.error + ': Network error', 'error');
            $saveBtn.prop('disabled', false).text('Save');
        });
    }

    function startBulkGenerate() {
        var $items = $('.icw-alt-item');
        if (!$items.length) {
            toast('No images loaded. Click Load Images first.', 'warning');
            return;
        }

        altBulkRun  = true;
        altBulkStop = false;

        var ids   = [];
        $items.each(function () {
            ids.push(parseInt($(this).data('id'), 10));
        });

        var total = ids.length;
        var done  = 0;
        var errs  = 0;

        $('#icw-alt-bulk-progress').removeClass('hidden');
        $('#icw-bulk-generate-btn').text('Stop Bulk Generate');
        $('#icw-alt-bulk-stop-btn').text('Stop');
        setAltBulkBar(0, '0 / ' + total);

        function processNext() {
            if (altBulkStop || !ids.length) {
                altBulkRun = false;
                $('#icw-alt-bulk-progress').addClass('hidden');
                $('#icw-bulk-generate-btn').text('Bulk Generate All');
                var msg = altBulkStop
                    ? 'Stopped after ' + done + ' images.'
                    : 'Done! ' + done + ' generated, ' + errs + ' errors.';
                toast(msg, errs ? 'warning' : 'success');
                return;
            }

            var id  = ids.shift();
            var $el = $('#icw-alt-item-' + id);

            generateOne(id, $el, true).always(function (res) {
                done++;
                if (!res || !res.success) errs++;
                var pct = Math.round(done / total * 100);
                setAltBulkBar(pct, done + ' / ' + total + ' — ' + pct + '%');
                // Small delay so API isn't hammered
                setTimeout(processNext, 400);
            });
        }

        processNext();
    }

    function setAltBulkBar(pct, label) {
        $('#icw-alt-bulk-bar').css('width', pct + '%');
        $('#icw-alt-bulk-label').text(label);
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    $(function () {
        initToasts();
        if ($('.icw-tabs').length) {
            initTabs();
        }
        initUnusedImages();
        initAltText();
    });

}(jQuery));
