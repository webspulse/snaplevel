/**
 * Snaplevel — Unused images admin view.
 * Requires: window.SNAP_UNUSED localized config.
 */
( function ( $ ) {
	'use strict';

	var CFG           = window.SNAP_UNUSED || {};
	var unusedIds     = [];
	var currentOffset = 0;
	var limit         = CFG.limit || 24;
	var nonce         = CFG.nonce || '';
	var ajaxurl       = CFG.ajaxurl || '';

	$( '#icw-scan-btn' ).on( 'click', function () {
		var $btn = $( this );
		$btn.prop( 'disabled', true ).text( CFG.i18n.scanning );
		$( '#icw-unused-results' ).hide();
		$( '#icw-scan-status' ).show();
		$( '#icw-unused-grid' ).empty();
		$( '#icw-select-all-wrap' ).hide();
		$( '#icw-bulk-trash-btn' ).hide();

		$.post( ajaxurl, { action: 'icw_scan_unused', nonce: nonce, offset: 0, limit: limit }, function ( res ) {
			$( '#icw-scan-status' ).hide();
			$btn.prop( 'disabled', false ).html( CFG.scanBtnHtml );

			if ( res.success ) {
				unusedIds = res.data.unused_ids || [];
				var total = res.data.total || 0;
				$( '#icw-unused-total' ).text( total );

				if ( total === 0 ) {
					$( '#icw-unused-results' ).show();
					$( '#icw-unused-empty' ).show();
				} else {
					$( '#icw-unused-results' ).show();
					$( '#icw-unused-empty' ).hide();
					$( '#icw-select-all-wrap' ).css( 'display', 'flex' );
					$( '#icw-bulk-trash-btn' ).css( 'display', 'inline-flex' );
					appendItems( res.data.items );
					currentOffset = limit;
					$( '#icw-load-more-wrap' ).toggle( total > limit );
				}
			} else {
				alert( 'Scan failed: ' + ( res.data || 'Unknown error' ) );
			}
		} ).fail( function ( xhr ) {
			$( '#icw-scan-status' ).hide();
			$btn.prop( 'disabled', false ).html( CFG.scanBtnHtml );
			alert( 'Scan request failed (Server Error ' + xhr.status + '). This usually means your database is too large and the request timed out.' );
		} );
	} );

	function appendItems( items ) {
		var tpl = $( '#icw-unused-item-tpl' ).html();
		items.forEach( function ( item ) {
			var html = tpl.replace( /{{id}}/g, item.id )
				.replace( /{{thumb}}/g, item.thumb )
				.replace( /{{title}}/g, item.title )
				.replace( /{{mime}}/g, item.mime )
				.replace( /{{filesize}}/g, item.filesize )
				.replace( /{{date}}/g, item.date )
				.replace( /{{url}}/g, item.url );
			$( '#icw-unused-grid' ).append( html );
		} );
		updateSelection();
	}

	$( '#icw-load-more-btn' ).on( 'click', function () {
		var $btn = $( this );
		$btn.prop( 'disabled', true ).text( CFG.i18n.loading );

		$.post( ajaxurl, { action: 'icw_scan_unused', nonce: nonce, offset: currentOffset, limit: limit }, function ( res ) {
			$btn.prop( 'disabled', false ).text( CFG.i18n.loadMore );
			if ( res.success ) {
				appendItems( res.data.items );
				currentOffset += limit;
				if ( currentOffset >= unusedIds.length ) {
					$( '#icw-load-more-wrap' ).hide();
				}
			}
		} );
	} );

	$( document ).on( 'change', '.icw-unused-check', updateSelection );
	$( '#icw-select-all' ).on( 'change', function () {
		$( '.icw-unused-check' ).prop( 'checked', $( this ).prop( 'checked' ) );
		updateSelection();
	} );

	function updateSelection() {
		var selected   = $( '.icw-unused-check:checked' ).length;
		var totalBoxes = $( '.icw-unused-check' ).length;
		$( '#icw-selected-count' ).text( selected );
		$( '#icw-bulk-trash-btn' ).prop( 'disabled', selected === 0 );
		$( '#icw-select-all' ).prop( 'checked', totalBoxes > 0 && selected === totalBoxes );
	}

	$( document ).on( 'click', '.icw-trash-one-btn', function () {
		if ( ! window.confirm( CFG.i18n.confirmOne ) ) {
			return;
		}
		var $btn = $( this );
		var id   = $btn.data( 'id' );
		$btn.prop( 'disabled', true ).css( 'opacity', '0.5' );

		$.post( ajaxurl, { action: 'icw_trash_one_unused', nonce: nonce, attachment_id: id }, function ( res ) {
			if ( res.success ) {
				$( '.icw-unused-item[data-id="' + id + '"]' ).slideUp( function () {
					$( this ).remove();
					updateSelection();
				} );
				var total = parseInt( $( '#icw-unused-total' ).text(), 10 );
				$( '#icw-unused-total' ).text( total - 1 );
			} else {
				alert( 'Failed to trash: ' + res.data );
				$btn.prop( 'disabled', false ).css( 'opacity', '1' );
			}
		} );
	} );

	$( '#icw-bulk-trash-btn' ).on( 'click', function () {
		if ( ! window.confirm( CFG.i18n.confirmBulk ) ) {
			return;
		}
		var ids = [];
		$( '.icw-unused-check:checked' ).each( function () {
			ids.push( $( this ).data( 'id' ) );
		} );
		if ( ! ids.length ) {
			return;
		}

		var $btn    = $( this );
		var btnIdle = $btn.html();
		var failed  = 0;
		$btn.prop( 'disabled', true ).text( CFG.i18n.trashing );

		function trashNext() {
			if ( ! ids.length ) {
				$btn.prop( 'disabled', false ).html( btnIdle );
				updateSelection();
				if ( failed > 0 ) {
					alert( failed + ' images failed to trash (they might be in use).' );
				}
				return;
			}
			var id = ids.shift();
			$( '.icw-unused-item[data-id="' + id + '"]' ).css( 'opacity', '0.5' );
			$.post( ajaxurl, { action: 'icw_trash_one_unused', nonce: nonce, attachment_id: id }, function ( res ) {
				if ( res.success ) {
					$( '.icw-unused-item[data-id="' + id + '"]' ).slideUp( function () {
						$( this ).remove();
						updateSelection();
					} );
					var total = parseInt( $( '#icw-unused-total' ).text(), 10 );
					$( '#icw-unused-total' ).text( total - 1 );
				} else {
					failed++;
					$( '.icw-unused-item[data-id="' + id + '"]' ).css( 'opacity', '1' );
				}
				trashNext();
			} );
		}
		trashNext();
	} );
} )( jQuery );