/**
 * Snaplevel admin app — REST-driven, no jQuery.
 *
 * Every settings screen uses the Rank Math pattern: 200px vertical icon
 * tab nav on the left, white content panel on the right, cmb2-style
 * label/control rows, sticky save bar.
 *
 * Titles & Meta renders one tab per registered public post type and
 * taxonomy (ACF / JetEngine / WooCommerce CPTs included automatically).
 */
/* global SNAP, wp */
( function () {
	'use strict';

	var root = document.getElementById( 'snap-settings-app' );
	if ( ! root || ! window.SNAP ) { return; }

	var apiFetch = wp.apiFetch;
	var PAGE_TAB = root.dataset.tab || 'modules';
	var SINGLE   = [ 'titles', 'schema', 'training' ].indexOf( PAGE_TAB ) !== -1;
	var ICONS    = SNAP.icons || {};

	var PROVIDERS = {
		anthropic: {
			name: 'Claude (Anthropic)', sub: 'console.anthropic.com', placeholder: 'sk-ant-…',
			fast: 'claude-haiku-4-5-20251001', smart: 'claude-sonnet-4-6',
			models: [
				{ id: 'claude-opus-4-8', label: 'Claude Opus 4.8 — 💎 Premium · best quality, highest cost' },
				{ id: 'claude-sonnet-4-6', label: 'Claude Sonnet 4.6 — ⚖️ Balanced · great quality, fair price' },
				{ id: 'claude-haiku-4-5-20251001', label: 'Claude Haiku 4.5 — 🪙 Budget · fast and very cheap' }
			]
		},
		openai: {
			name: 'ChatGPT (OpenAI)', sub: 'platform.openai.com', placeholder: 'sk-…',
			fast: 'gpt-4o-mini', smart: 'gpt-4o',
			models: [
				{ id: 'gpt-4o', label: 'GPT-4o — 💎 Premium · best quality' },
				{ id: 'gpt-4o-mini', label: 'GPT-4o mini — 🪙 Budget · fast and very cheap' }
			]
		},
		gemini: {
			name: 'Google Gemini', sub: 'aistudio.google.com', placeholder: 'AIza…',
			fast: 'gemini-2.5-flash', smart: 'gemini-2.5-pro',
			models: [
				{ id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro — 💎 Premium · best quality' },
				{ id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash — 🪙 Budget · fast and cheap' }
			]
		},
		deepseek: {
			name: 'DeepSeek', sub: 'platform.deepseek.com', placeholder: 'sk-…',
			fast: 'deepseek-chat', smart: 'deepseek-chat',
			models: [
				{ id: 'deepseek-reasoner', label: 'DeepSeek Reasoner — 💎 Premium · deeper thinking' },
				{ id: 'deepseek-chat', label: 'DeepSeek Chat — 🪙 Budget · fast and very cheap' }
			]
		},
		mistral: {
			name: 'Mistral AI', sub: 'console.mistral.ai', placeholder: '…',
			fast: 'mistral-small-latest', smart: 'mistral-large-latest',
			models: [
				{ id: 'mistral-large-latest', label: 'Mistral Large — 💎 Premium · best quality' },
				{ id: 'mistral-medium-latest', label: 'Mistral Medium — ⚖️ Balanced' },
				{ id: 'mistral-small-latest', label: 'Mistral Small — 🪙 Budget · fast and cheap' }
			]
		}
	};

	var VARIABLES = [ '%title%', '%sitename%', '%sitedesc%', '%sep%', '%excerpt%', '%category%', '%date%', '%name%', '%term%', '%page%', '%currentdate%', '%currentyear%' ];

	var state = { settings: null, tab: getUrlTab() || PAGE_TAB, subtab: '', training: null, sources: null };

	function getUrlTab() {
		var m = window.location.search.match( /[?&]tab=([a-z_]+)/ );
		return m ? m[ 1 ] : '';
	}

	function toast( msg, isError ) {
		var t = document.createElement( 'div' );
		t.className = 'snap-toast';
		if ( isError ) { t.style.background = '#e93f30'; }
		t.textContent = msg;
		document.body.appendChild( t );
		setTimeout( function () { t.remove(); }, 3500 );
	}

	function h( tag, attrs, children ) {
		var node = document.createElement( tag );
		attrs = attrs || {};
		Object.keys( attrs ).forEach( function ( k ) {
			if ( k === 'class' ) { node.className = attrs[ k ]; }
			else if ( k === 'html' ) { node.innerHTML = attrs[ k ]; }
			else if ( k.indexOf( 'on' ) === 0 ) { node.addEventListener( k.slice( 2 ), attrs[ k ] ); }
			else if ( k === 'checked' || k === 'disabled' || k === 'selected' ) { if ( attrs[ k ] ) { node[ k ] = true; } }
			else { node.setAttribute( k, attrs[ k ] ); }
		} );
		( children || [] ).forEach( function ( c ) {
			if ( c === null || c === undefined ) { return; }
			node.appendChild( typeof c === 'string' ? document.createTextNode( c ) : c );
		} );
		return node;
	}

	function icon( id, cls ) {
		return h( 'span', { class: 'snap-icon' + ( cls ? ' ' + cls : '' ), html: ICONS[ id ] || ICONS.grid || '' } );
	}

	function textInput( value, onInput, attrs ) {
		attrs = attrs || {};
		attrs.class = attrs.class || 'snap-input';
		attrs.type = attrs.type || 'text';
		attrs.value = value || '';
		var node = h( 'input', attrs );
		node.addEventListener( 'input', function () { onInput( node.value ); } );
		return node;
	}

	/* Rank Math cmb2 toggle with On/Off labels (spec 5). */
	function toggle( checked, onChange, disabled ) {
		var input = h( 'input', { type: 'checkbox', checked: checked, disabled: disabled } );
		input.addEventListener( 'change', function () { onChange( input.checked ); } );
		return h( 'label', { class: 'snap-toggle' }, [
			input,
			h( 'span', { class: 'snap-slider' }, [
				h( 'span', { class: 'toggle_on' }, [ 'On' ] ),
				h( 'span', { class: 'toggle_off' }, [ 'Off' ] )
			] )
		] );
	}

	function toggleRow( label, checked, onChange ) {
		return h( 'div', { style: 'display:flex;gap:10px;align-items:center;margin-bottom:10px' }, [ toggle( checked, onChange ), label ] );
	}

	function tip( text ) {
		return h( 'span', { class: 'snap-tip dashicons-before dashicons-admin-comments', tabindex: '0', 'data-tip': text, style: 'margin-left:6px;font-size:16px;color:var(--snap-text-muted);cursor:help;' }, [] );
	}

	/* cmb2 field row: 200px label column + control column (spec 6.3). */
	function row( name, content, opts ) {
		opts = opts || {};
		return h( 'div', { class: 'snap-row' + ( opts.advanced ? ' snap-advanced-option' : '' ) }, [
			h( 'div', { class: 'snap-th' }, [ h( 'label', null, [ name, opts.tip ? tip( opts.tip ) : null ] ) ] ),
			h( 'div', { class: 'snap-td' }, ( Array.isArray( content ) ? content : [ content ] ).concat(
				opts.help ? [ h( 'p', { class: 'snap-field-desc snap-help' }, [ opts.help ] ) ] : []
			) )
		] );
	}

	/* Template input + clickable variable chips. */
	function templateInput( value, onInput, placeholder ) {
		var input = textInput( value, onInput, { placeholder: placeholder || '' } );
		var chips = h( 'div', { class: 'snap-vars' }, VARIABLES.map( function ( v ) {
			return h( 'span', {
				class: 'snap-var-chip',
				onclick: function () {
					input.value = ( input.value + ' ' + v ).trim();
					input.dispatchEvent( new Event( 'input' ) );
				}
			}, [ v ] );
		} ) );
		return h( 'div', null, [ input, chips ] );
	}

	function saveBar( onSave, label ) {
		var btn = h( 'button', { class: 'snap-btn snap-btn-primary', onclick: function () { onSave( btn ); } }, [ label || 'Save Changes' ] );
		return h( 'div', { class: 'snap-save-bar' }, [
			btn,
			h( 'span', { class: 'snap-muted', style: 'font-size:12px' }, [ 'Changes apply site-wide immediately after saving.' ] )
		] );
	}

	function save( partial, cb ) {
		apiFetch( { path: '/snaplevel/v1/settings', method: 'POST', data: partial } )
			.then( function ( res ) {
				state.settings = res;
				toast( 'Saved.' );
				if ( cb ) { cb( res ); }
			} )
			.catch( function ( err ) { toast( ( err && err.message ) || 'Save failed.', true ); } );
	}

	/* Generic vertical-tab shell (Rank Math settings layout, spec 6.1). */
	function vtabs( tabs, activeId, onPick, panel ) {
		var navChildren = [];
		tabs.forEach( function ( t ) {
			if ( t.group ) {
				navChildren.push( h( 'div', { class: 'snap-vtabs-group' }, [ t.group ] ) );
				return;
			}
			navChildren.push( h( 'button', {
				class: 'snap-vtab' + ( activeId === t.id ? ' is-active' : '' ) + ( t.advanced ? ' snap-advanced-option' : '' ),
				onclick: function () { onPick( t.id ); }
			}, [ icon( t.icon || 'grid' ), t.label ] ) );
		} );
		return h( 'div', { class: 'snap-vtabs' }, [
			h( 'div', { class: 'snap-vtabs-nav' }, navChildren ),
			h( 'div', { class: 'snap-vtabs-panel' }, [ panel ] )
		] );
	}

	// ── Modules ──────────────────────────────────────────────────────────────

	function renderModules() {
		var meta = state.settings.modules_meta || {};
		var cards = Object.keys( meta ).map( function ( id ) {
			var m = meta[ id ];
			return h( 'div', { class: 'snap-module-card' + ( m.enabled ? ' active' : ' is-off' ) }, [
				icon( m.icon || 'grid', 'snap-module-icon' ),
				h( 'header', null, [
					h( 'h3', null, [ m.name, m.always_on ? h( 'span', { class: 'snap-core-badge' }, [ 'Core' ] ) : null ] ),
					h( 'p', null, [ m.desc || '' ] )
				] ),
				h( 'div', { class: 'snap-module-status' }, [
					h( 'span', null, [] ),
					toggle( m.enabled, function ( on ) {
						apiFetch( { path: '/snaplevel/v1/modules/toggle', method: 'POST', data: { module: id, state: on } } )
							.then( function () { toast( m.name + ( on ? ' enabled.' : ' disabled.' ) ); render(); } )
							.catch( function ( err ) { toast( ( err && err.message ) || 'Failed.', true ); } );
					}, m.always_on )
				] )
			] );
		} );
		return h( 'div', { class: 'snap-module-listing' }, [ h( 'div', { class: 'snap-module-grid' }, cards ) ] );
	}

	// ── AI settings ──────────────────────────────────────────────────────────

	/** Model picker: Auto (recommended) + the provider's models with price tiers. */
	function modelSelect( current, pconf, autoModel, onChange ) {
		var sel = h( 'select', { class: 'snap-select', style: 'max-width:480px' } );
		var opts = [ { id: '', label: 'Auto (recommended) — ' + autoModel } ].concat( pconf.models || [] );
		var known = opts.some( function ( o ) { return o.id === ( current || '' ); } );
		if ( ! known && current ) { opts.push( { id: current, label: current + ' — custom' } ); }
		opts.forEach( function ( o ) {
			var opt = document.createElement( 'option' );
			opt.value = o.id;
			opt.textContent = o.label;
			if ( ( current || '' ) === o.id ) { opt.selected = true; }
			sel.appendChild( opt );
		} );
		sel.addEventListener( 'change', function () { onChange( sel.value ); } );
		return sel;
	}

	function renderAI() {
		var s = state.settings;
		var provider = PROVIDERS[ s.ai.provider ] ? s.ai.provider : 'anthropic';
		var draft = { api_key: '' };

		function maskedKey( id ) {
			return id === 'anthropic' ? s.ai.api_key_masked : s.ai[ 'api_key_' + id + '_masked' ];
		}

		var pick = h( 'div', { class: 'snap-provider-pick' }, Object.keys( PROVIDERS ).map( function ( id ) {
			var p = PROVIDERS[ id ];
			var masked = maskedKey( id );
			return h( 'button', {
				type: 'button',
				class: provider === id ? 'is-selected' : '',
				onclick: function () {
					save( { ai: { provider: id } }, function () { render(); } );
				}
			}, [
				p.name,
				h( 'span', { class: 'snap-provider-sub' }, [ masked ? 'Key saved: ' + masked : 'No key yet · ' + p.sub ] )
			] );
		} ) );

		var pconf  = PROVIDERS[ provider ];
		var masked = maskedKey( provider );

		var keyInput = textInput( '', function ( v ) { draft.api_key = v; }, {
			type: 'password',
			placeholder: masked ? 'Saved: ' + masked + ' — paste a new key to replace' : pconf.placeholder,
			autocomplete: 'new-password'
		} );

		var testBtn = h( 'button', { class: 'snap-btn snap-btn-ai', onclick: function () {
			if ( ! draft.api_key && ! masked ) { toast( 'Paste your ' + pconf.name + ' API key first.', true ); return; }
			testBtn.disabled = true;
			testBtn.innerHTML = '<span class="snap-spinner"></span> Testing…';
			apiFetch( { path: '/snaplevel/v1/ai/test', method: 'POST', data: { provider: provider, api_key: draft.api_key } } )
				.then( function ( res ) {
					testBtn.disabled = false;
					testBtn.textContent = 'Test & save key';
					toast( res.message || 'Connection successful.' );
					apiFetch( { path: '/snaplevel/v1/settings' } ).then( function ( r ) { state.settings = r; render(); } );
				} )
				.catch( function ( err ) {
					testBtn.disabled = false;
					testBtn.textContent = 'Test & save key';
					toast( ( err && err.message ) || 'Connection failed.', true );
				} );
		} }, [ 'Test & save key' ] );

		var usage = h( 'div', { id: 'snap-usage', class: 'snap-muted' }, [ 'Loading…' ] );
		apiFetch( { path: '/snaplevel/v1/ai/usage' } ).then( function ( u ) {
			usage.className = ''; usage.innerHTML = '';
			usage.appendChild( h( 'div', { style: 'display:flex;gap:32px' }, [
				h( 'div', null, [ h( 'div', { class: 'snap-stat-value' }, [ String( u.month.calls ) ] ), h( 'div', { class: 'snap-stat-label' }, [ 'AI calls' ] ) ] ),
				h( 'div', null, [ h( 'div', { class: 'snap-stat-value' }, [ String( u.month.tokens_in + u.month.tokens_out ) ] ), h( 'div', { class: 'snap-stat-label' }, [ 'Tokens' ] ) ] ),
				h( 'div', null, [ h( 'div', { class: 'snap-stat-value' }, [ '$' + u.month.cost.toFixed( 2 ) ] ), h( 'div', { class: 'snap-stat-label' }, [ 'Estimated cost' ] ) ] )
			] ) );
		} ).catch( function () {} );

		return h( 'div', null, [
			row( 'AI provider', [
				h( 'p', { class: 'snap-muted', style: 'margin-top:0' }, [ 'Pick Claude, ChatGPT, Gemini, DeepSeek, or Mistral — every AI feature works with all of them. Keys are stored encrypted.' ] ),
				pick
			] ),
			row( pconf.name + ' API key', [ keyInput, h( 'div', { style: 'margin-top:10px' }, [ testBtn ] ) ], { help: 'Get a key at ' + pconf.sub } ),
			row( 'Fast model (bulk tasks)', modelSelect( s.ai.model_fast, pconf, pconf.fast, function ( v ) { s.ai.model_fast = v; } ), { tip: 'Bulk operations model.', help: 'Used for titles, descriptions, keywords, and alt text. Auto picks the best value model.' } ),
			row( 'Smart model (analysis & schema)', modelSelect( s.ai.model_smart, pconf, pconf.smart, function ( v ) { s.ai.model_smart = v; } ), { tip: 'Reasoning model.', help: 'Used for schema generation and content analysis. Auto picks a higher-quality model.' } ),
			row( 'Context keywords', textInput( s.ai.keywords, function ( v ) { s.ai.keywords = v; } ), { tip: 'Global target keywords.', help: 'Comma-separated. Woven into alt text and meta where natural.' } ),
			row( 'Knowledge budget per call', textInput( String( s.ai.training_budget || 8000 ), function ( v ) { s.ai.training_budget = parseInt( v, 10 ) || 0; }, { type: 'number', min: '0', max: '30000', style: 'max-width:140px' } ), { advanced: true, tip: 'Max characters of training context.', help: 'Characters of your AI Training knowledge injected into each prompt.' } ),
			row( 'Auto mode (per task)', [
				h( 'p', { class: 'snap-muted', style: 'margin-top:0' }, [ 'Off by default. When on, Snaplevel generates the field on publish if it is empty.' ] ),
				toggleRow( 'SEO titles', !! ( s.ai.auto_modes && s.ai.auto_modes.seo_title ), function ( on ) { s.ai.auto_modes = s.ai.auto_modes || {}; s.ai.auto_modes.seo_title = on; } ),
				toggleRow( 'Meta descriptions', !! ( s.ai.auto_modes && s.ai.auto_modes.meta_description ), function ( on ) { s.ai.auto_modes = s.ai.auto_modes || {}; s.ai.auto_modes.meta_description = on; } )
			] ),
			row( 'Usage this month', usage ),
			saveBar( function () {
				save( { ai: { model_fast: s.ai.model_fast, model_smart: s.ai.model_smart, keywords: s.ai.keywords, training_budget: s.ai.training_budget, auto_modes: s.ai.auto_modes || {} } } );
			}, 'Save AI Settings' )
		] );
	}

	// ── Titles & Meta — Rank Math layout: one tab per post type/taxonomy ─────

	function titlesTabs() {
		var ct   = state.settings.content_types || { post_types: {}, taxonomies: {} };
		var tabs = [
			{ id: 'global',   label: 'Global Meta', icon: 'globe' },
			{ id: 'homepage', label: 'Homepage',    icon: 'home' },
			{ id: 'authors',  label: 'Authors',     icon: 'user' },
			{ id: 'misc',     label: 'Misc Pages',  icon: 'file' }
		];

		var ptIcons = { post: 'pin', page: 'file-text', product: 'cart' };
		var pts = Object.keys( ct.post_types );
		if ( pts.length ) {
			tabs.push( { group: 'Post Types:' } );
			pts.forEach( function ( slug ) {
				tabs.push( { id: 'pt:' + slug, label: ct.post_types[ slug ].label, icon: ptIcons[ slug ] || 'folder' } );
			} );
		}
		var txs = Object.keys( ct.taxonomies );
		if ( txs.length ) {
			tabs.push( { group: 'Taxonomies:' } );
			txs.forEach( function ( slug ) {
				tabs.push( { id: 'tax:' + slug, label: ct.taxonomies[ slug ].label, icon: ct.taxonomies[ slug ].hierarchical ? 'folder' : 'tag' } );
			} );
		}
		return tabs;
	}

	function serpPreview( titleTpl, descTpl, label ) {
		var siteName = ( window.SNAP && SNAP.siteName ) || document.title;
		var demo = function ( tpl, fallback ) {
			return ( tpl || fallback )
				.replace( /%title%/g, 'Sample ' + ( label || 'Post' ) + ' Title' )
				.replace( /%sitename%/g, siteName )
				.replace( /%sitedesc%/g, 'Just another WordPress site' )
				.replace( /%sep%/g, ( state.settings.titles.separator || '–' ) )
				.replace( /%excerpt%/g, 'This is how the description preview will appear in Google search results.' )
				.replace( /%[a-z_]+%/g, '' ).replace( /\s+/g, ' ' ).trim();
		};
		return h( 'div', { class: 'snap-serp' }, [
			h( 'div', { class: 'snap-serp-url' }, [ ( SNAP.adminUrl || '' ).replace( /wp-admin\/?$/, '' ) + 'sample-' + ( label || 'post' ).toLowerCase().replace( /\s+/g, '-' ) ] ),
			h( 'div', { class: 'snap-serp-title' }, [ demo( titleTpl, '%title% %sep% %sitename%' ) ] ),
			h( 'div', { class: 'snap-serp-desc' }, [ demo( descTpl, '%excerpt%' ) ] )
		] );
	}

	function titlesPanel( tabId ) {
		var t  = state.settings.titles;
		var ct = state.settings.content_types || { post_types: {}, taxonomies: {} };

		function doSave() { save( { titles: t } ); }

		if ( tabId === 'global' ) {
			return h( 'div', null, [
				row( 'Title separator', textInput( t.separator, function ( v ) { t.separator = v; }, { style: 'max-width:80px' } ), { help: 'Used by the %sep% variable: – — | » /' } ),
				row( 'Noindex empty archives', toggleRow( 'Set empty category and tag archives to noindex', !! t.noindex_empty_archives, function ( on ) { t.noindex_empty_archives = on; } ), { advanced: true, help: 'Avoids indexation of thin content pages and dilution of page rank. The page flips back to index as soon as a post is added.' } ),
				saveBar( doSave )
			] );
		}

		if ( tabId === 'homepage' ) {
			return h( 'div', null, [
				row( 'Homepage title', templateInput( t.home_title, function ( v ) { t.home_title = v; render(); }, '%sitename% %sep% %sitedesc%' ) ),
				row( 'Homepage description', templateInput( t.home_desc, function ( v ) { t.home_desc = v; render(); }, '' ) ),
				row( 'Preview', serpPreview( t.home_title || '%sitename% %sep% %sitedesc%', t.home_desc, 'Homepage' ) ),
				saveBar( doSave )
			] );
		}

		if ( tabId === 'authors' ) {
			return h( 'div', null, [
				row( 'Author archive title', templateInput( t.archive_author, function ( v ) { t.archive_author = v; }, '%name% %sep% %sitename%' ) ),
				saveBar( doSave )
			] );
		}

		if ( tabId === 'misc' ) {
			return h( 'div', null, [
				row( 'Date archive title', templateInput( t.archive_date, function ( v ) { t.archive_date = v; }, '%date% %sep% %sitename%' ) ),
				row( 'Search results title', templateInput( t.archive_search, function ( v ) { t.archive_search = v; }, 'Search: %term% %sep% %sitename%' ) ),
				row( '404 title', templateInput( t.archive_404, function ( v ) { t.archive_404 = v; }, 'Page not found %sep% %sitename%' ) ),
				saveBar( doSave )
			] );
		}

		var m = tabId.match( /^(pt|tax):(.+)$/ );
		if ( m ) {
			var group = m[ 1 ] === 'pt' ? 'post_types' : 'taxonomies';
			var slug  = m[ 2 ];
			var meta  = ( m[ 1 ] === 'pt' ? ct.post_types : ct.taxonomies )[ slug ] || { label: slug, singular: slug };
			t[ group ] = t[ group ] || {};
			t[ group ][ slug ] = t[ group ][ slug ] || { title: '', desc: '', noindex: false };
			var conf = t[ group ][ slug ];

			var rows = [
				row( meta.singular + ' title template', templateInput( conf.title, function ( v ) { conf.title = v; }, '%title% %sep% %sitename%' ), { help: 'Default title shown in search results when no custom SEO title is set in the editor.' } ),
				row( meta.singular + ' description template', templateInput( conf.desc, function ( v ) { conf.desc = v; }, '%excerpt%' ), { help: 'Per-' + ( meta.singular || slug ).toLowerCase() + ' values from the editor always win.' } ),
				row( 'Robots meta', toggleRow( 'noindex ' + meta.label.toLowerCase(), !! conf.noindex, function ( on ) { conf.noindex = on; } ), { advanced: true, help: 'Prevents search engines from indexing this content type entirely.' } ),
				row( 'Preview', serpPreview( conf.title, conf.desc, meta.singular ) ),
				saveBar( doSave )
			];

			if ( m[ 1 ] === 'pt' && meta.taxonomies && meta.taxonomies.length ) {
				rows.splice( 3, 0, row( 'Attached taxonomies', h( 'p', { class: 'snap-muted', style: 'margin:6px 0 0' }, [ meta.taxonomies.join( ', ' ) ] ), { advanced: true } ) );
			}
			return h( 'div', null, rows );
		}

		return h( 'div', null, [ 'Unknown tab.' ] );
	}

	function renderTitles() {
		var tabs = titlesTabs();
		if ( ! state.subtab || ! tabs.some( function ( t ) { return t.id === state.subtab; } ) ) {
			state.subtab = 'global';
		}
		return vtabs( tabs, state.subtab, function ( id ) { state.subtab = id; render(); }, titlesPanel( state.subtab ) );
	}

	// ── Schema ───────────────────────────────────────────────────────────────

	function renderSchema() {
		var sc = state.settings.schema || { site_type: 'organization', name: '', logo: '', social: '' };

		var typeSelect = h( 'select', { class: 'snap-select', style: 'max-width:280px' }, [
			h( 'option', { value: 'organization', selected: sc.site_type !== 'person' }, [ 'Organization' ] ),
			h( 'option', { value: 'person', selected: sc.site_type === 'person' }, [ 'Person' ] )
		] );
		typeSelect.addEventListener( 'change', function () { sc.site_type = typeSelect.value; } );

		return h( 'div', null, [
			h( 'div', { class: 'snap-box' }, [
				h( 'div', { class: 'snap-box-title' }, [ icon( 'schema' ), 'Site-level schema (JSON-LD)' ] ),
				h( 'p', { class: 'snap-muted' }, [ 'Output on your homepage: Organization or Person, plus WebSite with SearchAction. Per-post schema is generated with AI right in the editor.' ] ),
				row( 'This site represents', typeSelect ),
				row( 'Name', textInput( sc.name, function ( v ) { sc.name = v; }, { placeholder: 'Defaults to the site name' } ) ),
				row( 'Logo / image URL', textInput( sc.logo, function ( v ) { sc.logo = v; }, { type: 'url' } ) ),
				row( 'Social profile URLs', textInput( sc.social, function ( v ) { sc.social = v; } ), { help: 'Comma-separated: Facebook, X, LinkedIn, Instagram, YouTube…' } ),
				h( 'div', { style: 'margin-top:16px' }, [ h( 'button', { class: 'snap-btn snap-btn-primary', onclick: function () { save( { schema: sc } ); } }, [ 'Save Schema Settings' ] ) ] )
			] ),
			h( 'div', { class: 'snap-box' }, [
				h( 'div', { class: 'snap-box-title' }, [ icon( 'sparkle' ), 'Per-post schema' ] ),
				h( 'p', null, [ 'Open any post or product and press ', h( 'strong', null, [ 'Generate schema with AI' ] ), '. The AI reads the content and builds the right type automatically — Article, Product, FAQ, Recipe, HowTo, Event and more.' ] ),
				h( 'p', { class: 'snap-muted' }, [ 'Validate output with Google\'s Rich Results Test after publishing.' ] )
			] )
		] );
	}

	// ── AI Training (manual knowledge + self-training) ──────────────────────

	function loadTraining( then ) {
		apiFetch( { path: '/snaplevel/v1/training' } ).then( function ( res ) {
			state.training = res;
			then();
		} ).catch( function () { state.training = { docs: [], total: 0, limit: 0, error: true }; then(); } );
	}

	function renderSelfTraining() {
		var s  = state.settings;
		var on = s.ai.self_training !== false;

		var sources = [
			{ name: 'Google Search Central Blog', what: 'Official algorithm rollouts, core updates, documentation changes' },
			{ name: 'Google Search Status Dashboard', what: 'Live crawling / indexing / serving incidents' },
			{ name: 'The Keyword (Google Blog)', what: 'AI Search & consumer feature announcements' },
			{ name: 'Ahrefs Blog', what: 'Technical SEO workflows and data studies' },
			{ name: 'Search Engine Land', what: 'AEO & GEO experiments and industry news' },
			{ name: 'Search Engine Journal', what: 'SEO news and practical guides' }
		];

		var updateBtn = h( 'button', { class: 'snap-btn snap-btn-ai-soft snap-btn-sm', onclick: function () {
			updateBtn.disabled = true;
			updateBtn.innerHTML = '<span class="snap-spinner snap-spinner-dark"></span> Fetching latest SEO knowledge…';
			apiFetch( { path: '/snaplevel/v1/training/self-update', method: 'POST' } )
				.then( function ( res ) {
					updateBtn.disabled = false;
					updateBtn.textContent = 'Update knowledge now';
					toast( res.message || 'Self-training updated.' );
					state.training = null;
					render();
				} )
				.catch( function ( err ) {
					updateBtn.disabled = false;
					updateBtn.textContent = 'Update knowledge now';
					toast( ( err && err.message ) || 'Update failed.', true );
				} );
		} }, [ 'Update knowledge now' ] );

		return h( 'div', { class: 'snap-box' }, [
			h( 'div', { class: 'snap-flex-between' }, [
				h( 'div', { class: 'snap-box-title', style: 'margin:0' }, [ icon( 'feed', 'snap-anim-pulse' ), 'Self-training — keeps your AI teammate current (on by default)' ] ),
				toggle( on, function ( v ) { s.ai.self_training = v; save( { ai: { self_training: v } } ); } )
			] ),
			h( 'p', { class: 'snap-muted' }, [ 'Your AI teammate ships with a built-in SEO / AEO / GEO playbook and refreshes itself weekly from official sources. Every generation benefits automatically — no manual setup required. This is the baseline "employee training" that makes the entire Opportunity Stream and Copilot feel smart and up-to-date.' ] ),
			h( 'div', { class: 'snap-table-wrap', style: 'border:1px solid var(--snap-border-light);border-radius:6px;overflow:hidden;margin:12px 0' }, [
				h( 'table', { class: 'snap-table' }, [
					h( 'thead', null, [ h( 'tr', null, [ h( 'th', null, [ 'Source' ] ), h( 'th', null, [ 'What it teaches the AI' ] ) ] ) ] ),
					h( 'tbody', null, sources.map( function ( src ) {
						return h( 'tr', null, [
							h( 'td', null, [ h( 'strong', null, [ src.name ] ) ] ),
							h( 'td', { class: 'snap-muted' }, [ src.what ] )
						] );
					} ) )
				] )
			] ),
			h( 'div', { class: 'snap-flex', style: 'gap:12px' }, [
				updateBtn,
				h( 'span', { class: 'snap-muted', style: 'font-size:12px' }, [ 'Runs automatically every week via WP-Cron.' ] )
			] )
		] );
	}

	function renderTraining() {
		if ( ! state.training ) {
			loadTraining( render );
			return h( 'div', { class: 'snap-skeleton', style: 'height:220px' } );
		}

		var tr = state.training;
		var pct = tr.limit ? Math.min( 100, Math.round( tr.total / tr.limit * 100 ) ) : 0;
		var editing = { id: 0, title: '', content: '' };

		var titleInput = textInput( '', function ( v ) { editing.title = v; }, { placeholder: 'e.g. Brand voice, Products, Services, Audience, FAQ' } );
		var contentArea = h( 'textarea', { class: 'snap-textarea', rows: '10', placeholder: 'Paste everything you have: who you are, what you sell, your tone of voice, your customers, your locations, your FAQs. You can also write commands the AI must always follow, e.g. "Always mention free shipping" or "Never use exclamation marks". The more you add, the more on-brand every AI generation becomes.' } );
		var counter = h( 'div', { class: 'snap-help' }, [ '0 characters' ] );
		contentArea.addEventListener( 'input', function () {
			editing.content = contentArea.value;
			counter.textContent = contentArea.value.length.toLocaleString() + ' characters';
		} );

		var saveBtn = h( 'button', { class: 'snap-btn snap-btn-ai', onclick: function () {
			if ( ! editing.content.trim() ) { toast( 'Paste some content first.', true ); return; }
			saveBtn.disabled = true;
			apiFetch( { path: '/snaplevel/v1/training', method: 'POST', data: { id: editing.id, title: editing.title, content: editing.content } } )
				.then( function ( res ) {
					state.training = res;
					toast( 'Knowledge saved. AI will use it from the next generation.' );
					render();
				} )
				.catch( function ( err ) { saveBtn.disabled = false; toast( ( err && err.message ) || 'Save failed.', true ); } );
		} }, [ 'Save to knowledge base' ] );

		var docsList = ( tr.docs || [] ).map( function ( doc ) {
			return h( 'div', { class: 'snap-box snap-flex-between', style: 'padding:16px 20px' }, [
				h( 'div', null, [
					h( 'div', { style: 'font-weight:600;color:var(--snap-text-dark)' }, [ doc.title ] ),
					h( 'div', { class: 'snap-muted', style: 'font-size:12px' }, [
						Number( doc.chars ).toLocaleString() + ' characters · updated ' + ( doc.updated || '' )
					] )
				] ),
				h( 'div', { style: 'display:flex;gap:8px;flex:none' }, [
					h( 'button', { class: 'snap-btn snap-btn-secondary snap-btn-sm', onclick: function () {
						editing.id = parseInt( doc.id, 10 );
						editing.title = doc.title;
						editing.content = doc.content;
						titleInput.value = doc.title;
						contentArea.value = doc.content;
						counter.textContent = doc.content.length.toLocaleString() + ' characters';
						window.scrollTo( { top: 0, behavior: 'smooth' } );
					} }, [ 'Edit' ] ),
					h( 'button', { class: 'snap-btn snap-btn-danger snap-btn-sm', onclick: function () {
						if ( ! window.confirm( 'Delete this document from the knowledge base?' ) ) { return; }
						apiFetch( { path: '/snaplevel/v1/training/' + doc.id, method: 'DELETE' } )
							.then( function ( res ) { state.training = res; render(); toast( 'Deleted.' ); } )
							.catch( function () { toast( 'Delete failed.', true ); } );
					} }, [ 'Delete' ] )
				] )
			] );
		} );

		return h( 'div', null, [
			renderSelfTraining(),
			h( 'div', { class: 'snap-box' }, [
				h( 'div', { class: 'snap-box-title' }, [ icon( 'brain' ), 'Train the AI on your business' ] ),
				h( 'p', { class: 'snap-muted' }, [ 'Everything you save here is injected into every AI generation — titles, descriptions, keywords, schema. Limit: ' + Number( tr.limit ).toLocaleString() + ' characters (≈100,000 words).' ] ),
				h( 'div', { class: 'snap-field' }, [ h( 'label', null, [ 'Document title' ] ), titleInput ] ),
				h( 'div', { class: 'snap-field' }, [ h( 'label', null, [ 'Knowledge & commands' ] ), contentArea, counter ] ),
				saveBtn
			] ),
			h( 'div', { class: 'snap-box' }, [
				h( 'div', { class: 'snap-box-title' }, [ 'Knowledge base usage' ] ),
				h( 'div', { class: 'snap-progress', style: 'margin-bottom:8px' }, [ h( 'div', { class: 'snap-progress-bar', style: 'width:' + pct + '%' } ) ] ),
				h( 'p', { class: 'snap-muted', style: 'margin:0' }, [ Number( tr.total ).toLocaleString() + ' / ' + Number( tr.limit ).toLocaleString() + ' characters used (' + pct + '%)' ] )
			] ),
			docsList.length
				? h( 'div', null, docsList )
				: h( 'div', { class: 'snap-box snap-empty' }, [
					h( 'span', { class: 'snap-empty-icon', html: ICONS.brain || '' } ),
					h( 'strong', null, [ 'No custom knowledge yet.' ] ),
					h( 'p', { style: 'margin:0' }, [ 'Paste your first document above — brand voice and product info are the highest-impact starting points.' ] )
				] )
		] );
	}

	// ── Sitemap / Compression ────────────────────────────────────────────────

	function renderSitemap() {
		var s = state.settings;
		s.sitemap.post_types = s.sitemap.post_types || {};
		if ( Array.isArray( s.sitemap.post_types ) ) { s.sitemap.post_types = {}; }
		s.sitemap.taxonomies = s.sitemap.taxonomies || {};
		if ( Array.isArray( s.sitemap.taxonomies ) ) { s.sitemap.taxonomies = {}; }
		var ct = s.content_types || { post_types: {}, taxonomies: {} };

		function contentToggles( group, labelFallback ) {
			var slugs = Object.keys( ct[ group ] || {} );
			if ( ! slugs.length ) { return h( 'p', { class: 'snap-muted' }, [ 'None found.' ] ); }
			return h( 'div', null, slugs.map( function ( slug ) {
				var label = ( ct[ group ][ slug ] && ct[ group ][ slug ].label ) || slug;
				var on = ! ( slug in s.sitemap[ group ] ) || false !== s.sitemap[ group ][ slug ];
				return toggleRow( label + ' (' + slug + ')', on, function ( v ) { s.sitemap[ group ][ slug ] = v; } );
			} ) );
		}

		return h( 'div', null, [
			row( 'Sitemap URL', h( 'a', { href: ( window.location.origin || '' ) + '/sitemap_index.xml', target: '_blank' }, [ '/sitemap_index.xml' ] ) ),
			row( 'Post types in sitemap', contentToggles( 'post_types' ), { help: 'Turn a post type off to remove it from the sitemap entirely.' } ),
			row( 'Taxonomies in sitemap', contentToggles( 'taxonomies' ), { help: 'Category and tag archive pages.' } ),
			row( 'URLs per sitemap', textInput( String( s.sitemap.per_page ), function ( v ) { s.sitemap.per_page = parseInt( v, 10 ) || 1000; }, { type: 'number', min: '100', max: '5000', style: 'max-width:120px' } ), { advanced: true, help: 'Max number of links on each sitemap page.' } ),
			row( 'IndexNow', toggleRow( 'Ping IndexNow on publish (Bing & others)', !! s.sitemap.indexnow, function ( on ) { s.sitemap.indexnow = on; } ) ),
			saveBar( function () { save( { sitemap: s.sitemap } ); }, 'Save Sitemap Settings' )
		] );
	}

	function renderCompression() {
		var c = state.settings.compression;
		return h( 'div', null, [
			row( 'Quality (50–100)', textInput( String( c.quality ), function ( v ) { c.quality = parseInt( v, 10 ) || 82; }, { type: 'number', min: '50', max: '100', style: 'max-width:120px' } ) ),
			row( 'WebP', toggleRow( 'Convert to WebP', !! c.convert_to_webp, function ( on ) { c.convert_to_webp = on; } ) ),
			row( 'Backups', toggleRow( 'Backup originals', !! c.backup_originals, function ( on ) { c.backup_originals = on; } ) ),
			row( 'On upload', toggleRow( 'Compress automatically on upload', !! c.auto_on_upload, function ( on ) { c.auto_on_upload = on; } ) ),
			saveBar( function () { save( { compression: c } ); }, 'Save Compression Settings' )
		] );
	}

	// ── LLMs.txt ─────────────────────────────────────────────────────────────

	function renderLLMs() {
		var s = state.settings;
		s.llms = s.llms || { enabled: true, content: '' };

		var area = h( 'textarea', { class: 'snap-textarea', rows: '18', style: 'font-family:Consolas,Monaco,monospace;font-size:12.5px', placeholder: '# Your Site Name\n> One dense, objective description of what your site does.\n\n## Core Pages\n* [Page Title](https://yoursite.com/page): What user intent this page answers.' } );
		area.value = s.llms.content || '';
		area.addEventListener( 'input', function () { s.llms.content = area.value; } );

		var fileUrl = ( window.location.origin || '' ) + '/llms.txt';

		var aiBtn = h( 'button', { class: 'snap-btn snap-btn-ai', onclick: function () {
			if ( ! SNAP.hasKey ) { toast( 'Connect your Claude or ChatGPT key in the AI tab first.', true ); return; }
			aiBtn.disabled = true;
			aiBtn.innerHTML = '<span class="snap-spinner"></span> Reading your site, sitemap & training…';
			apiFetch( { path: '/snaplevel/v1/llms/generate', method: 'POST' } )
				.then( function ( res ) {
					aiBtn.disabled = false;
					aiBtn.textContent = 'Make with AI';
					area.value = res.content || '';
					s.llms.content = area.value;
					toast( 'Generated. Review it, then press Save.' );
				} )
				.catch( function ( err ) {
					aiBtn.disabled = false;
					aiBtn.textContent = 'Make with AI';
					toast( ( err && err.message ) || 'Generation failed.', true );
				} );
		} }, [ 'Make with AI' ] );

		return h( 'div', null, [
			row( 'Serve llms.txt', toggleRow( 'Serve this file at /llms.txt', s.llms.enabled !== false, function ( on ) { s.llms.enabled = on; } ), { help: 'llms.txt is the Markdown standard AI crawlers (ChatGPT, Claude, Perplexity, Gemini) read to understand and cite your site.' } ),
			row( 'Live file', h( 'a', { href: fileUrl, target: '_blank' }, [ fileUrl ] ), { help: 'Saved changes appear here instantly. Empty content serves an automatic version built from your pages.' } ),
			row( 'Content (Markdown)', [
				h( 'div', { style: 'margin-bottom:10px' }, [ aiBtn ] ),
				area
			], { help: 'Make with AI reads your published pages, sitemap and AI Training knowledge, then writes the file: H1 + dense blockquote, key page lists with one-sentence intent descriptions, no promo fluff.' } ),
			saveBar( function () { save( { llms: { enabled: s.llms.enabled !== false, content: s.llms.content || '' } } ); }, 'Save LLMs.txt' )
		] );
	}

	// ── Webmaster Tools (verification codes) ────────────────────────────────

	function renderWebmasters() {
		var s = state.settings;
		s.webmasters = s.webmasters || {};

		var engines = [
			{ id: 'google',    name: 'Google Search Console', meta: 'google-site-verification', url: 'search.google.com/search-console' },
			{ id: 'bing',      name: 'Bing Webmaster Tools',  meta: 'msvalidate.01', url: 'bing.com/webmasters' },
			{ id: 'yandex',    name: 'Yandex Webmaster',      meta: 'yandex-verification', url: 'webmaster.yandex.com' },
			{ id: 'baidu',     name: 'Baidu Webmaster Tools', meta: 'baidu-site-verification', url: 'ziyuan.baidu.com' },
			{ id: 'pinterest', name: 'Pinterest',             meta: 'p:domain_verify', url: 'pinterest.com/settings/claim' },
			{ id: 'norton',    name: 'Norton Safe Web',       meta: 'norton-safeweb-site-verification', url: 'safeweb.norton.com' }
		];

		var rows = engines.map( function ( e ) {
			return row( e.name, textInput( s.webmasters[ e.id ] || '', function ( v ) { s.webmasters[ e.id ] = v; }, { placeholder: 'Verification code or full <meta> tag' } ), { help: 'Outputs <meta name="' + e.meta + '" …> in your site head. Get the code at ' + e.url + ' (HTML tag method). Paste the whole tag or just the code — both work.' } );
		} );

		rows.unshift( h( 'p', { class: 'snap-muted', style: 'margin-top:0' }, [ 'Verify your site with each search engine. After saving, go back to the search console and press Verify — the meta tag is already live in your head section.' ] ) );
		rows.push( saveBar( function () { save( { webmasters: s.webmasters } ); }, 'Save Verification Codes' ) );

		return h( 'div', null, rows );
	}

	// ── Tools (importers) ────────────────────────────────────────────────────

	function renderTools() {
		var box = h( 'div', { class: 'snap-grid snap-grid-2' }, [ h( 'div', { class: 'snap-box' }, [ h( 'div', { class: 'snap-skeleton', style: 'height:80px' } ) ] ) ] );

		apiFetch( { path: '/snaplevel/v1/import/detect' } ).then( function ( res ) {
			box.innerHTML = '';
			Object.keys( res ).forEach( function ( source ) {
				var info = res[ source ];
				if ( ! info || ! info.name ) { return; }
				var card = h( 'div', { class: 'snap-box' }, [
					h( 'div', { class: 'snap-box-title' }, [ icon( 'import' ), 'Import from ' + info.name ] ),
					info.available
						? h( 'p', null, [ String( info.posts ) + ' posts with ' + info.name + ' data found.' + ( info.active ? ' Plugin is currently active.' : '' ) ] )
						: h( 'p', { class: 'snap-muted' }, [ 'No ' + info.name + ' data found on this site.' ] )
				] );
				if ( info.available ) {
					var progress = h( 'div', { class: 'snap-progress', style: 'margin:12px 0;display:none' }, [ h( 'div', { class: 'snap-progress-bar', style: 'width:0%' } ) ] );
					var status = h( 'p', { class: 'snap-muted' }, [] );
					var btn = h( 'button', { class: 'snap-btn snap-btn-primary', onclick: function () {
						btn.disabled = true;
						progress.style.display = '';
						var importedTotal = 0;
						function step( offset ) {
							apiFetch( { path: '/snaplevel/v1/import/run', method: 'POST', data: { source: source, offset: offset } } )
								.then( function ( r ) {
									importedTotal += r.imported;
									var pct = r.total ? Math.min( 100, Math.round( r.next_offset / r.total * 100 ) ) : 100;
									progress.firstChild.style.width = pct + '%';
									status.textContent = 'Imported ' + importedTotal + ' of ' + r.total + ' posts…';
									if ( ! r.done ) { step( r.next_offset ); }
									else {
										status.textContent = 'Done. Imported data for ' + importedTotal + ' posts. Existing Snaplevel data was never overwritten.';
										btn.disabled = false;
										toast( 'Import finished.' );
									}
								} )
								.catch( function ( err ) { btn.disabled = false; toast( ( err && err.message ) || 'Import failed.', true ); } );
						}
						step( 0 );
					} }, [ 'Import now' ] );
					card.appendChild( progress );
					card.appendChild( status );
					card.appendChild( btn );
				}
				box.appendChild( card );
			} );
		} ).catch( function () {
			box.innerHTML = '';
			box.appendChild( h( 'p', { class: 'snap-notice snap-notice-error' }, [ 'Could not load importer status.' ] ) );
		} );

		// ── Settings backup / restore / reset ────────────────────────────
		var exportBtn = h( 'button', { class: 'snap-btn snap-btn-primary', onclick: function () {
			apiFetch( { path: '/snaplevel/v1/tools/export' } ).then( function ( data ) {
				var blob = new Blob( [ JSON.stringify( data, null, 2 ) ], { type: 'application/json' } );
				var a = document.createElement( 'a' );
				a.href = URL.createObjectURL( blob );
				a.download = 'snaplevel-settings-' + new Date().toISOString().slice( 0, 10 ) + '.json';
				a.click();
				URL.revokeObjectURL( a.href );
			} ).catch( function ( err ) { toast( ( err && err.message ) || 'Export failed.', true ); } );
		} }, [ 'Download settings JSON' ] );

		var fileInput = h( 'input', { type: 'file', accept: '.json', style: 'margin-bottom:10px;display:block' } );
		var importBtn = h( 'button', { class: 'snap-btn snap-btn-primary', onclick: function () {
			var file = fileInput.files && fileInput.files[ 0 ];
			if ( ! file ) { toast( 'Choose an export file first.', true ); return; }
			var reader = new FileReader();
			reader.onload = function () {
				var data;
				try { data = JSON.parse( String( reader.result ) ); } catch ( e ) { toast( 'Not a valid JSON file.', true ); return; }
				apiFetch( { path: '/snaplevel/v1/tools/import', method: 'POST', data: data } )
					.then( function ( res ) { toast( res.message || 'Settings imported.' ); setTimeout( function () { window.location.reload(); }, 900 ); } )
					.catch( function ( err ) { toast( ( err && err.message ) || 'Import failed.', true ); } );
			};
			reader.readAsText( file );
		} }, [ 'Import settings' ] );

		var resetBtn = h( 'button', { class: 'snap-btn snap-btn-secondary', onclick: function () {
			if ( ! window.confirm( 'Reset ALL Snaplevel settings to defaults?\n\nPost SEO data, AI training, and redirects are kept. API keys will be removed.' ) ) { return; }
			if ( ! window.confirm( 'Are you sure? This cannot be undone.' ) ) { return; }
			apiFetch( { path: '/snaplevel/v1/tools/reset', method: 'POST' } )
				.then( function ( res ) { toast( res.message || 'Settings reset.' ); setTimeout( function () { window.location.reload(); }, 900 ); } )
				.catch( function ( err ) { toast( ( err && err.message ) || 'Reset failed.', true ); } );
		} }, [ 'Reset all settings' ] );

		var backup = h( 'div', { class: 'snap-grid snap-grid-2', style: 'margin-top:16px' }, [
			h( 'div', { class: 'snap-box' }, [
				h( 'div', { class: 'snap-box-title' }, [ icon( 'file' ), 'Export Settings' ] ),
				h( 'p', { class: 'snap-muted' }, [ 'Download every Snaplevel setting as JSON. API keys are never included.' ] ),
				exportBtn
			] ),
			h( 'div', { class: 'snap-box' }, [
				h( 'div', { class: 'snap-box-title' }, [ icon( 'import' ), 'Import Settings' ] ),
				h( 'p', { class: 'snap-muted' }, [ 'Restore settings from a Snaplevel export file.' ] ),
				fileInput,
				importBtn
			] ),
			h( 'div', { class: 'snap-box' }, [
				h( 'div', { class: 'snap-box-title' }, [ icon( 'refresh' ), 'Reset' ] ),
				h( 'p', { class: 'snap-muted' }, [ 'Back to factory defaults with a double confirmation. Post SEO data and AI training stay untouched.' ] ),
				resetBtn
			] )
		] );

		return h( 'div', null, [ box, backup ] );
	}

	// ── Render ───────────────────────────────────────────────────────────────

	var SETTINGS_TABS = [
		{ id: 'modules', label: 'Modules', icon: 'grid' },
		{ id: 'ai', label: 'AI', icon: 'sparkle' },
		{ id: 'codes', label: 'Ads & Analytics', icon: 'chart' },
		{ id: 'llms', label: 'LLMs.txt', icon: 'robot' },
		{ id: 'webmasters', label: 'Webmaster Tools', icon: 'shield' },
		{ id: 'sitemap', label: 'Sitemap', icon: 'sitemap' },
		{ id: 'compression', label: 'Compression', icon: 'compress' },
		{ id: 'tools', label: 'Tools', icon: 'import' },
		{ id: 'changelog', label: 'Plugin Changelog', icon: 'file-text' },
		{ id: 'seo_changelog', label: 'SEO Changelog', icon: 'chart' },
		{ id: 'support', label: 'Support', icon: 'help' }
	];

	// ── Ads & Analytics ──────────────────────────────────────────────────────

	function renderCodes() {
		var s = state.settings;
		s.codes = s.codes || { ga4_id: '', adsense_client: '', head_code: '', footer_code: '' };

		function codeArea( value, onChange, placeholder ) {
			var area = h( 'textarea', { class: 'snap-textarea', rows: '6', style: 'font-family:Consolas,Monaco,monospace;font-size:12.5px', placeholder: placeholder } );
			area.value = value || '';
			area.addEventListener( 'input', function () { onChange( area.value ); } );
			return area;
		}

		return h( 'div', null, [
			row( 'Google Analytics 4', textInput( s.codes.ga4_id, function ( v ) { s.codes.ga4_id = v; }, { placeholder: 'G-XXXXXXXXXX', style: 'max-width:260px' } ),
				{ tip: 'Find this in GA Admin -> Data Streams.', help: 'Paste your GA4 Measurement ID (Admin → Data Streams). Snaplevel outputs the official gtag.js snippet on every page — no extra plugin needed.' } ),
			row( 'Google AdSense', textInput( s.codes.adsense_client, function ( v ) { s.codes.adsense_client = v; }, { placeholder: 'ca-pub-1234567890123456', style: 'max-width:300px' } ),
				{ tip: 'Starts with ca-pub-', help: 'Your AdSense publisher ID. Outputs the site-level Auto Ads script so AdSense can verify your site and place ads.' } ),
			row( 'Header code', codeArea( s.codes.head_code, function ( v ) { s.codes.head_code = v; }, '<!-- Any verification tags, pixels, or ad code — printed inside <head> -->' ),
				{ tip: 'Custom tags placed in <head>.', help: 'Printed near the top of <head> on every page. Use for Facebook Pixel, extra ad units, or verification tags.' } ),
			row( 'Footer code', codeArea( s.codes.footer_code, function ( v ) { s.codes.footer_code = v; }, '<!-- Printed before </body> -->' ),
				{ tip: 'Custom tags placed before </body>.', help: 'Printed just before </body>. Use for chat widgets or scripts that should load last.' } ),
			saveBar( function () { save( { codes: s.codes } ); }, 'Save Ads & Analytics' )
		] );
	}

	function body() {
		switch ( state.tab ) {
			case 'ai': return renderAI();
			case 'codes': return renderCodes();
			case 'titles': return renderTitles();
			case 'schema': return renderSchema();
			case 'training': return renderTraining();
			case 'llms': return renderLLMs();
			case 'webmasters': return renderWebmasters();
			case 'sitemap': return renderSitemap();
			case 'compression': return renderCompression();
			case 'tools': return renderTools();
			case 'changelog': return renderChangelog();
			case 'seo_changelog': return renderSeoChangelog();
			case 'support': return renderSupport();
			default: return renderModules();
		}
	}

	function renderChangelog() {
		return h( 'div', { class: 'snap-box' }, [
			h( 'div', { class: 'snap-box-title' }, [ icon( 'file-text' ), 'Plugin Changelog' ] ),
			h( 'p', { class: 'snap-muted' }, [ 'Stay up to date with the latest features, bug fixes, and improvements in Snaplevel.' ] ),
			h( 'ul', { style: 'padding-left: 20px;' }, [
				h( 'li', null, [ h( 'strong', null, [ 'v1.0.0' ] ), ' — Initial release with AI capabilities, SEO tools, and more.' ] )
			] )
		] );
	}

	function renderSeoChangelog() {
		return h( 'div', { class: 'snap-box' }, [
			h( 'div', { class: 'snap-box-title' }, [ icon( 'chart' ), 'SEO Changelog' ] ),
			h( 'p', { class: 'snap-muted' }, [ 'Track all SEO changes over time. See exactly when titles, meta descriptions, or content were updated and correlate them with ranking drops or gains.' ] ),
			h( 'p', { class: 'snap-notice snap-notice-info' }, [ 'We are actively tracking your SEO changes. The historical diffs and correlations will appear here.' ] )
		] );
	}

	function renderSupport() {
		return h( 'div', { class: 'snap-box' }, [
			h( 'div', { class: 'snap-box-title' }, [ icon( 'help' ), 'Premium Support' ] ),
			h( 'p', { class: 'snap-muted' }, [ 'Need help? Our dedicated support team is available to assist you with any Snaplevel feature or SEO inquiry.' ] ),
			h( 'a', { href: 'https://autogencrm.com/snaplevel', target: '_blank', class: 'snap-btn snap-btn-primary' }, [ 'Contact Support' ] )
		] );
	}

	var LEADS = {
		titles: 'Templates for every title and meta description on your site — every post type and taxonomy gets its own tab. Per-post values from the editor always win.',
		schema: 'Structured data for rich results. Site-level identity here, AI-generated schema per post.',
		training: 'Self-trained on SEO / AEO / GEO best practices by default. Add your business knowledge to make every generation on-brand.',
		tools: 'Import your SEO data from other plugins. Nothing is ever overwritten.',
		modules: 'Configure Snaplevel. Most defaults are already sensible.'
	};

	function render() {
		root.innerHTML = '';

		if ( ! state.settings ) {
			root.appendChild( h( 'div', { class: 'snap-skeleton', style: 'height:220px' } ) );
			return;
		}

		root.appendChild( h( 'p', { class: 'snap-page-lead', style: 'margin:0 0 14px' }, [ LEADS[ SINGLE ? PAGE_TAB : 'modules' ] || '' ] ) );

		if ( state.tab === 'titles' ) {
			root.appendChild( renderTitles() );
		} else if ( SINGLE ) {
			root.appendChild( body() );
		} else {
			// Settings page: vertical tabs shell.
			if ( SETTINGS_TABS.every( function ( t ) { return t.id !== state.tab; } ) ) { state.tab = 'modules'; }
			root.appendChild( vtabs( SETTINGS_TABS, state.tab, function ( id ) { state.tab = id; render(); }, body() ) );
		}
	}

	render();
	apiFetch( { path: '/snaplevel/v1/settings' } )
		.then( function ( res ) { state.settings = res; render(); } )
		.catch( function ( err ) {
			root.innerHTML = '';
			root.appendChild( h( 'p', { class: 'snap-notice snap-notice-error' }, [ ( err && err.message ) || 'Could not load settings.' ] ) );
		} );
} )();
