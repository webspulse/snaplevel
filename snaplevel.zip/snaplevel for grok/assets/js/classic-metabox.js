/**
 * Snaplevel — Classic Editor metabox behavior.
 * Copilot (AI opportunities) primary at top of General. Score + checklist secondary/collapsed.
 * Builder popup uses same render. Low-risk reorg for AI-first editor experience.
 * Requires: window.SNAP_METABOX localized config.
 */
( function () {
	'use strict';
	var CFG     = window.SNAP_METABOX || {};
	var restUrl = CFG.restUrl || '';
	var nonce   = CFG.nonce || '';
	var box     = document.querySelector( '.snap-metabox' );
	if ( ! box ) { return; }
	var postId  = parseInt( box.dataset.postId, 10 );

	// Tabs.
	box.querySelectorAll( '.snap-mtab[data-pane]' ).forEach( function ( tab ) {
		tab.addEventListener( 'click', function () {
			box.querySelectorAll( '.snap-mtab[data-pane]' ).forEach( function ( t ) { t.classList.remove( 'is-active' ); } );
			box.querySelectorAll( '.snap-metabox-pane' ).forEach( function ( p ) { p.classList.remove( 'is-active' ); } );
			tab.classList.add( 'is-active' );
			var pane = box.querySelector( '[data-pane-content="' + tab.dataset.pane + '"]' );
			if ( pane ) { pane.classList.add( 'is-active' ); }
		} );
	} );

	// ── URL slug: auto-sanitize + live preview ─────────────────────
	var slugField = document.getElementById( 'snap_slug' );
	var homeUrl   = CFG.homeUrl || '';
	function sanitizeSlug( v ) {
		return v.toLowerCase().replace( /[^a-z0-9\s_-]/g, '' ).replace( /[\s_]+/g, '-' ).replace( /-{2,}/g, '-' );
	}
	function updateSlugPreview() {
		var prev = document.getElementById( 'snap-slug-preview' );
		if ( prev && slugField ) {
			prev.textContent = homeUrl + sanitizeSlug( slugField.value ).replace( /^-+|-+$/g, '' ) + '/';
		}
	}
	if ( slugField ) {
		slugField.addEventListener( 'input', function () {
			var clean = sanitizeSlug( slugField.value );
			if ( clean !== slugField.value ) { slugField.value = clean; }
			updateSlugPreview();
		} );
		slugField.addEventListener( 'blur', function () {
			slugField.value = sanitizeSlug( slugField.value ).replace( /^-+|-+$/g, '' );
			updateSlugPreview();
		} );
		updateSlugPreview();
	}

	// ── Social: inherit toggle, live cards, image pickers ──────────
	var inheritCb = document.getElementById( 'snap-social-inherit' );
	function val( id ) { var f = document.getElementById( id ); return f ? f.value.trim() : ''; }
	function syncSocialCards() {
		var inherit  = inheritCb && inheritCb.checked;
		var baseT    = val( 'snap_title' ) || CFG.postTitle;
		var baseD    = val( 'snap_desc' );
		var ogT      = ( ! inherit && val( 'snap_og_title' ) ) || baseT;
		var ogD      = ( ! inherit && val( 'snap_og_desc' ) ) || baseD;
		var set      = function ( id, t ) { var n = document.getElementById( id ); if ( n ) { n.textContent = t; } };
		set( 'snap-og-card-title', ogT );
		set( 'snap-og-card-desc', ogD );
		set( 'snap-tw-card-title', val( 'snap_tw_title' ) || ogT );
		set( 'snap-tw-card-desc', val( 'snap_tw_desc' ) || ogD );
		var twImg = document.getElementById( 'snap-tw-card-img' );
		if ( twImg && ! val( 'snap_tw_image' ) ) {
			var ogImgUrl = val( 'snap_og_image' );
			if ( ogImgUrl ) { twImg.style.backgroundImage = 'url(' + ogImgUrl + ')'; twImg.textContent = ''; }
		}
		[ 'snap_og_title', 'snap_og_desc' ].forEach( function ( id ) {
			var f = document.getElementById( id );
			if ( f ) { f.disabled = !! inherit; f.style.opacity = inherit ? '.55' : '1'; }
		} );
	}
	if ( inheritCb ) {
		inheritCb.addEventListener( 'change', function () {
			if ( inheritCb.checked ) {
				var t = document.getElementById( 'snap_og_title' );
				var d = document.getElementById( 'snap_og_desc' );
				if ( t ) { t.value = ''; }
				if ( d ) { d.value = ''; }
			}
			syncSocialCards();
		} );
	}
	[ 'snap_og_title', 'snap_og_desc', 'snap_tw_title', 'snap_tw_desc' ].forEach( function ( id ) {
		var f = document.getElementById( id );
		if ( f ) {
			f.addEventListener( 'input', function () {
				if ( inheritCb && ( 'snap_og_title' === id || 'snap_og_desc' === id ) ) { inheritCb.checked = false; }
				syncSocialCards();
			} );
		}
	} );

	box.querySelectorAll( '.snap-img-pick' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			if ( ! window.wp || ! wp.media ) { return; }
			var frame = wp.media( { title: CFG.i18n.selectImage, multiple: false, library: { type: 'image' } } );
			frame.on( 'select', function () {
				var att  = frame.state().get( 'selection' ).first().toJSON();
				var url  = ( att.sizes && att.sizes.large ? att.sizes.large.url : att.url );
				document.getElementById( btn.dataset.target ).value = url;
				var card = document.getElementById( btn.dataset.card );
				if ( card ) { card.style.backgroundImage = 'url(' + url + ')'; card.textContent = ''; }
				var clear = box.querySelector( '.snap-img-clear[data-target="' + btn.dataset.target + '"]' );
				if ( clear ) { clear.style.display = ''; }
				syncSocialCards();
			} );
			frame.open();
		} );
	} );
	box.querySelectorAll( '.snap-img-clear' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			document.getElementById( btn.dataset.target ).value = '';
			var card = document.getElementById( btn.dataset.card );
			if ( card ) { card.style.backgroundImage = ''; }
			btn.style.display = 'none';
			syncSocialCards();
		} );
	} );
	syncSocialCards();

	// ── Advanced: robots checkboxes → hidden field ─────────────────
	var robotsHidden = document.getElementById( 'snap_robots' );
	box.querySelectorAll( '.snap-robots-cb' ).forEach( function ( cb ) {
		cb.addEventListener( 'change', function () {
			var on = [];
			box.querySelectorAll( '.snap-robots-cb' ).forEach( function ( c ) { if ( c.checked ) { on.push( c.value ); } } );
			if ( robotsHidden ) { robotsHidden.value = on.join( ',' ); }
		} );
	} );

	function call( task ) {
		var kwField = document.getElementById( 'snap_focus_kw' );
		return window.fetch( restUrl + '/ai/generate', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
			body: JSON.stringify( { task: task, post_id: postId, context: { focus_keyword: kwField ? kwField.value : '' } } )
		} ).then( function ( r ) { return r.json().then( function ( j ) { if ( ! r.ok ) { throw new Error( j.message || 'AI request failed.' ); } return j; } ); } );
	}

	function showOptions( targetId, options, mapPick ) {
		var holder = box.querySelector( '[data-options-for="' + targetId + '"]' );
		if ( ! holder ) { return; }
		holder.innerHTML = '';
		options.forEach( function ( opt ) {
			var b = document.createElement( 'button' );
			b.type = 'button';
			b.className = 'snap-ai-option';
			b.textContent = opt.label;
			b.addEventListener( 'click', function () {
				document.getElementById( targetId ).value = mapPick ? mapPick( opt ) : opt.value;
				holder.innerHTML = '';
				analyze();
			} );
			holder.appendChild( b );
		} );
	}

	// Per-field generate buttons.
	box.querySelectorAll( '.snap-ai-btn' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var original = btn.innerHTML;
			btn.disabled = true;
			btn.innerHTML = '<span class="snap-spinner snap-spinner-dark"></span> ' + CFG.i18n.generating;
			call( btn.dataset.task ).then( function ( res ) {
				btn.disabled = false;
				btn.innerHTML = original;
				var d = res && res.data ? res.data : {};
				if ( d.options ) {
					showOptions( btn.dataset.target, d.options.map( function ( o ) { return { label: o, value: o }; } ) );
				} else if ( d.keywords ) {
					showOptions( btn.dataset.target, d.keywords.map( function ( k ) {
						return { label: k.keyword + '  ·  ' + k.intent, value: k.keyword };
					} ) );
				}
			} ).catch( function ( err ) {
				btn.disabled = false;
				btn.innerHTML = original;
				window.alert( err.message );
			} );
		} );
	} );

	// Schema generate / clear.
	var genSchema = document.getElementById( 'snap-gen-schema' );
	if ( genSchema ) {
		genSchema.addEventListener( 'click', function () {
			var original = genSchema.innerHTML;
			genSchema.disabled = true;
			genSchema.innerHTML = '<span class="snap-spinner snap-spinner-dark"></span> ' + CFG.i18n.analyzingPost;
			call( 'schema' ).then( function ( res ) {
				genSchema.disabled = false;
				genSchema.innerHTML = original;
				if ( res && res.data && res.data.jsonld ) {
					document.getElementById( 'snap_schema' ).value = JSON.stringify( res.data.jsonld );
					document.getElementById( 'snap-schema-state' ).innerHTML =
						'<span class="snap-badge snap-badge-green">✓ ' + ( res.data.schema_type || 'Schema' ) + ' ' + CFG.i18n.schemaReady + '</span>';
					document.getElementById( 'snap-clear-schema' ).style.display = '';
				}
			} ).catch( function ( err ) {
				genSchema.disabled = false;
				genSchema.innerHTML = original;
				window.alert( err.message );
			} );
		} );
	}
	var clearSchema = document.getElementById( 'snap-clear-schema' );
	if ( clearSchema ) {
		clearSchema.addEventListener( 'click', function () {
			document.getElementById( 'snap_schema' ).value = '';
			document.getElementById( 'snap-schema-state' ).innerHTML = '<span class="snap-muted">' + CFG.i18n.noSchema + '</span>';
			clearSchema.style.display = 'none';
		} );
	}

	// ── Live analyzer: preview, counters, checklist, score ─────────
	var siteName  = CFG.siteName || '';
	var sep       = CFG.separator || '–';
	var permalink = CFG.permalink || '';
	var postTitle = CFG.postTitle || '';

	function el( id ) { return document.getElementById( id ); }
	function barColor( bar, txt, len, min, max, hardMax ) {
		var pct = Math.min( 100, Math.round( len / hardMax * 100 ) );
		var color = ( len >= min && len <= max ) ? '#58bb58' : ( len === 0 || len > hardMax ? '#e93f30' : '#bf890d' );
		bar.style.width = pct + '%';
		bar.style.background = color;
		txt.textContent = len + ' / ' + max;
		txt.style.color = color;
	}
	function getContent() {
		try {
			if ( window.tinyMCE && tinyMCE.activeEditor && ! tinyMCE.activeEditor.isHidden() ) {
				var d = document.createElement( 'div' );
				d.innerHTML = tinyMCE.activeEditor.getContent();
				return d.textContent || '';
			}
		} catch ( e ) {}
		var ta = el( 'content' );
		return ta ? ta.value.replace( /<[^>]+>/g, ' ' ) : '';
	}
	function analyze() {
		var kw    = ( el( 'snap_focus_kw' ) ? el( 'snap_focus_kw' ).value : '' ).trim();
		var title = ( el( 'snap_title' ) ? el( 'snap_title' ).value : '' ).trim() || postTitle;
		var desc  = ( el( 'snap_desc' ) ? el( 'snap_desc' ).value : '' ).trim();
		var body  = getContent();
		var words = body.split( /\s+/ ).filter( Boolean ).length;
		var firstPara = body.trim().split( /\n+/ )[ 0 ] || body.slice( 0, 600 );
		var kwL = kw.toLowerCase(), tL = title.toLowerCase(), dL = desc.toLowerCase();

		// Preview.
		if ( el( 'snap-mb-ptitle' ) ) {
			el( 'snap-mb-ptitle' ).textContent = title ? title + ' ' + sep + ' ' + siteName : '';
			el( 'snap-mb-pdesc' ).textContent = desc || CFG.i18n.noMetaDesc;
		}

		// Counters.
		if ( el( 'snap-title-bar' ) ) { barColor( el( 'snap-title-bar' ), el( 'snap-title-count' ), title.length, 35, 60, 70 ); }
		if ( el( 'snap-desc-bar' ) ) { barColor( el( 'snap-desc-bar' ), el( 'snap-desc-count' ), desc.length, 120, 156, 170 ); }

		// Checks.
		var checks = [
			{ ok: kw.length > 0, label: CFG.i18n.kwSet },
			{ ok: !! kw && tL.indexOf( kwL ) !== -1, label: CFG.i18n.kwInTitle },
			{ ok: !! kw && tL.indexOf( kwL ) === 0, label: CFG.i18n.kwStartTitle, warn: true },
			{ ok: !! kw && dL.indexOf( kwL ) !== -1, label: CFG.i18n.kwInDesc },
			{ ok: title.length >= 35 && title.length <= 60, label: CFG.i18n.titleLength },
			{ ok: desc.length >= 120 && desc.length <= 156, label: CFG.i18n.descLength },
			{ ok: !! kw && permalink.toLowerCase().indexOf( kwL.replace( /\s+/g, '-' ) ) !== -1, label: CFG.i18n.kwInUrl, warn: true },
			{ ok: !! kw && firstPara.toLowerCase().indexOf( kwL ) !== -1, label: CFG.i18n.kwFirstPara },
			{ ok: words >= 600, label: CFG.i18n.contentLength + ( words ? ' — ' + words + ' ' + CFG.i18n.words : '' ), warn: words >= 300 }
		];

		var list = el( 'snap-mb-checks' );
		if ( list ) {
			list.innerHTML = '';
			var passed = 0;
			checks.forEach( function ( c ) {
				if ( c.ok ) { passed++; }
				var li = document.createElement( 'li' );
				li.className = c.ok ? 'is-pass' : ( c.warn ? 'is-warn' : 'is-fail' );
				li.textContent = c.label;
				list.appendChild( li );
			} );
			el( 'snap-mb-mini' ).textContent = passed + '/' + checks.length;

			var score = Math.round( passed / checks.length * 100 );
			var stateCls = score >= 81 ? 'is-good' : ( score >= 51 ? 'is-ok' : 'is-bad' );
			var pill = el( 'snap-mb-score' );
			pill.textContent = score + ' / 100';
			pill.className = 'snap-score-pill ' + stateCls;
			pill.style.borderRadius = '7px';

			var side = el( 'snap-side-score' );
			if ( side ) {
				side.textContent = score + ' / 100';
				side.className = 'snap-score-pill ' + stateCls;
				side.style.borderRadius = '7px';
				side.style.width = '110px';
			}
			var sideBar = el( 'snap-side-bar' );
			if ( sideBar ) {
				sideBar.style.width = score + '%';
				sideBar.style.background = score >= 81 ? '#58bb58' : ( score >= 51 ? '#bf890d' : '#e93f30' );
			}
			var sideMini = el( 'snap-side-mini' );
			if ( sideMini ) {
				sideMini.textContent = passed + ' / ' + checks.length + ' ' + CFG.i18n.checksPassed;
			}
		}
	}
	[ 'snap_focus_kw', 'snap_title', 'snap_desc' ].forEach( function ( id ) {
		var f = el( id );
		if ( f ) { f.addEventListener( 'input', function () { analyze(); syncSocialCards(); } ); }
	} );
	analyze();

	// Fix with AI — keyword → title → description.
	var fixBtn = document.getElementById( 'snap-fix-all' );
	if ( fixBtn ) {
		var status = document.getElementById( 'snap-fix-status' );
		fixBtn.addEventListener( 'click', function () {
			fixBtn.disabled = true;
			var kwField = document.getElementById( 'snap_focus_kw' );

			var kwStep = kwField.value
				? Promise.resolve()
				: ( status.textContent = CFG.i18n.findingKeywords,
					call( 'focus_keywords' ).then( function ( res ) {
						if ( res.data && res.data.keywords && res.data.keywords[0] ) {
							kwField.value = res.data.keywords[0].keyword;
						}
					} ) );

			kwStep.then( function () {
				status.textContent = CFG.i18n.writingTitle;
				return call( 'seo_title' );
			} ).then( function ( res ) {
				if ( res.data && res.data.options && res.data.options[0] ) {
					document.getElementById( 'snap_title' ).value = res.data.options[0];
				}
				status.textContent = CFG.i18n.writingDesc;
				return call( 'meta_description' );
			} ).then( function ( res ) {
				if ( res.data && res.data.options && res.data.options[0] ) {
					document.getElementById( 'snap_desc' ).value = res.data.options[0];
				}
				status.textContent = '✓ ' + CFG.i18n.done;
				fixBtn.disabled = false;
				analyze();
			} ).catch( function ( err ) {
				status.textContent = err.message;
				fixBtn.disabled = false;
			} );
		} );
	}

	// ── Copilot (primary AI assistant) in Classic / builder panel ───────────
	// Surfaces opportunities first. Traditional score/checklist is secondary/collapsed in markup.
	var copilotBtn = document.getElementById( 'snap-copilot-analyze' );
	var copilotResults = document.getElementById( 'snap-copilot-results' );
	if ( copilotBtn && copilotResults && restUrl ) {
		function renderCopilotOpps( analysis ) {
			copilotResults.innerHTML = '';
			var opps = ( analysis && analysis.opportunities ) || [];
			var readiness = analysis && analysis.readiness ? analysis.readiness : '';

			var header = document.createElement( 'div' );
			header.style.cssText = 'font-size:12px;font-weight:600;margin:4px 0;color:#374151;';
			header.textContent = opps.length ? ( 'Copilot found ' + opps.length + ' opportunities' + ( readiness ? ' · ' + readiness : '' ) ) : 'Copilot: looking good';
			copilotResults.appendChild( header );

			if ( ! opps.length ) {
				var p = document.createElement( 'p' );
				p.style.cssText = 'font-size:12px;color:#6b7280;margin:4px 0;';
				p.textContent = 'No AI opportunities detected. Content looks solid.';
				copilotResults.appendChild( p );
				return;
			}

			opps.forEach( function ( opp ) {
				var card = document.createElement( 'div' );
				card.style.cssText = 'margin:8px 0;padding:10px 12px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;font-size:12px;';
				var title = document.createElement( 'div' );
				title.style.cssText = 'font-weight:600;line-height:1.35;';
				title.textContent = opp.title || 'Opportunity';
				var reason = document.createElement( 'div' );
				reason.style.cssText = 'color:#4b5563;font-size:11px;margin-top:2px;line-height:1.4;';
				reason.textContent = opp.reason || '';
				card.appendChild( title );
				card.appendChild( reason );

				if ( opp.fixable && opp.fix_task && opp.fix_task !== 'none' ) {
					var fix = document.createElement( 'button' );
					fix.type = 'button';
					fix.style.cssText = 'margin-top:8px;font-size:11px;padding:4px 10px;border-radius:4px;border:1px solid #a5b4fc;background:#eef2ff;color:#4338ca;cursor:pointer;';
					fix.textContent = '✦ Fix with AI';
					fix.addEventListener( 'click', function () {
						fix.disabled = true;
						fix.textContent = 'Fixing…';
						// Low-risk: trigger bulk AI fix flow for meta opportunities; user can refine.
						if ( fixBtn ) {
							fixBtn.click();
						} else {
							// Fallback: simple alert + re-analyze hook.
							window.alert( 'Use the "Fix with AI" button above to apply.' );
						}
						setTimeout( function () {
							fix.textContent = '✓ Applied (review fields)';
							analyze(); // refresh instant checks
						}, 900 );
					} );
					card.appendChild( fix );
				}
				copilotResults.appendChild( card );
			} );

			var re = document.createElement( 'button' );
			re.type = 'button';
			re.style.cssText = 'font-size:11px;margin-top:6px;color:#6b7280;background:none;border:0;cursor:pointer;';
			re.textContent = 'Re-analyze';
			re.addEventListener( 'click', runCopilot );
			copilotResults.appendChild( re );
		}

		function runCopilot() {
			copilotBtn.disabled = true;
			var orig = copilotBtn.innerHTML;
			copilotBtn.innerHTML = '<span class="snap-spinner snap-spinner-dark"></span> Thinking…';
			copilotResults.innerHTML = '<div style="font-size:11px;color:#6b7280;padding:4px 0;">AI reading content…</div>';

			window.fetch( restUrl + '/copilot/analyze', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
				body: JSON.stringify( { post_id: postId } )
			} ).then( function ( r ) {
				return r.json().then( function ( j ) { if ( ! r.ok ) { throw new Error( j && (j.error || j.message) || 'Copilot failed' ); } return j; } );
			} ).then( function ( res ) {
				copilotBtn.disabled = false;
				copilotBtn.innerHTML = orig;
				var analysis = res && res.analysis ? res.analysis : null;
				if ( analysis ) {
					renderCopilotOpps( analysis );
				} else {
					copilotResults.innerHTML = '<p style="font-size:11px;color:#e93f30;">No analysis returned.</p>';
				}
			} ).catch( function ( err ) {
				copilotBtn.disabled = false;
				copilotBtn.innerHTML = orig;
				copilotResults.innerHTML = '<p style="font-size:11px;color:#e93f30;">' + ( err.message || 'Request failed' ) + '</p>';
			} );
		}

		copilotBtn.addEventListener( 'click', runCopilot );
	}
} )();
