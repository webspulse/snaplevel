/**
 * Snaplevel — Broken Links admin view.
 * Requires: window.SNAP_BROKEN_LINKS localized config.
 */
( function () {
	'use strict';
	var CFG     = window.SNAP_BROKEN_LINKS || {};
	var nonce   = CFG.nonce || '';
	var ajaxurl = CFG.ajaxurl || '';

	function post( action, data ) {
		var body = new FormData();
		body.append( 'action', action );
		body.append( 'nonce', nonce );
		Object.keys( data || {} ).forEach( function ( k ) { body.append( k, data[ k ] ); } );
		return window.fetch( ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' } )
			.then( function ( r ) { return r.json(); } )
			.then( function ( j ) { if ( ! j.success ) { throw new Error( j.data || 'Request failed.' ); } return j.data; } );
	}

	var scanBtn = document.getElementById( 'snap-bl-scan' );
	if ( ! scanBtn ) { return; }
	scanBtn.addEventListener( 'click', function () {
		scanBtn.disabled = true;
		var box    = document.getElementById( 'snap-bl-progress' );
		var bar    = document.getElementById( 'snap-bl-bar' );
		var status = document.getElementById( 'snap-bl-status' );
		box.style.display = '';
		status.textContent = CFG.i18n.collecting;

		post( 'snap_bl_collect', {} ).then( function ( d ) {
			var total = d.total;
			var brokenTotal = 0;
			if ( ! total ) {
				status.textContent = CFG.i18n.noLinks;
				scanBtn.disabled = false;
				return;
			}
			function step() {
				post( 'snap_bl_batch', {} ).then( function ( r ) {
					brokenTotal += r.broken_found;
					var doneCount = total - r.remaining;
					bar.style.width = Math.min( 100, Math.round( doneCount / total * 100 ) ) + '%';
					status.textContent = doneCount + ' / ' + total + ' ' + CFG.i18n.linksChecked + ' — ' + brokenTotal + ' ' + CFG.i18n.broken;
					if ( ! r.done ) { step(); } else { window.location.reload(); }
				} ).catch( function ( err ) {
					status.textContent = err.message;
					scanBtn.disabled = false;
				} );
			}
			step();
		} ).catch( function ( err ) {
			status.textContent = err.message;
			scanBtn.disabled = false;
		} );
	} );

	document.querySelectorAll( '.snap-bl-act' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var data = { id: btn.dataset.id, do: btn.dataset.do };
			if ( 'update' === btn.dataset.do ) {
				var url = window.prompt( CFG.i18n.replaceWith );
				if ( ! url ) { return; }
				data.new_url = url;
			}
			if ( 'unlink' === btn.dataset.do && ! window.confirm( CFG.i18n.confirmUnlink ) ) { return; }
			btn.disabled = true;
			post( 'snap_bl_action', data ).then( function () {
				var row = btn.closest( 'tr' );
				if ( row ) { row.remove(); }
			} ).catch( function ( err ) {
				btn.disabled = false;
				window.alert( err.message );
			} );
		} );
	} );
} )();
