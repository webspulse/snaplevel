/**
 * Snaplevel — Guides slide-out panel behavior.
 */
( function () {
	'use strict';
	var openBtn = document.getElementById( 'snap-guides-open' );
	var panel   = document.getElementById( 'snap-guides' );
	var overlay = document.getElementById( 'snap-guides-overlay' );
	if ( ! openBtn || ! panel ) { return; }
	function close() { panel.style.display = 'none'; overlay.style.display = 'none'; }
	openBtn.addEventListener( 'click', function () {
		panel.style.display = 'flex';
		overlay.style.display = 'block';
	} );
	overlay.addEventListener( 'click', close );
	document.getElementById( 'snap-guides-close' ).addEventListener( 'click', close );
	document.addEventListener( 'keydown', function ( e ) { if ( 'Escape' === e.key ) { close(); } } );
	panel.querySelectorAll( 'details' ).forEach( function ( d ) {
		d.addEventListener( 'toggle', function () {
			var a = d.querySelector( '.snap-guide-arrow' );
			if ( a ) { a.style.transform = d.open ? 'rotate(180deg)' : ''; }
		} );
	} );
	document.addEventListener( 'click', function ( e ) {
		var helpIcon = e.target.closest( '.dashicons-editor-help' );
		var link     = e.target.closest( 'a' );
		if ( helpIcon || ( link && link.querySelector( '.dashicons-editor-help' ) ) ) {
			e.preventDefault();
			panel.style.display = 'flex';
			overlay.style.display = 'block';
		}
	} );
} )();
