/**
 * Snaplevel — Compression admin view.
 * Requires: window.SNAP_COMPRESSION localized config.
 */
( function( $ ) {
	'use strict';
	var CFG           = window.SNAP_COMPRESSION || {};
	var nonce         = CFG.nonce || '';
	var ajaxurl       = CFG.ajaxurl || '';
	var isRunning     = false;
	var stopRequested = false;
	var processed     = 0;
	var total         = 0;

	loadStats();

	$( '#icw-scan-stats-btn' ).on( 'click', function() {
		var $btn = $( this );
		var original = $btn.html();
		$btn.prop( 'disabled', true ).text( CFG.i18n.refreshing );
		$.post( ajaxurl, { action: 'icw_get_compression_stats', nonce: nonce }, function( res ) {
			$btn.prop( 'disabled', false ).html( original );
			if ( res.success ) { updateStatsUI( res.data ); }
		} ).fail( function( xhr ) {
			$btn.prop( 'disabled', false ).html( original );
			alert( 'Stats refresh failed. Server error: ' + xhr.status );
		} );
	} );

	function loadStats() {
		$.post( ajaxurl, { action: 'icw_get_compression_stats', nonce: nonce }, function( res ) {
			if ( res.success ) { updateStatsUI( res.data ); }
		} );
	}

	function updateStatsUI( data ) {
		$( '#stat-total' ).text( data.total );
		$( '#stat-over100' ).text( data.over_100kb !== undefined ? data.over_100kb : data.unprocessed );
		$( '#stat-processed' ).text( data.processed );
		$( '#stat-saved' ).text( data.saved_fmt || data.saved );
		total = parseInt( data.over_100kb !== undefined ? data.over_100kb : data.unprocessed ) || 0;
		$( '#icw-total-count' ).text( total );
	}

	$( '#icw-start-compress' ).on( 'click', function() {
		if ( isRunning ) return;
		if ( total === 0 ) {
			alert( CFG.i18n.noLarge );
			return;
		}
		isRunning     = true;
		stopRequested = false;
		processed     = 0;
		$( this ).prop( 'disabled', true ).text( CFG.i18n.running );
		$( '#icw-stop-compress' ).show();
		$( '#icw-progress-wrap' ).slideDown( 300 );
		$( '#icw-progress-log' ).html( '' );
		processNext();
	} );

	$( '#icw-stop-compress' ).on( 'click', function( e ) {
		e.preventDefault();
		if ( isRunning ) {
			stopRequested = true;
			$( this ).text( CFG.i18n.stopping );
		}
	} );

	function processNext() {
		if ( stopRequested ) {
			log( '<span style="color:#e8cb57;">[STOPPED] ' + CFG.i18n.halted + '</span>' );
			finishRun();
			return;
		}

		$.post( ajaxurl, { action: 'icw_bulk_compress_next', nonce: nonce }, function( res ) {
			if ( ! res.success ) {
				log( '<span style="color:#ee6a5e;">[ERROR] ' + ( res.data || 'Unknown error' ) + '</span>' );
				finishRun();
				return;
			}

			if ( res.data.done ) {
				$( '#icw-progress-bar' ).css( 'width', '100%' );
				$( '#icw-progress-label' ).html( '<span style="color:#8fd6a7;">✓ ' + CFG.i18n.allDone + '</span>' );
				finishRun();
				return;
			}

			processed++;
			var pct = total > 0 ? Math.min( Math.round( ( processed / total ) * 100 ), 100 ) : 0;
			$( '#icw-progress-bar' ).css( 'width', pct + '%' );
			$( '#icw-progress-fraction' ).html( processed + ' / ' + total );
			$( '#icw-progress-label' ).text( CFG.i18n.compressing + ' ' + processed + ' / ' + total + '…' );

			var d = res.data;
			var color = d.saved_pct > 50 ? '#8fd6a7' : '#9db8e8';
			if ( d.saved_pct < 10 ) color = '#e8cb57';

			log( '<span style="color:' + color + ';">[' + String( processed ).padStart( 3, '0' ) + '] ' +
				d.filename + ' — ' +
				d.original_kb + ' KB → ' + d.new_kb + ' KB &nbsp;' +
				'<strong style="color:#fff;">(' + d.saved_pct + '% smaller)</strong>' +
				'</span>' );

			processNext();
		} ).fail( function( xhr ) {
			log( '<span style="color:#ee6a5e;">[CRITICAL ERROR] Server returned ' + xhr.status + '. Compression halted.</span>' );
			finishRun();
		} );
	}

	function finishRun() {
		isRunning = false;
		$( '#icw-start-compress' ).prop( 'disabled', false ).html( CFG.btnHtml );
		$( '#icw-stop-compress' ).hide().text( CFG.i18n.stop );
		loadStats();
	}

	function log( html ) {
		var $log = $( '#icw-progress-log' );
		$log.append( '<div class="snap-log-line">' + html + '</div>' );
		$log.scrollTop( $log[0].scrollHeight );
	}

	// Detailed scanner.
	var scanOffset = 0;
	var scanLimit  = 30;

	$( '#icw-detailed-scan-btn' ).on( 'click', function() {
		$( '#icw-detailed-scanner-results' ).hide();
		$( '#icw-detailed-scanner-tbody' ).empty();
		$( '#icw-detailed-scanner-status' ).show();
		$( this ).prop( 'disabled', true );
		scanOffset = 0;
		loadDetailedScanner();
	} );

	$( '#icw-detailed-load-more' ).on( 'click', function() {
		$( this ).prop( 'disabled', true ).text( CFG.i18n.loading );
		loadDetailedScanner();
	} );

	function loadDetailedScanner() {
		$.post( ajaxurl, { action: 'icw_get_detailed_scanner', nonce: nonce, offset: scanOffset, limit: scanLimit }, function( res ) {
			$( '#icw-detailed-scanner-status' ).hide();
			$( '#icw-detailed-scan-btn' ).prop( 'disabled', false );

			if ( res.success ) {
				$( '#icw-detailed-scanner-results' ).show();
				res.data.items.forEach( function( item ) {
					var kb = Math.round( item.size / 1024 );
					var sizeBadge = kb > 100 ? '<span class="snap-badge snap-badge-red">' + kb + ' KB</span>' : '<span class="snap-badge snap-badge-green">' + kb + ' KB</span>';
					var compBadge = item.compressed ? '<span class="snap-pill snap-pill-blue">' + CFG.i18n.compressed + '</span>' : '<span class="snap-pill snap-pill-amber">' + CFG.i18n.original + '</span>';
					var altBadge = item.has_alt ? '<span class="snap-pill snap-pill-green">' + CFG.i18n.added + '</span>' : '<span class="snap-pill snap-pill-red">' + CFG.i18n.missing + '</span>';

					var html = '<tr>' +
						'<td><div style="display:flex;align-items:center;gap:10px;">' +
							'<img src="' + item.thumb + '" style="width:36px;height:36px;border-radius:3px;object-fit:cover;" alt="">' +
							'<span style="font-weight:600;max-width:280px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:inline-block;">' + item.title + '</span>' +
						'</div></td>' +
						'<td>' + sizeBadge + '</td>' +
						'<td>' + compBadge + '</td>' +
						'<td>' + altBadge + '</td>' +
					'</tr>';
					$( '#icw-detailed-scanner-tbody' ).append( html );
				} );

				scanOffset += scanLimit;
				if ( scanOffset < res.data.total ) {
					$( '#icw-detailed-load-more' ).show().prop( 'disabled', false ).text( CFG.i18n.loadMore );
				} else {
					$( '#icw-detailed-load-more' ).hide();
				}
			} else {
				alert( 'Scanner failed: ' + res.data );
			}
		} ).fail( function( xhr ) {
			$( '#icw-detailed-scanner-status' ).hide();
			$( '#icw-detailed-scan-btn' ).prop( 'disabled', false );
			alert( 'Detailed scanner request failed. Error: ' + xhr.status );
		} );
	}
} )( jQuery );
