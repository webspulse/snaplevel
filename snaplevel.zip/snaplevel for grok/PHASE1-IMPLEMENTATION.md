# Phase 1: Final Implementation Plan

## Scope (locked)

| Feature | Description | Status |
|---------|-------------|--------|
| Copilot sidebar panel | 4 states, opportunity cards, manual Analyze button | Build |
| Fix with AI | Per-opportunity AI fix (meta desc, title, FAQ schema) | Build |
| Fix All with AI | Sequential fix of all fixable opportunities | Build |
| 30-second magic onboarding | Quick scan + inline key entry + live generation | Build |
| Dashboard caching | Tiered TTL (real-time/1-min/5-min/1-hour) | Build |
| Empty states | All admin views get branded empty states | Build |
| Auto-analyze on save | Beta setting, OFF by default, offered after first manual success | Build (hidden) |

## Deferred to Phase 2

- AI Training improvements
- Internal link suggestions (requires content index)
- FAQ schema generation (requires separate AI task)
- Weekly SEO digest email
- WP 7.0 AI Client integration
- Advanced automation / autopilot

---

## Smallest "Wow" Deliverable

**The atomic wow is: user clicks Analyze, sees opportunities, clicks Fix, sees AI-generated meta description appear in the field.**

Everything else amplifies this. But if ONLY this works, users will leave 5-star reviews.

Minimum viable path:
1. `copilot_analyze` AI task (tells you what's wrong)
2. Existing `meta_description` AI task (fixes the meta)
3. Sidebar UI that connects them

That's 3 files changed, ~200 lines of PHP, ~300 lines of JS. Achievable in 1 day.

---

## API Cost Estimates

| Action | Model tier | Tokens in | Tokens out | Cost per call |
|--------|-----------|-----------|------------|---------------|
| Copilot Analyze | Fast (Haiku/4o-mini) | ~2000 | ~500 | ~$0.001 |
| Generate meta description | Fast | ~1500 | ~200 | ~$0.0005 |
| Generate SEO title | Fast | ~1500 | ~200 | ~$0.0005 |
| Fix All (3 opportunities) | Fast x3 | ~5000 total | ~900 total | ~$0.003 |
| Onboarding demo generation | Fast | ~1500 | ~200 | ~$0.0005 |

**Typical user session cost: $0.002-0.005**
**Monthly cost for daily user (1 analyze + 2 fixes per day): ~$0.15**
**Annual cost per active user: ~$1.80 on their own key**

This is negligible. No user will notice this on their API bill.

---

## Implementation Sequence

### Day 1: Copilot Backend
1. Add `copilot_analyze` task to `Snap_AI_Prompts`
2. Create `includes/core/class-copilot.php` (settings, post meta registration, optional save hook)
3. Register `_snap_copilot_analysis` post meta with `show_in_rest`
4. Wire into `snaplevel.php` bootstrap

### Day 2: Copilot Frontend
1. Add Copilot panel to `editor-sidebar.js`
2. States: ready, analyzing, opportunities, all-clear
3. "Analyze" button calls existing `/ai/generate` with task `copilot_analyze`
4. "Fix with AI" buttons call existing `/ai/generate` with task `meta_description` or `seo_title`
5. Results write directly to post meta fields (user sees them populate)

### Day 3: Onboarding Wizard
1. Add `/wizard/quick-scan` REST endpoint (no AI, pure SQL)
2. Rewrite wizard.js Step 1: "Show me" -> quick scan -> sample post
3. Inline key entry + validation
4. Live generation demo using existing `/ai/generate`
5. Success screen with Copilot opt-in

### Day 4: Dashboard + Empty States
1. Create `Snap_Dashboard_Stats` class with tiered caching
2. Refactor `dashboard.php` to use the new class
3. Create `admin/partials/empty-state.php` partial
4. Add empty states to all 6 admin views

### Day 5: Polish + Compliance
1. Extract inline scripts (or use wp_localize_script fallback)
2. CSS polish pass for Copilot + wizard components
3. Run WP Plugin Check
4. Manual QA of all flows

---

## File Change Map

### New files (5)

```
includes/core/class-copilot.php          (~120 lines)
includes/core/class-dashboard-stats.php  (~100 lines)
includes/core/class-first-run.php        (~40 lines)
admin/partials/empty-state.php           (~20 lines)
assets/js/views/                         (6 extracted JS files, Day 5)
```

### Modified files (8)

```
includes/ai/class-ai-prompts.php         (add copilot_analyze task)
includes/core/class-rest-api.php         (add /wizard/quick-scan endpoint)
includes/core/class-assets.php           (add copilotAnalysis to SNAP_SIDEBAR)
assets/js/editor-sidebar.js             (add Copilot panel)
assets/js/wizard.js                     (rewrite step 1)
admin/views/wizard.php                  (restructure for magic moment)
admin/views/dashboard.php               (use Snap_Dashboard_Stats)
snaplevel.php                           (require new classes)
assets/css/design-system.css            (Copilot component styles)
```

### Unchanged (everything else)

AI engine, providers, REST permission system, settings, all other modules.

---

## Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| AI returns bad suggestions | Validate against schema. If malformed, show "Couldn't analyze. Try again." |
| User has no API key during Copilot use | Show "Connect AI to use Copilot" with link to settings. Never crash. |
| Wizard quick-scan on empty site | Show "Your site is brand new" message. Skip to key entry. |
| Fix with AI writes bad meta | User must still Save the post to commit. Nothing is live until they save. |
| Performance on large sites (50k posts) | Quick-scan SQL uses COUNT with index. Dashboard stats are cached. |

---

## Success Criteria

Phase 1 ships when:
- [ ] Fresh install: wizard shows quick-scan results within 2 seconds
- [ ] First AI generation completes within 5 seconds
- [ ] Copilot Analyze returns opportunities within 4 seconds
- [ ] Fix with AI populates the meta field and user sees it change
- [ ] Fix All processes 3+ opportunities sequentially without error
- [ ] Dashboard loads in <200ms (cached)
- [ ] Empty states show on all views when data is empty
- [ ] WP Plugin Check: zero errors
- [ ] Works without API key (all features degrade gracefully)
