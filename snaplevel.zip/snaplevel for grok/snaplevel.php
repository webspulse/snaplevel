<?php
/**
 * Plugin Name:       Snaplevel
 * Plugin URI:        https://autogencrm.com
 * Description:       The all-in-one SEO plugin where AI does the work. AI titles, descriptions, schema, alt text, redirections + 404 monitor, broken link checker, breadcrumbs, sitemaps, 8-plugin importers, AI training, and smart image compression. Works with Claude, ChatGPT, Gemini, DeepSeek, and Mistral.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Autogencrm
 * Author URI:        https://autogencrm.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       snaplevel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SNAP_VERSION',     '1.0.0' );
define( 'SNAP_PLUGIN_FILE', __FILE__ );
define( 'SNAP_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SNAP_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

// Legacy aliases for backward compatibility with older installs (internal only — all user-facing UI is pure Snaplevel).
if ( ! defined( 'ICW_VERSION' ) )     { define( 'ICW_VERSION',     SNAP_VERSION ); }
if ( ! defined( 'ICW_PLUGIN_FILE' ) ) { define( 'ICW_PLUGIN_FILE', SNAP_PLUGIN_FILE ); }
if ( ! defined( 'ICW_PLUGIN_DIR' ) )  { define( 'ICW_PLUGIN_DIR',  SNAP_PLUGIN_DIR ); }
if ( ! defined( 'ICW_PLUGIN_URL' ) )  { define( 'ICW_PLUGIN_URL',  SNAP_PLUGIN_URL ); }
if ( ! defined( 'ICW_PREFIX' ) )      { define( 'ICW_PREFIX',      'icw' ); }

// ── Core Bootstrapper ─────────────────────────────────────────────────────────
final class Snap_Plugin {

	/** @var Snap_Plugin|null */
	private static $instance = null;

	public static function instance(): Snap_Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		register_activation_hook( SNAP_PLUGIN_FILE,   array( $this, 'activate' ) );
		register_deactivation_hook( SNAP_PLUGIN_FILE, array( $this, 'deactivate' ) );
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init(): void {
		$this->load_core();
		$this->load_ai();

		Snap_Module_Loader::instance()->boot_active_modules();

		do_action( 'snaplevel_loaded' );
	}

	private function load_core(): void {
		require_once SNAP_PLUGIN_DIR . 'includes/class-htaccess-manager.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-icons.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-settings.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-capabilities.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-module-loader.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-assets.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-rest-api.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-copilot.php';
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-dashboard-stats.php';

		Snap_Settings::instance()->maybe_migrate();
		new Snap_Assets();
		new Snap_REST_API();
		new Snap_Copilot();
		new Snap_Dashboard_Stats();

		// Search engine verification meta tags (always on).
		require_once SNAP_PLUGIN_DIR . 'includes/modules/core/class-webmasters.php';
		new Snap_Webmasters();

		// GA4 / AdSense / custom code injection (always on).
		require_once SNAP_PLUGIN_DIR . 'includes/modules/core/class-code-injector.php';
		new Snap_Code_Injector();

		// Admin UI (menus + views).
		require_once SNAP_PLUGIN_DIR . 'includes/modules/core/class-admin-menu.php';
		require_once SNAP_PLUGIN_DIR . 'includes/modules/core/class-settings-ajax.php';
		new ICW_Admin_Menu();
		new ICW_Settings_Ajax();
	}

	private function load_ai(): void {
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-provider.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/providers/class-provider-anthropic.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/providers/class-provider-openai.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/providers/class-provider-compatibles.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/providers/class-provider-snaplevel.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-prompts.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-cache.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-usage.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-training.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-self-training.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-queue.php';
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-engine.php';

		Snap_AI_Queue::instance()->init();
		new Snap_AI_Self_Training();
	}

	public function activate(): void {
		if ( class_exists( 'ICW_Htaccess_Manager' ) ) {
			ICW_Htaccess_Manager::add_webp_rules();
		}

		// Settings + migration from icw_settings.
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-settings.php';
		Snap_Settings::instance()->maybe_migrate();

		// Capabilities.
		require_once SNAP_PLUGIN_DIR . 'includes/core/class-capabilities.php';
		Snap_Capabilities::add_caps();

		// Tables: AI usage log, AI training, legacy SEO analyzer tables.
		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-usage.php';
		Snap_AI_Usage::create_table();

		require_once SNAP_PLUGIN_DIR . 'includes/ai/class-ai-training.php';
		Snap_AI_Training::create_table();

		// Redirections + 404 monitor and broken-link tables.
		require_once SNAP_PLUGIN_DIR . 'includes/modules/redirections/class-redirections.php';
		Snap_Redirections::create_tables();

		require_once SNAP_PLUGIN_DIR . 'includes/modules/broken-links/class-broken-links.php';
		Snap_Broken_Links::create_table();

		if ( file_exists( SNAP_PLUGIN_DIR . 'includes/modules/seo-analyzer/class-seo-analyzer.php' ) ) {
			require_once SNAP_PLUGIN_DIR . 'includes/modules/seo-analyzer/class-seo-analyzer.php';
			if ( class_exists( 'ICW_SEO_Scanner' ) ) {
				ICW_SEO_Scanner::create_tables();
			}
		}

		// Secure backups dir (compression module).
		$upload_dir  = wp_upload_dir();
		$backups_dir = $upload_dir['basedir'] . '/icw-backups';
		if ( ! is_dir( $backups_dir ) ) {
			wp_mkdir_p( $backups_dir );
		}
		$htaccess = $backups_dir . '/.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			@file_put_contents( $htaccess, "Order deny,allow\nDeny from all\n" );
		}

		// Sitemap rewrite rules need a flush on next init.
		update_option( 'snap_flush_rewrites', 1 );

		// First-run flag → onboarding wizard redirect.
		if ( false === get_option( 'snap_wizard_done', false ) && false === get_option( 'snap_wizard_skipped', false ) ) {
			update_option( 'snap_show_wizard_redirect', 1 );
		}
	}

	public function deactivate(): void {
		if ( class_exists( 'ICW_Htaccess_Manager' ) ) {
			ICW_Htaccess_Manager::remove_webp_rules();
		}
		wp_clear_scheduled_hook( 'snap_ai_queue_run' );
		wp_clear_scheduled_hook( 'snap_ai_self_training_run' );
		wp_clear_scheduled_hook( 'snap_broken_links_recheck' );
		flush_rewrite_rules();
	}
}

Snap_Plugin::instance();

