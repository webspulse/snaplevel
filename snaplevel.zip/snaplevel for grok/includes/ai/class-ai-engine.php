<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI — the one public AI API.
 *
 * No module ever calls a provider directly. Everything goes through:
 *   Snap_AI::generate( $task, $context )
 *
 * Providers: Anthropic (Claude) and OpenAI (ChatGPT), switchable in
 * settings. Flow: prompt template → site knowledge injection → cache →
 * provider call (forced structured output) → schema validation →
 * usage log → cache → return.
 */
final class Snap_AI {

	/** Sensible default models per provider and tier. Filterable. */
	public static function default_model( string $provider, string $tier ): string {
		$defaults = apply_filters( 'snaplevel_ai_default_models', array(
			'anthropic' => array( 'fast' => 'claude-haiku-4-5-20251001', 'smart' => 'claude-sonnet-4-6' ),
			'openai'    => array( 'fast' => 'gpt-4o-mini', 'smart' => 'gpt-4o' ),
			'gemini'    => array( 'fast' => 'gemini-2.5-flash', 'smart' => 'gemini-2.5-pro' ),
			'deepseek'  => array( 'fast' => 'deepseek-chat', 'smart' => 'deepseek-chat' ),
			'mistral'   => array( 'fast' => 'mistral-small-latest', 'smart' => 'mistral-large-latest' ),
		) );
		return (string) ( $defaults[ $provider ][ $tier ] ?? $defaults['anthropic']['fast'] );
	}

	/**
	 * Resolve the model for a tier, respecting user overrides but never
	 * sending a Claude model to OpenAI or vice versa.
	 */
	public static function resolve_model( string $provider, string $tier ): string {
		$override = (string) Snap_Settings::instance()->get( 'fast' === $tier ? 'ai.model_fast' : 'ai.model_smart', '' );
		if ( '' === $override ) {
			return self::default_model( $provider, $tier );
		}
		// Never send another family's model to a provider.
		$prefixes = array(
			'anthropic' => 'claude',
			'openai'    => 'gpt',
			'gemini'    => 'gemini',
			'deepseek'  => 'deepseek',
			'mistral'   => 'mistral',
		);
		$prefix = $prefixes[ $provider ] ?? '';
		if ( '' !== $prefix && 0 !== stripos( $override, $prefix ) ) {
			return self::default_model( $provider, $tier );
		}
		return $override;
	}

	/**
	 * @return Snap_AI_Provider|WP_Error
	 */
	public static function provider() {
		$id = (string) Snap_Settings::instance()->get( 'ai.provider', 'anthropic' );

		/**
		 * Filter the provider instance. Allows custom providers.
		 *
		 * @param Snap_AI_Provider|null $provider
		 * @param string                $id
		 */
		$custom = apply_filters( 'snaplevel_ai_provider', null, $id );
		if ( $custom instanceof Snap_AI_Provider ) {
			return $custom;
		}

		switch ( $id ) {
			case 'openai':
				return new Snap_Provider_OpenAI();
			case 'gemini':
				return new Snap_Provider_Gemini();
			case 'deepseek':
				return new Snap_Provider_DeepSeek();
			case 'mistral':
				return new Snap_Provider_Mistral();
			case 'snaplevel':
				return new Snap_Provider_Snaplevel();
			case 'anthropic':
			default:
				return new Snap_Provider_Anthropic();
		}
	}

	/**
	 * Generate a structured result for an AI task.
	 *
	 * @param string $task    Task id (see Snap_AI_Prompts).
	 * @param array  $context Task context (content, focus_keyword, image_url, …).
	 * @param array  $opts    { skip_cache?: bool }
	 * @return array|WP_Error { data, tokens_in, tokens_out, model, cached }
	 */
	public static function generate( string $task, array $context = array(), array $opts = array() ) {
		$definition = Snap_AI_Prompts::get_task( $task );
		if ( is_wp_error( $definition ) ) {
			return $definition;
		}

		$provider = self::provider();
		if ( is_wp_error( $provider ) ) {
			return $provider;
		}

		// Built-in SEO/AEO/GEO playbook (self-training layer 1) + the site
		// knowledge base, both injected into the system prompt for content
		// tasks. Part of the cache key via the training hash.
		$system = (string) $definition['system'];
		if ( ! empty( $definition['training'] ) ) {
			$blocks = '';
			if ( class_exists( 'Snap_AI_Self_Training' ) ) {
				$blocks .= Snap_AI_Self_Training::playbook_block();
			}
			if ( class_exists( 'Snap_AI_Training' ) ) {
				$blocks .= Snap_AI_Training::context_block();
			}
			if ( '' !== $blocks ) {
				$system .= $blocks;
				$context['_training_hash'] = md5( $blocks );
			}

			// SEO Memory: style rules learned from this site's editing history.
			$memory = trim( (string) Snap_Settings::instance()->get( 'ai.memory_rules', '' ) );
			if ( '' !== $memory ) {
				$system .= "\n\n## Site style rules (learned from how this user edits AI output — always follow these)\n" . $memory;
				$context['_memory_hash'] = md5( $memory );
			}
		}

		// Cache also keyed by provider so switching providers regenerates.
		$context['_provider'] = $provider->id();

		if ( empty( $opts['skip_cache'] ) ) {
			$cached = Snap_AI_Cache::get( $task, $context );
			if ( null !== $cached ) {
				$cached['cached'] = true;
				return $cached;
			}
		}

		$model = self::resolve_model( $provider->id(), (string) ( $definition['tier'] ?? 'fast' ) );

		$ctx_for_prompt = $context;
		unset( $ctx_for_prompt['_training_hash'], $ctx_for_prompt['_provider'], $ctx_for_prompt['_memory_hash'] );
		$user_content = call_user_func( $definition['user'], $ctx_for_prompt );

		$result = $provider->complete( array(
			'model'      => $model,
			'system'     => $system,
			'messages'   => array(
				array( 'role' => 'user', 'content' => $user_content ),
			),
			'schema'     => (array) $definition['schema'],
			'max_tokens' => (int) ( $definition['max_tokens'] ?? 1024 ),
		) );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Validate against the task schema before anything is saved or shown.
		$validation = self::validate( $result['data'], (array) $definition['schema'] );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$result['data'] = self::sanitize_output( $result['data'] );

		Snap_AI_Usage::log( $task, (string) $result['model'], (int) $result['tokens_in'], (int) $result['tokens_out'] );

		$result['cached'] = false;
		Snap_AI_Cache::set( $task, $context, $result );

		return $result;
	}

	/** Is auto mode enabled for a specific task? Off by default, per-task opt-in. */
	public static function auto_mode_enabled( string $task ): bool {
		$modes = (array) Snap_Settings::instance()->get( 'ai.auto_modes', array() );
		return ! empty( $modes[ $task ] );
	}

	// ── Validation ────────────────────────────────────────────────────────────

	/**
	 * Minimal JSON-Schema validation: required keys, types, maxLength,
	 * enum, array min/max items. Enough to guarantee we never save junk.
	 *
	 * @return true|WP_Error
	 */
	private static function validate( $data, array $schema ) {
		$err = self::validate_node( $data, $schema, '$' );
		if ( null !== $err ) {
			return new WP_Error( 'snap_ai_invalid_output', sprintf(
				/* translators: %s: validation detail */
				__( 'AI output failed validation (%s). Nothing was saved. Please retry.', 'snaplevel' ),
				$err
			) );
		}
		return true;
	}

	private static function validate_node( $data, array $schema, string $path ): ?string {
		$type = $schema['type'] ?? null;

		if ( 'object' === $type ) {
			if ( ! is_array( $data ) ) {
				return "{$path} is not an object";
			}
			foreach ( (array) ( $schema['required'] ?? array() ) as $key ) {
				if ( ! array_key_exists( $key, $data ) ) {
					return "{$path}.{$key} is missing";
				}
			}
			foreach ( (array) ( $schema['properties'] ?? array() ) as $key => $sub ) {
				if ( array_key_exists( $key, $data ) ) {
					$err = self::validate_node( $data[ $key ], (array) $sub, "{$path}.{$key}" );
					if ( null !== $err ) {
						return $err;
					}
				}
			}
			return null;
		}

		if ( 'array' === $type ) {
			if ( ! is_array( $data ) ) {
				return "{$path} is not an array";
			}
			if ( isset( $schema['minItems'] ) && count( $data ) < $schema['minItems'] ) {
				return "{$path} has too few items";
			}
			if ( isset( $schema['maxItems'] ) && count( $data ) > $schema['maxItems'] ) {
				return "{$path} has too many items";
			}
			if ( isset( $schema['items'] ) ) {
				foreach ( $data as $i => $item ) {
					$err = self::validate_node( $item, (array) $schema['items'], "{$path}[{$i}]" );
					if ( null !== $err ) {
						return $err;
					}
				}
			}
			return null;
		}

		if ( 'string' === $type ) {
			if ( ! is_string( $data ) ) {
				return "{$path} is not a string";
			}
			if ( isset( $schema['maxLength'] ) && function_exists( 'mb_strlen' ) && mb_strlen( $data ) > $schema['maxLength'] ) {
				return "{$path} is too long";
			}
			if ( isset( $schema['enum'] ) && ! in_array( $data, (array) $schema['enum'], true ) ) {
				return "{$path} is not an allowed value";
			}
			return null;
		}

		if ( 'integer' === $type || 'number' === $type ) {
			if ( ! is_numeric( $data ) ) {
				return "{$path} is not a number";
			}
			if ( isset( $schema['minimum'] ) && $data < $schema['minimum'] ) {
				return "{$path} is below minimum";
			}
			if ( isset( $schema['maximum'] ) && $data > $schema['maximum'] ) {
				return "{$path} is above maximum";
			}
			return null;
		}

		if ( 'boolean' === $type ) {
			return is_bool( $data ) ? null : "{$path} is not a boolean";
		}

		return null; // Unknown type — pass.
	}

	/** Recursively sanitize string output. */
	private static function sanitize_output( $data ) {
		if ( is_array( $data ) ) {
			return array_map( array( __CLASS__, 'sanitize_output' ), $data );
		}
		if ( is_string( $data ) ) {
			return sanitize_textarea_field( $data );
		}
		return $data;
	}
}
