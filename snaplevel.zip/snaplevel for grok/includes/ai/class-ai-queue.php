<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI_Queue — background queue for bulk AI jobs.
 *
 * v1 is a lightweight WP-Cron batch queue behind a stable API
 * (push / status / cancel). The interface is deliberately small so it
 * can be swapped for Action Scheduler later without touching callers.
 *
 * Job shape: [ 'id', 'task', 'context', 'callback' (named action), 'status' ]
 * Completed jobs fire: do_action( 'snap_ai_job_complete', $job, $result )
 */
final class Snap_AI_Queue {

	const OPTION     = 'snap_ai_queue';
	const CRON_HOOK  = 'snap_ai_queue_run';
	const BATCH_SIZE = 5;

	/** @var Snap_AI_Queue|null */
	private static $instance = null;

	public static function instance(): Snap_AI_Queue {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function init(): void {
		add_filter( 'cron_schedules', array( $this, 'add_schedule' ) );
		add_action( self::CRON_HOOK, array( $this, 'process_batch' ) );
	}

	public function add_schedule( array $schedules ): array {
		$schedules['snap_minutely'] = array(
			'interval' => 60,
			'display'  => __( 'Every minute (Snaplevel AI queue)', 'snaplevel' ),
		);
		return $schedules;
	}

	/**
	 * Queue an AI job.
	 *
	 * @param string $task    AI task id.
	 * @param array  $context Task context.
	 * @param string $group   Optional group label (e.g. 'bulk_alt_text').
	 * @return string Job id.
	 */
	public function push( string $task, array $context, string $group = '' ): string {
		$jobs = $this->jobs();
		$id   = uniqid( 'job_', true );

		$jobs[ $id ] = array(
			'id'      => $id,
			'task'    => $task,
			'context' => $context,
			'group'   => $group,
			'status'  => 'pending',
			'error'   => '',
			'created' => time(),
		);
		$this->save_jobs( $jobs );
		$this->ensure_scheduled();

		return $id;
	}

	public function process_batch(): void {
		$jobs      = $this->jobs();
		$processed = 0;

		foreach ( $jobs as $id => $job ) {
			if ( 'pending' !== $job['status'] ) {
				continue;
			}
			if ( $processed >= self::BATCH_SIZE ) {
				break;
			}

			$jobs[ $id ]['status'] = 'running';
			$this->save_jobs( $jobs );

			$result = Snap_AI::generate( (string) $job['task'], (array) $job['context'] );

			if ( is_wp_error( $result ) ) {
				$jobs[ $id ]['status'] = 'failed';
				$jobs[ $id ]['error']  = $result->get_error_message();
			} else {
				$jobs[ $id ]['status'] = 'done';
				/**
				 * A queued AI job finished. Listeners apply the result
				 * (always behind user approval unless auto mode is on).
				 */
				do_action( 'snap_ai_job_complete', $jobs[ $id ], $result );
			}
			$processed++;
		}

		// Prune finished jobs older than a day.
		foreach ( $jobs as $id => $job ) {
			if ( in_array( $job['status'], array( 'done', 'failed' ), true ) && $job['created'] < time() - DAY_IN_SECONDS ) {
				unset( $jobs[ $id ] );
			}
		}
		$this->save_jobs( $jobs );

		if ( $this->count_pending( $jobs ) === 0 ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}
	}

	public function status(): array {
		$jobs    = $this->jobs();
		$summary = array( 'pending' => 0, 'running' => 0, 'done' => 0, 'failed' => 0 );
		foreach ( $jobs as $job ) {
			if ( isset( $summary[ $job['status'] ] ) ) {
				$summary[ $job['status'] ]++;
			}
		}
		return $summary;
	}

	public function cancel_group( string $group ): int {
		$jobs    = $this->jobs();
		$removed = 0;
		foreach ( $jobs as $id => $job ) {
			if ( $job['group'] === $group && 'pending' === $job['status'] ) {
				unset( $jobs[ $id ] );
				$removed++;
			}
		}
		$this->save_jobs( $jobs );
		return $removed;
	}

	// ── Internals ─────────────────────────────────────────────────────────────

	private function jobs(): array {
		$jobs = get_option( self::OPTION, array() );
		return is_array( $jobs ) ? $jobs : array();
	}

	private function save_jobs( array $jobs ): void {
		update_option( self::OPTION, $jobs, false );
	}

	private function count_pending( array $jobs ): int {
		$n = 0;
		foreach ( $jobs as $job ) {
			if ( 'pending' === $job['status'] ) {
				$n++;
			}
		}
		return $n;
	}

	private function ensure_scheduled(): void {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 30, 'snap_minutely', self::CRON_HOOK );
		}
	}
}
