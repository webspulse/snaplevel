<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI_Provider — abstract provider interface.
 *
 * Every provider returns structured data (parsed JSON), never prose.
 * Switching between "user key" (Anthropic) and "Snaplevel proxy" is a
 * settings toggle, not a rewrite.
 */
abstract class Snap_AI_Provider {

	/**
	 * Run a completion that MUST return structured output.
	 *
	 * @param array $args {
	 *     @type string $model       Model id.
	 *     @type string $system      System prompt.
	 *     @type array  $messages    [ [ 'role' => 'user', 'content' => string|array of blocks ] ].
	 *     @type array  $schema      JSON Schema the output must satisfy.
	 *     @type int    $max_tokens  Token cap.
	 * }
	 * @return array|WP_Error {
	 *     @type array  $data       Parsed structured output.
	 *     @type int    $tokens_in
	 *     @type int    $tokens_out
	 *     @type string $model
	 * }
	 */
	abstract public function complete( array $args );

	/**
	 * Cheap connectivity / key validity test.
	 *
	 * @return true|WP_Error
	 */
	abstract public function test();

	/** Provider id, e.g. 'anthropic'. */
	abstract public function id(): string;
}
