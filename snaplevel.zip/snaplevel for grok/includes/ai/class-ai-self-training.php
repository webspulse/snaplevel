<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI_Self_Training — the AI is SEO-trained out of the box.
 *
 * Two layers, both on by default ( ai.self_training ):
 *
 * 1. BAKED-IN PLAYBOOK — a condensed SEO / AEO / GEO expert system
 *    injected into every training-enabled AI prompt. Zero network calls,
 *    works the second the plugin is activated.
 *
 * 2. WEEKLY NEWS DIGEST — WP-Cron pulls the latest headlines + summaries
 *    from official sources (Google Search Central, The Keyword, Ahrefs,
 *    Search Engine Land, Search Engine Journal) via their RSS feeds and
 *    stores a digest document in the knowledge base, so the AI knows
 *    about current algorithm updates without the user doing anything.
 */
final class Snap_AI_Self_Training {

	const CRON_HOOK  = 'snap_ai_self_training_run';
	const DOC_OPTION = 'snap_self_training_doc_id';

	/** RSS feeds — official / primary sources only. */
	public static function sources(): array {
		return apply_filters( 'snaplevel_self_training_sources', array(
			'google_search_central' => array(
				'name' => 'Google Search Central Blog',
				'feed' => 'https://feeds.feedburner.com/blogspot/amDG',
			),
			'the_keyword'           => array(
				'name' => 'The Keyword (Google)',
				'feed' => 'https://blog.google/rss/',
			),
			'ahrefs'                => array(
				'name' => 'Ahrefs Blog',
				'feed' => 'https://ahrefs.com/blog/feed/',
			),
			'search_engine_land'    => array(
				'name' => 'Search Engine Land',
				'feed' => 'https://searchengineland.com/feed',
			),
			'search_engine_journal' => array(
				'name' => 'Search Engine Journal',
				'feed' => 'https://www.searchenginejournal.com/feed/',
			),
		) );
	}

	public static function enabled(): bool {
		return false !== Snap_Settings::instance()->get( 'ai.self_training', true );
	}

	public function __construct() {
		add_action( 'init', array( $this, 'maybe_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'refresh' ) );
	}

	public function maybe_schedule(): void {
		if ( ! self::enabled() ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			return;
		}
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', self::CRON_HOOK );
		}
	}

	// ── Layer 1: baked-in expert playbook ─────────────────────────────────────

	/**
	 * Condensed SEO / AEO / GEO expert system. Injected into every
	 * training-enabled prompt ahead of the user's own knowledge base.
	 */
	public static function playbook(): string {
		return <<<'TXT'
You are pre-trained on modern search optimization (SEO + AEO + GEO). Apply these rules to everything you write.

GEO — get cited by AI engines (per the Princeton/Georgia Tech/Allen Institute GEO study):
- Statistics & data addition (+40% AI visibility): include hard numbers, percentages, and data points where the source content supports them.
- Inline citation style (+35%): attribute claims to their source explicitly in the text when sources exist in the content.
- Expert quotes (+30%): keep and surface named, attributed quotes that exist in the content.
- Answer-first structure: a direct answer under 60 words in the first 2-3 sentences below a heading. AI retrieval pulls from the top of the chunk.
- Entity clarity: keep subject-verb-object tight; name the brand/product explicitly next to the core keyword instead of pronouns; LLMs map co-occurrence in vector space.
- Multi-modal hints: tables, bulleted summaries, and descriptive alt text raise AI overview citation rates.
- Never fabricate statistics, sources, quotes, reviews, or credentials. Only use what the content or knowledge base provides.

SEO TITLES — pick the best-fitting proven pattern for the content (60 chars max, keyword near the start, natural, no clickbait):
1. Brackets dynamic: "[Keyword]: The Ultimate [Year] Guide [Free Template]"
2. Quantified value: "How to [Action] ([X]% [Result])" — only with real numbers.
3. Direct challenge: "Stop [Common Mistake]: [N] Fixes for [Outcome]"
4. Definitive entity: "What is [Topic]? [Context for Audience]"
5. Double hook: "[Benefit]: [Keyword Phrase]"
6. Curated list stack: "[Odd Number] [Proven Tactics] to [Outcome]"
7. Comparative versus: "[A] vs [B]: Which Is Better in [Year]?"

META DESCRIPTIONS — 120-156 chars, keyword early, active voice, pick the best-fitting pattern:
1. Question + value: "Looking for [X]? Learn how to [action] with our proven framework."
2. List preview: "Discover the [N] steps to [outcome]. Inside: [a], [b], and [c]."
3. Authority & proof: "Built by [expert role], this blueprint fixes [problem] and boosts [metric]." — only with real proof.
4. Problem-agitate-solve: "Struggling with [frustration]? Here is the exact [keyword] workflow you need."
5. "What is" snippet: "What is [concept]? [Concept] is [definition]. Read the expert guide."
6. Feature-benefit action: "Master [keyword]. Use [feature] to [benefit 1] and [benefit 2]."
7. Urgency/timeline: "Don't fall behind the [year] updates. Audit your [system] today."

SCHEMA (JSON-LD) — pick the right node and connect entities:
- Organization/WebSite at site level with sameAs social profiles. Person/ProfilePage for authors (E-E-A-T) with sameAs to LinkedIn etc.
- Article/TechArticle with datePublished, dateModified, publisher. FAQPage for Q&A blocks. HowTo for step processes with steps/tools. Product with real price/currency/availability/reviews only. LocalBusiness with NAP, geo, hours.
- Only state facts present in the content or knowledge base.

AEO: question-phrased headings, one-paragraph un-padded answers, FAQ blocks mapped to FAQPage schema.
SEO base: E-E-A-T, long-tail over head terms, information gain over me-too phrasing, inverted pyramid (conclusion first), clean readable prose.

Hard rules: never keyword-stuff; never sacrifice readability; match the site's tone and facts from the site knowledge base when present, and never contradict it.
TXT;
	}

	/** Playbook wrapped as a system-prompt block. */
	public static function playbook_block(): string {
		if ( ! self::enabled() ) {
			return '';
		}
		return "\n\nSEO/AEO/GEO EXPERT PLAYBOOK (built-in training — always follow):\n" . self::playbook();
	}

	// ── Layer 2: weekly digest from official sources ──────────────────────────

	/**
	 * Fetch the latest items from every source and store one digest doc
	 * in the AI knowledge base (replaces the previous digest).
	 *
	 * @return array{ok:bool, items:int, sources:int, message:string}
	 */
	public static function refresh(): array {
		if ( ! self::enabled() ) {
			return array( 'ok' => false, 'items' => 0, 'sources' => 0, 'message' => __( 'Self-training is disabled.', 'snaplevel' ) );
		}

		include_once ABSPATH . WPINC . '/feed.php';

		$sections = array();
		$items    = 0;
		$hit      = 0;

		foreach ( self::sources() as $source ) {
			$feed = fetch_feed( $source['feed'] );
			if ( is_wp_error( $feed ) ) {
				continue;
			}
			$hit++;
			$lines = array();
			foreach ( $feed->get_items( 0, 5 ) as $item ) {
				$title = wp_strip_all_tags( (string) $item->get_title() );
				$date  = (string) $item->get_date( 'Y-m-d' );
				$desc  = wp_strip_all_tags( (string) $item->get_description() );
				if ( function_exists( 'mb_substr' ) ) {
					$desc = mb_substr( $desc, 0, 350 );
				} else {
					$desc = substr( $desc, 0, 350 );
				}
				$lines[] = '- [' . $date . '] ' . $title . ' — ' . trim( $desc );
				$items++;
			}
			if ( ! empty( $lines ) ) {
				$sections[] = '## ' . $source['name'] . "\n" . implode( "\n", $lines );
			}
		}

		if ( empty( $sections ) ) {
			return array( 'ok' => false, 'items' => 0, 'sources' => 0, 'message' => __( 'No sources could be reached. Try again later.', 'snaplevel' ) );
		}

		$content = "Latest search-industry updates (auto-fetched " . current_time( 'Y-m-d H:i' ) . "). Use this to keep recommendations aligned with current Google guidance:\n\n"
			. implode( "\n\n", $sections );

		// Replace the previous digest document.
		$doc_id = (int) get_option( self::DOC_OPTION, 0 );
		$saved  = Snap_AI_Training::save(
			$doc_id,
			__( 'Auto · SEO News Digest (self-training)', 'snaplevel' ),
			$content,
			7 // user knowledge (priority 5) always wins the injection budget.
		);

		if ( is_wp_error( $saved ) ) {
			// Knowledge base may be full — drop the old digest and retry once.
			if ( $doc_id > 0 ) {
				Snap_AI_Training::delete( $doc_id );
				delete_option( self::DOC_OPTION );
			}
			$saved = Snap_AI_Training::save( 0, __( 'Auto · SEO News Digest (self-training)', 'snaplevel' ), $content, 7 );
			if ( is_wp_error( $saved ) ) {
				return array( 'ok' => false, 'items' => 0, 'sources' => $hit, 'message' => $saved->get_error_message() );
			}
		}

		update_option( self::DOC_OPTION, (int) $saved['id'] );
		update_option( 'snap_self_training_last_run', current_time( 'mysql' ) );

		return array(
			'ok'      => true,
			'items'   => $items,
			'sources' => $hit,
			'message' => sprintf(
				/* translators: 1: item count, 2: source count */
				__( 'Pulled %1$d updates from %2$d sources into the AI knowledge base.', 'snaplevel' ),
				$items,
				$hit
			),
		);
	}
}
