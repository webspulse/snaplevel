<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI_Prompts — every prompt template in one place, filterable.
 *
 * A task definition is:
 *   'system'     => string system prompt
 *   'user'       => callable( array $context ): string|array  (string or content blocks)
 *   'schema'     => array JSON Schema for the structured output
 *   'tier'       => 'fast' | 'smart'  (maps to ai.model_fast / ai.model_smart)
 *   'max_tokens' => int
 *   'training'   => bool — inject the site knowledge base into the system prompt
 */
final class Snap_AI_Prompts {

	/**
	 * @return array|WP_Error Task definition.
	 */
	public static function get_task( string $task ) {
		$tasks = self::tasks();
		if ( ! isset( $tasks[ $task ] ) ) {
			return new WP_Error( 'snap_unknown_task', sprintf( 'Unknown AI task: %s', $task ) );
		}
		/**
		 * Filter a single task definition (system prompt, schema, tier).
		 *
		 * @param array  $definition
		 * @param string $task
		 */
		return apply_filters( 'snaplevel_ai_task', $tasks[ $task ], $task );
	}

	public static function task_exists( string $task ): bool {
		return array_key_exists( $task, self::tasks() );
	}

	private static function tasks(): array {
		$site_name = get_bloginfo( 'name' );

		$tasks = array(

			'seo_title' => array(
				'tier'       => 'fast',
				'max_tokens' => 512,
				'training'   => true,
				'system'     => 'You are an expert SEO copywriter. You write search-optimized page titles that are accurate to the content, compelling to click, and never clickbait. Hard rules: each title must be 60 characters or fewer, must read naturally, and must include the focus keyword near the start when one is given.',
				'user'       => static function ( array $ctx ) use ( $site_name ): string {
					$kw = ! empty( $ctx['focus_keyword'] ) ? "Focus keyword: {$ctx['focus_keyword']}\n" : '';
					return "Write 3 SEO title options for this content.\n"
						. "Site name: {$site_name}\n"
						. $kw
						. 'Current title: ' . ( $ctx['post_title'] ?? '' ) . "\n\n"
						. "Content:\n" . self::trim_content( $ctx['content'] ?? '' );
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'options' => array(
							'type'     => 'array',
							'minItems' => 3,
							'maxItems' => 3,
							'items'    => array( 'type' => 'string', 'maxLength' => 70 ),
						),
					),
					'required'   => array( 'options' ),
				),
			),

			'meta_description' => array(
				'tier'       => 'fast',
				'max_tokens' => 512,
				'training'   => true,
				'system'     => 'You are an expert SEO copywriter. You write meta descriptions that summarize the page accurately and entice the right searcher to click. Hard rules: each description must be between 120 and 156 characters, active voice, no quotes, includes the focus keyword once when given.',
				'user'       => static function ( array $ctx ): string {
					$kw = ! empty( $ctx['focus_keyword'] ) ? "Focus keyword: {$ctx['focus_keyword']}\n" : '';
					return "Write 3 meta description options for this content.\n"
						. $kw
						. 'Title: ' . ( $ctx['post_title'] ?? '' ) . "\n\n"
						. "Content:\n" . self::trim_content( $ctx['content'] ?? '' );
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'options' => array(
							'type'     => 'array',
							'minItems' => 3,
							'maxItems' => 3,
							'items'    => array( 'type' => 'string', 'maxLength' => 170 ),
						),
					),
					'required'   => array( 'options' ),
				),
			),

			'focus_keywords' => array(
				'tier'       => 'fast',
				'max_tokens' => 768,
				'training'   => true,
				'system'     => 'You are an SEO strategist. Suggest focus keywords a page could realistically rank for, based only on its actual content. Prefer specific long-tail phrases over broad head terms.',
				'user'       => static function ( array $ctx ): string {
					return "Suggest 5 focus keywords for this content. For each, state the search intent (informational, commercial, transactional, navigational).\n\n"
						. 'Title: ' . ( $ctx['post_title'] ?? '' ) . "\n\n"
						. "Content:\n" . self::trim_content( $ctx['content'] ?? '' );
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'keywords' => array(
							'type'     => 'array',
							'minItems' => 5,
							'maxItems' => 5,
							'items'    => array(
								'type'       => 'object',
								'properties' => array(
									'keyword' => array( 'type' => 'string' ),
									'intent'  => array( 'type' => 'string', 'enum' => array( 'informational', 'commercial', 'transactional', 'navigational' ) ),
									'reason'  => array( 'type' => 'string' ),
								),
								'required'   => array( 'keyword', 'intent' ),
							),
						),
					),
					'required'   => array( 'keywords' ),
				),
			),

			'alt_text' => array(
				'tier'       => 'fast',
				'max_tokens' => 512,
				'training'   => false,
				'system'     => 'You write image metadata for accessibility and SEO. Alt text describes what is actually in the image, concisely, without starting with "image of". Never invent details you cannot see.',
				'user'       => static function ( array $ctx ): array {
					$keyword_note = ! empty( $ctx['keywords'] )
						? ' Where naturally relevant, incorporate these keywords: ' . $ctx['keywords'] . '.'
						: '';
					$blocks   = array();
					$blocks[] = array(
						'type' => 'text',
						'text' => 'Analyze this image and produce: alt (max 125 chars), title (max 60 chars), caption (max 200 chars), description (max 250 chars).' . $keyword_note,
					);
					if ( ! empty( $ctx['image_url'] ) ) {
						$blocks[] = array(
							'type'   => 'image',
							'source' => array( 'type' => 'url', 'url' => (string) $ctx['image_url'] ),
						);
					}
					return $blocks;
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'alt'         => array( 'type' => 'string', 'maxLength' => 140 ),
						'title'       => array( 'type' => 'string', 'maxLength' => 70 ),
						'caption'     => array( 'type' => 'string', 'maxLength' => 220 ),
						'description' => array( 'type' => 'string', 'maxLength' => 280 ),
					),
					'required'   => array( 'alt', 'title', 'caption', 'description' ),
				),
			),

			'schema' => array(
				'tier'       => 'smart',
				'max_tokens' => 2048,
				'training'   => true,
				'system'     => 'You are a structured data expert. You read a page and produce valid schema.org JSON-LD. You always detect the most appropriate type (Article, BlogPosting, Product, FAQPage, HowTo, Recipe, Event, LocalBusiness, Service, WebPage). Only state facts present in the content or knowledge base — never invent prices, ratings, dates, or addresses. Output must be a single JSON-LD object with @context and @type.',
				'user'       => static function ( array $ctx ): string {
					return "Detect the right schema.org type and generate complete JSON-LD for this page.\n"
						. 'Post type: ' . ( $ctx['post_type'] ?? 'post' ) . "\n"
						. 'URL: ' . ( $ctx['permalink'] ?? '' ) . "\n"
						. 'Title: ' . ( $ctx['post_title'] ?? '' ) . "\n\n"
						. "Content:\n" . self::trim_content( $ctx['content'] ?? '', 10000 );
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'schema_type' => array( 'type' => 'string' ),
						'jsonld'      => array( 'type' => 'object' ),
						'note'        => array( 'type' => 'string' ),
					),
					'required'   => array( 'schema_type', 'jsonld' ),
				),
			),

			'llms_txt' => array(
				'tier'       => 'smart',
				'max_tokens' => 3000,
				'training'   => true,
				'system'     => 'You write llms.txt files — the Markdown standard at a site root that guides AI crawlers (ChatGPT, Claude, Perplexity, Gemini). Rules: start with "# Site Name" H1, then a single "> blockquote" with a dense, objective, entity-rich description (no marketing hyperbole). Then "## " sections grouping the site\'s key pages as Markdown lists: "* [Title](URL): one specific sentence describing exactly what user intent that page answers." End with a "## Sitemap" section linking the XML sitemap. No promotional clutter, no countdown/discount copy, plain technical objective facts only. Output ONLY the raw Markdown content of the file.',
				'user'       => static function ( array $ctx ): string {
					$pages = '';
					foreach ( (array) ( $ctx['pages'] ?? array() ) as $p ) {
						$pages .= '- [' . ( $p['type'] ?? 'page' ) . '] ' . ( $p['title'] ?? '' ) . ' | ' . ( $p['url'] ?? '' ) . ' | ' . ( $p['summary'] ?? '' ) . "\n";
					}
					return "Write the llms.txt for this website.\n"
						. 'Site name: ' . ( $ctx['site_name'] ?? '' ) . "\n"
						. 'Tagline: ' . ( $ctx['site_tagline'] ?? '' ) . "\n"
						. 'Home: ' . ( $ctx['home_url'] ?? '' ) . "\n"
						. 'Sitemap: ' . ( $ctx['sitemap_url'] ?? '' ) . "\n\n"
						. "Published pages (type | title | url | summary):\n" . $pages;
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'content' => array( 'type' => 'string' ),
					),
					'required'   => array( 'content' ),
				),
			),

			'copilot_analyze' => array(
				'tier'       => 'fast',
				'max_tokens' => 1500,
				'training'   => true,
				'system'     => "You are Snaplevel Copilot, an SEO assistant for WordPress content creators.\n\nYour job: find actionable SEO opportunities in the user's content. Only flag things that genuinely matter and that can be improved. Never invent problems.\n\nRules:\n- Maximum 7 opportunities, minimum 0.\n- Each opportunity must be specific to THIS content (never generic advice).\n- Each opportunity must include a clear one-sentence reason that a non-SEO person would understand.\n- If the content is well-optimized, return zero opportunities. Say so honestly.\n- Focus on: missing or weak meta description, missing or weak SEO title, no internal links to other posts, schema opportunities (FAQ or HowTo detected in content), structural issues (very long paragraphs over 150 words, no subheadings for posts over 300 words), focus keyword not in the title or first paragraph.\n- Do NOT suggest things the user cannot control (backlinks, domain authority, page speed).\n- Do NOT mention scores, percentages, or density numbers.\n- Be honest. A short post does not need internal links. A well-written post with good meta needs zero changes.",
				'user'       => static function ( array $ctx ): string {
					$kw        = ! empty( $ctx['focus_keyword'] ) ? "Focus keyword: {$ctx['focus_keyword']}\n" : "Focus keyword: (none set)\n";
					$meta_note = ! empty( $ctx['has_meta_desc'] ) ? "Has meta description: yes\n" : "Has meta description: no\n";
					$title_note = ! empty( $ctx['has_seo_title'] ) ? "Has custom SEO title: yes\n" : "Has custom SEO title: no\n";
					$links_note = 'Internal links in content: ' . ( (int) ( $ctx['internal_links'] ?? 0 ) ) . "\n";
					$words_note = 'Word count: ' . ( (int) ( $ctx['word_count'] ?? 0 ) ) . "\n";
					return "Analyze this post and return actionable SEO opportunities.\n\n"
						. $kw . $meta_note . $title_note . $links_note . $words_note
						. "\nTitle: " . ( $ctx['post_title'] ?? '' ) . "\n\n"
						. "Content:\n" . self::trim_content( $ctx['content'] ?? '', 6000 );
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'opportunities' => array(
							'type'     => 'array',
							'maxItems' => 7,
							'items'    => array(
								'type'       => 'object',
								'properties' => array(
									'id'       => array( 'type' => 'string' ),
									'category' => array( 'type' => 'string', 'enum' => array( 'meta', 'title', 'links', 'schema', 'structure', 'keyword' ) ),
									'title'    => array( 'type' => 'string', 'maxLength' => 60 ),
									'reason'   => array( 'type' => 'string', 'maxLength' => 120 ),
									'fixable'  => array( 'type' => 'boolean' ),
									'fix_task' => array( 'type' => 'string', 'enum' => array( 'meta_description', 'seo_title', 'focus_keywords', 'none' ) ),
								),
								'required'   => array( 'id', 'category', 'title', 'reason', 'fixable' ),
							),
						),
						'readiness' => array( 'type' => 'string', 'enum' => array( 'good', 'needs_work', 'not_started' ) ),
					),
					'required'   => array( 'opportunities', 'readiness' ),
				),
			),

			'content_analysis' => array(
				'tier'       => 'smart',
				'max_tokens' => 2048,
				'training'   => true,
				'system'     => 'You are a senior SEO content editor. You analyze a post against its focus keyword and return specific, actionable issues. Every issue must include a concrete suggested fix the author can apply directly — not generic advice. Quote the exact text you are referring to where possible.',
				'user'       => static function ( array $ctx ): string {
					$kw = ! empty( $ctx['focus_keyword'] ) ? $ctx['focus_keyword'] : '(none set)';
					return "Analyze this post for SEO and readability. Focus keyword: {$kw}\n\n"
						. 'Title: ' . ( $ctx['post_title'] ?? '' ) . "\n\n"
						. "Content:\n" . self::trim_content( $ctx['content'] ?? '', 12000 );
				},
				'schema'     => array(
					'type'       => 'object',
					'properties' => array(
						'score'  => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 100 ),
						'issues' => array(
							'type'  => 'array',
							'items' => array(
								'type'       => 'object',
								'properties' => array(
									'severity'   => array( 'type' => 'string', 'enum' => array( 'critical', 'warning', 'suggestion' ) ),
									'category'   => array( 'type' => 'string' ),
									'issue'      => array( 'type' => 'string' ),
									'fix'        => array( 'type' => 'string' ),
								),
								'required'   => array( 'severity', 'issue', 'fix' ),
							),
						),
					),
					'required'   => array( 'score', 'issues' ),
				),
			),
		);

		/**
		 * Register or override AI task definitions.
		 *
		 * @param array $tasks
		 */
		return apply_filters( 'snaplevel_ai_tasks', $tasks );
	}

	/** Cap content length so prompts stay cheap. */
	public static function trim_content( string $content, int $max_chars = 8000 ): string {
		$content = trim( $content );
		if ( strlen( $content ) <= $max_chars ) {
			return $content;
		}
		return substr( $content, 0, $max_chars ) . "\n[…content truncated…]";
	}
}
