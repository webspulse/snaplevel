<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Provider_Snaplevel — Snaplevel proxy server (Phase 4).
 *
 * Stub. The provider interface is in place so the proxy becomes a
 * drop-in: implement complete()/test() against the proxy endpoint and
 * flip `ai.provider` to 'snaplevel' in settings.
 */
class Snap_Provider_Snaplevel extends Snap_AI_Provider {

	public function id(): string {
		return 'snaplevel';
	}

	public function complete( array $args ) {
		unset( $args );
		return new WP_Error(
			'snap_provider_unavailable',
			__( 'Snaplevel managed AI is not available yet. Use your own Anthropic API key in Settings → AI.', 'snaplevel' )
		);
	}

	public function test() {
		return new WP_Error(
			'snap_provider_unavailable',
			__( 'Snaplevel managed AI is not available yet.', 'snaplevel' )
		);
	}
}
