<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Provider_OpenAI — ChatGPT API with the user's own key.
 *
 * Uses forced function-calling so every response is machine-readable JSON
 * matching the task schema. Supports vision (image_url) for alt text.
 */
class Snap_Provider_OpenAI extends Snap_AI_Provider {

	const API_URL = 'https://api.openai.com/v1/chat/completions';

	/** @var string */
	private $api_key;

	public function __construct( string $api_key = '' ) {
		$this->api_key = '' !== $api_key ? $api_key : Snap_Settings::instance()->get_api_key( $this->id() );
	}

	public function id(): string {
		return 'openai';
	}

	/** Human label used in error messages. */
	public function label(): string {
		return 'OpenAI';
	}

	/** Chat-completions endpoint — overridable by OpenAI-compatible providers. */
	protected function api_url(): string {
		return static::API_URL;
	}

	public function complete( array $args ) {
		if ( '' === $this->api_key ) {
			/* translators: %s: provider name */
			return new WP_Error( 'snap_no_key', sprintf( __( 'No %s API key configured. Add one in Snaplevel → Settings → AI.', 'snaplevel' ), $this->label() ) );
		}

		$schema = isset( $args['schema'] ) && is_array( $args['schema'] ) ? $args['schema'] : array( 'type' => 'object' );

		$messages = array();
		if ( ! empty( $args['system'] ) ) {
			$messages[] = array( 'role' => 'system', 'content' => (string) $args['system'] );
		}
		foreach ( (array) ( $args['messages'] ?? array() ) as $message ) {
			$messages[] = array(
				'role'    => (string) ( $message['role'] ?? 'user' ),
				'content' => self::convert_content( $message['content'] ?? '' ),
			);
		}

		$payload = array(
			'model'       => (string) ( $args['model'] ?? 'gpt-4o-mini' ),
			'max_tokens'  => (int) ( $args['max_tokens'] ?? 1024 ),
			'messages'    => $messages,
			'tools'       => array(
				array(
					'type'     => 'function',
					'function' => array(
						'name'        => 'emit_result',
						'description' => 'Emit the structured result for this task.',
						'parameters'  => $schema,
					),
				),
			),
			'tool_choice' => array( 'type' => 'function', 'function' => array( 'name' => 'emit_result' ) ),
		);

		$response = wp_remote_post( $this->api_url(), array(
			'timeout' => 60,
			'headers' => array(
				'Authorization' => 'Bearer ' . $this->api_key,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode( $payload ),
		) );

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'snap_ai_connection', sprintf(
				/* translators: 1: provider name, 2: error message */
				__( 'Could not reach the %1$s API: %2$s', 'snaplevel' ),
				$this->label(),
				$response->get_error_message()
			) );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg      = isset( $body['error']['message'] ) ? (string) $body['error']['message'] : 'HTTP ' . $code;
			$err_code = 401 === $code ? 'snap_ai_auth' : ( 429 === $code ? 'snap_ai_rate_limit' : 'snap_ai_api' );
			return new WP_Error( $err_code, sprintf(
				/* translators: 1: provider name, 2: API error message */
				__( '%1$s API error: %2$s', 'snaplevel' ),
				$this->label(),
				$msg
			) );
		}

		$data = null;
		if ( isset( $body['choices'][0]['message']['tool_calls'][0]['function']['arguments'] ) ) {
			$data = json_decode( (string) $body['choices'][0]['message']['tool_calls'][0]['function']['arguments'], true );
		}

		if ( ! is_array( $data ) ) {
			return new WP_Error( 'snap_ai_bad_response', __( 'The AI response was not structured data. Please try again.', 'snaplevel' ) );
		}

		return array(
			'data'       => $data,
			'tokens_in'  => (int) ( $body['usage']['prompt_tokens'] ?? 0 ),
			'tokens_out' => (int) ( $body['usage']['completion_tokens'] ?? 0 ),
			'model'      => (string) ( $body['model'] ?? $payload['model'] ),
		);
	}

	/**
	 * Convert provider-neutral (Anthropic-style) content blocks to the
	 * OpenAI chat format. Strings pass through unchanged.
	 *
	 * @param string|array $content
	 * @return string|array
	 */
	public static function convert_content( $content ) {
		if ( ! is_array( $content ) ) {
			return (string) $content;
		}

		$parts = array();
		foreach ( $content as $block ) {
			$type = $block['type'] ?? '';
			if ( 'text' === $type ) {
				$parts[] = array( 'type' => 'text', 'text' => (string) ( $block['text'] ?? '' ) );
			} elseif ( 'image' === $type && ! empty( $block['source']['url'] ) ) {
				$parts[] = array(
					'type'      => 'image_url',
					'image_url' => array( 'url' => (string) $block['source']['url'], 'detail' => 'low' ),
				);
			}
		}
		return $parts;
	}

	public function test() {
		$result = $this->complete( array(
			'model'      => Snap_AI::default_model( $this->id(), 'fast' ),
			'max_tokens' => 64,
			'system'     => 'You confirm connectivity.',
			'messages'   => array(
				array( 'role' => 'user', 'content' => 'Reply with ok = true.' ),
			),
			'schema'     => array(
				'type'       => 'object',
				'properties' => array( 'ok' => array( 'type' => 'boolean' ) ),
				'required'   => array( 'ok' ),
			),
		) );

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return true;
	}
}
