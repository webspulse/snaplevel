<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OpenAI-compatible providers — Gemini, DeepSeek, Mistral.
 *
 * All three expose an OpenAI-style /chat/completions endpoint with
 * function calling, so they reuse Snap_Provider_OpenAI's request and
 * response handling and only swap the endpoint, id, and label.
 */

class Snap_Provider_Gemini extends Snap_Provider_OpenAI {

	const API_URL = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions';

	public function id(): string {
		return 'gemini';
	}

	public function label(): string {
		return 'Google Gemini';
	}
}

class Snap_Provider_DeepSeek extends Snap_Provider_OpenAI {

	const API_URL = 'https://api.deepseek.com/chat/completions';

	public function id(): string {
		return 'deepseek';
	}

	public function label(): string {
		return 'DeepSeek';
	}
}

class Snap_Provider_Mistral extends Snap_Provider_OpenAI {

	const API_URL = 'https://api.mistral.ai/v1/chat/completions';

	public function id(): string {
		return 'mistral';
	}

	public function label(): string {
		return 'Mistral AI';
	}
}
