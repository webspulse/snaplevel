<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Provider_Anthropic — direct Anthropic API with the user's own key.
 *
 * Uses forced tool-use so every response is machine-readable JSON that
 * matches the task schema. Never scrapes JSON out of prose.
 */
class Snap_Provider_Anthropic extends Snap_AI_Provider {

	const API_URL     = 'https://api.anthropic.com/v1/messages';
	const API_VERSION = '2023-06-01';

	/** @var string */
	private $api_key;

	public function __construct( string $api_key = '' ) {
		$this->api_key = '' !== $api_key ? $api_key : Snap_Settings::instance()->get_api_key( 'anthropic' );
	}

	public function id(): string {
		return 'anthropic';
	}

	public function complete( array $args ) {
		if ( '' === $this->api_key ) {
			return new WP_Error( 'snap_no_key', __( 'No Anthropic API key configured. Add one in Snaplevel → Settings → AI.', 'snaplevel' ) );
		}

		$schema = isset( $args['schema'] ) && is_array( $args['schema'] ) ? $args['schema'] : array( 'type' => 'object' );

		$payload = array(
			'model'      => (string) ( $args['model'] ?? 'claude-haiku-4-5-20251001' ),
			'max_tokens' => (int) ( $args['max_tokens'] ?? 1024 ),
			'system'     => (string) ( $args['system'] ?? '' ),
			'messages'   => $args['messages'] ?? array(),
			'tools'      => array(
				array(
					'name'         => 'emit_result',
					'description'  => 'Emit the structured result for this task.',
					'input_schema' => $schema,
				),
			),
			'tool_choice' => array( 'type' => 'tool', 'name' => 'emit_result' ),
		);

		$response = wp_remote_post( self::API_URL, array(
			'timeout' => 60,
			'headers' => array(
				'x-api-key'         => $this->api_key,
				'anthropic-version' => self::API_VERSION,
				'content-type'      => 'application/json',
			),
			'body'    => wp_json_encode( $payload ),
		) );

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'snap_ai_connection', sprintf(
				/* translators: %s: error message */
				__( 'Could not reach the Anthropic API: %s', 'snaplevel' ),
				$response->get_error_message()
			) );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg      = isset( $body['error']['message'] ) ? (string) $body['error']['message'] : 'HTTP ' . $code;
			$err_code = 401 === $code ? 'snap_ai_auth' : ( 429 === $code ? 'snap_ai_rate_limit' : 'snap_ai_api' );
			return new WP_Error( $err_code, sprintf(
				/* translators: %s: API error message */
				__( 'Anthropic API error: %s', 'snaplevel' ),
				$msg
			) );
		}

		$data = null;
		if ( isset( $body['content'] ) && is_array( $body['content'] ) ) {
			foreach ( $body['content'] as $block ) {
				if ( isset( $block['type'] ) && 'tool_use' === $block['type'] && isset( $block['input'] ) ) {
					$data = $block['input'];
					break;
				}
			}
		}

		if ( ! is_array( $data ) ) {
			return new WP_Error( 'snap_ai_bad_response', __( 'The AI response was not structured data. Please try again.', 'snaplevel' ) );
		}

		return array(
			'data'       => $data,
			'tokens_in'  => (int) ( $body['usage']['input_tokens'] ?? 0 ),
			'tokens_out' => (int) ( $body['usage']['output_tokens'] ?? 0 ),
			'model'      => (string) ( $body['model'] ?? $payload['model'] ),
		);
	}

	public function test() {
		$result = $this->complete( array(
			'model'      => Snap_AI::default_model( 'anthropic', 'fast' ),
			'max_tokens' => 64,
			'system'     => 'You confirm connectivity.',
			'messages'   => array(
				array( 'role' => 'user', 'content' => 'Reply with ok = true.' ),
			),
			'schema'     => array(
				'type'       => 'object',
				'properties' => array( 'ok' => array( 'type' => 'boolean' ) ),
				'required'   => array( 'ok' ),
			),
		) );

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return true;
	}
}
