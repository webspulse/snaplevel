<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI_Cache — cache AI responses by content hash.
 * If the input did not change, do not pay for tokens twice.
 */
final class Snap_AI_Cache {

	const TTL = 30 * DAY_IN_SECONDS;

	public static function key( string $task, array $context ): string {
		// Drop volatile keys that don't affect output.
		unset( $context['post_id'] );
		ksort( $context );
		return 'snap_ai_' . md5( $task . '|' . wp_json_encode( $context ) );
	}

	/** @return array|null */
	public static function get( string $task, array $context ): ?array {
		$hit = get_transient( self::key( $task, $context ) );
		return is_array( $hit ) ? $hit : null;
	}

	public static function set( string $task, array $context, array $result ): void {
		set_transient( self::key( $task, $context ), $result, self::TTL );
	}
}
