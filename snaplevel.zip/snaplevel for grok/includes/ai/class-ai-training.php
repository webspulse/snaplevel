<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI_Training — the AI knowledge base for this site.
 *
 * The user pastes business knowledge (brand voice, products, audience,
 * services, FAQs) as named documents. A capped slice of it is injected
 * into every AI prompt so output sounds like the site, not generic AI.
 *
 * Limits: 600,000 characters total (~100,000 words). Per-call injection
 * budget defaults to 8,000 chars (~2,000 tokens) and is configurable.
 */
final class Snap_AI_Training {

	const TOTAL_LIMIT = 600000; // characters across all documents.

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'snap_ai_training';
	}

	public static function create_table(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = self::table();

		dbDelta( "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			title VARCHAR(190) NOT NULL DEFAULT '',
			content LONGTEXT NOT NULL,
			chars INT UNSIGNED NOT NULL DEFAULT 0,
			priority TINYINT UNSIGNED NOT NULL DEFAULT 5,
			updated DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY priority (priority)
		) {$charset};" );
	}

	private static function ensure_table(): void {
		global $wpdb;
		$table = self::table();
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			self::create_table();
		}
	}

	// ── CRUD ──────────────────────────────────────────────────────────────────

	/** @return array[] */
	public static function all(): array {
		global $wpdb;
		self::ensure_table();
		$rows = $wpdb->get_results(
			'SELECT id, title, content, chars, priority, updated FROM ' . self::table() . ' ORDER BY priority ASC, id ASC',
			ARRAY_A
		);
		return is_array( $rows ) ? $rows : array();
	}

	public static function total_chars(): int {
		global $wpdb;
		self::ensure_table();
		return (int) $wpdb->get_var( 'SELECT COALESCE(SUM(chars),0) FROM ' . self::table() );
	}

	/**
	 * Create or update a document.
	 *
	 * @return array|WP_Error Saved row.
	 */
	public static function save( int $id, string $title, string $content, int $priority = 5 ) {
		global $wpdb;
		self::ensure_table();

		$title    = sanitize_text_field( $title );
		$content  = sanitize_textarea_field( $content );
		$priority = max( 1, min( 9, $priority ) );
		$chars    = function_exists( 'mb_strlen' ) ? mb_strlen( $content ) : strlen( $content );

		if ( '' === trim( $content ) ) {
			return new WP_Error( 'snap_training_empty', __( 'Document content is empty.', 'snaplevel' ) );
		}

		$other = self::total_chars();
		if ( $id > 0 ) {
			$current = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT chars FROM ' . self::table() . ' WHERE id = %d', $id ) );
			$other  -= $current;
		}
		if ( $other + $chars > self::TOTAL_LIMIT ) {
			return new WP_Error( 'snap_training_limit', sprintf(
				/* translators: 1: limit, 2: remaining */
				__( 'Knowledge base limit reached (%1$s characters total). You have %2$s characters left.', 'snaplevel' ),
				number_format_i18n( self::TOTAL_LIMIT ),
				number_format_i18n( max( 0, self::TOTAL_LIMIT - $other ) )
			) );
		}

		$data = array(
			'title'    => '' !== $title ? $title : __( 'Untitled document', 'snaplevel' ),
			'content'  => $content,
			'chars'    => $chars,
			'priority' => $priority,
			'updated'  => current_time( 'mysql' ),
		);

		if ( $id > 0 ) {
			$wpdb->update( self::table(), $data, array( 'id' => $id ) );
		} else {
			$wpdb->insert( self::table(), $data );
			$id = (int) $wpdb->insert_id;
		}

		$data['id'] = $id;
		return $data;
	}

	public static function delete( int $id ): bool {
		global $wpdb;
		self::ensure_table();
		return false !== $wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );
	}

	// ── Prompt injection ──────────────────────────────────────────────────────

	/**
	 * Build the system-prompt context block, capped at the configured budget.
	 * Documents are included in priority order until the budget is spent.
	 */
	public static function context_block(): string {
		$budget = (int) Snap_Settings::instance()->get( 'ai.training_budget', 8000 );
		if ( $budget <= 0 ) {
			return '';
		}

		$docs = self::all();
		if ( empty( $docs ) ) {
			return '';
		}

		$parts = array();
		$used  = 0;

		foreach ( $docs as $doc ) {
			if ( $used >= $budget ) {
				break;
			}
			$slice = (string) $doc['content'];
			$room  = $budget - $used;
			if ( ( function_exists( 'mb_strlen' ) ? mb_strlen( $slice ) : strlen( $slice ) ) > $room ) {
				$slice = ( function_exists( 'mb_substr' ) ? mb_substr( $slice, 0, $room ) : substr( $slice, 0, $room ) ) . ' […]';
			}
			$parts[] = '### ' . $doc['title'] . "\n" . $slice;
			$used   += function_exists( 'mb_strlen' ) ? mb_strlen( $slice ) : strlen( $slice );
		}

		if ( empty( $parts ) ) {
			return '';
		}

		return "\n\nSITE KNOWLEDGE BASE (provided by the site owner — use it to make output accurate and on-brand, never contradict it):\n"
			. implode( "\n\n", $parts );
	}
}
