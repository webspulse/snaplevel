<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_AI_Usage — token counting and per-site usage log.
 * Foundation for cost transparency now and proxy billing later.
 */
final class Snap_AI_Usage {

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'snap_ai_log';
	}

	public static function create_table(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = self::table();

		dbDelta( "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			task VARCHAR(64) NOT NULL,
			model VARCHAR(128) NOT NULL DEFAULT '',
			tokens_in INT UNSIGNED NOT NULL DEFAULT 0,
			tokens_out INT UNSIGNED NOT NULL DEFAULT 0,
			cost_estimate DECIMAL(10,6) NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY task (task),
			KEY created (created)
		) {$charset};" );
	}

	/**
	 * USD per million tokens, filterable. Estimates only — real billing
	 * is whatever the provider charges the user's key. Most specific
	 * substring must come first (matching is first-hit).
	 */
	public static function pricing(): array {
		return apply_filters( 'snaplevel_ai_pricing', array(
			// model substring => [ input $/MTok, output $/MTok ]
			'haiku'       => array( 1.0, 5.0 ),
			'sonnet'      => array( 3.0, 15.0 ),
			'opus'        => array( 15.0, 75.0 ),
			'gpt-4o-mini' => array( 0.15, 0.60 ),
			'gpt-4o'      => array( 2.50, 10.0 ),
			'gpt-4.1-mini' => array( 0.40, 1.60 ),
			'gpt-4.1'     => array( 2.00, 8.00 ),
			'gpt'         => array( 2.50, 10.0 ), // fallback for other GPT models
		) );
	}

	public static function log( string $task, string $model, int $tokens_in, int $tokens_out ): void {
		global $wpdb;

		$cost = 0.0;
		foreach ( self::pricing() as $needle => $rates ) {
			if ( false !== stripos( $model, (string) $needle ) ) {
				$cost = ( $tokens_in / 1000000 ) * $rates[0] + ( $tokens_out / 1000000 ) * $rates[1];
				break;
			}
		}

		$wpdb->insert( self::table(), array(
			'task'          => substr( $task, 0, 64 ),
			'model'         => substr( $model, 0, 128 ),
			'tokens_in'     => $tokens_in,
			'tokens_out'    => $tokens_out,
			'cost_estimate' => $cost,
			'user_id'       => get_current_user_id(),
			'created'       => current_time( 'mysql' ),
		), array( '%s', '%s', '%d', '%d', '%f', '%d', '%s' ) );
	}

	/** Usage summary for the dashboard / settings screen. */
	public static function summary(): array {
		global $wpdb;
		$table = self::table();

		// Table may not exist yet on upgraded installs.
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			self::create_table();
		}

		$month_start = gmdate( 'Y-m-01 00:00:00' );

		$month = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) AS calls, COALESCE(SUM(tokens_in),0) AS tokens_in,
				COALESCE(SUM(tokens_out),0) AS tokens_out, COALESCE(SUM(cost_estimate),0) AS cost
			 FROM {$table} WHERE created >= %s",
			$month_start
		), ARRAY_A );

		$by_task = $wpdb->get_results( $wpdb->prepare(
			"SELECT task, COUNT(*) AS calls, COALESCE(SUM(cost_estimate),0) AS cost
			 FROM {$table} WHERE created >= %s GROUP BY task ORDER BY calls DESC",
			$month_start
		), ARRAY_A );

		return array(
			'month'   => array(
				'calls'      => (int) ( $month['calls'] ?? 0 ),
				'tokens_in'  => (int) ( $month['tokens_in'] ?? 0 ),
				'tokens_out' => (int) ( $month['tokens_out'] ?? 0 ),
				'cost'       => round( (float) ( $month['cost'] ?? 0 ), 4 ),
			),
			'by_task' => is_array( $by_task ) ? $by_task : array(),
		);
	}
}
