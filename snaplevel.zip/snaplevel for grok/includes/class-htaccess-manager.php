<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manages Apache .htaccess WebP rewrite rules.
 *
 * When a browser sends "Accept: image/webp" and a sidecar .webp file exists
 * on disk next to the original, Apache serves the .webp transparently —
 * the URL in the browser and the database is entirely unchanged.
 *
 * PHP 7.4 compatible.
 */
class ICW_Htaccess_Manager {

    const MARKER = 'ICW WebP';

    // ── Public API ────────────────────────────────────────────────────────────

    public static function add_webp_rules(): bool {
        if ( ! self::is_apache() ) {
            return false;
        }

        // Ensure WordPress admin helpers are loaded (needed during activation hook)
        self::load_wp_admin_files();

        $htaccess = self::htaccess_path();
        if ( ! $htaccess ) {
            return false;
        }

        if ( self::rules_present( $htaccess ) ) {
            return true; // already inserted — idempotent
        }

        return (bool) insert_with_markers( $htaccess, self::MARKER, self::build_rules() );
    }

    public static function remove_webp_rules(): bool {
        self::load_wp_admin_files();

        $htaccess = self::htaccess_path();
        if ( ! $htaccess || ! file_exists( $htaccess ) ) {
            return false;
        }

        return (bool) insert_with_markers( $htaccess, self::MARKER, array() );
    }

    public static function is_apache(): bool {
        $software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';
        return stripos( $software, 'apache' ) !== false
            || stripos( $software, 'litespeed' ) !== false;
    }

    public static function rules_present( string $htaccess ): bool {
        if ( ! file_exists( $htaccess ) ) {
            return false;
        }
        $content = (string) @file_get_contents( $htaccess );
        // PHP 7.4 compatible — no str_contains
        return strpos( $content, '# BEGIN ' . self::MARKER ) !== false;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Returns the .htaccess path to write rules into.
     * Prefers the WordPress root .htaccess; falls back to uploads .htaccess.
     */
    private static function htaccess_path(): ?string {
        // get_home_path() is in wp-admin/includes/file.php (loaded by load_wp_admin_files)
        $root = function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH;
        $path = $root . '.htaccess';

        if ( file_exists( $path ) && is_writable( $path ) ) {
            return $path;
        }

        // Fallback: uploads directory .htaccess
        $uploads = wp_upload_dir();
        $uploads_htaccess = $uploads['basedir'] . '/.htaccess';

        // Create it if it doesn't exist and the directory is writable
        if ( ! file_exists( $uploads_htaccess ) && is_writable( $uploads['basedir'] ) ) {
            @touch( $uploads_htaccess );
        }

        return is_writable( $uploads_htaccess ) ? $uploads_htaccess : null;
    }

    /**
     * The rewrite rules served via .htaccess.
     *
     * Logic: if the browser accepts WebP AND the request is for a JPEG/PNG/GIF
     * AND a .webp sidecar exists on disk → serve the sidecar with WebP content-type.
     * The URL that the browser and database see is unchanged.
     */
    private static function build_rules(): array {
        return array(
            '<IfModule mod_rewrite.c>',
            '    RewriteEngine On',
            '    RewriteCond %{HTTP_ACCEPT} image/webp',
            '    RewriteCond %{REQUEST_FILENAME} (.*)\.(jpe?g|png|gif)$',
            '    RewriteCond %1\.webp -f',
            '    RewriteRule (.*)\.(jpe?g|png|gif)$ $1.webp [T=image/webp,E=webp:1,L]',
            '</IfModule>',
            '<IfModule mod_headers.c>',
            '    Header append Vary Accept env=webp',
            '</IfModule>',
        );
    }

    /** Load wp-admin helper files needed for get_home_path() and insert_with_markers(). */
    private static function load_wp_admin_files(): void {
        $misc = ABSPATH . 'wp-admin/includes/misc.php';
        $file = ABSPATH . 'wp-admin/includes/file.php';

        if ( file_exists( $misc ) && ! function_exists( 'insert_with_markers' ) ) {
            require_once $misc;
        }
        if ( file_exists( $file ) && ! function_exists( 'get_home_path' ) ) {
            require_once $file;
        }
    }
}
