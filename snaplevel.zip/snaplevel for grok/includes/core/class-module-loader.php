<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Module_Loader — registers and boots modules.
 *
 * Module contract: each module class implements
 *   id(): string, name(): string, boot(): void, activate(): void, deactivate(): void
 * Legacy ICW_* modules are wrapped via a callable bootstrapper instead.
 */
final class Snap_Module_Loader {

	/** @var Snap_Module_Loader|null */
	private static $instance = null;

	/** @var array<string, array{name:string, desc:string, icon:string, boot:callable, always_on:bool}> */
	private $modules = array();

	public static function instance(): Snap_Module_Loader {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_built_in();
		}
		return self::$instance;
	}

	/**
	 * Register a module.
	 *
	 * @param string   $id        Module id, e.g. 'seo_meta'.
	 * @param string   $name      Human name.
	 * @param callable $boot      Called when the module is enabled.
	 * @param bool     $always_on Cannot be disabled (core feature).
	 * @param string   $desc      Short description for the dashboard card.
	 * @param string   $icon      Emoji/icon for the dashboard card.
	 */
	public function register( string $id, string $name, callable $boot, bool $always_on = false, string $desc = '', string $icon = 'grid' ): void {
		$this->modules[ $id ] = array(
			'name'      => $name,
			'desc'      => $desc,
			'icon'      => $icon,
			'boot'      => $boot,
			'always_on' => $always_on,
		);
	}

	private function register_built_in(): void {
		$dir = SNAP_PLUGIN_DIR;

		$this->register( 'compression', __( 'Image Compression', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/compression/class-image-processor.php';
			require_once $dir . 'includes/modules/compression/class-media-library.php';
			require_once $dir . 'includes/modules/compression/class-compression-ajax.php';
			new ICW_Media_Library();
			new ICW_Compression_Ajax();
		}, true, __( 'Compresses and converts images to WebP automatically. Keeps files under 100KB with smart resizing.', 'snaplevel' ), 'compress' );

		$this->register( 'seo_analyzer', __( 'Site Audit', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/seo-analyzer/class-seo-analyzer.php';
			new ICW_SEO_Scanner();
		}, false, __( 'Full site audit: orphan pages, slow pages, redirects, large images, and indexing history.', 'snaplevel' ), 'gauge' );

		$this->register( 'alt_text', __( 'AI Alt Text', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/ai-alt-text/class-alt-text-generator.php';
			new ICW_Alt_Text_Generator();
		}, false, __( 'Claude reads your images and writes SEO-friendly alt text, titles, and captions in one click.', 'snaplevel' ), 'sparkle' );

		$this->register( 'unused_images', __( 'Unused Images', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/unused-images/class-unused-images.php';
			new ICW_Unused_Images();
		}, false, __( 'Finds images not used anywhere on your site so you can safely clean them up.', 'snaplevel' ), 'broom' );

		// Importers + conflict guard load BEFORE seo_meta: the meta output
		// module checks Snap_Conflict_Guard to avoid duplicate head tags.
		$this->register( 'importers', __( 'Import & Conflict Guard', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/importers/class-conflict-guard.php';
			require_once $dir . 'includes/modules/importers/class-importer-yoast.php';
			require_once $dir . 'includes/modules/importers/class-importer-rankmath.php';
			new Snap_Conflict_Guard();
		}, true, __( 'One-click import from Yoast and Rank Math. Blocks duplicate meta output while both are active.', 'snaplevel' ), 'import' );

		$this->register( 'seo_meta', __( 'SEO Meta', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/importers/class-conflict-guard.php';
			require_once $dir . 'includes/modules/seo-meta/class-template-variables.php';
			require_once $dir . 'includes/modules/seo-meta/class-post-meta.php';
			require_once $dir . 'includes/modules/seo-meta/class-meta-output.php';
			require_once $dir . 'includes/modules/seo-meta/class-seo-meta-module.php';
			require_once $dir . 'includes/modules/seo-meta/class-builder-integration.php';
			require_once $dir . 'includes/modules/seo-meta/class-seo-changelog.php';
			new Snap_SEO_Meta_Module();
			new Snap_Builder_Integration();
			new Snap_SEO_Changelog();
		}, false, __( 'SEO titles, descriptions, robots and canonicals on every template. AI writes them, you approve.', 'snaplevel' ), 'target' );

		$this->register( 'schema', __( 'Schema', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/schema/class-schema-module.php';
			new Snap_Schema_Module();
		}, false, __( 'Structured data (JSON-LD). AI detects the right type per post and builds it for rich results.', 'snaplevel' ), 'schema' );

		$this->register( 'sitemap', __( 'XML Sitemap', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/sitemap/class-sitemap-module.php';
			new Snap_Sitemap_Module();
		}, false, __( 'Clean sitemap index that honors noindex, replaces core sitemaps, and pings IndexNow on publish.', 'snaplevel' ), 'sitemap' );

		$this->register( 'llms_txt', __( 'LLMs Txt', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/llms-txt/class-llms-txt.php';
			new Snap_LLMS_Txt();
		}, false, __( 'Serves a custom llms.txt to guide AI crawlers like ChatGPT, Claude and Perplexity. AI writes it from your site.', 'snaplevel' ), 'robot' );

		$this->register( 'redirections', __( 'Redirections', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/redirections/class-redirections.php';
			new Snap_Redirections();
		}, false, __( '301/302/307/410 redirects with regex, hit tracking, CSV import/export, and a live 404 monitor with one-click fixes.', 'snaplevel' ), 'redirect' );

		$this->register( 'broken_links', __( 'Broken Links', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/broken-links/class-broken-links.php';
			new Snap_Broken_Links();
		}, false, __( 'Scans every link on your site in batches, flags broken ones, and fixes them in one click. Daily re-checks.', 'snaplevel' ), 'link' );

		$this->register( 'breadcrumbs', __( 'Breadcrumbs', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/breadcrumbs/class-breadcrumbs.php';
			new Snap_Breadcrumbs();
		}, false, __( 'Accessible breadcrumb trail (shortcode + template function) with automatic BreadcrumbList JSON-LD for rich results.', 'snaplevel' ), 'sitemap' );

		$this->register( 'image_seo', __( 'Image SEO', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/image-seo/class-image-seo.php';
			new Snap_Image_SEO();
		}, false, __( 'SEO filenames and automatic alt text on upload, plus attachment-page redirects. AI alt text lives here too.', 'snaplevel' ), 'image' );

		$this->register( 'woocommerce', __( 'WooCommerce SEO', 'snaplevel' ), static function () use ( $dir ): void {
			require_once $dir . 'includes/modules/woocommerce/class-woocommerce-seo.php';
			new Snap_WooCommerce_SEO();
		}, false, __( 'Noindex for cart/checkout/account, product price Open Graph tags, and generator-tag cleanup. Auto-detects WooCommerce.', 'snaplevel' ), 'globe' );

		/**
		 * Third parties can register modules here.
		 *
		 * @param Snap_Module_Loader $loader
		 */
		do_action( 'snaplevel_register_modules', $this );
	}

	public function boot_active_modules(): void {
		$settings = Snap_Settings::instance();
		foreach ( $this->modules as $id => $module ) {
			if ( $module['always_on'] || $settings->module_enabled( $id ) ) {
				call_user_func( $module['boot'] );
			}
		}
	}

	/** @return array<string, array{name:string, desc:string, icon:string, always_on:bool, enabled:bool}> */
	public function list_modules(): array {
		$settings = Snap_Settings::instance();
		$out      = array();
		foreach ( $this->modules as $id => $module ) {
			$out[ $id ] = array(
				'name'      => $module['name'],
				'desc'      => $module['desc'],
				'icon'      => $module['icon'],
				'always_on' => $module['always_on'],
				'enabled'   => $module['always_on'] || $settings->module_enabled( $id ),
			);
		}
		return $out;
	}

	public function exists( string $id ): bool {
		return isset( $this->modules[ $id ] );
	}

	public function is_always_on( string $id ): bool {
		return isset( $this->modules[ $id ] ) && $this->modules[ $id ]['always_on'];
	}
}
