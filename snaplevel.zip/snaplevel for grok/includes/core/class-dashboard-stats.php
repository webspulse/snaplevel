<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Dashboard_Stats -- tiered caching for dashboard metrics.
 *
 * TTL strategy:
 *   Real-time: posts_count (WordPress already caches internally)
 *   1-minute:  missing_meta, schema_coverage, alt_coverage, images_total
 *   5-minute:  ai_usage, redirects_active, count_404s
 *   1-hour:    broken_links (only changes when daily scan runs)
 */
final class Snap_Dashboard_Stats {

	public function __construct() {
		// Targeted invalidation hooks.
		add_action( 'save_post', array( $this, 'invalidate_content_stats' ) );
		add_action( 'delete_post', array( $this, 'invalidate_content_stats' ) );
		add_action( 'updated_post_meta', array( $this, 'maybe_invalidate_meta' ), 10, 3 );
		add_action( 'added_post_meta', array( $this, 'maybe_invalidate_meta' ), 10, 3 );
		add_action( 'deleted_post_meta', array( $this, 'maybe_invalidate_meta' ), 10, 3 );
	}

	// ── Real-time (no cache, already fast) ───────────────────────────────────

	public static function posts_count(): int {
		return (int) wp_count_posts( 'post' )->publish + (int) wp_count_posts( 'page' )->publish;
	}

	// ── 1-minute cache ───────────────────────────────────────────────────────

	public static function missing_meta(): int {
		return (int) self::cached( 'snap_dash_missing_meta', 60, static function (): int {
			global $wpdb;
			return (int) $wpdb->get_var(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				 WHERE p.post_status = 'publish' AND p.post_type IN ('post','page')
				 AND NOT EXISTS (
					 SELECT 1 FROM {$wpdb->postmeta} m
					 WHERE m.post_id = p.ID AND m.meta_key = '_snap_desc' AND m.meta_value != ''
				 )"
			);
		} );
	}

	public static function schema_coverage(): int {
		return (int) self::cached( 'snap_dash_schema_cov', 60, static function (): int {
			global $wpdb;
			return (int) $wpdb->get_var(
				"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta}
				 WHERE meta_key = '_snap_schema' AND meta_value != ''"
			);
		} );
	}

	public static function images_total(): int {
		return (int) self::cached( 'snap_dash_images_total', 60, static function (): int {
			global $wpdb;
			return (int) $wpdb->get_var(
				"SELECT COUNT(*) FROM {$wpdb->posts}
				 WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%'"
			);
		} );
	}

	public static function images_with_alt(): int {
		return (int) self::cached( 'snap_dash_images_alt', 60, static function (): int {
			global $wpdb;
			return (int) $wpdb->get_var(
				"SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID
					 AND m.meta_key = '_wp_attachment_image_alt' AND m.meta_value != ''
				 WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%'"
			);
		} );
	}

	// ── 5-minute cache ───────────────────────────────────────────────────────

	public static function ai_usage(): array {
		$result = self::cached( 'snap_dash_ai_usage', 300, static function (): array {
			if ( class_exists( 'Snap_AI_Usage' ) ) {
				return Snap_AI_Usage::summary();
			}
			return array( 'month' => array( 'calls' => 0, 'cost' => 0 ) );
		} );
		return is_array( $result ) ? $result : array( 'month' => array( 'calls' => 0, 'cost' => 0 ) );
	}

	public static function redirects_active(): int {
		return (int) self::cached( 'snap_dash_redirects', 300, static function (): int {
			if ( class_exists( 'Snap_Redirections' ) ) {
				return Snap_Redirections::count_active();
			}
			return 0;
		} );
	}

	public static function count_404s(): int {
		return (int) self::cached( 'snap_dash_404s', 300, static function (): int {
			if ( class_exists( 'Snap_Redirections' ) ) {
				return Snap_Redirections::count_404s();
			}
			return 0;
		} );
	}

	// ── 1-hour cache ─────────────────────────────────────────────────────────

	public static function broken_links(): int {
		return (int) self::cached( 'snap_dash_broken', 3600, static function (): int {
			if ( class_exists( 'Snap_Broken_Links' ) ) {
				return Snap_Broken_Links::count_broken();
			}
			return 0;
		} );
	}

	// ── Computed (always fresh from cached components) ────────────────────────

	public static function health_score(): array {
		$posts_count    = self::posts_count();
		$missing_meta   = self::missing_meta();
		$schema_count   = self::schema_coverage();
		$images_total   = self::images_total();
		$images_alt     = self::images_with_alt();
		$broken         = self::broken_links();
		$has_key        = '' !== Snap_Settings::instance()->get_api_key();
		$modules        = Snap_Module_Loader::instance()->list_modules();

		$meta_cov   = $posts_count > 0 ? ( $posts_count - $missing_meta ) / $posts_count : 0;
		$schema_cov = $posts_count > 0 ? min( 1, $schema_count / $posts_count ) : 0;
		$alt_cov    = $images_total > 0 ? $images_alt / $images_total : 1;

		$score = (int) round(
			$meta_cov * 40
			+ $schema_cov * 15
			+ $alt_cov * 15
			+ ( $has_key ? 10 : 0 )
			+ ( ! empty( $modules['sitemap']['enabled'] ) ? 10 : 0 )
			+ ( 0 === $broken ? 10 : max( 0, 10 - $broken ) )
		);
		$score = max( 0, min( 100, $score ) );

		$state = $score >= 81 ? 'good' : ( $score >= 51 ? 'ok' : 'bad' );

		return array(
			'score' => $score,
			'state' => $state,
		);
	}

	// ── Invalidation ─────────────────────────────────────────────────────────

	public function invalidate_content_stats(): void {
		delete_transient( 'snap_dash_missing_meta' );
		delete_transient( 'snap_dash_schema_cov' );
	}

	public function maybe_invalidate_meta( $meta_id, $post_id, $meta_key ): void {
		if ( in_array( $meta_key, array( '_snap_desc', '_snap_schema', '_wp_attachment_image_alt' ), true ) ) {
			delete_transient( 'snap_dash_missing_meta' );
			delete_transient( 'snap_dash_schema_cov' );
			delete_transient( 'snap_dash_images_alt' );
		}
	}

	public static function invalidate_redirects(): void {
		delete_transient( 'snap_dash_redirects' );
		delete_transient( 'snap_dash_404s' );
	}

	public static function invalidate_broken_links(): void {
		delete_transient( 'snap_dash_broken' );
	}

	// ── Cache helper ─────────────────────────────────────────────────────────

	private static function cached( string $key, int $ttl, callable $compute ) {
		$val = get_transient( $key );
		if ( false !== $val ) {
			return $val;
		}
		$val = $compute();
		set_transient( $key, $val, $ttl );
		return $val;
	}
}
