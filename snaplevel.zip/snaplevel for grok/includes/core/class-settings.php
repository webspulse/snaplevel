<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Settings — one settings API for the whole plugin.
 *
 * Stores everything in a single structured `snap_settings` option.
 * Migrates from the legacy flat `icw_settings` option on first run and
 * keeps a flat legacy mirror in sync so untouched ICW_* modules keep working.
 */
final class Snap_Settings {

	const OPTION        = 'snap_settings';
	const LEGACY_OPTION = 'icw_settings';

	/** @var Snap_Settings|null */
	private static $instance = null;

	/** @var array */
	private $data = array();

	public static function instance(): Snap_Settings {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$stored     = get_option( self::OPTION, array() );
		$this->data = $this->merge_defaults( is_array( $stored ) ? $stored : array() );
	}

	// ── Defaults ──────────────────────────────────────────────────────────────

	public static function defaults(): array {
		return array(
			'modules'     => array(
				'compression'   => true,
				'alt_text'      => true,
				'unused_images' => true,
				'seo_analyzer'  => true,
				'seo_meta'      => true,
				'sitemap'       => true,
				'schema'        => true,
				'llms_txt'      => true,
				'redirections'  => true,
				'broken_links'  => true,
				'breadcrumbs'   => true,
				'image_seo'     => true,
				'woocommerce'   => true,
			),
			'ai'          => array(
				'provider'         => 'anthropic', // anthropic | openai | gemini | deepseek | mistral
				'api_key'          => '',          // Anthropic key, stored encrypted
				'api_key_openai'   => '',          // OpenAI key, stored encrypted
				'api_key_gemini'   => '',
				'api_key_deepseek' => '',
				'api_key_mistral'  => '',
				'model_fast'      => '',           // empty = automatic per provider
				'model_smart'     => '',
				'keywords'        => '',
				'auto_modes'      => array(),      // per-task opt-in, e.g. [ 'seo_title' => true ]
				'training_budget' => 8000,         // chars of site knowledge injected per AI call
				'memory_rules'    => '',           // SEO Memory: learned style rules appended to every prompt
				'self_training'   => true,         // baked-in SEO/AEO/GEO playbook + weekly news digest
			),
			'compression' => array(
				'quality'            => 82,
				'compress_originals' => true,
				'convert_to_webp'    => true,
				'backup_originals'   => true,
				'auto_on_upload'     => false,
			),
			'titles'      => array(
				'separator'      => '–',
				'home_title'     => '%sitename% %sep% %sitedesc%',
				'home_desc'      => '',
				'post_types'     => array(),
				'taxonomies'     => array(),
				'archive_author' => '%name% %sep% %sitename%',
				'archive_date'   => '%date% %sep% %sitename%',
				'archive_search' => 'Search: %term% %sep% %sitename%',
				'archive_404'    => 'Page not found %sep% %sitename%',
				'noindex_empty_archives' => true,
			),
			'schema'      => array(
				'site_type' => 'organization',
				'name'      => '',
				'logo'      => '',
				'social'    => '',
			),
			'sitemap'     => array(
				'per_page'  => 1000,
				'indexnow'  => true,
				'post_types' => array(),
				'taxonomies' => array(),
			),
			'llms'        => array(
				'enabled' => true,
				'content' => '',
			),
			'codes'       => array(
				'ga4_id'         => '',
				'adsense_client' => '',
				'head_code'      => '',
				'footer_code'    => '',
			),
			'webmasters'  => array(
				'google'    => '',
				'bing'      => '',
				'yandex'    => '',
				'baidu'     => '',
				'pinterest' => '',
				'norton'    => '',
			),
			'business'    => array(
				'name'    => '',
				'owner'   => '',
				'tagline' => '',
				'purpose' => '',
			),
			'redirections' => array(
				'auto_deleted' => false,
			),
			'image_seo'   => array(
				'clean_filenames'      => true,
				'auto_alt_on_upload'   => true,
				'redirect_attachments' => true,
			),
			'breadcrumbs' => array(
				'separator' => '›',
			),
			'site_type'   => '',
			'wizard'      => array( 'step' => 0, 'done' => false ),
		);
	}

	private function merge_defaults( array $data ): array {
		return self::deep_merge( self::defaults(), $data );
	}

	private static function deep_merge( array $defaults, array $data ): array {
		foreach ( $data as $key => $value ) {
			if ( is_array( $value ) && isset( $defaults[ $key ] ) && is_array( $defaults[ $key ] )
				&& self::is_assoc( $defaults[ $key ] ) ) {
				$defaults[ $key ] = self::deep_merge( $defaults[ $key ], $value );
			} else {
				$defaults[ $key ] = $value;
			}
		}
		return $defaults;
	}

	private static function is_assoc( array $arr ): bool {
		if ( array() === $arr ) {
			return true;
		}
		return array_keys( $arr ) !== range( 0, count( $arr ) - 1 );
	}

	// ── Public API ────────────────────────────────────────────────────────────

	/**
	 * Get a setting with dot notation, e.g. get( 'ai.model_fast' ).
	 *
	 * @param string $key
	 * @param mixed  $fallback
	 * @return mixed
	 */
	public function get( string $key, $fallback = null ) {
		$parts = explode( '.', $key );
		$value = $this->data;
		foreach ( $parts as $part ) {
			if ( ! is_array( $value ) || ! array_key_exists( $part, $value ) ) {
				return $fallback;
			}
			$value = $value[ $part ];
		}
		return $value;
	}

	/**
	 * Set a setting with dot notation and persist.
	 *
	 * @param string $key
	 * @param mixed  $value
	 */
	public function set( string $key, $value ): void {
		$parts = explode( '.', $key );
		$ref   = &$this->data;
		foreach ( $parts as $i => $part ) {
			if ( $i === count( $parts ) - 1 ) {
				$ref[ $part ] = $value;
				break;
			}
			if ( ! isset( $ref[ $part ] ) || ! is_array( $ref[ $part ] ) ) {
				$ref[ $part ] = array();
			}
			$ref = &$ref[ $part ];
		}
		$this->save();
	}

	/** Merge a partial settings array (already-sanitized) and persist. */
	public function update( array $partial ): void {
		$this->data = self::deep_merge( $this->data, $partial );
		$this->save();
	}

	public function all(): array {
		return $this->data;
	}

	/** Module enabled check. */
	public function module_enabled( string $module_id ): bool {
		return (bool) $this->get( 'modules.' . $module_id, false );
	}

	// ── API keys (per provider, encrypted) ────────────────────────────────────

	/** Providers with their own stored API key. */
	public static function providers(): array {
		return array( 'anthropic', 'openai', 'gemini', 'deepseek', 'mistral' );
	}

	private function key_field( string $provider ): string {
		return in_array( $provider, array( 'openai', 'gemini', 'deepseek', 'mistral' ), true )
			? 'ai.api_key_' . $provider
			: 'ai.api_key';
	}

	/** @param string $provider 'anthropic' | 'openai' | '' (current provider). */
	public function set_api_key( string $plain, string $provider = '' ): void {
		$provider = '' !== $provider ? $provider : (string) $this->get( 'ai.provider', 'anthropic' );
		$this->set( $this->key_field( $provider ), '' === $plain ? '' : self::encrypt( $plain ) );
	}

	/** @param string $provider 'anthropic' | 'openai' | '' (current provider). */
	public function get_api_key( string $provider = '' ): string {
		$provider = '' !== $provider ? $provider : (string) $this->get( 'ai.provider', 'anthropic' );
		$stored   = (string) $this->get( $this->key_field( $provider ), '' );
		if ( '' === $stored ) {
			return '';
		}
		return self::decrypt( $stored );
	}

	/** Masked key for display: sk-ant-…1234 */
	public function get_api_key_masked( string $provider = '' ): string {
		$key = $this->get_api_key( $provider );
		if ( '' === $key ) {
			return '';
		}
		if ( strlen( $key ) <= 12 ) {
			return str_repeat( '•', 8 );
		}
		return substr( $key, 0, 7 ) . '…' . substr( $key, -4 );
	}

	public static function encrypt( string $plain ): string {
		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$key    = hash( 'sha256', wp_salt( 'auth' ), true );
			$nonce  = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = sodium_crypto_secretbox( $plain, $nonce, $key );
			return 'enc:v1:' . base64_encode( $nonce . $cipher );
		}
		// Fallback: reversible obfuscation (better than plain text, not real crypto).
		return 'enc:v0:' . base64_encode( $plain ^ str_pad( '', strlen( $plain ), wp_salt( 'auth' ) ) );
	}

	public static function decrypt( string $stored ): string {
		if ( 0 === strpos( $stored, 'enc:v1:' ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$raw = base64_decode( substr( $stored, 7 ), true );
			if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
				return '';
			}
			$nonce  = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$key    = hash( 'sha256', wp_salt( 'auth' ), true );
			$plain  = sodium_crypto_secretbox_open( $cipher, $nonce, $key );
			return false === $plain ? '' : $plain;
		}
		if ( 0 === strpos( $stored, 'enc:v0:' ) ) {
			$raw = base64_decode( substr( $stored, 7 ), true );
			if ( false === $raw ) {
				return '';
			}
			return $raw ^ str_pad( '', strlen( $raw ), wp_salt( 'auth' ) );
		}
		// Legacy plain-text key (pre-2.0) — return as-is.
		return $stored;
	}

	// ── Migration + legacy mirror ─────────────────────────────────────────────

	/** One-time migration from flat icw_settings into structured snap_settings. */
	public function maybe_migrate(): void {
		if ( false !== get_option( self::OPTION, false ) ) {
			return;
		}
		$legacy = get_option( self::LEGACY_OPTION, array() );
		if ( ! is_array( $legacy ) ) {
			$legacy = array();
		}

		$this->data = $this->merge_defaults( array(
			'modules'     => array(
				'seo_analyzer'  => ! isset( $legacy['module_seo'] ) || false !== $legacy['module_seo'],
				'alt_text'      => ! isset( $legacy['module_alt'] ) || false !== $legacy['module_alt'],
				'unused_images' => ! isset( $legacy['module_unused'] ) || false !== $legacy['module_unused'],
			),
			'compression' => array(
				'quality'            => isset( $legacy['quality'] ) ? (int) $legacy['quality'] : 82,
				'convert_to_webp'    => ! isset( $legacy['convert_to_webp'] ) || (bool) $legacy['convert_to_webp'],
				'backup_originals'   => ! isset( $legacy['backup_originals'] ) || (bool) $legacy['backup_originals'],
				'auto_on_upload'     => ! empty( $legacy['auto_on_upload'] ),
			),
			'ai'          => array(
				'keywords' => isset( $legacy['ai_keywords'] ) ? (string) $legacy['ai_keywords'] : '',
			),
		) );

		$this->save();
	}

	private function save(): void {
		update_option( self::OPTION, $this->data );
		$this->sync_legacy_mirror();
	}

	/**
	 * Keep the flat icw_settings option in sync for legacy ICW_* classes
	 * that still call get_option('icw_settings').
	 */
	private function sync_legacy_mirror(): void {
		$legacy = get_option( self::LEGACY_OPTION, array() );
		if ( ! is_array( $legacy ) ) {
			$legacy = array();
		}
		$legacy = array_merge( $legacy, array(
			'quality'            => (int) $this->get( 'compression.quality', 82 ),
			'compress_originals' => (bool) $this->get( 'compression.compress_originals', true ),
			'convert_to_webp'    => (bool) $this->get( 'compression.convert_to_webp', true ),
			'backup_originals'   => (bool) $this->get( 'compression.backup_originals', true ),
			'auto_on_upload'     => (bool) $this->get( 'compression.auto_on_upload', false ),
			'ai_keywords'        => (string) $this->get( 'ai.keywords', '' ),
			'module_seo'         => (bool) $this->get( 'modules.seo_analyzer', true ),
			'module_alt'         => (bool) $this->get( 'modules.alt_text', true ),
			'module_unused'      => (bool) $this->get( 'modules.unused_images', true ),
		) );
		update_option( self::LEGACY_OPTION, $legacy );
	}
}
