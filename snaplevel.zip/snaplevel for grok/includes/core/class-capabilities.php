<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Capabilities — custom capabilities.
 *
 * snap_manage_seo → manage plugin settings, run imports, edit global meta.
 * snap_use_ai     → trigger AI generations (editors get this too).
 */
final class Snap_Capabilities {

	const MANAGE = 'snap_manage_seo';
	const USE_AI = 'snap_use_ai';

	public static function add_caps(): void {
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( self::MANAGE );
			$admin->add_cap( self::USE_AI );
		}
		$editor = get_role( 'editor' );
		if ( $editor ) {
			$editor->add_cap( self::USE_AI );
		}
	}

	public static function remove_caps(): void {
		foreach ( array( 'administrator', 'editor' ) as $role_id ) {
			$role = get_role( $role_id );
			if ( $role ) {
				$role->remove_cap( self::MANAGE );
				$role->remove_cap( self::USE_AI );
			}
		}
	}

	/** Capability check with fallback for sites where caps were never added. */
	public static function can_manage(): bool {
		return current_user_can( self::MANAGE ) || current_user_can( 'manage_options' );
	}

	public static function can_use_ai(): bool {
		return current_user_can( self::USE_AI ) || current_user_can( 'edit_posts' );
	}

	/**
	 * Task-aware permission check for the /ai/generate REST endpoint.
	 * Site-wide tasks require manage capability; post tasks require edit_post.
	 */
	public static function can_generate_ai( WP_REST_Request $request ): bool {
		if ( ! self::can_use_ai() ) {
			return false;
		}

		$task = sanitize_key( (string) $request->get_param( 'task' ) );
		if ( '' === $task || ! class_exists( 'Snap_AI_Prompts' ) || ! Snap_AI_Prompts::task_exists( $task ) ) {
			return false;
		}

		$admin_tasks = array( 'llms_txt' );
		if ( in_array( $task, $admin_tasks, true ) ) {
			return self::can_manage();
		}

		$post_id = (int) $request->get_param( 'post_id' );
		if ( $post_id > 0 ) {
			return current_user_can( 'edit_post', $post_id );
		}

		$post_tasks = array( 'seo_title', 'meta_description', 'focus_keywords', 'schema', 'copilot_analyze', 'content_analysis' );
		if ( in_array( $task, $post_tasks, true ) ) {
			return false;
		}

		if ( 'alt_text' === $task ) {
			return current_user_can( 'upload_files' ) || self::can_manage();
		}

		return self::can_manage();
	}
}
