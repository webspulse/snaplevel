<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Assets — central asset registration.
 *
 * Versioning uses the file's modification time so the browser cache is
 * busted the moment a file changes — never a stale stylesheet again.
 */
final class Snap_Assets {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'register' ), 5 );
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_sidebar' ) );
	}

	/** File-based version: SNAP_VERSION + mtime of the asset. */
	public static function version( string $relative_path = '' ): string {
		if ( '' !== $relative_path ) {
			$file = SNAP_PLUGIN_DIR . ltrim( $relative_path, '/' );
			if ( file_exists( $file ) ) {
				return SNAP_VERSION . '.' . (string) filemtime( $file );
			}
		}
		return SNAP_VERSION;
	}

	public function register(): void {
		wp_register_style( 'snap-design-system', SNAP_PLUGIN_URL . 'assets/css/design-system.css', array(), self::version( 'assets/css/design-system.css' ) );
		wp_register_style( 'icw-admin', SNAP_PLUGIN_URL . 'assets/css/admin.css', array( 'snap-design-system' ), self::version( 'assets/css/admin.css' ) );

		wp_register_script( 'icw-admin', SNAP_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), self::version( 'assets/js/admin.js' ), true );
		wp_register_script( 'snap-settings-app', SNAP_PLUGIN_URL . 'assets/js/settings-app.js', array( 'wp-api-fetch', 'wp-i18n' ), self::version( 'assets/js/settings-app.js' ), true );
		wp_register_script( 'snap-wizard', SNAP_PLUGIN_URL . 'assets/js/wizard.js', array( 'wp-api-fetch', 'wp-i18n' ), self::version( 'assets/js/wizard.js' ), true );
		wp_register_script( 'snap-vtabs', SNAP_PLUGIN_URL . 'assets/js/vtabs.js', array(), self::version( 'assets/js/vtabs.js' ), true );
		wp_register_script( 'snap-seo-audit', SNAP_PLUGIN_URL . 'assets/js/seo-audit.js', array( 'jquery' ), self::version( 'assets/js/seo-audit.js' ), true );
		wp_register_script( 'snap-image-seo', SNAP_PLUGIN_URL . 'assets/js/image-seo.js', array(), self::version( 'assets/js/image-seo.js' ), true );
		wp_register_script( 'snap-compression', SNAP_PLUGIN_URL . 'assets/js/compression.js', array( 'jquery' ), self::version( 'assets/js/compression.js' ), true );
		wp_register_script( 'snap-unused-images', SNAP_PLUGIN_URL . 'assets/js/unused-images.js', array( 'jquery' ), self::version( 'assets/js/unused-images.js' ), true );
	}

	public function enqueue_editor_sidebar(): void {
		if ( ! Snap_Settings::instance()->module_enabled( 'seo_meta' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && 'post' !== $screen->base ) {
			return;
		}

		wp_enqueue_style( 'snap-design-system', SNAP_PLUGIN_URL . 'assets/css/design-system.css', array(), self::version( 'assets/css/design-system.css' ) );
		wp_enqueue_script(
			'snap-editor-sidebar',
			SNAP_PLUGIN_URL . 'assets/js/editor-sidebar.js',
			array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'wp-api-fetch', 'wp-compose', 'wp-i18n' ),
			self::version( 'assets/js/editor-sidebar.js' ),
			true
		);

		wp_localize_script( 'snap-editor-sidebar', 'SNAP_SIDEBAR', array(
			'siteName'        => get_bloginfo( 'name' ),
			'siteUrl'         => home_url( '/' ),
			'separator'       => (string) Snap_Settings::instance()->get( 'titles.separator', '–' ),
			'canUseAI'        => Snap_Capabilities::can_use_ai(),
			'hasKey'          => '' !== Snap_Settings::instance()->get_api_key(),
			'copilotEnabled'  => Snap_Copilot::is_enabled(),
			'copilotEndpoint' => esc_url_raw( rest_url( 'snaplevel/v1/copilot/analyze' ) ),
		) );
	}

	/** Shared JS config for admin app screens. */
	public static function localize_app( string $handle ): void {
		$settings = Snap_Settings::instance();
		wp_localize_script( $handle, 'SNAP', array(
			'restUrl'   => esc_url_raw( rest_url( 'snaplevel/v1' ) ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'version'   => SNAP_VERSION,
			'canManage' => Snap_Capabilities::can_manage(),
			'hasKey'    => '' !== $settings->get_api_key(),
			'adminUrl'  => admin_url(),
			'logoUrl'   => SNAP_PLUGIN_URL . 'assets/images/logo-dark-text.svg',
			'siteName'  => get_bloginfo( 'name' ),
			'icons'     => class_exists( 'Snap_Icons' ) ? Snap_Icons::js_map() : array(),
		) );
	}
}
