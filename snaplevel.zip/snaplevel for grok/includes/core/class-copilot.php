<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Copilot -- opportunity-based SEO assistant.
 *
 * Copilot finds actionable SEO opportunities in a post and offers to fix
 * them with AI. Manual analyze by default. Auto-analyze on save is an
 * opt-in Beta setting (disabled by default).
 *
 * Post meta stored:
 *   _snap_copilot_analysis  JSON  Cached analysis (opportunities + readiness)
 *   _snap_copilot_hash      str   MD5 of title+content at last analysis
 *   _snap_copilot_time      int   Unix timestamp of last analysis
 */
final class Snap_Copilot {

	/** Max analyses per site per day (configurable in settings). */
	const DEFAULT_DAILY_LIMIT = 50;

	public function __construct() {
		add_action( 'init', array( $this, 'register_meta' ), 20 );
		add_action( 'save_post', array( $this, 'maybe_auto_analyze' ), 99, 2 );
		add_action( 'snap_copilot_analyze_post', array( $this, 'run_background_analysis' ) );
	}

	/**
	 * Register Copilot post meta so the block editor sidebar can read it.
	 */
	public function register_meta(): void {
		$post_types = get_post_types( array( 'public' => true ), 'names' );
		unset( $post_types['attachment'] );

		foreach ( $post_types as $post_type ) {
			register_post_meta( $post_type, '_snap_copilot_analysis', array(
				'show_in_rest'      => true,
				'single'            => true,
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
			) );
			register_post_meta( $post_type, '_snap_copilot_hash', array(
				'show_in_rest'      => true,
				'single'            => true,
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
			) );
			register_post_meta( $post_type, '_snap_copilot_time', array(
				'show_in_rest'      => true,
				'single'            => true,
				'type'              => 'integer',
				'default'           => 0,
				'sanitize_callback' => 'absint',
				'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
			) );
		}
	}

	/**
	 * Auto-analyze on save (Beta, OFF by default).
	 */
	public function maybe_auto_analyze( int $post_id, WP_Post $post ): void {
		// Guard: only if auto-analyze is explicitly enabled.
		if ( ! (bool) Snap_Settings::instance()->get( 'copilot.auto_analyze', false ) ) {
			return;
		}
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! in_array( $post->post_status, array( 'publish', 'draft', 'pending' ), true ) ) {
			return;
		}
		if ( str_word_count( wp_strip_all_tags( $post->post_content ) ) < 100 ) {
			return;
		}

		// Content hash check: skip if nothing changed.
		$hash      = md5( $post->post_title . $post->post_content );
		$last_hash = (string) get_post_meta( $post_id, '_snap_copilot_hash', true );
		if ( $hash === $last_hash ) {
			return;
		}

		// Debounce: 60 seconds between analyses.
		$last_time = (int) get_post_meta( $post_id, '_snap_copilot_time', true );
		if ( time() - $last_time < 60 ) {
			return;
		}

		// Daily cap.
		$today_count = (int) get_transient( 'snap_copilot_daily_count' );
		$limit       = (int) Snap_Settings::instance()->get( 'copilot.daily_limit', self::DEFAULT_DAILY_LIMIT );
		if ( $today_count >= $limit ) {
			return;
		}

		// Schedule background analysis (non-blocking).
		if ( ! wp_next_scheduled( 'snap_copilot_analyze_post', array( $post_id ) ) ) {
			wp_schedule_single_event( time(), 'snap_copilot_analyze_post', array( $post_id ) );
		}
	}

	/**
	 * Run the actual AI analysis (called from cron or directly).
	 */
	public function run_background_analysis( int $post_id ): void {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return;
		}

		$result = self::analyze( $post );
		if ( is_wp_error( $result ) ) {
			return;
		}

		$hash = md5( $post->post_title . $post->post_content );
		update_post_meta( $post_id, '_snap_copilot_analysis', wp_json_encode( $result['data'] ) );
		update_post_meta( $post_id, '_snap_copilot_hash', $hash );
		update_post_meta( $post_id, '_snap_copilot_time', time() );

		// Increment daily counter.
		$count = (int) get_transient( 'snap_copilot_daily_count' );
		set_transient( 'snap_copilot_daily_count', $count + 1, DAY_IN_SECONDS );
	}

	/**
	 * Run Copilot analysis for a post. Can be called directly for manual analyze.
	 *
	 * @return array|WP_Error
	 */
	public static function analyze( WP_Post $post ) {
		$content    = wp_strip_all_tags( $post->post_content );
		$word_count = str_word_count( $content );

		// Count internal links.
		$internal_links = 0;
		$home_host      = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)/i', $post->post_content, $matches ) ) {
			foreach ( $matches[1] as $url ) {
				$parsed = wp_parse_url( $url );
				if ( ! empty( $parsed['host'] ) && $parsed['host'] === $home_host ) {
					$internal_links++;
				} elseif ( empty( $parsed['host'] ) && ! empty( $parsed['path'] ) ) {
					$internal_links++; // Relative URL = internal.
				}
			}
		}

		$context = array(
			'content'        => $post->post_content,
			'post_title'     => $post->post_title,
			'focus_keyword'  => (string) get_post_meta( $post->ID, '_snap_focus_kw', true ),
			'has_meta_desc'  => '' !== (string) get_post_meta( $post->ID, '_snap_desc', true ),
			'has_seo_title'  => '' !== (string) get_post_meta( $post->ID, '_snap_title', true ),
			'internal_links' => $internal_links,
			'word_count'     => $word_count,
		);

		return Snap_AI::generate( 'copilot_analyze', $context );
	}

	/**
	 * Check if Copilot is enabled globally.
	 */
	public static function is_enabled(): bool {
		return '' !== Snap_Settings::instance()->get_api_key();
	}
}
