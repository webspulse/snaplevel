<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_REST_API — all new UI talks to snaplevel/v1.
 */
final class Snap_REST_API {

	const NS = 'snaplevel/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route( self::NS, '/settings', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_settings' ),
				'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_settings' ),
				'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			),
		) );

		register_rest_route( self::NS, '/modules/toggle', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'toggle_module' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			'args'                => array(
				'module' => array( 'type' => 'string', 'required' => true ),
				'state'  => array( 'type' => 'boolean', 'required' => true ),
			),
		) );

		register_rest_route( self::NS, '/ai/test', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'test_ai' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			'args'                => array(
				'provider' => array( 'type' => 'string', 'required' => false, 'enum' => array( 'anthropic', 'openai', 'gemini', 'deepseek', 'mistral' ) ),
				'api_key'  => array( 'type' => 'string', 'required' => false ),
			),
		) );

		register_rest_route( self::NS, '/ai/generate', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'generate' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_generate_ai' ),
			'args'                => array(
				'task'    => array( 'type' => 'string', 'required' => true ),
				'post_id' => array( 'type' => 'integer', 'required' => false ),
				'context' => array( 'type' => 'object', 'required' => false ),
			),
		) );

		register_rest_route( self::NS, '/ai/usage', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( $this, 'usage' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/training', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'training_list' ),
				'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'training_save' ),
				'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			),
		) );

		register_rest_route( self::NS, '/training/(?P<id>\d+)', array(
			'methods'             => WP_REST_Server::DELETABLE,
			'callback'            => array( $this, 'training_delete' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/ai/fix-meta', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'ai_fix_meta' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/llms/generate', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'llms_generate' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/training/self-update', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'training_self_update' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/import/detect', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( $this, 'import_detect' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/import/run', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'import_run' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			'args'                => array(
				'source' => array( 'type' => 'string', 'required' => true, 'enum' => array( 'yoast', 'rankmath', 'aioseo', 'seopress', 'seoframework', 'smartcrawl', 'wpmetaseo', 'slimseo' ) ),
				'offset' => array( 'type' => 'integer', 'required' => false, 'default' => 0 ),
			),
		) );

		register_rest_route( self::NS, '/audit/fix-links', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'audit_fix_links' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			'args'                => array(
				'offset' => array( 'type' => 'integer', 'required' => false, 'default' => 0 ),
			),
		) );

		register_rest_route( self::NS, '/tools/export', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( $this, 'tools_export' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/tools/import', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'tools_import' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/tools/reset', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'tools_reset' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/wizard', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_wizard' ),
				'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_wizard' ),
				'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
			),
		) );

		register_rest_route( self::NS, '/wizard/quick-scan', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( $this, 'wizard_quick_scan' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_manage' ),
		) );

		register_rest_route( self::NS, '/copilot/analyze', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( $this, 'copilot_analyze' ),
			'permission_callback' => array( 'Snap_Capabilities', 'can_use_ai' ),
			'args'                => array(
				'post_id' => array( 'type' => 'integer', 'required' => true ),
			),
		) );
	}

	// ── Settings ──────────────────────────────────────────────────────────────

	public function get_settings(): WP_REST_Response {
		$settings = Snap_Settings::instance();
		$data     = $settings->all();

		// Never return real keys.
		foreach ( Snap_Settings::providers() as $provider_id ) {
			$field = 'anthropic' === $provider_id ? 'api_key' : 'api_key_' . $provider_id;
			$data['ai'][ $field ]             = '';
			$data['ai'][ $field . '_masked' ] = $settings->get_api_key_masked( $provider_id );
		}
		$data['ai']['has_active_key']        = '' !== $settings->get_api_key();
		$data['modules_meta']                = Snap_Module_Loader::instance()->list_modules();
		$data['training_total']              = class_exists( 'Snap_AI_Training' ) ? Snap_AI_Training::total_chars() : 0;
		$data['training_limit']              = class_exists( 'Snap_AI_Training' ) ? Snap_AI_Training::TOTAL_LIMIT : 0;
		$data['content_types']               = self::content_types();

		return rest_ensure_response( $data );
	}

	/**
	 * Every registered public post type and taxonomy on this site.
	 * Includes CPTs from ACF, JetEngine/Crocoblock, CPT UI, WooCommerce, etc. —
	 * anything that calls register_post_type() / register_taxonomy().
	 */
	public static function content_types(): array {
		$post_types = array();
		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $pt ) {
			if ( 'attachment' === $pt->name ) {
				continue; // Media gets no title templates.
			}
			$post_types[ $pt->name ] = array(
				'label'        => (string) $pt->labels->name,
				'singular'     => (string) $pt->labels->singular_name,
				'hierarchical' => (bool) $pt->hierarchical,
				'has_archive'  => (bool) $pt->has_archive,
				'builtin'      => (bool) $pt->_builtin,
				'taxonomies'   => array_values( get_object_taxonomies( $pt->name ) ),
			);
		}

		$taxonomies = array();
		foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $tx ) {
			if ( in_array( $tx->name, array( 'post_format' ), true ) ) {
				continue;
			}
			$taxonomies[ $tx->name ] = array(
				'label'        => (string) $tx->labels->name,
				'singular'     => (string) $tx->labels->singular_name,
				'hierarchical' => (bool) $tx->hierarchical,
				'builtin'      => (bool) $tx->_builtin,
				'post_types'   => array_values( (array) $tx->object_type ),
			);
		}

		return array(
			'post_types' => $post_types,
			'taxonomies' => $taxonomies,
		);
	}

	public function save_settings( WP_REST_Request $request ) {
		$settings = Snap_Settings::instance();
		$body     = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'snap_bad_request', __( 'Invalid request body.', 'snaplevel' ), array( 'status' => 400 ) );
		}

		$clean = array();

		if ( isset( $body['compression'] ) && is_array( $body['compression'] ) ) {
			$c = $body['compression'];
			$clean['compression'] = array(
				'quality'          => isset( $c['quality'] ) ? max( 50, min( 100, (int) $c['quality'] ) ) : 82,
				'convert_to_webp'  => ! empty( $c['convert_to_webp'] ),
				'backup_originals' => ! empty( $c['backup_originals'] ),
				'auto_on_upload'   => ! empty( $c['auto_on_upload'] ),
			);
		}

		if ( isset( $body['ai'] ) && is_array( $body['ai'] ) ) {
			$a           = $body['ai'];
			$clean['ai'] = array();
			if ( isset( $a['provider'] ) && in_array( $a['provider'], Snap_Settings::providers(), true ) ) {
				$clean['ai']['provider'] = $a['provider'];
			}
			foreach ( array( 'model_fast', 'model_smart', 'keywords' ) as $field ) {
				if ( isset( $a[ $field ] ) ) {
					$clean['ai'][ $field ] = sanitize_text_field( (string) $a[ $field ] );
				}
			}
			if ( isset( $a['training_budget'] ) ) {
				$clean['ai']['training_budget'] = max( 0, min( 30000, (int) $a['training_budget'] ) );
			}
			if ( isset( $a['memory_rules'] ) ) {
				$clean['ai']['memory_rules'] = sanitize_textarea_field( (string) $a['memory_rules'] );
			}
			if ( isset( $a['self_training'] ) ) {
				$clean['ai']['self_training'] = (bool) $a['self_training'];
			}
			if ( isset( $a['auto_modes'] ) && is_array( $a['auto_modes'] ) ) {
				$clean['ai']['auto_modes'] = array_map( 'boolval', $a['auto_modes'] );
			}
			// Keys handled separately: only overwrite when a new one is sent.
			foreach ( Snap_Settings::providers() as $provider_id ) {
				$field = 'anthropic' === $provider_id ? 'api_key' : 'api_key_' . $provider_id;
				if ( ! empty( $a[ $field ] ) && is_string( $a[ $field ] ) ) {
					$settings->set_api_key( sanitize_text_field( $a[ $field ] ), $provider_id );
				}
				if ( ! empty( $a[ 'remove_' . $field ] ) ) {
					$settings->set_api_key( '', $provider_id );
				}
			}
		}

		if ( isset( $body['titles'] ) && is_array( $body['titles'] ) ) {
			$t = $body['titles'];
			$clean['titles'] = array();
			foreach ( array( 'separator', 'home_title', 'home_desc', 'archive_author', 'archive_date', 'archive_search', 'archive_404' ) as $field ) {
				if ( isset( $t[ $field ] ) ) {
					$clean['titles'][ $field ] = sanitize_text_field( (string) $t[ $field ] );
				}
			}
			if ( isset( $t['noindex_empty_archives'] ) ) {
				$clean['titles']['noindex_empty_archives'] = (bool) $t['noindex_empty_archives'];
			}
			foreach ( array( 'post_types', 'taxonomies' ) as $group ) {
				if ( isset( $t[ $group ] ) && is_array( $t[ $group ] ) ) {
					$clean['titles'][ $group ] = array();
					foreach ( $t[ $group ] as $slug => $tpl ) {
						$slug = sanitize_key( (string) $slug );
						$clean['titles'][ $group ][ $slug ] = array(
							'title'   => sanitize_text_field( (string) ( $tpl['title'] ?? '' ) ),
							'desc'    => sanitize_text_field( (string) ( $tpl['desc'] ?? '' ) ),
							'noindex' => ! empty( $tpl['noindex'] ),
						);
					}
				}
			}
		}

		if ( isset( $body['schema'] ) && is_array( $body['schema'] ) ) {
			$s = $body['schema'];
			$clean['schema'] = array(
				'site_type' => in_array( $s['site_type'] ?? '', array( 'organization', 'person' ), true ) ? $s['site_type'] : 'organization',
				'name'      => sanitize_text_field( (string) ( $s['name'] ?? '' ) ),
				'logo'      => esc_url_raw( (string) ( $s['logo'] ?? '' ) ),
				'social'    => sanitize_text_field( (string) ( $s['social'] ?? '' ) ),
			);
		}

		if ( isset( $body['sitemap'] ) && is_array( $body['sitemap'] ) ) {
			$s = $body['sitemap'];
			$clean['sitemap'] = array(
				'per_page' => isset( $s['per_page'] ) ? max( 100, min( 5000, (int) $s['per_page'] ) ) : 1000,
				'indexnow' => ! empty( $s['indexnow'] ),
			);
			foreach ( array( 'post_types', 'taxonomies' ) as $group ) {
				if ( isset( $s[ $group ] ) && is_array( $s[ $group ] ) ) {
					$clean['sitemap'][ $group ] = array();
					foreach ( $s[ $group ] as $slug => $on ) {
						$clean['sitemap'][ $group ][ sanitize_key( (string) $slug ) ] = (bool) $on;
					}
				}
			}
		}

		if ( isset( $body['llms'] ) && is_array( $body['llms'] ) ) {
			$l = $body['llms'];
			$clean['llms'] = array();
			if ( isset( $l['enabled'] ) ) {
				$clean['llms']['enabled'] = (bool) $l['enabled'];
			}
			if ( isset( $l['content'] ) ) {
				// Markdown: strip tags/scripts but keep line breaks and symbols.
				$clean['llms']['content'] = wp_strip_all_tags( (string) wp_unslash( $l['content'] ) );
			}
		}

		if ( isset( $body['codes'] ) && is_array( $body['codes'] ) ) {
			$c = $body['codes'];
			$clean['codes'] = array();
			if ( isset( $c['ga4_id'] ) ) {
				$ga = strtoupper( sanitize_text_field( (string) $c['ga4_id'] ) );
				$clean['codes']['ga4_id'] = preg_match( '/^(G|UA|AW|GT)-[A-Z0-9-]+$/', $ga ) || '' === $ga ? $ga : '';
			}
			if ( isset( $c['adsense_client'] ) ) {
				$ads = strtolower( sanitize_text_field( (string) $c['adsense_client'] ) );
				$clean['codes']['adsense_client'] = preg_match( '/^(ca-)?pub-\d{6,}$/', $ads ) || '' === $ads ? $ads : '';
			}
			foreach ( array( 'head_code', 'footer_code' ) as $field ) {
				if ( isset( $c[ $field ] ) ) {
					$raw = (string) wp_unslash( $c[ $field ] );
					// Script tags allowed only for users who may post unfiltered HTML.
					$clean['codes'][ $field ] = current_user_can( 'unfiltered_html' ) ? $raw : wp_kses_post( $raw );
				}
			}
		}

		if ( isset( $body['webmasters'] ) && is_array( $body['webmasters'] ) ) {
			$clean['webmasters'] = array();
			require_once SNAP_PLUGIN_DIR . 'includes/modules/core/class-webmasters.php';
			foreach ( array_keys( Snap_Webmasters::ENGINES ) as $engine ) {
				if ( isset( $body['webmasters'][ $engine ] ) ) {
					$clean['webmasters'][ $engine ] = Snap_Webmasters::sanitize_code( (string) $body['webmasters'][ $engine ] );
				}
			}
		}

		if ( isset( $body['business'] ) && is_array( $body['business'] ) ) {
			$clean['business'] = array();
			foreach ( array( 'name', 'owner', 'tagline', 'purpose' ) as $field ) {
				if ( isset( $body['business'][ $field ] ) ) {
					$clean['business'][ $field ] = sanitize_text_field( (string) $body['business'][ $field ] );
				}
			}
		}

		if ( isset( $body['site_type'] ) ) {
			$clean['site_type'] = in_array( $body['site_type'], array( 'blog', 'business', 'shop' ), true ) ? $body['site_type'] : '';
		}

		if ( isset( $body['redirections'] ) && is_array( $body['redirections'] ) ) {
			$clean['redirections'] = array();
			if ( isset( $body['redirections']['auto_deleted'] ) ) {
				$clean['redirections']['auto_deleted'] = (bool) $body['redirections']['auto_deleted'];
			}
		}

		if ( isset( $body['image_seo'] ) && is_array( $body['image_seo'] ) ) {
			$clean['image_seo'] = array();
			foreach ( array( 'clean_filenames', 'auto_alt_on_upload', 'redirect_attachments' ) as $field ) {
				if ( isset( $body['image_seo'][ $field ] ) ) {
					$clean['image_seo'][ $field ] = (bool) $body['image_seo'][ $field ];
				}
			}
		}

		if ( isset( $body['breadcrumbs'] ) && is_array( $body['breadcrumbs'] ) ) {
			$clean['breadcrumbs'] = array();
			if ( isset( $body['breadcrumbs']['separator'] ) ) {
				$clean['breadcrumbs']['separator'] = sanitize_text_field( (string) $body['breadcrumbs']['separator'] );
			}
		}

		if ( ! empty( $clean ) ) {
			$settings->update( $clean );
		}

		return $this->get_settings();
	}

	public function toggle_module( WP_REST_Request $request ) {
		$module = sanitize_key( (string) $request->get_param( 'module' ) );
		$state  = (bool) $request->get_param( 'state' );
		$loader = Snap_Module_Loader::instance();

		if ( ! $loader->exists( $module ) ) {
			return new WP_Error( 'snap_unknown_module', __( 'Unknown module.', 'snaplevel' ), array( 'status' => 404 ) );
		}
		if ( $loader->is_always_on( $module ) ) {
			return new WP_Error( 'snap_module_locked', __( 'This module cannot be disabled.', 'snaplevel' ), array( 'status' => 400 ) );
		}

		Snap_Settings::instance()->set( 'modules.' . $module, $state );
		return rest_ensure_response( array( 'module' => $module, 'state' => $state ) );
	}

	// ── AI ────────────────────────────────────────────────────────────────────

	public function test_ai( WP_REST_Request $request ) {
		$provider_id = (string) $request->get_param( 'provider' );
		if ( ! in_array( $provider_id, Snap_Settings::providers(), true ) ) {
			$provider_id = (string) Snap_Settings::instance()->get( 'ai.provider', 'anthropic' );
		}
		$key = sanitize_text_field( (string) $request->get_param( 'api_key' ) );

		$classes = array(
			'anthropic' => 'Snap_Provider_Anthropic',
			'openai'    => 'Snap_Provider_OpenAI',
			'gemini'    => 'Snap_Provider_Gemini',
			'deepseek'  => 'Snap_Provider_DeepSeek',
			'mistral'   => 'Snap_Provider_Mistral',
		);
		$class    = $classes[ $provider_id ] ?? 'Snap_Provider_Anthropic';
		$provider = new $class( $key );

		$result = $provider->test();
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Key works — persist it if a new one was sent, and switch to this provider.
		if ( '' !== $key ) {
			Snap_Settings::instance()->set_api_key( $key, $provider_id );
		}
		Snap_Settings::instance()->set( 'ai.provider', $provider_id );

		$names = array(
			'anthropic' => __( 'Claude is ready.', 'snaplevel' ),
			'openai'    => __( 'ChatGPT is ready.', 'snaplevel' ),
			'gemini'    => __( 'Gemini is ready.', 'snaplevel' ),
			'deepseek'  => __( 'DeepSeek is ready.', 'snaplevel' ),
			'mistral'   => __( 'Mistral is ready.', 'snaplevel' ),
		);
		return rest_ensure_response( array( 'ok' => true, 'message' => __( 'Connection successful.', 'snaplevel' ) . ' ' . ( $names[ $provider_id ] ?? '' ) ) );
	}

	public function generate( WP_REST_Request $request ) {
		$task    = sanitize_key( (string) $request->get_param( 'task' ) );
		$post_id = (int) $request->get_param( 'post_id' );
		$context = $request->get_param( 'context' );
		$context = is_array( $context ) ? $context : array();

		if ( $post_id > 0 ) {
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return new WP_Error( 'snap_forbidden', __( 'You cannot edit this post.', 'snaplevel' ), array( 'status' => 403 ) );
			}
			$post = get_post( $post_id );
			if ( $post ) {
				$context['post_id']      = $post_id;
				$context['post_title']   = $post->post_title;
				$context['post_type']    = $post->post_type;
				$context['post_excerpt'] = $post->post_excerpt;
				$context['permalink']    = (string) get_permalink( $post );
				if ( empty( $context['content'] ) ) {
					$context['content'] = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
				}
			}
		}

		$result = Snap_AI::generate( $task, $context );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( $result );
	}

	public function usage(): WP_REST_Response {
		return rest_ensure_response( Snap_AI_Usage::summary() );
	}

	// ── AI Training ───────────────────────────────────────────────────────────

	public function training_list(): WP_REST_Response {
		return rest_ensure_response( array(
			'docs'  => Snap_AI_Training::all(),
			'total' => Snap_AI_Training::total_chars(),
			'limit' => Snap_AI_Training::TOTAL_LIMIT,
		) );
	}

	public function training_save( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$body = is_array( $body ) ? $body : array();

		$result = Snap_AI_Training::save(
			(int) ( $body['id'] ?? 0 ),
			(string) ( $body['title'] ?? '' ),
			(string) ( $body['content'] ?? '' ),
			(int) ( $body['priority'] ?? 5 )
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $this->training_list();
	}

	public function training_delete( WP_REST_Request $request ): WP_REST_Response {
		Snap_AI_Training::delete( (int) $request->get_param( 'id' ) );
		return $this->training_list();
	}

	/**
	 * AI Fix: batch-generate missing SEO titles + meta descriptions for
	 * published posts/pages. Called in a loop from the Site Audit page.
	 */
	public function ai_fix_meta() {
		$query = new WP_Query( array(
			'post_type'      => array( 'post', 'page' ),
			'post_status'    => 'publish',
			'posts_per_page' => 3,
			'meta_query'     => array(
				'relation' => 'OR',
				array( 'key' => '_snap_desc', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_snap_desc', 'value' => '', 'compare' => '=' ),
			),
		) );

		$fixed = array();
		foreach ( $query->posts as $post ) {
			$ctx = array(
				'post_id'    => $post->ID,
				'post_title' => $post->post_title,
				'post_type'  => $post->post_type,
				'permalink'  => (string) get_permalink( $post ),
				'content'    => wp_strip_all_tags( strip_shortcodes( $post->post_content ) ),
			);

			$desc = Snap_AI::generate( 'meta_description', $ctx );
			if ( is_wp_error( $desc ) ) {
				return $desc;
			}
			if ( ! empty( $desc['data']['options'][0] ) ) {
				update_post_meta( $post->ID, '_snap_desc', sanitize_text_field( (string) $desc['data']['options'][0] ) );
			}

			if ( '' === (string) get_post_meta( $post->ID, '_snap_title', true ) ) {
				$title = Snap_AI::generate( 'seo_title', $ctx );
				if ( ! is_wp_error( $title ) && ! empty( $title['data']['options'][0] ) ) {
					update_post_meta( $post->ID, '_snap_title', sanitize_text_field( (string) $title['data']['options'][0] ) );
				}
			}

			$fixed[] = array( 'id' => $post->ID, 'title' => $post->post_title );
		}

		$remaining = max( 0, (int) $query->found_posts - count( $fixed ) );

		return rest_ensure_response( array(
			'fixed'     => $fixed,
			'remaining' => $remaining,
			'done'      => 0 === $remaining || empty( $fixed ),
		) );
	}

	/** Generate llms.txt content with AI from the site's pages + training. */
	public function llms_generate() {
		require_once SNAP_PLUGIN_DIR . 'includes/modules/llms-txt/class-llms-txt.php';

		$result = Snap_AI::generate( 'llms_txt', Snap_LLMS_Txt::site_context(), array( 'skip_cache' => true ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$content = isset( $result['data']['content'] ) ? (string) $result['data']['content'] : '';
		if ( '' === trim( $content ) ) {
			return new WP_Error( 'snap_llms_empty', __( 'AI returned no content. Try again.', 'snaplevel' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response( array( 'content' => $content ) );
	}

	/** Pull the latest SEO updates from official sources right now. */
	public function training_self_update() {
		if ( ! class_exists( 'Snap_AI_Self_Training' ) ) {
			return new WP_Error( 'snap_no_self_training', __( 'Self-training module not loaded.', 'snaplevel' ), array( 'status' => 500 ) );
		}
		$result = Snap_AI_Self_Training::refresh();
		if ( empty( $result['ok'] ) ) {
			return new WP_Error( 'snap_self_training_failed', $result['message'], array( 'status' => 500 ) );
		}
		return rest_ensure_response( $result );
	}

	// ── Import ────────────────────────────────────────────────────────────────

	private function load_importers(): void {
		require_once SNAP_PLUGIN_DIR . 'includes/modules/importers/class-importer-yoast.php';
		require_once SNAP_PLUGIN_DIR . 'includes/modules/importers/class-importer-rankmath.php';
		require_once SNAP_PLUGIN_DIR . 'includes/modules/importers/class-importer-extra.php';
	}

	public function import_detect(): WP_REST_Response {
		$this->load_importers();
		return rest_ensure_response( array_merge(
			array(
				'yoast'    => Snap_Importer_Yoast::detect(),
				'rankmath' => Snap_Importer_RankMath::detect(),
			),
			Snap_Importer_Extra::detect_all()
		) );
	}

	public function import_run( WP_REST_Request $request ) {
		$this->load_importers();
		$source = (string) $request->get_param( 'source' );
		$offset = max( 0, (int) $request->get_param( 'offset' ) );

		if ( 'yoast' === $source ) {
			$result = Snap_Importer_Yoast::run_batch( $offset, 200 );
		} elseif ( 'rankmath' === $source ) {
			$result = Snap_Importer_RankMath::run_batch( $offset, 200 );
		} else {
			$result = Snap_Importer_Extra::run_batch( $source, $offset, 200 );
		}

		return rest_ensure_response( $result );
	}

	// ── Audit: fix internal links that point at redirects ─────────────────────

	/**
	 * Batch fixer: finds internal <a href> links in published content that
	 * 301/302/308-redirect, and rewrites them to the final URL. This clears
	 * the "Pages Linking to Redirects" and "Sitemap 3XX" audit findings and
	 * stops link-equity loss. 5 posts per call so it never times out.
	 */
	public function audit_fix_links( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;
		$offset = max( 0, (int) $request->get_param( 'offset' ) );
		$batch  = 5;

		$total = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts}
			 WHERE post_status = 'publish' AND post_type NOT IN ('attachment','revision','nav_menu_item')
			 AND post_content LIKE '%href=%'"
		);
		$posts = $wpdb->get_results( $wpdb->prepare(
			"SELECT ID, post_content FROM {$wpdb->posts}
			 WHERE post_status = 'publish' AND post_type NOT IN ('attachment','revision','nav_menu_item')
			 AND post_content LIKE '%href=%'
			 ORDER BY ID ASC LIMIT %d OFFSET %d",
			$batch,
			$offset
		), ARRAY_A );

		$home_host   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$fixed_links = 0;
		$cache       = get_transient( 'snap_fixlinks_cache' );
		$cache       = is_array( $cache ) ? $cache : array();

		foreach ( (array) $posts as $row ) {
			$content = (string) $row['post_content'];
			if ( ! preg_match_all( '~href=["\']([^"\']+)["\']~i', $content, $m ) ) {
				continue;
			}
			$updated = $content;
			foreach ( array_unique( $m[1] ) as $url ) {
				$abs = 0 === strpos( $url, '/' ) ? home_url( $url ) : $url;
				if ( 0 !== strpos( $abs, 'http' ) || wp_parse_url( $abs, PHP_URL_HOST ) !== $home_host ) {
					continue; // Internal links only.
				}
				$key = md5( $abs );
				if ( ! array_key_exists( $key, $cache ) ) {
					$response = wp_remote_head( $abs, array( 'timeout' => 6, 'redirection' => 0 ) );
					$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
					$location = (string) wp_remote_retrieve_header( $response, 'location' );
					$cache[ $key ] = ( in_array( $code, array( 301, 302, 308 ), true ) && '' !== $location
						&& wp_parse_url( $location, PHP_URL_HOST ) === $home_host )
						? $location
						: '';
				}
				if ( '' !== $cache[ $key ] && $cache[ $key ] !== $url ) {
					$updated = str_replace( 'href="' . $url . '"', 'href="' . esc_url_raw( $cache[ $key ] ) . '"', $updated );
					$updated = str_replace( "href='" . $url . "'", "href='" . esc_url_raw( $cache[ $key ] ) . "'", $updated );
					$fixed_links++;
				}
			}
			if ( $updated !== $content ) {
				wp_update_post( array( 'ID' => (int) $row['ID'], 'post_content' => $updated ) );
			}
		}
		set_transient( 'snap_fixlinks_cache', $cache, HOUR_IN_SECONDS );

		$scanned = count( (array) $posts );
		return rest_ensure_response( array(
			'done'        => ( $offset + $scanned ) >= $total || 0 === $scanned,
			'next_offset' => $offset + $scanned,
			'total'       => $total,
			'fixed_links' => $fixed_links,
		) );
	}

	// ── Tools: export / import / reset ────────────────────────────────────────

	/** Export all settings as JSON (API keys excluded — they never leave the site). */
	public function tools_export(): WP_REST_Response {
		$data = Snap_Settings::instance()->all();
		unset( $data['ai']['api_key'], $data['ai']['api_key_openai'], $data['ai']['api_key_gemini'], $data['ai']['api_key_deepseek'], $data['ai']['api_key_mistral'] );
		return rest_ensure_response( array(
			'plugin'   => 'snaplevel',
			'version'  => SNAP_VERSION,
			'exported' => gmdate( 'c' ),
			'settings' => $data,
		) );
	}

	/** Import settings from a previous export. Runs through the same sanitizer as saves. */
	public function tools_import( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) || empty( $body['settings'] ) || ! is_array( $body['settings'] ) || 'snaplevel' !== ( $body['plugin'] ?? '' ) ) {
			return new WP_Error( 'snap_bad_import', __( 'This is not a valid Snaplevel export file.', 'snaplevel' ), array( 'status' => 400 ) );
		}
		$incoming = $body['settings'];
		// Never import key material, even if someone hand-edited the file.
		unset( $incoming['ai']['api_key'], $incoming['ai']['api_key_openai'], $incoming['ai']['api_key_gemini'], $incoming['ai']['api_key_deepseek'], $incoming['ai']['api_key_mistral'] );

		$inner = new WP_REST_Request( 'POST', '/' . self::NS . '/settings' );
		$inner->set_body( (string) wp_json_encode( $incoming ) );
		$inner->set_header( 'Content-Type', 'application/json' );
		$this->save_settings( $inner );

		// Module toggles import directly (booleans only).
		if ( isset( $incoming['modules'] ) && is_array( $incoming['modules'] ) ) {
			foreach ( $incoming['modules'] as $module_id => $on ) {
				$module_id = sanitize_key( (string) $module_id );
				if ( Snap_Module_Loader::instance()->exists( $module_id ) && ! Snap_Module_Loader::instance()->is_always_on( $module_id ) ) {
					Snap_Settings::instance()->set( 'modules.' . $module_id, (bool) $on );
				}
			}
		}

		return rest_ensure_response( array( 'ok' => true, 'message' => __( 'Settings imported.', 'snaplevel' ) ) );
	}

	/** Reset all settings to defaults. Keeps post meta and AI training data. */
	public function tools_reset(): WP_REST_Response {
		delete_option( Snap_Settings::OPTION );
		return rest_ensure_response( array( 'ok' => true, 'message' => __( 'Settings reset to defaults. Post SEO data and AI training were kept.', 'snaplevel' ) ) );
	}

	// ── Wizard ────────────────────────────────────────────────────────────────

	public function get_wizard(): WP_REST_Response {
		return rest_ensure_response( array(
			'wizard'    => Snap_Settings::instance()->get( 'wizard', array( 'step' => 0, 'done' => false ) ),
			'site_type' => Snap_Settings::instance()->get( 'site_type', '' ),
			'provider'  => Snap_Settings::instance()->get( 'ai.provider', 'anthropic' ),
			'hasKey'    => '' !== Snap_Settings::instance()->get_api_key(),
		) );
	}

	public function save_wizard( WP_REST_Request $request ): WP_REST_Response {
		$body = $request->get_json_params();
		$body = is_array( $body ) ? $body : array();

		$wizard = array(
			'step' => isset( $body['step'] ) ? max( 0, min( 6, (int) $body['step'] ) ) : 0,
			'done' => ! empty( $body['done'] ),
		);
		Snap_Settings::instance()->set( 'wizard', $wizard );

		if ( $wizard['done'] ) {
			update_option( 'snap_wizard_done', 1 );
			delete_option( 'snap_show_wizard_redirect' );
		}
		if ( ! empty( $body['skipped'] ) ) {
			update_option( 'snap_wizard_skipped', 1 );
			delete_option( 'snap_show_wizard_redirect' );
		}

		return $this->get_wizard();
	}

	// ── Wizard Quick Scan ────────────────────────────────────────────────────

	public function wizard_quick_scan(): WP_REST_Response {
		global $wpdb;

		$posts_count  = (int) wp_count_posts( 'post' )->publish + (int) wp_count_posts( 'page' )->publish;
		$missing_meta = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts} p
			 WHERE p.post_status = 'publish' AND p.post_type IN ('post','page')
			 AND NOT EXISTS (
				 SELECT 1 FROM {$wpdb->postmeta} m
				 WHERE m.post_id = p.ID AND m.meta_key = '_snap_desc' AND m.meta_value != ''
			 )"
		);
		$missing_alt = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts} p
			 WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%'
			 AND NOT EXISTS (
				 SELECT 1 FROM {$wpdb->postmeta} m
				 WHERE m.post_id = p.ID AND m.meta_key = '_wp_attachment_image_alt' AND m.meta_value != ''
			 )"
		);

		// Most recent published post for the live demo.
		$sample = get_posts( array(
			'post_type'      => array( 'post', 'page' ),
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );
		$sample_post = null;
		if ( ! empty( $sample ) ) {
			$sample_post = array(
				'id'    => $sample[0]->ID,
				'title' => $sample[0]->post_title,
			);
		}

		// Detect existing SEO plugin data for import.
		$detected_plugin = null;
		if ( get_option( 'wpseo_titles' ) ) {
			$detected_plugin = 'yoast';
		} elseif ( get_option( 'rank-math-options-general' ) ) {
			$detected_plugin = 'rankmath';
		} elseif ( get_option( 'aioseo_options' ) ) {
			$detected_plugin = 'aioseo';
		}

		return rest_ensure_response( array(
			'posts_count'      => $posts_count,
			'missing_meta'     => $missing_meta,
			'missing_alt'      => $missing_alt,
			'sample_post'      => $sample_post,
			'detected_plugin'  => $detected_plugin,
		) );
	}

	// ── Copilot Analyze ──────────────────────────────────────────────────────

	public function copilot_analyze( WP_REST_Request $request ): WP_REST_Response {
		$post_id = (int) $request->get_param( 'post_id' );
		$post    = get_post( $post_id );

		if ( ! $post ) {
			return new WP_REST_Response( array( 'error' => 'Post not found.' ), 404 );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_REST_Response( array( 'error' => 'Permission denied.' ), 403 );
		}

		$result = Snap_Copilot::analyze( $post );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'error' => $result->get_error_message() ), 500 );
		}

		// Cache the result in post meta.
		update_post_meta( $post_id, '_snap_copilot_analysis', wp_json_encode( $result['data'] ) );
		update_post_meta( $post_id, '_snap_copilot_hash', md5( $post->post_title . $post->post_content ) );
		update_post_meta( $post_id, '_snap_copilot_time', time() );

		return rest_ensure_response( array(
			'analysis' => $result['data'],
			'cached'   => $result['cached'] ?? false,
			'model'    => $result['model'] ?? '',
		) );
	}
}
