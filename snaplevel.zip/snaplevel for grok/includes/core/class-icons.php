<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Icons — inline SVG icon set (24x24 stroke icons, MIT/CC0 shapes).
 *
 * Usage: Snap_Icons::get( 'image' )            → svg string
 *        Snap_Icons::e( 'image', 'snap-anim-pulse' ) → echoes wrapped icon
 *
 * Every icon inherits currentColor so CSS controls the tint.
 * Optional loop animations: snap-anim-spin | pulse | bounce | glow.
 */
final class Snap_Icons {

	/** @return string[] raw inner SVG per icon id */
	private static function paths(): array {
		return array(
			// Media / compression
			'image'      => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
			'compress'   => '<path d="M8 3v3a2 2 0 0 1-2 2H3"/><path d="M21 8h-3a2 2 0 0 1-2-2V3"/><path d="M3 16h3a2 2 0 0 1 2 2v3"/><path d="M16 21v-3a2 2 0 0 1 2-2h3"/>',
			'broom'      => '<path d="M19 21l-7-7 2-9 3 3 4-4"/><path d="M5 21h8l-6-6-2 6z"/>',
			// SEO / analysis
			'chart'      => '<path d="M3 3v18h18"/><path d="M7 15l4-6 3 4 5-8"/>',
			'gauge'      => '<path d="M12 15l4-7"/><path d="M3.3 14a9 9 0 1 1 17.4 0"/>',
			'search'     => '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>',
			'target'     => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
			'link'       => '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
			'sitemap'    => '<rect x="9" y="2" width="6" height="5" rx="1"/><rect x="2" y="17" width="6" height="5" rx="1"/><rect x="16" y="17" width="6" height="5" rx="1"/><path d="M12 7v4m0 0H5v6m7-6h7v6"/>',
			'schema'     => '<path d="M7 8l-4 4 4 4"/><path d="M17 8l4 4-4 4"/><path d="M14 4l-4 16"/>',
			'globe'      => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14.5 14.5 0 0 1 0 18 14.5 14.5 0 0 1 0-18z"/>',
			'redirect'   => '<path d="M15 4h6v6"/><path d="M21 4l-8 8-4-4-6 6"/>',
			// AI
			'sparkle'    => '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15z"/>',
			'brain'      => '<path d="M9.5 2a2.5 2.5 0 0 0-2.5 2.5v.55A3.5 3.5 0 0 0 4 8.5c0 .64.17 1.23.47 1.74A3.5 3.5 0 0 0 3 13.5 3.5 3.5 0 0 0 6.5 17H7v1.5A2.5 2.5 0 0 0 9.5 21h.5V2h-.5z"/><path d="M14.5 2a2.5 2.5 0 0 1 2.5 2.5v.55A3.5 3.5 0 0 1 20 8.5c0 .64-.17 1.23-.47 1.74A3.5 3.5 0 0 1 21 13.5 3.5 3.5 0 0 1 17.5 17H17v1.5a2.5 2.5 0 0 1-2.5 2.5H14V2h.5z"/>',
			'zap'        => '<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>',
			'robot'      => '<rect x="4" y="8" width="16" height="12" rx="2"/><path d="M12 8V4m0 0h3M9 13v2m6-2v2"/><circle cx="12" cy="3" r="1"/>',
			// UI / actions
			'grid'       => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
			'settings'   => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
			'refresh'    => '<path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
			'import'     => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>',
			'trash'      => '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6m4-6v6"/>',
			'check'      => '<path d="M20 6L9 17l-5-5"/>',
			'check-circle' => '<circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-6"/>',
			'x'          => '<path d="M18 6L6 18M6 6l12 12"/>',
			'alert'      => '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4m0 4h.01"/>',
			'info'       => '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4m0-4h.01"/>',
			'help'       => '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
			'external'   => '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14L21 3"/>',
			'eye'        => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
			'wand'       => '<path d="M15 4V2m0 14v-2M8 9h2m10 0h2m-4.2-4.2L19 3.6m-1.2 9.2l1.4 1.2M3 21l9-9"/><path d="M12.2 6.2L11 5"/>',
			'home'       => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
			'user'       => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
			'users'      => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
			'file'       => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
			'file-text'  => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8m8 4H8m2-8H8"/>',
			'pin'        => '<path d="M12 2a8 8 0 0 0-8 8c0 5.4 7 11.5 7.35 11.8a1 1 0 0 0 1.3 0C13 21.5 20 15.4 20 10a8 8 0 0 0-8-8z"/><circle cx="12" cy="10" r="3"/>',
			'tag'        => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><path d="M7 7h.01"/>',
			'folder'     => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
			'cart'       => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
			'clock'      => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
			'download'   => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>',
			'upload'     => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v12"/>',
			'rocket'     => '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
			'shield'     => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
			'list'       => '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
			'edit'       => '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
			'feed'       => '<path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="20" r="1"/>',
			'book'       => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
			'play'       => '<circle cx="12" cy="12" r="10"/><path d="M10 8l6 4-6 4V8z"/>',
			'bars'       => '<rect x="3" y="13" width="4.6" height="8" rx="1.4"/><rect x="9.7" y="8.5" width="4.6" height="12.5" rx="1.4"/><rect x="16.4" y="3" width="4.6" height="18" rx="1.4"/>',
		);
	}

	/**
	 * Get an icon SVG.
	 *
	 * @param string $id    Icon id.
	 * @param int    $size  Pixel size.
	 * @param string $class Extra classes on the <svg> (e.g. snap-anim-pulse).
	 */
	public static function get( string $id, int $size = 24, string $class = '' ): string {
		$paths = self::paths();
		if ( ! isset( $paths[ $id ] ) ) {
			$id = 'grid';
		}
		$fill   = 'bars' === $id ? 'currentColor' : 'none';
		$stroke = 'bars' === $id ? 'none' : 'currentColor';
		return sprintf(
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="%1$d" height="%1$d" fill="%2$s" stroke="%3$s" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="%4$s" aria-hidden="true" focusable="false">%5$s</svg>',
			$size,
			$fill,
			$stroke,
			esc_attr( $class ),
			$paths[ $id ]
		);
	}

	/** Echo an icon wrapped in .snap-icon. */
	public static function e( string $id, int $size = 24, string $class = '', string $wrap_class = '' ): void {
		echo '<span class="snap-icon ' . esc_attr( $wrap_class ) . '">' . self::get( $id, $size, $class ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/** Full map for JS (settings app renders icons client-side). */
	public static function js_map(): array {
		$out = array();
		foreach ( array_keys( self::paths() ) as $id ) {
			$out[ $id ] = self::get( $id, 18 );
		}
		return $out;
	}
}
