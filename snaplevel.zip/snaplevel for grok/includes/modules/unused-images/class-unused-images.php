<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Detects which images in the Media Library are not referenced anywhere on
 * the site, then lets admins safely trash them one-by-one or in bulk.
 *
 * Safety-first design:
 *  - Always TRASH (not delete), so images can be recovered.
 *  - Before every trash operation the image is re-verified as unused.
 *  - Checks: post content, featured images, post meta (ACF, Elementor, WC),
 *    theme mods (custom logo, header), options (site icon), attached parents.
 *
 * PHP 7.4 compatible.
 */
class ICW_Unused_Images {

    public function __construct() {
        add_action( 'wp_ajax_icw_scan_unused',      array( $this, 'ajax_scan'  ) );
        add_action( 'wp_ajax_icw_trash_one_unused', array( $this, 'ajax_trash' ) );
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Return the IDs of every image attachment that cannot be found in any
     * post content, meta, option, or theme-mod reference.
     *
     * @return int[]
     */
    public static function get_unused_ids(): array {
        global $wpdb;

        // All live image attachments
        $all_ids = array_map( 'intval', (array) $wpdb->get_col(
            "SELECT ID FROM {$wpdb->posts}
              WHERE post_type   = 'attachment'
                AND post_status = 'inherit'
                AND post_mime_type IN ('image/jpeg','image/png','image/gif','image/webp')
              ORDER BY ID ASC"
        ) );

        if ( empty( $all_ids ) ) {
            return array();
        }

        $used = self::collect_used_ids( $all_ids );
        return array_values( array_diff( $all_ids, $used ) );
    }

    /**
     * Return rich data for a slice of unused IDs (for the admin table).
     *
     * @param int[] $unused_ids Full list returned by get_unused_ids().
     * @param int   $offset
     * @param int   $limit
     * @return array[]
     */
    public static function build_items( array $unused_ids, int $offset = 0, int $limit = 24 ): array {
        $slice = array_slice( $unused_ids, $offset, $limit );
        $items = array();

        foreach ( $slice as $id ) {
            $path      = get_attached_file( $id );
            $filesize  = ( $path && file_exists( $path ) ) ? size_format( (int) @filesize( $path ) ) : '—';
            $thumb     = wp_get_attachment_image_url( $id, 'thumbnail' );
            $full_url  = wp_get_attachment_url( $id );

            $items[] = array(
                'id'       => $id,
                'title'    => get_the_title( $id ) ?: basename( (string) $path ),
                'thumb'    => $thumb ? $thumb : '',
                'url'      => $full_url ? $full_url : '',
                'filesize' => $filesize,
                'date'     => get_the_date( 'M j, Y', $id ),
                'mime'     => get_post_mime_type( $id ),
            );
        }

        return $items;
    }

    // ── AJAX handlers ─────────────────────────────────────────────────────────

    public function ajax_scan(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        if ( ! current_user_can( 'delete_posts' ) ) {
            wp_send_json_error( 'Permission denied.' );
        }

        $offset     = max( 0, (int) ( isset( $_POST['offset'] ) ? $_POST['offset'] : 0 ) );
        $limit      = min( 48, max( 1, (int) ( isset( $_POST['limit'] ) ? $_POST['limit'] : 24 ) ) );
        $unused_ids = self::get_unused_ids();
        $total      = count( $unused_ids );
        $items      = self::build_items( $unused_ids, $offset, $limit );

        wp_send_json_success( array(
            'total'      => $total,
            'offset'     => $offset,
            'items'      => $items,
            'unused_ids' => $unused_ids, // full list so JS can do bulk
        ) );
    }

    public function ajax_trash(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        if ( ! current_user_can( 'delete_posts' ) ) {
            wp_send_json_error( 'Permission denied.' );
        }

        $id = (int) ( isset( $_POST['attachment_id'] ) ? $_POST['attachment_id'] : 0 );
        if ( $id <= 0 ) {
            wp_send_json_error( 'Invalid ID.' );
        }

        // Re-verify the image is still unused right before trashing
        $used = self::collect_used_ids( array( $id ) );
        if ( in_array( $id, $used, true ) ) {
            wp_send_json_error( 'Image is referenced in content — skipped for safety.' );
        }

        $result = wp_trash_post( $id );
        if ( $result ) {
            wp_send_json_success( array( 'trashed' => $id ) );
        } else {
            wp_send_json_error( 'Could not trash image.' );
        }
    }

    // ── Core detection ────────────────────────────────────────────────────────

    /**
     * Build the complete set of attachment IDs that ARE referenced somewhere.
     * Errs on the side of caution: anything ambiguous is marked as "used".
     *
     * @param int[] $candidate_ids IDs to check (usually all image IDs).
     * @return int[]
     */
    private static function collect_used_ids( array $candidate_ids ): array {
        global $wpdb;

        if ( empty( $candidate_ids ) ) {
            return array();
        }

        $used = array();

        // ── 1. Featured images ─────────────────────────────────────────────────
        $thumb_ids = $wpdb->get_col(
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta}
              WHERE meta_key = '_thumbnail_id' AND meta_value != ''"
        );
        foreach ( $thumb_ids as $v ) {
            if ( is_numeric( $v ) ) {
                $used[] = (int) $v;
            }
        }

        // ── 2. Post content: wp-image-{id} CSS class ──────────────────────────
        $contents = (array) $wpdb->get_col(
            "SELECT post_content FROM {$wpdb->posts}
              WHERE post_status NOT IN ('trash','auto-draft')
                AND post_type   NOT IN ('attachment','revision')"
        );

        $upload_dir  = wp_upload_dir();
        $uploads_url = rtrim( $upload_dir['baseurl'], '/' );

        foreach ( $contents as $content ) {
            if ( ! $content ) {
                continue;
            }
            // wp-image-{id} — WordPress adds this class to every inserted image block
            if ( preg_match_all( '/wp-image-(\d+)/i', $content, $m ) ) {
                foreach ( $m[1] as $v ) {
                    $used[] = (int) $v;
                }
            }
            // [gallery ids="..."]
            if ( preg_match_all( '/\[gallery[^\]]+ids=["\']([0-9,\s]+)["\']/', $content, $m ) ) {
                foreach ( $m[1] as $list ) {
                    foreach ( array_filter( explode( ',', $list ) ) as $v ) {
                        if ( is_numeric( trim( $v ) ) ) {
                            $used[] = (int) trim( $v );
                        }
                    }
                }
            }
            // Image URLs within the uploads folder
            $escaped_url = preg_quote( $uploads_url, '/' );
            if ( preg_match_all( '/' . $escaped_url . '\/[^\s"\'<>]+\.(jpe?g|png|gif|webp)/i', $content, $m ) ) {
                foreach ( $m[0] as $url ) {
                    $id = self::url_to_id( $url );
                    if ( $id ) {
                        $used[] = $id;
                    }
                }
            }
        }

        // ── 3. Attachments whose post_parent != 0 (attached to a post) ────────
        $ids_in = implode( ',', $candidate_ids );
        $attached = (array) $wpdb->get_col(
            "SELECT ID FROM {$wpdb->posts}
              WHERE post_type = 'attachment'
                AND post_parent != 0
                AND ID IN ({$ids_in})"
        );
        foreach ( $attached as $v ) {
            $used[] = (int) $v;
        }

        // ── 4. Post meta with exact numeric ID match (ACF image, etc.) ────────
        $meta_ids = (array) $wpdb->get_col(
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta}
              WHERE meta_key != '_thumbnail_id'
                AND meta_value IN ({$ids_in})"
        );
        foreach ( $meta_ids as $v ) {
            if ( is_numeric( $v ) ) {
                $used[] = (int) $v;
            }
        }

        // ── 5. Rich meta: Elementor, WooCommerce gallery, ACF repeater ────────
        // Fetch known page-builder / gallery meta keys and regex-search for IDs.
        $rich_keys = array(
            '_elementor_data',
            '_elementor_page_settings',
            '_product_image_gallery',
        );
        $keys_placeholder = implode( ',', array_fill( 0, count( $rich_keys ), '%s' ) );
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $rich_values = (array) $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key IN ({$keys_placeholder}) AND meta_value != ''",
                ...$rich_keys
            )
        );

        $candidates_set = array_flip( $candidate_ids ); // O(1) lookup
        foreach ( $rich_values as $val ) {
            if ( ! $val ) {
                continue;
            }
            if ( preg_match_all( '/\b(\d{1,10})\b/', $val, $m ) ) {
                foreach ( $m[1] as $v ) {
                    $v = (int) $v;
                    if ( isset( $candidates_set[ $v ] ) ) {
                        $used[] = $v;
                    }
                }
            }
        }

        // ── 6. Theme mods & WordPress options ─────────────────────────────────
        $logo_id = (int) get_theme_mod( 'custom_logo', 0 );
        if ( $logo_id ) {
            $used[] = $logo_id;
        }
        $site_icon = (int) get_option( 'site_icon', 0 );
        if ( $site_icon ) {
            $used[] = $site_icon;
        }
        $site_logo = (int) get_option( 'site_logo', 0 );
        if ( $site_logo ) {
            $used[] = $site_logo;
        }

        $header_url = get_theme_mod( 'header_image', '' );
        if ( $header_url ) {
            $id = self::url_to_id( (string) $header_url );
            if ( $id ) {
                $used[] = $id;
            }
        }

        return array_unique( array_filter( array_map( 'intval', $used ) ) );
    }

    /**
     * Resolve a uploads-relative URL to an attachment ID via post meta.
     * Much faster than attachment_url_to_postid() — no extra queries per URL.
     */
    private static function url_to_id( string $url ): int {
        global $wpdb;

        $upload_dir = wp_upload_dir();
        $base_url   = rtrim( $upload_dir['baseurl'], '/' );
        $base_dir   = rtrim( $upload_dir['basedir'], '/' );

        // Strip query string and WebP variant
        $url = strtok( $url, '?' );
        $url = (string) preg_replace( '/\.webp$/i', '', $url );

        if ( strpos( $url, $base_url ) === false ) {
            return 0;
        }

        $rel  = ltrim( str_replace( $base_url, '', $url ), '/' );
        $file = basename( $rel );

        $id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta}
                  WHERE meta_key   = '_wp_attached_file'
                    AND meta_value LIKE %s
                  LIMIT 1",
                '%' . $wpdb->esc_like( $file )
            )
        );

        return $id;
    }
}
