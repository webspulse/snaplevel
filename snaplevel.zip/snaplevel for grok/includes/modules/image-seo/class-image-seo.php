<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Image_SEO — upload-time image SEO.
 *
 * - Clean SEO filenames on upload (lowercase, hyphens, no accents).
 * - Auto-set alt text, title and caption from the filename on upload.
 * - Redirect attachment pages to their parent post (thin-content fix).
 * - Lazy-loading is left to WordPress core (loading="lazy" since 5.5).
 */
final class Snap_Image_SEO {

	public function __construct() {
		$s = Snap_Settings::instance();

		if ( $s->get( 'image_seo.clean_filenames', true ) ) {
			add_filter( 'sanitize_file_name', array( $this, 'clean_filename' ), 20 );
		}
		if ( $s->get( 'image_seo.auto_alt_on_upload', true ) ) {
			add_action( 'add_attachment', array( $this, 'auto_meta_on_upload' ) );
		}
		if ( $s->get( 'image_seo.redirect_attachments', true ) ) {
			add_action( 'template_redirect', array( $this, 'redirect_attachment_pages' ), 2 );
		}
	}

	/** SEO filename: transliterate, lowercase, hyphens, deduped. */
	public function clean_filename( string $filename ): string {
		$info = pathinfo( $filename );
		$ext  = isset( $info['extension'] ) ? '.' . strtolower( $info['extension'] ) : '';
		$name = $info['filename'] ?? $filename;

		$name = remove_accents( $name );
		$name = strtolower( $name );
		$name = (string) preg_replace( '/[^a-z0-9]+/', '-', $name );
		$name = trim( (string) preg_replace( '/-{2,}/', '-', $name ), '-' );

		return ( '' !== $name ? $name : 'image' ) . $ext;
	}

	/** Derive readable alt/title from the filename for new image uploads. */
	public function auto_meta_on_upload( int $attachment_id ): void {
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return;
		}
		if ( '' !== (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) {
			return;
		}

		$file  = (string) get_post_meta( $attachment_id, '_wp_attached_file', true );
		$name  = pathinfo( $file, PATHINFO_FILENAME );
		$label = ucfirst( trim( (string) preg_replace( '/[-_]+/', ' ', (string) preg_replace( '/-(scaled|\d+x\d+|e\d+)$/', '', $name ) ) ) );
		if ( '' === $label || preg_match( '/^(img|image|dsc|screenshot|photo|untitled)[ \d]*$/i', $label ) ) {
			return; // Camera junk names make bad alt text.
		}

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', $label );

		$post = get_post( $attachment_id );
		if ( $post instanceof WP_Post && ( '' === $post->post_title || $post->post_title === $name ) ) {
			wp_update_post( array( 'ID' => $attachment_id, 'post_title' => $label ) );
		}
	}

	/** Attachment pages are thin content — send visitors to the parent or file. */
	public function redirect_attachment_pages(): void {
		if ( ! is_attachment() ) {
			return;
		}
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		$target = $post->post_parent ? (string) get_permalink( $post->post_parent ) : (string) wp_get_attachment_url( $post->ID );
		if ( '' === $target ) {
			$target = home_url( '/' );
		}
		wp_safe_redirect( $target, 301 );
		exit;
	}

	// ── Stats for the Image SEO screen ────────────────────────────────────────

	public static function stats(): array {
		global $wpdb;
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%'" );
		$with_alt = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_attachment_image_alt' AND m.meta_value != ''
			 WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%'"
		);
		$webp = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_icw_compressed' OR meta_key = '_icw_webp_path'"
		);
		return array(
			'total'    => $total,
			'with_alt' => $with_alt,
			'no_alt'   => max( 0, $total - $with_alt ),
			'webp'     => $webp,
		);
	}
}
