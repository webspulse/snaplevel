<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_LLMS_Txt — serves a real /llms.txt at the site root.
 *
 * The llms.txt standard is a Markdown "recommended reading list" for AI
 * crawlers (ChatGPT, Claude, Perplexity, Gemini). Content is edited in
 * Snaplevel → Settings → LLMs.txt, or generated with AI from the site's
 * pages, sitemap and the AI Training knowledge base.
 *
 * Served via parse_request interception — no rewrite flush needed.
 */
final class Snap_LLMS_Txt {

	public function __construct() {
		add_action( 'parse_request', array( $this, 'maybe_serve' ), 0 );
	}

	public function maybe_serve(): void {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		$path = untrailingslashit( (string) strtok( $uri, '?' ) );
		if ( '' === $path || '/llms.txt' !== substr( $path, -9 ) ) {
			return;
		}

		$settings = Snap_Settings::instance();
		if ( ! $settings->get( 'llms.enabled', true ) ) {
			return;
		}

		$content = (string) $settings->get( 'llms.content', '' );
		if ( '' === trim( $content ) ) {
			$content = self::default_content();
		}

		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo $content; // phpcs:ignore WordPress.Security.EscapeOutput -- plain text file.
		exit;
	}

	/** Fallback content when the user has not written/generated anything yet. */
	public static function default_content(): string {
		$name = get_bloginfo( 'name' );
		$desc = get_bloginfo( 'description' );
		$out  = '# ' . $name . "\n\n";
		if ( '' !== $desc ) {
			$out .= '> ' . $desc . "\n\n";
		}
		$out .= "## Key Pages\n";
		foreach ( self::top_pages( 15 ) as $page ) {
			$out .= '* [' . $page['title'] . '](' . $page['url'] . ')' . ( '' !== $page['summary'] ? ': ' . $page['summary'] : '' ) . "\n";
		}
		$out .= "\n## Sitemap\n* [" . home_url( '/sitemap_index.xml' ) . '](' . home_url( '/sitemap_index.xml' ) . ")\n";
		return $out;
	}

	/** @return array[] title, url, summary for the most important content. */
	public static function top_pages( int $limit = 30 ): array {
		$posts = get_posts( array(
			'post_type'      => array( 'page', 'post' ),
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'orderby'        => 'menu_order date',
			'order'          => 'ASC',
		) );

		$out = array();
		foreach ( $posts as $p ) {
			$summary = '' !== $p->post_excerpt
				? $p->post_excerpt
				: wp_trim_words( wp_strip_all_tags( strip_shortcodes( $p->post_content ) ), 22, '…' );
			$out[] = array(
				'title'   => wp_strip_all_tags( get_the_title( $p ) ),
				'url'     => (string) get_permalink( $p ),
				'type'    => $p->post_type,
				'summary' => wp_strip_all_tags( $summary ),
			);
		}
		return $out;
	}

	/** Context handed to the AI generator. */
	public static function site_context(): array {
		return array(
			'site_name'    => get_bloginfo( 'name' ),
			'site_tagline' => get_bloginfo( 'description' ),
			'home_url'     => home_url( '/' ),
			'sitemap_url'  => home_url( '/sitemap_index.xml' ),
			'pages'        => self::top_pages( 30 ),
		);
	}
}
