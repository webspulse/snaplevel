<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Schema_Module — structured data (JSON-LD only, never microdata).
 *
 * Site level: Organization or Person + WebSite with SearchAction.
 * Post level: AI-generated JSON-LD stored in _snap_schema, output in <head>.
 * AI detects the right type (a recipe post gets Recipe, not Article).
 */
final class Snap_Schema_Module {

	public function __construct() {
		add_action( 'init', array( $this, 'register_meta' ), 20 );

		if ( ! is_admin() ) {
			add_action( 'wp_head', array( $this, 'output' ), 5 );
		}
	}

	public function id(): string {
		return 'schema';
	}

	public function name(): string {
		return __( 'Schema', 'snaplevel' );
	}

	public function register_meta(): void {
		$types = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'] );

		foreach ( $types as $post_type ) {
			register_post_meta( $post_type, '_snap_schema', array(
				'show_in_rest'      => true,
				'single'            => true,
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => array( __CLASS__, 'sanitize_schema' ),
				'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
			) );
		}
	}

	/** Only store valid JSON objects. */
	public static function sanitize_schema( $value ): string {
		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return '';
		}
		$decoded = json_decode( $value, true );
		if ( ! is_array( $decoded ) || empty( $decoded['@type'] ) ) {
			return '';
		}
		if ( empty( $decoded['@context'] ) ) {
			$decoded['@context'] = 'https://schema.org';
		}
		return (string) wp_json_encode( $decoded );
	}

	// ── Output ────────────────────────────────────────────────────────────────

	public function output(): void {
		$graphs = array();

		// Site-level schema on the front page.
		if ( is_front_page() || is_home() ) {
			$graphs = array_merge( $graphs, $this->site_graphs() );
		}

		// Post-level schema.
		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				$json = (string) get_post_meta( $post->ID, '_snap_schema', true );
				if ( '' !== $json ) {
					$decoded = json_decode( $json, true );
					if ( is_array( $decoded ) && ! empty( $decoded['@type'] ) ) {
						$graphs[] = $decoded;
					}
				}
			}
		}

		/**
		 * Filter the JSON-LD graphs before output.
		 *
		 * @param array $graphs
		 */
		$graphs = apply_filters( 'snaplevel_schema_graphs', $graphs );

		foreach ( $graphs as $graph ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $graph ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode escapes for script context.
		}
	}

	private function site_graphs(): array {
		$settings = Snap_Settings::instance();
		$graphs   = array();

		$name = (string) $settings->get( 'schema.name', '' );
		if ( '' === $name ) {
			$name = (string) get_bloginfo( 'name' );
		}

		$entity = array(
			'@context' => 'https://schema.org',
			'@type'    => 'person' === $settings->get( 'schema.site_type', 'organization' ) ? 'Person' : 'Organization',
			'@id'      => home_url( '/#site-entity' ),
			'name'     => $name,
			'url'      => home_url( '/' ),
		);

		$logo = (string) $settings->get( 'schema.logo', '' );
		if ( '' !== $logo ) {
			$entity['logo'] = $logo;
			$entity['image'] = $logo;
		}

		$social = (string) $settings->get( 'schema.social', '' );
		if ( '' !== $social ) {
			$profiles = array_filter( array_map( 'trim', explode( ',', $social ) ) );
			if ( ! empty( $profiles ) ) {
				$entity['sameAs'] = array_values( $profiles );
			}
		}

		$graphs[] = $entity;

		$graphs[] = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'@id'             => home_url( '/#website' ),
			'name'            => (string) get_bloginfo( 'name' ),
			'url'             => home_url( '/' ),
			'publisher'       => array( '@id' => home_url( '/#site-entity' ) ),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => array(
					'@type'       => 'EntryPoint',
					'urlTemplate' => home_url( '/?s={search_term_string}' ),
				),
				'query-input' => 'required name=search_term_string',
			),
		);

		return $graphs;
	}
}
