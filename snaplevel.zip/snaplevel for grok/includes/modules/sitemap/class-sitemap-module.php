<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Sitemap_Module — XML sitemap index + IndexNow ping.
 *
 * URLs:
 *   /sitemap_index.xml
 *   /{type}-sitemap.xml and /{type}-sitemap2.xml … (posts, pages, CPTs)
 *   /tax-{taxonomy}-sitemap.xml
 *   /{indexnow-key}.txt  (key file, served dynamically)
 *
 * Honors noindex (_snap_robots) and disables core WP sitemaps.
 */
final class Snap_Sitemap_Module {

	public function __construct() {
		// Disable WordPress core sitemaps while we're active.
		add_filter( 'wp_sitemaps_enabled', '__return_false' );

		add_action( 'init', array( $this, 'add_rewrites' ) );
		add_filter( 'query_vars', array( $this, 'query_vars' ) );
		add_action( 'template_redirect', array( $this, 'maybe_render' ), 0 );
		add_action( 'parse_request', array( $this, 'maybe_serve_indexnow_key' ) );

		if ( Snap_Settings::instance()->get( 'sitemap.indexnow', true ) ) {
			add_action( 'transition_post_status', array( $this, 'ping_indexnow' ), 20, 3 );
		}

		// Flush rewrites once after activation.
		if ( get_option( 'snap_flush_rewrites' ) ) {
			add_action( 'init', static function (): void {
				flush_rewrite_rules();
				delete_option( 'snap_flush_rewrites' );
			}, 99 );
		}
	}

	public function id(): string {
		return 'sitemap';
	}

	public function name(): string {
		return __( 'XML Sitemap', 'snaplevel' );
	}

	// ── Routing ───────────────────────────────────────────────────────────────

	public function add_rewrites(): void {
		add_rewrite_rule( '^sitemap_index\.xml$', 'index.php?snap_sitemap=index', 'top' );
		add_rewrite_rule( '^([a-z0-9_-]+?)-sitemap([0-9]*)\.xml$', 'index.php?snap_sitemap=$matches[1]&snap_sitemap_page=$matches[2]', 'top' );
	}

	public function query_vars( array $vars ): array {
		$vars[] = 'snap_sitemap';
		$vars[] = 'snap_sitemap_page';
		return $vars;
	}

	public function maybe_render(): void {
		$which = (string) get_query_var( 'snap_sitemap' );
		if ( '' === $which ) {
			return;
		}

		$page = max( 1, (int) get_query_var( 'snap_sitemap_page' ) ?: 1 );

		status_header( 200 );
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );

		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		echo '<?xml-stylesheet type="text/xsl" href="' . esc_url( home_url( '/snap-sitemap.xsl' ) ) . '"?>' . "\n";

		if ( 'index' === $which ) {
			$this->render_index();
		} elseif ( 0 === strpos( $which, 'tax-' ) ) {
			$this->render_taxonomy( substr( $which, 4 ) );
		} else {
			$this->render_post_type( $which, $page );
		}

		exit;
	}

	// ── Renderers ─────────────────────────────────────────────────────────────

	private function per_page(): int {
		return max( 100, min( 5000, (int) Snap_Settings::instance()->get( 'sitemap.per_page', 1000 ) ) );
	}

	private function post_types(): array {
		$types = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'] );
		// Per-type opt-out: sitemap.post_types is a slug => bool map; missing = included.
		$enabled = (array) Snap_Settings::instance()->get( 'sitemap.post_types', array() );
		$types   = array_filter( $types, static function ( $type ) use ( $enabled ) {
			return ! isset( $enabled[ $type ] ) || ! empty( $enabled[ $type ] );
		} );
		return array_values( $types );
	}

	private function taxonomies(): array {
		$taxes = get_taxonomies( array( 'public' => true ), 'names' );
		unset( $taxes['post_format'] );
		$enabled = (array) Snap_Settings::instance()->get( 'sitemap.taxonomies', array() );
		$taxes   = array_filter( $taxes, static function ( $tax ) use ( $enabled ) {
			return ! isset( $enabled[ $tax ] ) || ! empty( $enabled[ $tax ] );
		} );
		return array_values( $taxes );
	}

	private function render_index(): void {
		echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

		foreach ( $this->post_types() as $type ) {
			$total = $this->count_posts( $type );
			if ( 0 === $total ) {
				continue;
			}
			$pages = (int) ceil( $total / $this->per_page() );
			for ( $i = 1; $i <= $pages; $i++ ) {
				$suffix  = $i > 1 ? (string) $i : '';
				$lastmod = $this->last_modified( $type );
				echo "\t<sitemap>\n";
				echo "\t\t<loc>" . esc_url( home_url( "/{$type}-sitemap{$suffix}.xml" ) ) . "</loc>\n";
				if ( $lastmod ) {
					echo "\t\t<lastmod>" . esc_html( $lastmod ) . "</lastmod>\n";
				}
				echo "\t</sitemap>\n";
			}
		}

		foreach ( $this->taxonomies() as $tax ) {
			$count = (int) wp_count_terms( array( 'taxonomy' => $tax, 'hide_empty' => true ) );
			if ( $count > 0 ) {
				echo "\t<sitemap>\n";
				echo "\t\t<loc>" . esc_url( home_url( "/tax-{$tax}-sitemap.xml" ) ) . "</loc>\n";
				echo "\t</sitemap>\n";
			}
		}

		echo '</sitemapindex>';
	}

	private function render_post_type( string $type, int $page ): void {
		if ( ! in_array( $type, $this->post_types(), true ) ) {
			status_header( 404 );
			echo '<error>Unknown sitemap</error>';
			return;
		}

		$query = new WP_Query( array(
			'post_type'      => $type,
			'post_status'    => 'publish',
			'posts_per_page' => $this->per_page(),
			'paged'          => $page,
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'meta_query'     => array(
				'relation' => 'OR',
				array( 'key' => '_snap_robots', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_snap_robots', 'value' => 'noindex', 'compare' => 'NOT LIKE' ),
			),
			'no_found_rows'  => true,
		) );

		echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

		foreach ( $query->posts as $post ) {
			$loc = get_permalink( $post );
			if ( ! $loc ) {
				continue;
			}
			echo "\t<url>\n";
			echo "\t\t<loc>" . esc_url( (string) $loc ) . "</loc>\n";
			echo "\t\t<lastmod>" . esc_html( get_post_modified_time( 'c', true, $post ) ) . "</lastmod>\n";

			$thumb_id = get_post_thumbnail_id( $post );
			if ( $thumb_id ) {
				$img = wp_get_attachment_url( $thumb_id );
				if ( $img ) {
					echo "\t\t<image:image><image:loc>" . esc_url( $img ) . "</image:loc></image:image>\n";
				}
			}
			echo "\t</url>\n";
		}

		echo '</urlset>';
	}

	private function render_taxonomy( string $tax ): void {
		if ( ! in_array( $tax, $this->taxonomies(), true ) ) {
			status_header( 404 );
			echo '<error>Unknown sitemap</error>';
			return;
		}

		$noindex = (bool) Snap_Settings::instance()->get( 'titles.taxonomies.' . $tax . '.noindex', false );
		if ( $noindex ) {
			echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>';
			return;
		}

		$terms = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => true ) );

		echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$link = get_term_link( $term );
				if ( is_wp_error( $link ) ) {
					continue;
				}
				echo "\t<url>\n\t\t<loc>" . esc_url( (string) $link ) . "</loc>\n\t</url>\n";
			}
		}
		echo '</urlset>';
	}

	private function count_posts( string $type ): int {
		$counts = wp_count_posts( $type );
		return isset( $counts->publish ) ? (int) $counts->publish : 0;
	}

	private function last_modified( string $type ): string {
		$latest = get_posts( array(
			'post_type'      => $type,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'fields'         => 'ids',
		) );
		if ( empty( $latest ) ) {
			return '';
		}
		return (string) get_post_modified_time( 'c', true, $latest[0] );
	}

	// ── IndexNow ──────────────────────────────────────────────────────────────

	public static function indexnow_key(): string {
		$key = get_option( 'snap_indexnow_key', '' );
		if ( ! is_string( $key ) || 32 !== strlen( $key ) ) {
			$key = strtolower( wp_generate_password( 32, false, false ) );
			update_option( 'snap_indexnow_key', $key );
		}
		return $key;
	}

	/** Serve /{key}.txt so search engines can verify ownership, and the branded XSL. */
	public function maybe_serve_indexnow_key( $wp ): void {
		$request = isset( $wp->request ) ? (string) $wp->request : '';

		if ( 'snap-sitemap.xsl' === $request ) {
			status_header( 200 );
			header( 'Content-Type: text/xsl; charset=UTF-8' );
			echo self::xsl(); // phpcs:ignore WordPress.Security.EscapeOutput
			exit;
		}

		$key = self::indexnow_key();
		if ( $request === $key . '.txt' ) {
			status_header( 200 );
			header( 'Content-Type: text/plain; charset=UTF-8' );
			echo esc_html( $key );
			exit;
		}
	}

	/** Branded, human-readable sitemap stylesheet (index + urlset). */
	private static function xsl(): string {
		$title    = esc_html( get_bloginfo( 'name' ) );
		$css_href = esc_url( SNAP_PLUGIN_URL . 'assets/css/sitemap-xsl.css' );
		return '<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:s="http://www.sitemaps.org/schemas/sitemap/0.9"
	xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
<xsl:output method="html" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html><head><title>XML Sitemap — ' . $title . '</title>
<meta name="robots" content="noindex"/>
<link rel="stylesheet" href="' . $css_href . '"/>
</head>
<body>
<div class="head">
	<div class="mark"><svg width="22" height="22" viewBox="0 0 30.462 30.461" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M16.109,13.997l-4.312-4.479L1.426,20.058L0,18.656L11.812,6.651l4.354,4.522l7.49-7.172l-2.146-2.145h5.603v5.601 L25.07,5.415L16.109,13.997z M4.962,28.606h6.75v-9.5h-6.75V28.606z M14.337,28.606h6.75v-12.5h-6.75V28.606z M23.712,9.856v18.75 h6.75V9.856H23.712z"/></svg></div>
	<h1>' . $title . ' <small>— XML Sitemap by Snaplevel</small></h1>
</div>
<div class="wrap">
<div class="note">This sitemap is generated automatically so search engines like Google and Bing can find every page. You do not need to do anything with it.</div>
<xsl:choose>
<xsl:when test="s:sitemapindex">
	<table>
	<tr><th>Sitemap</th><th>Last updated</th></tr>
	<xsl:for-each select="s:sitemapindex/s:sitemap">
		<tr>
			<td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td>
			<td class="c"><xsl:value-of select="concat(substring(s:lastmod,1,10),\' \',substring(s:lastmod,12,5))"/></td>
		</tr>
	</xsl:for-each>
	</table>
</xsl:when>
<xsl:otherwise>
	<table>
	<tr><th>Page URL</th><th>Image</th><th>Last updated</th></tr>
	<xsl:for-each select="s:urlset/s:url">
		<tr>
			<td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td>
			<td class="c"><xsl:value-of select="count(image:image)"/></td>
			<td class="c"><xsl:value-of select="concat(substring(s:lastmod,1,10),\' \',substring(s:lastmod,12,5))"/></td>
		</tr>
	</xsl:for-each>
	</table>
</xsl:otherwise>
</xsl:choose>
</div>
</body></html>
</xsl:template>
</xsl:stylesheet>';
	}

	public function ping_indexnow( string $new_status, string $old_status, WP_Post $post ): void {
		if ( 'publish' !== $new_status ) {
			return;
		}
		if ( ! in_array( $post->post_type, $this->post_types(), true ) ) {
			return;
		}
		$robots = (string) get_post_meta( $post->ID, '_snap_robots', true );
		if ( false !== strpos( $robots, 'noindex' ) ) {
			return;
		}

		$url = get_permalink( $post );
		if ( ! $url ) {
			return;
		}

		wp_remote_post( 'https://api.indexnow.org/indexnow', array(
			'timeout'  => 5,
			'blocking' => false,
			'headers'  => array( 'Content-Type' => 'application/json; charset=utf-8' ),
			'body'     => wp_json_encode( array(
				'host'        => wp_parse_url( home_url(), PHP_URL_HOST ),
				'key'         => self::indexnow_key(),
				'keyLocation' => home_url( '/' . self::indexnow_key() . '.txt' ),
				'urlList'     => array( $url ),
			) ),
		) );
	}
}
