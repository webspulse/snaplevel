<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_SEO_Meta_Module — boots the SEO Meta module pieces and the
 * optional "auto mode" (generate meta on publish when fields are empty,
 * off by default, per-task opt-in).
 */
final class Snap_SEO_Meta_Module {

	public function __construct() {
		new Snap_Post_Meta();

		if ( ! is_admin() ) {
			new Snap_Meta_Output();
		}

		add_action( 'transition_post_status', array( $this, 'maybe_auto_generate' ), 10, 3 );
	}

	public function id(): string {
		return 'seo_meta';
	}

	public function name(): string {
		return __( 'SEO Meta', 'snaplevel' );
	}

	/**
	 * Auto mode: on publish, queue AI meta generation when fields are
	 * empty AND the user explicitly opted in for that task.
	 */
	public function maybe_auto_generate( string $new_status, string $old_status, WP_Post $post ): void {
		if ( 'publish' !== $new_status || 'publish' === $old_status ) {
			return;
		}
		if ( ! in_array( $post->post_type, Snap_Post_Meta::post_types(), true ) ) {
			return;
		}
		if ( '' === Snap_Settings::instance()->get_api_key() ) {
			return;
		}

		$content = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
		if ( '' === trim( $content ) ) {
			return;
		}

		$context = array(
			'post_id'       => $post->ID,
			'post_title'    => $post->post_title,
			'content'       => $content,
			'focus_keyword' => (string) get_post_meta( $post->ID, '_snap_focus_kw', true ),
		);

		if ( Snap_AI::auto_mode_enabled( 'seo_title' ) && '' === (string) get_post_meta( $post->ID, '_snap_title', true ) ) {
			Snap_AI_Queue::instance()->push( 'seo_title', $context, 'auto_publish' );
		}
		if ( Snap_AI::auto_mode_enabled( 'meta_description' ) && '' === (string) get_post_meta( $post->ID, '_snap_desc', true ) ) {
			Snap_AI_Queue::instance()->push( 'meta_description', $context, 'auto_publish' );
		}
	}
}

// Apply auto-publish results: first option wins, only if still empty.
add_action( 'snap_ai_job_complete', static function ( $job, $result ) {
	if ( 'auto_publish' !== ( $job['group'] ?? '' ) ) {
		return;
	}
	$post_id = (int) ( $job['context']['post_id'] ?? 0 );
	if ( $post_id <= 0 || empty( $result['data']['options'][0] ) ) {
		return;
	}
	$key = 'seo_title' === $job['task'] ? '_snap_title' : ( 'meta_description' === $job['task'] ? '_snap_desc' : '' );
	if ( '' === $key ) {
		return;
	}
	if ( '' === (string) get_post_meta( $post_id, $key, true ) ) {
		update_post_meta( $post_id, $key, sanitize_text_field( (string) $result['data']['options'][0] ) );
	}
}, 10, 2 );
