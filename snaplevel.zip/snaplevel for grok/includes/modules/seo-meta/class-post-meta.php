<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Post_Meta — registers _snap_* post meta (REST-exposed for the
 * Gutenberg sidebar) and the Classic Editor / WooCommerce metabox.
 *
 * Editor surfaces prioritize Copilot (AI opportunities as hero at top, calm
 * opportunity cards). Traditional score + checklist are secondary/collapsed.
 * Low-risk reorg for AI-assistant feel, not Rank Math clone.
 */
final class Snap_Post_Meta {

	const FIELDS = array(
		'_snap_title'            => array( 'type' => 'string', 'label' => 'SEO Title' ),
		'_snap_desc'             => array( 'type' => 'string', 'label' => 'Meta Description' ),
		'_snap_focus_kw'         => array( 'type' => 'string', 'label' => 'Focus Keyword' ),
		'_snap_robots'           => array( 'type' => 'string', 'label' => 'Robots Meta' ),
		'_snap_canonical'        => array( 'type' => 'string', 'label' => 'Canonical URL', 'sanitize' => 'url' ),
		// Social (Open Graph — Facebook, LinkedIn, WhatsApp, Threads).
		'_snap_og_title'         => array( 'type' => 'string', 'label' => 'Social Title' ),
		'_snap_og_desc'          => array( 'type' => 'string', 'label' => 'Social Description' ),
		'_snap_og_image'         => array( 'type' => 'string', 'label' => 'Social Image', 'sanitize' => 'url' ),
		// Social (X / Twitter).
		'_snap_tw_title'         => array( 'type' => 'string', 'label' => 'X Title' ),
		'_snap_tw_desc'          => array( 'type' => 'string', 'label' => 'X Description' ),
		'_snap_tw_image'         => array( 'type' => 'string', 'label' => 'X Image', 'sanitize' => 'url' ),
		'_snap_tw_card'          => array( 'type' => 'string', 'label' => 'X Card Type' ),
		// Advanced.
		'_snap_breadcrumb_title' => array( 'type' => 'string', 'label' => 'Breadcrumb Title' ),
	);

	public function __construct() {
		add_action( 'init', array( $this, 'register_meta' ), 20 );
		add_action( 'add_meta_boxes', array( $this, 'add_metabox' ), 10, 2 );
		add_action( 'save_post', array( $this, 'save_metabox' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'metabox_assets' ) );
	}

	public static function post_types(): array {
		$types = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'] );
		return array_values( $types );
	}

	public function register_meta(): void {
		foreach ( self::post_types() as $post_type ) {
			foreach ( self::FIELDS as $key => $def ) {
				register_post_meta( $post_type, $key, array(
					'show_in_rest'      => true,
					'single'            => true,
					'type'              => 'string',
					'default'           => '',
					'sanitize_callback' => ( isset( $def['sanitize'] ) && 'url' === $def['sanitize'] ) ? 'esc_url_raw' : 'sanitize_text_field',
					'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
						return current_user_can( 'edit_post', $post_id );
					},
				) );
			}
		}
	}

	public function metabox_assets( string $hook ): void {
		if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
			return;
		}
		// Always available on edit screens: covers Classic Editor, Elementor,
		// WooCommerce products, and any CPT regardless of editor.
		wp_enqueue_style( 'snap-design-system' );
		wp_enqueue_media(); // Social image pickers (metabox + Gutenberg sidebar).
	}

	// ── Classic Editor / Elementor / WooCommerce / CPT metabox ───────────────

	/**
	 * Add the metabox for every public post type EXCEPT when the block
	 * editor is actually used for the specific post being edited (the
	 * Gutenberg sidebar handles that case). Checking per-post instead of
	 * per-type keeps compatibility with the Classic Editor plugin's
	 * per-post switch, Elementor, and CPTs without REST support.
	 */
	public function add_metabox( string $post_type = '', $post = null ): void {
		if ( '' === $post_type || ! in_array( $post_type, self::post_types(), true ) ) {
			return;
		}
		if ( $post instanceof WP_Post && function_exists( 'use_block_editor_for_post' ) && use_block_editor_for_post( $post ) ) {
			return; // Gutenberg gets the sidebar.
		}
		if ( ! ( $post instanceof WP_Post ) && use_block_editor_for_post_type( $post_type ) ) {
			return;
		}
		add_meta_box( 'snap-seo-meta', __( 'Snaplevel SEO', 'snaplevel' ), array( $this, 'render_metabox' ), $post_type, 'normal', 'high' );
		add_meta_box( 'snap-seo-side', __( 'Signals — Snaplevel', 'snaplevel' ), array( $this, 'render_side_metabox' ), $post_type, 'side', 'high' );
	}

	/** Compact sidebar box (classic editor) — live-synced with the main metabox. Secondary signals only. */
	public function render_side_metabox(): void {
		?>
		<div style="background: var(--snap-bg-card); border: 1px solid var(--snap-border-light); border-radius: 8px; padding: 10px 12px; text-align: center;">
			<div style="font-size: 10px; font-weight: 600; color: var(--snap-text-secondary); margin-bottom: 4px;">SNAPLEVEL SEO</div>
			<span class="snap-score-pill" id="snap-side-score" style="border-radius: 999px; width: 92px; font-size: 12px; height: 28px; line-height: 28px;">— / 100</span>
			<div class="snap-progress" style="height: 4px; margin: 8px 8px 6px; background: var(--snap-border-light);">
				<div class="snap-progress-bar" id="snap-side-bar" style="width:0%; transition: width .4s ease, background .4s ease;"></div>
			</div>
			<a href="#snap-seo-meta" class="snap-btn snap-btn-ai-soft snap-btn-sm" style="margin-top: 6px; font-size: 11px;"
				onclick="document.getElementById('snap-seo-meta').scrollIntoView({behavior:'smooth'});return false;">
				✦ <?php esc_html_e( 'Open full panel', 'snaplevel' ); ?>
			</a>
		</div>
		<?php
	}

	public function render_metabox( WP_Post $post ): void {
		wp_nonce_field( 'snap_meta_save', 'snap_meta_nonce' );

		$title  = (string) get_post_meta( $post->ID, '_snap_title', true );
		$desc   = (string) get_post_meta( $post->ID, '_snap_desc', true );
		$kw     = (string) get_post_meta( $post->ID, '_snap_focus_kw', true );
		$robots = (string) get_post_meta( $post->ID, '_snap_robots', true );
		$canon  = (string) get_post_meta( $post->ID, '_snap_canonical', true );
		$schema = (string) get_post_meta( $post->ID, '_snap_schema', true );

		$og_title  = (string) get_post_meta( $post->ID, '_snap_og_title', true );
		$og_desc   = (string) get_post_meta( $post->ID, '_snap_og_desc', true );
		$og_image  = (string) get_post_meta( $post->ID, '_snap_og_image', true );
		$tw_title  = (string) get_post_meta( $post->ID, '_snap_tw_title', true );
		$tw_desc   = (string) get_post_meta( $post->ID, '_snap_tw_desc', true );
		$tw_image  = (string) get_post_meta( $post->ID, '_snap_tw_image', true );
		$tw_card   = (string) get_post_meta( $post->ID, '_snap_tw_card', true );
		$bc_title  = (string) get_post_meta( $post->ID, '_snap_breadcrumb_title', true );

		$robots_directives = array_filter( array_map( 'trim', explode( ',', $robots ) ) );
		$featured          = get_the_post_thumbnail_url( $post, 'large' );
		$fallback_image    = $og_image ?: ( $featured ?: '' );

		$has_key     = '' !== Snap_Settings::instance()->get_api_key();
		$schema_type = '';
		if ( '' !== $schema ) {
			$decoded     = json_decode( $schema, true );
			$schema_type = is_array( $decoded ) && ! empty( $decoded['@type'] ) ? (string) $decoded['@type'] : '';
		}
		?>
		<?php
		$is_builder_context = isset( $_GET['context'] ) && $_GET['context'] === 'builder';
		$is_popup = isset( $_GET['page'] ) && $_GET['page'] === 'snap-seo-popup';
		?>

		<div class="snap-metabox snap-shell<?php echo $is_builder_context ? ' is-builder' : ''; ?>" data-post-id="<?php echo esc_attr( (string) $post->ID ); ?>">

			<?php if ( ! $is_popup ) : ?>
			<!-- Branded header for classic editor metabox only (popup provides its own top bar to avoid double branding) -->
			<div class="snap-metabox-header">
				<img src="<?php echo esc_url( SNAP_PLUGIN_URL . 'assets/images/icon.svg' ); ?>" alt="" class="snap-metabox-brand-icon">
				<strong class="snap-metabox-brand">Snaplevel SEO</strong>
				<span class="snap-muted snap-metabox-post-title">— <?php echo esc_html( mb_strimwidth( get_the_title( $post ) ?: '(no title)', 0, 40, '…' ) ); ?></span>
			</div>
			<?php endif; ?>

			<!-- Easy AI Quick Optimize row (makes the metabox much more powerful and easier than before) -->
			<?php if ( $has_key ) : ?>
				<div class="snap-ai-quick-row" style="display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap;">
					<button type="button" class="snap-btn snap-btn-ai snap-btn-sm" id="snap-quick-title" data-task="seo_title" data-target="snap_title">✦ Title</button>
					<button type="button" class="snap-btn snap-btn-ai snap-btn-sm" id="snap-quick-desc" data-task="meta_description" data-target="snap_desc">✦ Description</button>
					<button type="button" class="snap-btn snap-btn-ai snap-btn-sm" id="snap-quick-kw" data-task="focus_keywords" data-target="snap_focus_kw">✦ Keywords</button>
					<button type="button" class="snap-btn snap-btn-ai" id="snap-fix-all" style="margin-left:auto; font-size:12px;">⚡ Fix All with AI</button>
				</div>
			<?php endif; ?>

			<?php if ( ! $is_builder_context ) : ?>
			<!-- AI Analyzer integrated into classic metabox for advanced live insights (new advanced feature for easier use) -->
			<div class="snap-builder-ai-analyzer" style="margin-bottom:14px; background:#fff; border:1px solid var(--snap-border-light); border-radius:8px; padding:10px 12px; font-size:12px;">
				<div style="display:flex; align-items:center; gap:6px; margin-bottom:8px; font-weight:600;">
					<?php Snap_Icons::e('target', 14); ?> AI ANALYZER — LIVE
				</div>
				<?php
				// Self-contained safe analyzer for classic metabox
				$title_val = (string) get_post_meta( $post->ID, '_snap_title', true );
				$desc_val  = (string) get_post_meta( $post->ID, '_snap_desc', true );
				$kw_val    = (string) get_post_meta( $post->ID, '_snap_focus_kw', true );
				$content_len = strlen( wp_strip_all_tags( $post->post_content ?? '' ) );

				$ai_issues = [];
				if ( trim($title_val) === '' ) {
					$ai_issues[] = ['sev' => 'high', 't' => 'SEO Title missing', 'd' => 'Biggest miss for rankings & clicks.', 'btn' => 'Generate Title', 'id' => 'snap_title'];
				} elseif ( strlen($title_val) < 45 || strlen($title_val) > 62 ) {
					$ai_issues[] = ['sev' => 'med', 't' => 'Title length not ideal', 'd' => 'Best 50-60 chars.', 'btn' => 'Optimize Title', 'id' => 'snap_title'];
				}
				if ( trim($desc_val) === '' ) {
					$ai_issues[] = ['sev' => 'high', 't' => 'Meta description missing', 'd' => 'Let AI create one from your training.', 'btn' => 'Generate Description', 'id' => 'snap_desc'];
				}
				if ( trim($kw_val) === '' ) {
					$ai_issues[] = ['sev' => 'med', 't' => 'Focus keyword not set', 'd' => 'AI needs a target topic.', 'btn' => 'Suggest Keywords', 'id' => 'snap_focus_kw'];
				}
				if ( $content_len > 0 && $content_len < 650 ) {
					$ai_issues[] = ['sev' => 'med', 't' => 'Content is quite short', 'd' => $content_len . ' chars — add depth.', 'btn' => 'Improve with AI', 'id' => 'snap_desc'];
				}

				if ( empty($ai_issues) ) {
					echo '<div style="padding:6px 8px; background:#e6f4ea; color:#1e8e3e; border-radius:4px;">✅ Core fields look good.</div>';
				} else {
					foreach ($ai_issues as $i) {
						$color = $i['sev'] === 'high' ? '#d93025' : '#f9ab00';
						echo '<div style="display:flex; gap:8px; padding:5px 0; border-bottom:1px solid #f1f3f4;">';
						echo '<div style="width:4px; background:' . $color . '; border-radius:2px; margin:2px 0;"></div>';
						echo '<div style="flex:1;">';
						echo '<div style="font-weight:600;">' . esc_html($i['t']) . '</div>';
						echo '<div style="font-size:11px; color:#5f6368; margin:1px 0 4px;">' . esc_html($i['d']) . '</div>';
						echo '<button type="button" class="snap-btn snap-btn-ai-soft snap-btn-sm" style="font-size:10px; padding:1px 6px;" onclick="var f=document.getElementById(\'' . esc_js($i['id']) . '\'); if(f){f.focus(); f.scrollIntoView({block:\'center\', behavior:\'smooth\'});}">✦ ' . esc_html($i['btn']) . '</button>';
						echo '</div></div>';
					}
				}
				?>
			</div>
			<?php endif; ?>

			<!-- Horizontal 47px tabs (spec 7.1) -->
			<div class="snap-metabox-tabs" role="tablist">
				<button type="button" class="snap-mtab is-active" data-pane="general"><?php esc_html_e( 'General', 'snaplevel' ); ?></button>
				<button type="button" class="snap-mtab" data-pane="social"><?php esc_html_e( 'Social', 'snaplevel' ); ?></button>
				<button type="button" class="snap-mtab snap-advanced-option" data-pane="advanced"><?php esc_html_e( 'Advanced', 'snaplevel' ); ?></button>
				<button type="button" class="snap-mtab" data-pane="schema"><?php esc_html_e( 'Schema', 'snaplevel' ); ?></button>
			</div>

			<!-- General: fields left, live preview right -->
			<div class="snap-metabox-pane is-active" data-pane-content="general">
			<div class="snap-mb-cols">
			<div class="snap-mb-main">

				<!-- Copilot hero (primary, AI assistant first). Traditional score/checklist made secondary below. -->
				<?php if ( $has_key ) : ?>
					<div id="snap-mb-copilot" class="snap-copilot-panel" style="margin-bottom:16px;border-bottom:1px solid var(--snap-border-subtle, #e5e7eb);padding-bottom:12px;">
						<div class="snap-copilot-header" style="padding:4px 0 8px;">
							<span style="font-weight:700;font-size:14px;color:#4338CA;">✦ <?php esc_html_e( 'Copilot', 'snaplevel' ); ?></span>
						</div>
						<p style="margin:0 0 10px;font-size:12px;color:#4b5563;"><?php esc_html_e( 'AI scans your post and lists concrete opportunities with direct fixes.', 'snaplevel' ); ?></p>
						<button type="button" class="snap-btn snap-btn-ai" id="snap-copilot-analyze" style="width:100%;justify-content:center;">✦ <?php esc_html_e( 'Find AI opportunities', 'snaplevel' ); ?></button>
						<div id="snap-copilot-results" style="margin-top:10px;"></div>
					</div>
				<?php endif; ?>

				<?php if ( $has_key ) : ?>
					<p>
						<button type="button" class="snap-btn snap-btn-ai" id="snap-fix-all">⚡ <?php esc_html_e( 'Fix with AI — keyword, title & description', 'snaplevel' ); ?></button>
						<span id="snap-fix-status" class="snap-muted" style="margin-left:8px;"></span>
					</p>
				<?php else : ?>
					<p class="snap-notice snap-notice-info" style="margin-top:0;">
						<?php esc_html_e( 'Connect AI (Claude, ChatGPT, Gemini, DeepSeek, or Mistral) in Snaplevel → Settings to unlock one-click AI for every field below.', 'snaplevel' ); ?>
					</p>
				<?php endif; ?>

				<div class="snap-field">
					<label for="snap_focus_kw"><?php esc_html_e( 'Focus Keyword', 'snaplevel' ); ?></label>
					<input type="text" id="snap_focus_kw" name="_snap_focus_kw" value="<?php echo esc_attr( $kw ); ?>" class="snap-input">
					<?php if ( $has_key ) : ?>
						<p style="margin:8px 0 0;"><button type="button" class="snap-btn snap-btn-ai-soft snap-btn-sm snap-ai-btn" data-task="focus_keywords" data-target="snap_focus_kw">✦ <?php esc_html_e( 'Suggest keywords', 'snaplevel' ); ?></button></p>
						<div class="snap-ai-options" data-options-for="snap_focus_kw"></div>
					<?php endif; ?>
				</div>

				<div class="snap-field">
					<label for="snap_title"><?php esc_html_e( 'SEO Title', 'snaplevel' ); ?> <span class="snap-muted" style="font-weight:400;font-size:12px;">(<?php esc_html_e( 'best: 50–60 characters, keyword near the start', 'snaplevel' ); ?>)</span></label>
					<input type="text" id="snap_title" name="_snap_title" value="<?php echo esc_attr( $title ); ?>" class="snap-input" maxlength="100">
					<div style="max-width:450px;margin-top:5px;">
						<div class="snap-progress" style="height:5px;"><div class="snap-progress-bar" id="snap-title-bar" style="width:0%;"></div></div>
						<div class="snap-help" id="snap-title-count" style="margin-top:3px;">0 / 60</div>
					</div>
					<?php if ( $has_key ) : ?>
						<p style="margin:8px 0 0;"><button type="button" class="snap-btn snap-btn-ai-soft snap-btn-sm snap-ai-btn" data-task="seo_title" data-target="snap_title">✦ <?php esc_html_e( 'Generate title', 'snaplevel' ); ?></button></p>
						<div class="snap-ai-options" data-options-for="snap_title"></div>
					<?php endif; ?>
				</div>

				<div class="snap-field">
					<label for="snap_slug"><?php esc_html_e( 'URL Slug', 'snaplevel' ); ?> <span class="snap-muted" style="font-weight:400;font-size:12px;">(<?php esc_html_e( 'short, keyword-rich, hyphens between words', 'snaplevel' ); ?>)</span></label>
					<input type="text" id="snap_slug" name="snap_slug" value="<?php echo esc_attr( $post->post_name ); ?>" class="snap-input" style="max-width:450px;">
					<div class="snap-help" id="snap-slug-preview" style="margin-top:4px;word-break:break-all;"></div>
				</div>

				<div class="snap-field">
					<label for="snap_desc"><?php esc_html_e( 'Meta Description', 'snaplevel' ); ?> <span class="snap-muted" style="font-weight:400;font-size:12px;">(<?php esc_html_e( 'best: 120–156 characters, active voice, keyword once', 'snaplevel' ); ?>)</span></label>
					<textarea id="snap_desc" name="_snap_desc" class="snap-textarea" rows="3" maxlength="320" style="max-width:720px;"><?php echo esc_textarea( $desc ); ?></textarea>
					<div style="max-width:720px;margin-top:5px;">
						<div class="snap-progress" style="height:5px;"><div class="snap-progress-bar" id="snap-desc-bar" style="width:0%;"></div></div>
						<div class="snap-help" id="snap-desc-count" style="margin-top:3px;">0 / 156</div>
					</div>
					<?php if ( $has_key ) : ?>
						<p style="margin:8px 0 0;"><button type="button" class="snap-btn snap-btn-ai-soft snap-btn-sm snap-ai-btn" data-task="meta_description" data-target="snap_desc">✦ <?php esc_html_e( 'Generate description', 'snaplevel' ); ?></button></p>
						<div class="snap-ai-options" data-options-for="snap_desc"></div>
					<?php endif; ?>
				</div>

				<!-- Traditional checklist: now SECONDARY / optional (collapsed by default). Copilot (AI opportunities) is the primary hero above. -->
				<details class="snap-checklist-group" style="max-width:720px;opacity:0.7;">
					<summary class="snap-checklist-head" style="cursor:pointer;list-style:none;">
						<span><?php esc_html_e( 'Traditional SEO checklist (optional)', 'snaplevel' ); ?></span>
						<span class="snap-mini-score" id="snap-mb-mini">0/7</span>
					</summary>
					<ul class="snap-checklist-items" id="snap-mb-checks" style="margin:0;"></ul>
				</details>
			</div><!-- /.snap-mb-main -->

			<!-- Right rail: live Google preview + score -->
			<div class="snap-mb-side">
				<div class="snap-mb-side-sticky">
					<div style="font-weight:600;margin-bottom:8px;"><?php esc_html_e( 'Google Preview', 'snaplevel' ); ?></div>
					<div class="snap-serp snap-serp-card" style="margin-bottom:0;">
						<?php if ( $featured ) : ?>
							<div class="snap-serp-thumb" style="height:150px;border-radius:10px 10px 0 0;background:#F3F4F6 url(<?php echo esc_url( $featured ); ?>) center/cover no-repeat;margin:-14px -16px 12px;"></div>
						<?php endif; ?>
						<div class="snap-serp-url" id="snap-mb-url"><?php echo esc_html( (string) get_permalink( $post ) ); ?></div>
						<div class="snap-serp-title" id="snap-mb-ptitle"></div>
						<div class="snap-serp-desc" id="snap-mb-pdesc"></div>
					</div>
					<div style="text-align:center;margin-top:16px;">
						<div style="font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'SEO Score', 'snaplevel' ); ?></div>
						<span class="snap-score-pill" id="snap-mb-score" style="border-radius:7px;">—</span>
					</div>
				</div>
			</div>
			</div><!-- /.snap-mb-cols -->
			</div>

			<!-- Social (Open Graph + X) -->
			<div class="snap-metabox-pane" data-pane-content="social">

				<label class="snap-social-inherit" style="display:flex;align-items:center;gap:8px;margin:0 0 16px;cursor:pointer;">
					<input type="checkbox" id="snap-social-inherit" <?php checked( '' === $og_title && '' === $og_desc ); ?>>
					<span><?php esc_html_e( 'Use SEO title & description from the General tab', 'snaplevel' ); ?></span>
				</label>

				<div class="snap-social-grid" style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start;">

					<!-- Facebook / Open Graph -->
					<div style="flex:1;min-width:320px;">
						<div style="font-weight:600;margin-bottom:10px;"><?php esc_html_e( 'Facebook · LinkedIn · WhatsApp (Open Graph)', 'snaplevel' ); ?></div>

						<div class="snap-share-card" id="snap-og-card" style="border:1px solid var(--snap-border,#E5E7EB);border-radius:12px;overflow:hidden;max-width:500px;background:#fff;margin-bottom:14px;">
							<div class="snap-share-img" id="snap-og-card-img" style="height:200px;background:#F3F4F6 center/cover no-repeat;display:flex;align-items:center;justify-content:center;color:#9CA3AF;font-size:13px;<?php echo $fallback_image ? 'background-image:url(' . esc_url( $fallback_image ) . ');' : ''; ?>">
								<?php if ( ! $fallback_image ) : esc_html_e( 'No image — set one below or add a featured image', 'snaplevel' ); endif; ?>
							</div>
							<div style="padding:10px 12px;background:#F0F2F5;">
								<div style="font-size:12px;color:#65676B;text-transform:uppercase;"><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ?: '' ); ?></div>
								<div id="snap-og-card-title" style="font-weight:600;font-size:15px;color:#050505;line-height:1.3;"></div>
								<div id="snap-og-card-desc" style="font-size:13px;color:#65676B;line-height:1.35;overflow:hidden;max-height:36px;"></div>
							</div>
						</div>

						<div class="snap-social-fields" data-social-fields="og">
							<div class="snap-field">
								<label for="snap_og_title"><?php esc_html_e( 'Social Title', 'snaplevel' ); ?></label>
								<input type="text" id="snap_og_title" name="_snap_og_title" value="<?php echo esc_attr( $og_title ); ?>" class="snap-input" maxlength="100" placeholder="<?php echo esc_attr( $title ?: $post->post_title ); ?>">
							</div>
							<div class="snap-field">
								<label for="snap_og_desc"><?php esc_html_e( 'Social Description', 'snaplevel' ); ?></label>
								<textarea id="snap_og_desc" name="_snap_og_desc" class="snap-textarea" rows="2" maxlength="300"><?php echo esc_textarea( $og_desc ); ?></textarea>
							</div>
							<div class="snap-field">
								<label><?php esc_html_e( 'Social Image', 'snaplevel' ); ?> <span class="snap-muted" style="font-weight:400;font-size:12px;">(<?php esc_html_e( 'recommended 1200×630', 'snaplevel' ); ?>)</span></label>
								<input type="hidden" id="snap_og_image" name="_snap_og_image" value="<?php echo esc_attr( $og_image ); ?>">
								<p style="margin:0;">
									<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-img-pick" data-target="snap_og_image" data-card="snap-og-card-img"><?php esc_html_e( 'Choose image', 'snaplevel' ); ?></button>
									<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-img-clear" data-target="snap_og_image" data-card="snap-og-card-img" <?php echo '' === $og_image ? 'style="display:none"' : ''; ?>><?php esc_html_e( 'Remove', 'snaplevel' ); ?></button>
								</p>
							</div>
						</div>
					</div>

					<!-- X (Twitter) -->
					<div style="flex:1;min-width:320px;">
						<div style="font-weight:600;margin-bottom:10px;"><?php esc_html_e( 'X (Twitter)', 'snaplevel' ); ?></div>

						<div class="snap-share-card" id="snap-tw-card-prev" style="border:1px solid var(--snap-border,#E5E7EB);border-radius:16px;overflow:hidden;max-width:500px;background:#fff;margin-bottom:14px;">
							<div class="snap-share-img" id="snap-tw-card-img" style="height:200px;background:#F3F4F6 center/cover no-repeat;display:flex;align-items:center;justify-content:center;color:#9CA3AF;font-size:13px;<?php echo ( $tw_image ?: $fallback_image ) ? 'background-image:url(' . esc_url( $tw_image ?: $fallback_image ) . ');' : ''; ?>">
								<?php if ( ! ( $tw_image ?: $fallback_image ) ) : esc_html_e( 'No image', 'snaplevel' ); endif; ?>
							</div>
							<div style="padding:10px 12px;">
								<div id="snap-tw-card-title" style="font-weight:600;font-size:14px;color:#0F1419;line-height:1.3;"></div>
								<div id="snap-tw-card-desc" style="font-size:13px;color:#536471;line-height:1.35;overflow:hidden;max-height:36px;"></div>
								<div style="font-size:12px;color:#536471;margin-top:2px;"><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ?: '' ); ?></div>
							</div>
						</div>

						<div class="snap-social-fields" data-social-fields="tw">
							<div class="snap-field">
								<label for="snap_tw_card"><?php esc_html_e( 'Card Type', 'snaplevel' ); ?></label>
								<select id="snap_tw_card" name="_snap_tw_card" class="snap-select" style="max-width:280px;">
									<option value="" <?php selected( $tw_card, '' ); ?>><?php esc_html_e( 'Large image (default)', 'snaplevel' ); ?></option>
									<option value="summary" <?php selected( $tw_card, 'summary' ); ?>><?php esc_html_e( 'Summary (small image)', 'snaplevel' ); ?></option>
								</select>
							</div>
							<div class="snap-field">
								<label for="snap_tw_title"><?php esc_html_e( 'X Title', 'snaplevel' ); ?> <span class="snap-muted" style="font-weight:400;font-size:12px;">(<?php esc_html_e( 'empty = use social title', 'snaplevel' ); ?>)</span></label>
								<input type="text" id="snap_tw_title" name="_snap_tw_title" value="<?php echo esc_attr( $tw_title ); ?>" class="snap-input" maxlength="100">
							</div>
							<div class="snap-field">
								<label for="snap_tw_desc"><?php esc_html_e( 'X Description', 'snaplevel' ); ?></label>
								<textarea id="snap_tw_desc" name="_snap_tw_desc" class="snap-textarea" rows="2" maxlength="300"><?php echo esc_textarea( $tw_desc ); ?></textarea>
							</div>
							<div class="snap-field">
								<label><?php esc_html_e( 'X Image', 'snaplevel' ); ?> <span class="snap-muted" style="font-weight:400;font-size:12px;">(<?php esc_html_e( 'empty = use social image', 'snaplevel' ); ?>)</span></label>
								<input type="hidden" id="snap_tw_image" name="_snap_tw_image" value="<?php echo esc_attr( $tw_image ); ?>">
								<p style="margin:0;">
									<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-img-pick" data-target="snap_tw_image" data-card="snap-tw-card-img"><?php esc_html_e( 'Choose image', 'snaplevel' ); ?></button>
									<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-img-clear" data-target="snap_tw_image" data-card="snap-tw-card-img" <?php echo '' === $tw_image ? 'style="display:none"' : ''; ?>><?php esc_html_e( 'Remove', 'snaplevel' ); ?></button>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Advanced -->
			<div class="snap-metabox-pane" data-pane-content="advanced">
				<div class="snap-field">
					<label><?php esc_html_e( 'Robots Meta', 'snaplevel' ); ?></label>
					<input type="hidden" id="snap_robots" name="_snap_robots" value="<?php echo esc_attr( $robots ); ?>">
					<div style="display:flex;flex-direction:column;gap:6px;max-width:560px;">
						<?php
						$directive_labels = array(
							'noindex'      => __( 'No Index — hide this page from search results', 'snaplevel' ),
							'nofollow'     => __( 'No Follow — don\'t follow links on this page', 'snaplevel' ),
							'noimageindex' => __( 'No Image Index — don\'t index images on this page', 'snaplevel' ),
							'nosnippet'    => __( 'No Snippet — don\'t show a text snippet or preview', 'snaplevel' ),
						);
						foreach ( $directive_labels as $directive => $label ) :
							?>
							<label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:400;">
								<input type="checkbox" class="snap-robots-cb" value="<?php echo esc_attr( $directive ); ?>" <?php checked( in_array( $directive, $robots_directives, true ) ); ?>>
								<span><?php echo esc_html( $label ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
				<div class="snap-field">
					<label for="snap_canonical"><?php esc_html_e( 'Canonical URL', 'snaplevel' ); ?></label>
					<input type="url" id="snap_canonical" name="_snap_canonical" value="<?php echo esc_attr( $canon ); ?>" class="snap-input" placeholder="<?php echo esc_attr( get_permalink( $post ) ?: '' ); ?>">
					<div class="snap-help"><?php esc_html_e( 'Leave empty to use the default permalink. Set this when the content exists at another URL.', 'snaplevel' ); ?></div>
				</div>
				<div class="snap-field">
					<label for="snap_breadcrumb_title"><?php esc_html_e( 'Breadcrumb Title', 'snaplevel' ); ?></label>
					<input type="text" id="snap_breadcrumb_title" name="_snap_breadcrumb_title" value="<?php echo esc_attr( $bc_title ); ?>" class="snap-input" style="max-width:450px;" placeholder="<?php echo esc_attr( $post->post_title ); ?>">
					<div class="snap-help"><?php esc_html_e( 'Shorter title used in breadcrumb trails. Empty = post title.', 'snaplevel' ); ?></div>
				</div>
			</div>

			<!-- Schema -->
			<div class="snap-metabox-pane" data-pane-content="schema">
				<input type="hidden" id="snap_schema" name="_snap_schema" value="<?php echo esc_attr( $schema ); ?>">
				<p style="margin:0 0 8px;">
					<span id="snap-schema-state">
						<?php if ( '' !== $schema_type ) : ?>
							<span class="snap-badge snap-badge-green">✓ <?php echo esc_html( $schema_type ); ?> <?php esc_html_e( 'active', 'snaplevel' ); ?></span>
						<?php else : ?>
							<span class="snap-muted"><?php esc_html_e( 'No schema yet.', 'snaplevel' ); ?></span>
						<?php endif; ?>
					</span>
				</p>
				<p class="snap-muted" style="font-size:12px;"><?php esc_html_e( 'AI reads this post and builds the right schema.org markup — Article, Product, FAQ, Recipe, HowTo and more. It detects the type automatically.', 'snaplevel' ); ?></p>
				<?php if ( $has_key ) : ?>
					<p style="margin:8px 0 0;">
						<button type="button" class="snap-btn snap-btn-ai-soft snap-btn-sm" id="snap-gen-schema">✦ <?php esc_html_e( 'Generate schema with AI', 'snaplevel' ); ?></button>
						<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm" id="snap-clear-schema" <?php echo '' === $schema ? 'style="display:none"' : ''; ?>><?php esc_html_e( 'Remove', 'snaplevel' ); ?></button>
					</p>
				<?php endif; ?>
			</div>
		</div>

		<?php
		wp_enqueue_script( 'snap-classic-metabox', SNAP_PLUGIN_URL . 'assets/js/classic-metabox.js', array( 'wp-api-fetch' ), Snap_Assets::version( 'assets/js/classic-metabox.js' ), true );
		wp_localize_script( 'snap-classic-metabox', 'SNAP_METABOX', array(
			'restUrl'   => esc_url_raw( rest_url( 'snaplevel/v1' ) ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'homeUrl'   => trailingslashit( home_url() ),
			'postTitle' => (string) $post->post_title,
			'siteName'  => get_bloginfo( 'name' ),
			'separator' => (string) Snap_Settings::instance()->get( 'titles.separator', '–' ),
			'permalink' => (string) get_permalink( $post ),
			'i18n'      => array(
				'selectImage'    => __( 'Select social image', 'snaplevel' ),
				'generating'     => __( 'Generating…', 'snaplevel' ),
				'analyzingPost'  => __( 'Analyzing post…', 'snaplevel' ),
				'schemaReady'    => __( 'ready — save the post to apply', 'snaplevel' ),
				'noSchema'       => __( 'No schema yet. Save the post to apply removal.', 'snaplevel' ),
				'noMetaDesc'     => __( 'No meta description yet — Google will pick random text from the page.', 'snaplevel' ),
				'kwSet'          => __( 'Focus keyword is set', 'snaplevel' ),
				'kwInTitle'      => __( 'Keyword used in the SEO title', 'snaplevel' ),
				'kwStartTitle'   => __( 'Keyword at the start of the title', 'snaplevel' ),
				'kwInDesc'       => __( 'Keyword used in the meta description', 'snaplevel' ),
				'titleLength'    => __( 'Title length is 35–60 characters', 'snaplevel' ),
				'descLength'     => __( 'Description length is 120–156 characters', 'snaplevel' ),
				'kwInUrl'        => __( 'Keyword used in the URL', 'snaplevel' ),
				'kwFirstPara'    => __( 'Keyword in the first paragraph', 'snaplevel' ),
				'contentLength'  => __( 'Content is 600+ words', 'snaplevel' ),
				'words'          => __( 'words', 'snaplevel' ),
				'checksPassed'   => __( 'checks passed', 'snaplevel' ),
				'findingKeywords' => __( 'Finding keywords…', 'snaplevel' ),
				'writingTitle'   => __( 'Writing title…', 'snaplevel' ),
				'writingDesc'    => __( 'Writing description…', 'snaplevel' ),
				'done'           => __( 'Done. Review the fields, then save the post.', 'snaplevel' ),
			),
		) );
		?>
		<?php
	}

	public function save_metabox( int $post_id, WP_Post $post ): void {
		if ( ! isset( $_POST['snap_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['snap_meta_nonce'] ) ), 'snap_meta_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( self::FIELDS as $key => $def ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$value = ( isset( $def['sanitize'] ) && 'url' === $def['sanitize'] )
				? esc_url_raw( (string) $_POST[ $key ] )
				: sanitize_text_field( (string) $_POST[ $key ] );

			if ( '_snap_tw_card' === $key && ! in_array( $value, array( '', 'summary', 'summary_large_image' ), true ) ) {
				$value = '';
			}

			if ( '' === $value ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $value );
			}
		}

		// URL slug editor (General tab). Recursion-safe: unhook, update, rehook.
		if ( isset( $_POST['snap_slug'] ) ) {
			$new_slug = sanitize_title( (string) wp_unslash( $_POST['snap_slug'] ) );
			if ( '' !== $new_slug && $new_slug !== $post->post_name && ! in_array( $post->post_status, array( 'auto-draft', 'trash' ), true ) ) {
				remove_action( 'save_post', array( $this, 'save_metabox' ), 10 );
				wp_update_post( array( 'ID' => $post_id, 'post_name' => $new_slug ) );
				add_action( 'save_post', array( $this, 'save_metabox' ), 10, 2 );
			}
		}

		// Schema: validated by Snap_Schema_Module::sanitize_schema().
		if ( isset( $_POST['_snap_schema'] ) ) {
			$schema = class_exists( 'Snap_Schema_Module' )
				? Snap_Schema_Module::sanitize_schema( (string) wp_unslash( $_POST['_snap_schema'] ) )
				: '';
			if ( '' === $schema ) {
				delete_post_meta( $post_id, '_snap_schema' );
			} else {
				update_post_meta( $post_id, '_snap_schema', $schema );
			}
		}
	}
}
