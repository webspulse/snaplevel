<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Meta_Output — frontend <head> output.
 *
 * Title rewrite, meta description, robots, canonical, prev/next.
 * Hard-disables itself when another SEO plugin is active (conflict guard)
 * so a site never gets duplicate meta output.
 */
final class Snap_Meta_Output {

	public function __construct() {
		if ( class_exists( 'Snap_Conflict_Guard' ) && Snap_Conflict_Guard::has_conflict() ) {
			return; // Another SEO plugin owns the head. Do not double-output.
		}

		add_filter( 'pre_get_document_title', array( $this, 'filter_title' ), 15 );
		add_filter( 'document_title_separator', array( $this, 'filter_separator' ), 15 );
		add_action( 'wp_head', array( $this, 'output_head' ), 1 );

		// Ours replaces core's canonical + robots handling.
		remove_action( 'wp_head', 'rel_canonical' );
		add_filter( 'wp_robots', array( $this, 'filter_robots' ), 20 );
	}

	// ── Title ─────────────────────────────────────────────────────────────────

	public function filter_title( string $title ): string {
		$custom = $this->resolve_title();
		return '' !== $custom ? $custom : $title;
	}

	public function filter_separator( string $sep ): string {
		return (string) Snap_Settings::instance()->get( 'titles.separator', $sep );
	}

	private function resolve_title(): string {
		$settings = Snap_Settings::instance();

		if ( is_singular() || ( is_front_page() && ! is_home() && get_queried_object() instanceof WP_Post ) ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				$custom = (string) get_post_meta( $post->ID, '_snap_title', true );
				if ( '' !== $custom ) {
					return Snap_Template_Variables::replace( $custom, $post );
				}
				$tpl = (string) $settings->get( 'titles.post_types.' . $post->post_type . '.title', '' );
				if ( '' !== $tpl ) {
					return Snap_Template_Variables::replace( $tpl, $post );
				}
			}
			return '';
		}

		if ( is_front_page() || is_home() ) {
			$tpl = (string) $settings->get( 'titles.home_title', '' );
			return '' !== $tpl ? Snap_Template_Variables::replace( $tpl ) : '';
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term instanceof WP_Term ) {
				$tpl = (string) $settings->get( 'titles.taxonomies.' . $term->taxonomy . '.title', '' );
				if ( '' !== $tpl ) {
					return Snap_Template_Variables::replace( $tpl );
				}
			}
			return '';
		}

		if ( is_author() ) {
			return Snap_Template_Variables::replace( (string) $settings->get( 'titles.archive_author', '' ) );
		}
		if ( is_date() ) {
			return Snap_Template_Variables::replace( (string) $settings->get( 'titles.archive_date', '' ) );
		}
		if ( is_search() ) {
			return Snap_Template_Variables::replace( (string) $settings->get( 'titles.archive_search', '' ) );
		}
		if ( is_404() ) {
			return Snap_Template_Variables::replace( (string) $settings->get( 'titles.archive_404', '' ) );
		}

		return '';
	}

	// ── Head output ───────────────────────────────────────────────────────────

	public function output_head(): void {
		echo "\n<!-- Snaplevel SEO -->\n";

		$desc = $this->resolve_description();
		if ( '' !== $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}

		$canonical = $this->resolve_canonical();
		if ( '' !== $canonical ) {
			echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
		}

		$this->output_prev_next();
		$this->output_social();

		echo "<!-- /Snaplevel SEO -->\n";
	}

	// ── Social (Open Graph + X/Twitter cards) ─────────────────────────────────

	private function output_social(): void {
		$title     = '';
		$desc      = $this->resolve_description();
		$url       = $this->resolve_canonical();
		$image     = '';
		$tw_title  = '';
		$tw_desc   = '';
		$tw_image  = '';
		$tw_card   = 'summary_large_image';
		$type      = is_singular() && ! is_front_page() ? 'article' : 'website';

		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				$og_title = (string) get_post_meta( $post->ID, '_snap_og_title', true );
				$og_desc  = (string) get_post_meta( $post->ID, '_snap_og_desc', true );
				$title    = '' !== $og_title ? Snap_Template_Variables::replace( $og_title, $post ) : '';
				if ( '' !== $og_desc ) {
					$desc = Snap_Template_Variables::replace( $og_desc, $post );
				}
				$image    = (string) get_post_meta( $post->ID, '_snap_og_image', true );
				$tw_title = (string) get_post_meta( $post->ID, '_snap_tw_title', true );
				$tw_desc  = (string) get_post_meta( $post->ID, '_snap_tw_desc', true );
				$tw_image = (string) get_post_meta( $post->ID, '_snap_tw_image', true );
				$card     = (string) get_post_meta( $post->ID, '_snap_tw_card', true );
				if ( in_array( $card, array( 'summary', 'summary_large_image' ), true ) ) {
					$tw_card = $card;
				}
				if ( '' === $image ) {
					$image = (string) get_the_post_thumbnail_url( $post, 'large' );
				}
			}
		}

		if ( '' === $title ) {
			$title = wp_get_document_title();
		}
		if ( '' === $url ) {
			$url = home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) );
		}

		echo '<meta property="og:locale" content="' . esc_attr( str_replace( '-', '_', get_bloginfo( 'language' ) ) ) . '">' . "\n";
		echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( '' !== $desc ) {
			echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
		if ( '' !== $image ) {
			echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
		}

		if ( is_singular() && 'article' === $type ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				echo '<meta property="article:published_time" content="' . esc_attr( (string) get_the_date( 'c', $post ) ) . '">' . "\n";
				echo '<meta property="article:modified_time" content="' . esc_attr( (string) get_the_modified_date( 'c', $post ) ) . '">' . "\n";
			}
		}

		echo '<meta name="twitter:card" content="' . esc_attr( $tw_card ) . '">' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( '' !== $tw_title ? $tw_title : $title ) . '">' . "\n";
		$x_desc = '' !== $tw_desc ? $tw_desc : $desc;
		if ( '' !== $x_desc ) {
			echo '<meta name="twitter:description" content="' . esc_attr( $x_desc ) . '">' . "\n";
		}
		$x_image = '' !== $tw_image ? $tw_image : $image;
		if ( '' !== $x_image ) {
			echo '<meta name="twitter:image" content="' . esc_url( $x_image ) . '">' . "\n";
		}
	}

	private function resolve_description(): string {
		$settings = Snap_Settings::instance();

		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				$custom = (string) get_post_meta( $post->ID, '_snap_desc', true );
				if ( '' !== $custom ) {
					return Snap_Template_Variables::replace( $custom, $post );
				}
				$tpl = (string) $settings->get( 'titles.post_types.' . $post->post_type . '.desc', '' );
				if ( '' !== $tpl ) {
					return Snap_Template_Variables::replace( $tpl, $post );
				}
			}
			return '';
		}

		if ( is_front_page() || is_home() ) {
			$desc = (string) $settings->get( 'titles.home_desc', '' );
			if ( '' !== $desc ) {
				return Snap_Template_Variables::replace( $desc );
			}
			return (string) get_bloginfo( 'description' );
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term instanceof WP_Term ) {
				$tpl = (string) $settings->get( 'titles.taxonomies.' . $term->taxonomy . '.desc', '' );
				if ( '' !== $tpl ) {
					return Snap_Template_Variables::replace( $tpl );
				}
				$td = wp_strip_all_tags( (string) term_description( $term ) );
				return wp_trim_words( $td, 30, '' );
			}
		}

		return '';
	}

	private function resolve_canonical(): string {
		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				$custom = (string) get_post_meta( $post->ID, '_snap_canonical', true );
				if ( '' !== $custom ) {
					return $custom;
				}
				$paged = (int) get_query_var( 'page' );
				$link  = (string) get_permalink( $post );
				if ( $paged >= 2 ) {
					$link = trailingslashit( $link ) . $paged . '/';
				}
				return $link;
			}
		}

		if ( is_front_page() || is_home() ) {
			$paged = (int) get_query_var( 'paged' );
			return $paged >= 2 ? (string) get_pagenum_link( $paged ) : home_url( '/' );
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term instanceof WP_Term ) {
				$link = get_term_link( $term );
				if ( ! is_wp_error( $link ) ) {
					$paged = (int) get_query_var( 'paged' );
					return $paged >= 2 ? (string) get_pagenum_link( $paged ) : (string) $link;
				}
			}
		}

		if ( is_search() || is_404() ) {
			return '';
		}

		return '';
	}

	private function output_prev_next(): void {
		global $wp_query;

		if ( is_singular() || ! $wp_query instanceof WP_Query ) {
			return;
		}

		$paged = max( 1, (int) get_query_var( 'paged' ) );
		$max   = (int) $wp_query->max_num_pages;

		if ( $max <= 1 ) {
			return;
		}
		if ( $paged > 1 ) {
			echo '<link rel="prev" href="' . esc_url( get_pagenum_link( $paged - 1 ) ) . '">' . "\n";
		}
		if ( $paged < $max ) {
			echo '<link rel="next" href="' . esc_url( get_pagenum_link( $paged + 1 ) ) . '">' . "\n";
		}
	}

	// ── Robots ────────────────────────────────────────────────────────────────

	public function filter_robots( array $robots ): array {
		$settings = Snap_Settings::instance();

		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				$value = (string) get_post_meta( $post->ID, '_snap_robots', true );
				if ( '' === $value && $settings->get( 'titles.post_types.' . $post->post_type . '.noindex', false ) ) {
					$value = 'noindex';
				}
				foreach ( explode( ',', $value ) as $directive ) {
					$directive = trim( $directive );
					if ( in_array( $directive, array( 'noindex', 'nofollow', 'noimageindex', 'nosnippet' ), true ) ) {
						$robots[ $directive ] = true;
						if ( 'noindex' === $directive || 'noimageindex' === $directive ) {
							unset( $robots['max-image-preview'] );
						}
						if ( 'nosnippet' === $directive ) {
							unset( $robots['max-snippet'] );
						}
					}
				}
				if ( ! empty( $robots['noindex'] ) ) {
					unset( $robots['index'] );
				}
			}
			return $robots;
		}

		if ( is_search() || is_404() ) {
			$robots['noindex'] = true;
			unset( $robots['index'] );
			return $robots;
		}

		if ( ( is_category() || is_tag() || is_tax() ) ) {
			$term = get_queried_object();
			if ( $term instanceof WP_Term ) {
				if ( $settings->get( 'titles.taxonomies.' . $term->taxonomy . '.noindex', false )
					|| ( $settings->get( 'titles.noindex_empty_archives', true ) && 0 === (int) $term->count ) ) {
					$robots['noindex'] = true;
					unset( $robots['index'] );
				}
			}
		}

		return $robots;
	}
}
