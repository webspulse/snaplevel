<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Template_Variables — Rank Math style template variables.
 *
 * Supported: %title% %sitename% %sitedesc% %sep% %excerpt% %category%
 * %currentdate% %currentyear% %date% %name% %term% %page% %postname%
 */
final class Snap_Template_Variables {

	/**
	 * Replace template variables in a string for the current context.
	 *
	 * @param string       $template
	 * @param WP_Post|null $post Optional post context.
	 */
	public static function replace( string $template, $post = null ): string {
		if ( '' === $template ) {
			return '';
		}

		$sep      = (string) Snap_Settings::instance()->get( 'titles.separator', '–' );
		$post     = $post instanceof WP_Post ? $post : ( is_singular() ? get_queried_object() : null );
		$post     = $post instanceof WP_Post ? $post : null;

		$vars = array(
			'%sitename%'    => get_bloginfo( 'name' ),
			'%sitedesc%'    => get_bloginfo( 'description' ),
			'%sep%'         => $sep,
			'%currentdate%' => date_i18n( get_option( 'date_format' ) ),
			'%currentyear%' => date_i18n( 'Y' ),
			'%page%'        => self::page_number(),
		);

		if ( $post ) {
			$category = '';
			$cats     = get_the_category( $post->ID );
			if ( ! empty( $cats ) && ! is_wp_error( $cats ) ) {
				$category = $cats[0]->name;
			}
			$excerpt = $post->post_excerpt;
			if ( '' === $excerpt ) {
				$excerpt = wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 25, '' );
			}

			$vars['%title%']    = get_the_title( $post );
			$vars['%postname%'] = $post->post_name;
			$vars['%excerpt%']  = $excerpt;
			$vars['%category%'] = $category;
			$vars['%date%']     = get_the_date( '', $post );
		} else {
			$vars['%title%']    = wp_get_document_title();
			$vars['%postname%'] = '';
			$vars['%excerpt%']  = '';
			$vars['%category%'] = '';
			$vars['%date%']     = '';
		}

		// Archive context.
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term instanceof WP_Term ) {
				$vars['%term%']    = $term->name;
				$vars['%title%']   = $term->name;
				$vars['%excerpt%'] = wp_strip_all_tags( (string) term_description( $term ) );
			}
		} elseif ( is_search() ) {
			$vars['%term%'] = get_search_query();
		} elseif ( is_author() ) {
			$vars['%name%'] = (string) get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) );
		} elseif ( is_date() ) {
			$vars['%date%'] = self::archive_date();
		}
		if ( ! isset( $vars['%term%'] ) ) {
			$vars['%term%'] = '';
		}
		if ( ! isset( $vars['%name%'] ) ) {
			$vars['%name%'] = '';
		}

		/**
		 * Filter the available template variables.
		 *
		 * @param array        $vars
		 * @param WP_Post|null $post
		 */
		$vars = apply_filters( 'snaplevel_template_variables', $vars, $post );

		$out = strtr( $template, $vars );

		// Collapse leftover separators/whitespace from empty vars.
		$out = (string) preg_replace( '/\s{2,}/', ' ', $out );
		$out = trim( $out, " \t–—|-•" . chr( 194 ) . chr( 160 ) );

		return trim( $out );
	}

	private static function page_number(): string {
		$paged = max( (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
		if ( $paged >= 2 ) {
			/* translators: %d: page number */
			return sprintf( __( 'Page %d', 'snaplevel' ), $paged );
		}
		return '';
	}

	private static function archive_date(): string {
		if ( is_day() ) {
			return get_the_date();
		}
		if ( is_month() ) {
			return single_month_title( ' ', false );
		}
		if ( is_year() ) {
			return (string) get_query_var( 'year' );
		}
		return '';
	}

	/** Variables documented for the settings UI. */
	public static function available(): array {
		return array(
			'%title%'       => __( 'Post / term title', 'snaplevel' ),
			'%sitename%'    => __( 'Site name', 'snaplevel' ),
			'%sitedesc%'    => __( 'Site tagline', 'snaplevel' ),
			'%sep%'         => __( 'Separator', 'snaplevel' ),
			'%excerpt%'     => __( 'Post excerpt (auto-generated if empty)', 'snaplevel' ),
			'%category%'    => __( 'First category', 'snaplevel' ),
			'%currentdate%' => __( 'Current date', 'snaplevel' ),
			'%currentyear%' => __( 'Current year', 'snaplevel' ),
			'%date%'        => __( 'Post / archive date', 'snaplevel' ),
			'%name%'        => __( 'Author name', 'snaplevel' ),
			'%term%'        => __( 'Term name / search query', 'snaplevel' ),
			'%page%'        => __( 'Page number (pagination)', 'snaplevel' ),
		);
	}
}
