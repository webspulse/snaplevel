<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_SEO_Changelog — every SEO change, recorded.
 *
 * Logs before/after for every _snap_* post meta change (works in the
 * classic metabox, Gutenberg, the builder popup, importers, and AI fixes)
 * plus URL slug changes. Powers the SEO History tab and feeds SEO Memory,
 * which detects the user's editing patterns from these diffs.
 */
final class Snap_SEO_Changelog {

	/** Human labels for logged fields. */
	const FIELD_LABELS = array(
		'_snap_title'            => 'SEO Title',
		'_snap_desc'             => 'Meta Description',
		'_snap_focus_kw'         => 'Focus Keyword',
		'_snap_robots'           => 'Robots Meta',
		'_snap_canonical'        => 'Canonical URL',
		'_snap_og_title'         => 'Social Title',
		'_snap_og_desc'          => 'Social Description',
		'_snap_og_image'         => 'Social Image',
		'_snap_tw_title'         => 'X Title',
		'_snap_tw_desc'          => 'X Description',
		'_snap_tw_image'         => 'X Image',
		'_snap_tw_card'          => 'X Card Type',
		'_snap_breadcrumb_title' => 'Breadcrumb Title',
		'_snap_schema'           => 'Schema',
		'post_name'              => 'URL Slug',
	);

	public function __construct() {
		add_filter( 'update_post_metadata', array( __CLASS__, 'stash_pre_value' ), 10, 4 );
		add_action( 'updated_post_meta', array( $this, 'on_meta_updated' ), 10, 4 );
		add_action( 'added_post_meta', array( $this, 'on_meta_added' ), 10, 4 );
		add_action( 'deleted_post_meta', array( $this, 'on_meta_deleted' ), 10, 4 );
		add_action( 'post_updated', array( $this, 'on_post_updated' ), 10, 3 );
	}

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'snap_seo_changelog';
	}

	public static function maybe_create_table(): void {
		if ( get_option( 'snap_changelog_db' ) ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( 'CREATE TABLE ' . self::table() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			field VARCHAR(64) NOT NULL,
			old_value TEXT NULL,
			new_value TEXT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY post_idx (post_id),
			KEY field_idx (field)
		) " . $wpdb->get_charset_collate() . ';' );
		update_option( 'snap_changelog_db', 1 );
	}

	// ── Capture ───────────────────────────────────────────────────────────────

	private static function is_tracked( string $key ): bool {
		return isset( self::FIELD_LABELS[ $key ] ) && 'post_name' !== $key;
	}

	public function on_meta_updated( $meta_id, $post_id, $key, $value ): void {
		if ( ! self::is_tracked( (string) $key ) ) {
			return;
		}
		// The previous value was cached by WP before the update; fetch from the
		// 'update_postmeta' pre-hook is gone here, so we keep a per-request stash.
		$old = self::$pre_values[ $post_id . ':' . $key ] ?? null;
		self::log( (int) $post_id, (string) $key, $old, is_scalar( $value ) ? (string) $value : wp_json_encode( $value ) );
	}

	public function on_meta_added( $meta_id, $post_id, $key, $value ): void {
		if ( ! self::is_tracked( (string) $key ) ) {
			return;
		}
		self::log( (int) $post_id, (string) $key, '', is_scalar( $value ) ? (string) $value : wp_json_encode( $value ) );
	}

	public function on_meta_deleted( $meta_ids, $post_id, $key, $value ): void {
		if ( ! self::is_tracked( (string) $key ) ) {
			return;
		}
		self::log( (int) $post_id, (string) $key, is_scalar( $value ) ? (string) $value : '', '' );
	}

	/** @var array<string, string> old values stashed before update */
	private static $pre_values = array();

	/** Hooked statically from boot: stash old value before an update overwrites it. */
	public static function stash_pre_value( $check, $post_id, $key, $value ) {
		if ( self::is_tracked( (string) $key ) ) {
			self::$pre_values[ $post_id . ':' . $key ] = (string) get_post_meta( (int) $post_id, (string) $key, true );
		}
		return $check;
	}

	public function on_post_updated( int $post_id, WP_Post $after, WP_Post $before ): void {
		if ( $after->post_name !== $before->post_name && 'auto-draft' !== $before->post_status ) {
			self::log( $post_id, 'post_name', $before->post_name, $after->post_name );
		}
	}

	private static function log( int $post_id, string $field, $old, string $new ): void {
		$old = null === $old ? '' : (string) $old;
		if ( $old === $new ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		self::maybe_create_table();
		global $wpdb;
		$wpdb->insert( self::table(), array(
			'post_id'   => $post_id,
			'field'     => $field,
			'old_value' => mb_substr( $old, 0, 1000 ),
			'new_value' => mb_substr( $new, 0, 1000 ),
			'user_id'   => get_current_user_id(),
			'created'   => current_time( 'mysql' ),
		), array( '%d', '%s', '%s', '%s', '%d', '%s' ) );

		// Cap at 5000 rows.
		$count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() ); // phpcs:ignore
		if ( $count > 5000 ) {
			$wpdb->query( 'DELETE FROM ' . self::table() . ' ORDER BY id ASC LIMIT 500' ); // phpcs:ignore
		}
	}

	// ── Read ──────────────────────────────────────────────────────────────────

	public static function get_entries( int $limit = 200, int $post_id = 0 ): array {
		self::maybe_create_table();
		global $wpdb;
		if ( $post_id > 0 ) {
			return (array) $wpdb->get_results( $wpdb->prepare( // phpcs:ignore
				'SELECT * FROM ' . self::table() . ' WHERE post_id = %d ORDER BY id DESC LIMIT %d',
				$post_id,
				$limit
			), ARRAY_A );
		}
		return (array) $wpdb->get_results( $wpdb->prepare( // phpcs:ignore
			'SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT %d',
			$limit
		), ARRAY_A );
	}

	public static function count(): int {
		if ( ! get_option( 'snap_changelog_db' ) ) {
			return 0;
		}
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() ); // phpcs:ignore
	}

	// ── SEO Memory: learn the user's style from the diffs ─────────────────────

	/**
	 * Analyze title/description edits and infer style preferences.
	 *
	 * @return array{edits:int, avg_title_len:int, avg_desc_len:int, removed_words:array, added_words:array}
	 */
	public static function memory_analysis(): array {
		self::maybe_create_table();
		global $wpdb;
		$rows = (array) $wpdb->get_results( // phpcs:ignore
			"SELECT field, old_value, new_value FROM " . self::table() . "
			 WHERE field IN ('_snap_title','_snap_desc','_snap_og_title','_snap_og_desc')
			 AND old_value != '' AND new_value != ''
			 ORDER BY id DESC LIMIT 500",
			ARRAY_A
		);

		$stop = array( 'the', 'a', 'an', 'and', 'or', 'of', 'to', 'in', 'on', 'for', 'with', 'your', 'you', 'is', 'are', 'at', 'by', 'it', 'this', 'that', 'from', 'as', 'be', '&', '-', '–', '|' );

		$title_lens = array();
		$desc_lens  = array();
		$removed    = array();
		$added      = array();

		foreach ( $rows as $row ) {
			$old_words = array_filter( array_map( 'strtolower', preg_split( '/[\s,.:;!?()]+/', (string) $row['old_value'] ) ?: array() ) );
			$new_words = array_filter( array_map( 'strtolower', preg_split( '/[\s,.:;!?()]+/', (string) $row['new_value'] ) ?: array() ) );

			foreach ( array_diff( $old_words, $new_words, $stop ) as $w ) {
				if ( mb_strlen( $w ) > 2 ) {
					$removed[ $w ] = ( $removed[ $w ] ?? 0 ) + 1;
				}
			}
			foreach ( array_diff( $new_words, $old_words, $stop ) as $w ) {
				if ( mb_strlen( $w ) > 2 ) {
					$added[ $w ] = ( $added[ $w ] ?? 0 ) + 1;
				}
			}

			if ( in_array( $row['field'], array( '_snap_title', '_snap_og_title' ), true ) ) {
				$title_lens[] = mb_strlen( (string) $row['new_value'] );
			} else {
				$desc_lens[] = mb_strlen( (string) $row['new_value'] );
			}
		}

		arsort( $removed );
		arsort( $added );
		// Only patterns seen at least twice are signals, not noise.
		$removed = array_filter( $removed, static function ( $n ) { return $n >= 2; } );
		$added   = array_filter( $added, static function ( $n ) { return $n >= 2; } );

		return array(
			'edits'         => count( $rows ),
			'avg_title_len' => $title_lens ? (int) round( array_sum( $title_lens ) / count( $title_lens ) ) : 0,
			'avg_desc_len'  => $desc_lens ? (int) round( array_sum( $desc_lens ) / count( $desc_lens ) ) : 0,
			'removed_words' => array_slice( $removed, 0, 8, true ),
			'added_words'   => array_slice( $added, 0, 8, true ),
		);
	}

	/** Build suggested style rules from the analysis (user can edit before saving). */
	public static function suggested_rules( array $analysis ): string {
		$rules = array();
		if ( $analysis['avg_title_len'] > 0 ) {
			$rules[] = sprintf( 'Keep SEO titles close to %d characters.', $analysis['avg_title_len'] );
		}
		if ( $analysis['avg_desc_len'] > 0 ) {
			$rules[] = sprintf( 'Keep meta descriptions close to %d characters.', $analysis['avg_desc_len'] );
		}
		if ( ! empty( $analysis['removed_words'] ) ) {
			$rules[] = 'Avoid these words (the user always removes them): ' . implode( ', ', array_keys( $analysis['removed_words'] ) ) . '.';
		}
		if ( ! empty( $analysis['added_words'] ) ) {
			$rules[] = 'Prefer using these words where natural (the user often adds them): ' . implode( ', ', array_keys( $analysis['added_words'] ) ) . '.';
		}
		return implode( "\n", $rules );
	}
}
