<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Builder_Integration — the SEO panel inside page builders.
 *
 * A hidden fullscreen admin page (admin.php?page=snap-seo-popup&post=ID)
 * renders the complete Snaplevel metabox with its own Save button.
 * Uses native top-bar/toolbar icon injection in Elementor and Bricks for a seamless experience.
 * Opens a premium docked side panel (iframe) with the full Snaplevel metabox + Copilot AI tools.
 * Works for other builders via admin bar or direct link.
 * 100% Snaplevel branded — no third-party names.
 */
final class Snap_Builder_Integration {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_hidden_page' ) );
		add_action( 'admin_post_snap_seo_popup_save', array( $this, 'handle_save' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'popup_assets' ) );

		// Elementor editor: native top-bar icon injection + overlay iframe panel.
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_builder_assets_for_elementor' ] );
		add_action( 'elementor/editor/footer', array( $this, 'print_elementor_launcher' ) );

		// Bricks: native toolbar li injection.
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_for_bricks' ], 9999 );

		// Divi support (Phase 2 expansion): basic native feel via admin bar + future toolbar if hooks.
		if ( defined( 'ET_BUILDER_VERSION' ) ) {
			add_action( 'admin_bar_menu', array( $this, 'admin_bar_link' ), 90 );
			// Placeholder for future Divi-specific icon injection similar to Bricks/Elementor.
		}

		// Front-end builders (Divi VB, Bricks, Oxygen): SEO link in the admin bar.
		add_action( 'admin_bar_menu', array( $this, 'admin_bar_link' ), 90 );
	}

	public function register_hidden_page(): void {
		add_submenu_page(
			'', // No parent — hidden from the menu, reachable by URL.
			__( 'Snaplevel SEO', 'snaplevel' ),
			__( 'Snaplevel SEO', 'snaplevel' ),
			'edit_posts',
			'snap-seo-popup',
			array( $this, 'render_popup' )
		);
	}

	public function body_class( string $classes ): string {
		if ( isset( $_GET['page'] ) && 'snap-seo-popup' === $_GET['page'] ) {
			$classes .= ' snap-page snap-fullscreen snap-mode-advanced';
		}
		return $classes;
	}

	public function popup_assets( string $hook ): void {
		if ( false === strpos( $hook, 'snap-seo-popup' ) ) {
			return;
		}
		wp_enqueue_style( 'snap-design-system' );
		wp_enqueue_media();
	}

	// ── Popup page ────────────────────────────────────────────────────────────

	public function render_popup(): void {
		$post = get_post( (int) ( $_GET['post'] ?? 0 ) );
		if ( ! $post instanceof WP_Post || ! current_user_can( 'edit_post', $post->ID ) ) {
			wp_die( esc_html__( 'You cannot edit this post.', 'snaplevel' ) );
		}
		if ( ! class_exists( 'Snap_Post_Meta' ) ) {
			require_once SNAP_PLUGIN_DIR . 'includes/modules/seo-meta/class-template-variables.php';
			require_once SNAP_PLUGIN_DIR . 'includes/modules/seo-meta/class-post-meta.php';
		}
		$saved = ! empty( $_GET['saved'] );
		$context = isset( $_GET['context'] ) ? sanitize_key( $_GET['context'] ) : '';
		$is_builder = ( 'builder' === $context );
		$header_pad = $is_builder ? '6px 12px' : '10px 16px';
		$header_bg  = $is_builder ? 'var(--snap-bg-page)' : '#fff';
		$inner_pad  = $is_builder ? '12px 14px' : '20px';
		$title_max  = $is_builder ? 32 : 40;

		// Clean the panel completely from other plugins' admin notices (cache plugins, optimizers, security, etc.)
		// This makes the iframe side panel 100% ours and stable.
		if ( $is_builder ) {
			remove_all_actions( 'admin_notices' );
			remove_all_actions( 'all_admin_notices' );
		}
		?>
		<div class="snap-wrap" style="padding:0;margin:0;background:var(--snap-bg-page);min-height:100vh;">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="snap_seo_popup_save">
				<input type="hidden" name="post_id" value="<?php echo esc_attr( (string) $post->ID ); ?>">

				<div style="position:sticky;top:0;z-index:50;display:flex;align-items:center;gap:8px;background:<?php echo esc_attr( $header_bg ); ?>;border-bottom:1px solid var(--snap-border);padding:<?php echo esc_attr( $header_pad ); ?>;font-family:var(--snap-font, system-ui, sans-serif);">
					<img src="<?php echo esc_url( SNAP_PLUGIN_URL . 'assets/images/icon.svg' ); ?>" alt="" style="width:18px;height:18px;border-radius:4px;flex:none;">
					<strong style="font-size:13px;font-weight:600;letter-spacing:-.01em;color:#1e2937;">Snaplevel</strong>
					<span class="snap-muted" style="font-size:11px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.85;">— <?php echo esc_html( mb_strimwidth( get_the_title( $post ) ?: '(no title)', 0, $title_max, '…' ) ); ?></span>

					<?php if ( $is_builder ) : ?>
						<span class="snap-badge snap-badge-blue" style="font-size:10px; padding:1px 6px; margin-left:6px;">AI Powered</span>
					<?php endif; ?>

					<span id="snap-popup-saved" class="snap-badge snap-badge-green" style="font-size:10px;padding:1px 6px;<?php echo $saved ? '' : 'display:none'; ?>">✓ <?php esc_html_e( 'Saved', 'snaplevel' ); ?></span>
					<button type="submit" class="snap-btn snap-btn-primary snap-btn-sm" style="height:26px;padding:0 10px;font-size:11px;"><?php esc_html_e( 'Save', 'snaplevel' ); ?></button>
				</div>

				<div style="padding:<?php echo esc_attr( $inner_pad ); ?>;">
					<?php if ( $is_builder ) : ?>
						<!-- Beautiful "AI Analyzer" (SureRank-quality panel, 100% Snaplevel branded & much easier for users).
						     Live per-post issues with clear impact + one-click jump to the exact AI field below. -->
						<div class="snap-builder-ai-analyzer" style="margin-bottom:14px; background:#fff; border:1px solid var(--snap-border-light); border-radius:8px; padding:12px 14px;">
							<div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
								<?php Snap_Icons::e('target', 16); ?>
								<span style="font-weight:700; font-size:13px; color:var(--snap-text-dark);">AI ANALYZER — LIVE FOR THIS PAGE</span>
								<span class="snap-badge snap-badge-blue" style="font-size:10px; margin-left:auto;">Uses your Training</span>
							</div>

							<?php
							// Safe & simple analysis (no fatals) - wrapped for extra safety
							try {
								$title_val = (string) get_post_meta( $post->ID, '_snap_title', true );
								$desc_val  = (string) get_post_meta( $post->ID, '_snap_desc', true );
								$kw_val    = (string) get_post_meta( $post->ID, '_snap_focus_kw', true );
								$content_len = strlen( wp_strip_all_tags( $post->post_content ?? '' ) );

								$ai_issues = [];

								if ( trim($title_val) === '' ) {
									$ai_issues[] = ['sev' => 'high', 't' => 'SEO Title missing', 'd' => 'Biggest miss for rankings & clicks. AI writes perfect ones using your voice.', 'btn' => 'Generate Title', 'id' => 'snap_title'];
								} elseif ( strlen($title_val) < 45 || strlen($title_val) > 62 ) {
									$ai_issues[] = ['sev' => 'med', 't' => 'Title length not ideal', 'd' => 'Best 50-60 characters. You have ' . strlen($title_val) . '.', 'btn' => 'Optimize Title', 'id' => 'snap_title'];
								}

								if ( trim($desc_val) === '' ) {
									$ai_issues[] = ['sev' => 'high', 't' => 'Meta description missing', 'd' => 'Google makes a boring one. Let AI create a compelling one from your training.', 'btn' => 'Generate Description', 'id' => 'snap_desc'];
								} elseif ( strlen($desc_val) < 110 || strlen($desc_val) > 158 ) {
									$ai_issues[] = ['sev' => 'med', 't' => 'Description length off', 'd' => 'Ideal is 120-156 chars for rich snippets.', 'btn' => 'Fix Description', 'id' => 'snap_desc'];
								}

								if ( trim($kw_val) === '' ) {
									$ai_issues[] = ['sev' => 'med', 't' => 'Focus keyword not set', 'd' => 'AI and search don\'t know the main topic.', 'btn' => 'Suggest Keywords', 'id' => 'snap_focus_kw'];
								}

								if ( $content_len > 0 && $content_len < 650 ) {
									$ai_issues[] = ['sev' => 'med', 't' => 'Content is quite short', 'd' => $content_len . ' characters. Longer helpful content usually ranks better.', 'btn' => 'Improve with AI', 'id' => 'snap_desc'];
								}

								if ( empty($ai_issues) ) {
									echo '<div style="padding:8px 10px; background:#e6f4ea; color:#1e8e3e; border-radius:6px; font-size:12px;">✅ Core fields look good. Copilot below can still improve clarity, voice, or SEO.</div>';
								} else {
									foreach ($ai_issues as $i) {
										$color = $i['sev'] === 'high' ? '#d93025' : '#f9ab00';
										echo '<div style="display:flex; gap:10px; padding:7px 0; border-bottom:1px solid #f1f3f4; font-size:12px;">';
										echo '<div style="width:5px; background:' . $color . '; border-radius:3px; margin:1px 0;"></div>';
										echo '<div style="flex:1; min-width:0;">';
										echo '<div style="font-weight:600; color:#202124;">' . esc_html($i['t']) . '</div>';
										echo '<div style="color:#5f6368; font-size:11px; line-height:1.3; margin:2px 0 5px;">' . esc_html($i['d']) . '</div>';
										echo '<button type="button" class="snap-btn snap-btn-ai-soft snap-btn-sm" style="font-size:11px; padding:2px 8px;" onclick="var f=document.getElementById(\'' . esc_js($i['id']) . '\'); if(f){f.focus(); f.scrollIntoView({block:\'center\', behavior:\'smooth\'});}">✦ ' . esc_html($i['btn']) . '</button>';
										echo '</div></div>';
									}
								}
							} catch (Throwable $e) {
								echo '<div style="padding:8px 10px; background:#fce8e6; color:#d93025; border-radius:6px; font-size:12px;">Analyzer temporarily unavailable (safe mode). Open the post editor for full tools.</div>';
							}
							?>
							<div style="margin-top:8px; font-size:10.5px; color:#5f6368;">Live analysis. One click jumps you to the field + AI button. Everything goes through your Review Queue.</div>
						</div>
					<?php endif; ?>

					<div class="snap-box" style="max-width:<?php echo $is_builder ? '100%' : '1100px'; ?>;margin:0 auto;border-radius:<?php echo $is_builder ? '0' : 'var(--snap-radius-md)'; ?>;box-shadow:<?php echo $is_builder ? 'none' : 'var(--snap-shadow-card)'; ?>;">
						<?php ( new Snap_Post_Meta() )->render_metabox( $post ); ?>
					</div>
				</div>
			</form>
		</div>
		<?php
	}

	public function handle_save(): void {
		$post_id = (int) ( $_POST['post_id'] ?? 0 );
		$post    = get_post( $post_id );
		if ( ! $post instanceof WP_Post || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( esc_html__( 'You cannot edit this post.', 'snaplevel' ) );
		}
		if ( ! class_exists( 'Snap_Post_Meta' ) ) {
			require_once SNAP_PLUGIN_DIR . 'includes/modules/seo-meta/class-template-variables.php';
			require_once SNAP_PLUGIN_DIR . 'includes/modules/seo-meta/class-post-meta.php';
		}
		// save_metabox verifies the snap_meta_save nonce printed by the metabox.
		( new Snap_Post_Meta() )->save_metabox( $post_id, $post );

		wp_safe_redirect( admin_url( 'admin.php?page=snap-seo-popup&post=' . $post_id . '&saved=1' ) );
		exit;
	}

	// ── Elementor launcher (clean: only the docked panel overlay DOM + styles for panel.
	// No floating button at all. Native top-bar icon injected via the enqueued JS.
	// The overlay iframe loads our branded popup with full Snaplevel SEO tools.
	// ─────────────────────────────────────────────────────────────────────

	public function print_elementor_launcher(): void {
		$post_id = (int) ( $_GET['post'] ?? 0 );
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$popup_url = admin_url( 'admin.php?page=snap-seo-popup&post=' . $post_id . '&context=builder' );

		// Only overlay styles (no floating button styles)
		wp_register_style( 'snap-builder-overlay', false, array(), SNAP_VERSION );
		wp_enqueue_style( 'snap-builder-overlay' );
		wp_add_inline_style( 'snap-builder-overlay', '
			#snap-el-overlay {
				position: fixed; inset: 0; z-index: 999999; display: none;
				background: rgba(15, 23, 42, .10);
				opacity: 0; transition: opacity .18s ease;
			}
			#snap-el-overlay.is-open { display: block; opacity: 1; }

			/* Docked side panel — flush right, premium minimal chrome */
			#snap-el-frame-wrap {
				position: absolute; top: 0; right: 0; bottom: 0; width: 380px; max-width: 82vw;
				background: var(--snap-bg-page, #F9FAFB);
				border-left: 1px solid var(--snap-border, #E5E7EB);
				overflow: hidden;
				box-shadow: -1px 0 0 rgba(15,23,42,.04);
				transform: translateX(100%);
				transition: transform .22s cubic-bezier(0.32, 0.72, 0, 1);
				will-change: transform;
			}
			#snap-el-overlay.is-open #snap-el-frame-wrap {
				transform: translateX(0);
			}
			#snap-el-frame { width: 100%; height: 100%; border: 0; background: #F9FAFB; }

			#snap-el-close {
				position: absolute; top: 10px; right: 10px; z-index: 1000000;
				width: 22px; height: 22px; border-radius: 4px; border: 0; cursor: pointer;
				background: rgba(255,255,255,.92); color: #64748B; font-size: 13px; line-height: 20px;
				box-shadow: 0 0 0 1px rgba(15,23,42,.08);
				transition: all .1s ease;
			}
			#snap-el-close:hover { background: #fff; color: #334155; }
		' );

		// Overlay container only (no floating button, no legacy tab script)
		?>
		<div id="snap-el-overlay">
			<button type="button" id="snap-el-close" aria-label="<?php esc_attr_e( 'Close', 'snaplevel' ); ?>">✕</button>
			<div id="snap-el-frame-wrap"><iframe id="snap-el-frame" title="Snaplevel SEO" loading="lazy"></iframe></div>
		</div>
		<?php

		// Note: JS + design-system already enqueued early via after_enqueue_scripts hook.
		// Localize also done there. This footer hook now purely for the DOM container.
	}

	// ── Admin-bar link for front-end builders ─────────────────────────────────

	public function admin_bar_link( WP_Admin_Bar $bar ): void {
		if ( is_admin() ) {
			return;
		}
		$post_id = get_queried_object_id();
		if ( ! $post_id || ! is_singular() || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$bar->add_node( array(
			'id'    => 'snap-seo',
			'title' => '📈 ' . __( 'Snaplevel SEO', 'snaplevel' ),
			'href'  => admin_url( 'admin.php?page=snap-seo-popup&post=' . $post_id ),
		) );
	}

	// ── Native builder enqueues (top bar icon + panel assets) ─────────────────

	public function enqueue_builder_assets_for_elementor(): void {
		wp_enqueue_style( 'snap-design-system', SNAP_PLUGIN_URL . 'assets/css/design-system.css', [], Snap_Assets::version( 'assets/css/design-system.css' ) );
		wp_enqueue_script( 'snap-builder-overlay', SNAP_PLUGIN_URL . 'assets/js/builder-overlay.js', [ 'jquery' ], Snap_Assets::version( 'assets/js/builder-overlay.js' ), true );
		$this->localize_for_builder( 'snap-builder-overlay' );
	}

	public function maybe_enqueue_for_bricks(): void {
		if ( ! defined( 'BRICKS_VERSION' ) ) {
			return;
		}
		if ( ! function_exists( 'bricks_is_builder_main' ) || ! bricks_is_builder_main() ) {
			return;
		}
		wp_enqueue_style( 'snap-design-system', SNAP_PLUGIN_URL . 'assets/css/design-system.css', [], Snap_Assets::version( 'assets/css/design-system.css' ) );
		wp_enqueue_script( 'snap-builder-overlay', SNAP_PLUGIN_URL . 'assets/js/builder-overlay.js', [ 'jquery' ], Snap_Assets::version( 'assets/js/builder-overlay.js' ), true );
		$this->localize_for_builder( 'snap-builder-overlay' );
	}

	private function localize_for_builder( string $handle ): void {
		$post_id = (int) ( $_GET['post'] ?? $_GET['post_id'] ?? 0 );
		wp_localize_script( $handle, 'SNAP_BUILDER_OVERLAY', [
			'popupUrl' => esc_url_raw( admin_url( 'admin.php?page=snap-seo-popup&post=' . $post_id . '&context=builder' ) ),
			'postId'   => $post_id,
			'restUrl'  => esc_url_raw( rest_url( 'wp/v2/posts' ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
		] );
	}
}
