<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Integrates with the WordPress Media Library:
 *  - Adds a "Compression" column in list view.
 *  - Adds a "Compress / Restore" action row in list view.
 *  - Adds a meta-box panel in the attachment edit screen.
 *  - Auto-compresses on upload (if setting enabled).
 */
class ICW_Media_Library {

    public function __construct() {
        add_filter( 'manage_media_columns',           array( $this, 'add_column'               ) );
        add_action( 'manage_media_custom_column',     array( $this, 'render_column'            ), 10, 2 );
        add_filter( 'media_row_actions',              array( $this, 'add_row_actions'          ), 10, 2 );
        add_action( 'add_meta_boxes',                 array( $this, 'add_attachment_meta_box'  ) );
        add_action( 'admin_enqueue_scripts',          array( $this, 'enqueue_assets'           ) );

        // Auto-compress AFTER all thumbnails are generated (not add_attachment which fires too early)
        add_filter( 'wp_generate_attachment_metadata', array( $this, 'maybe_auto_compress'    ), 99, 2 );
    }

    // ── Column ────────────────────────────────────────────────────────────────

    public function add_column( array $columns ): array {
        $columns['icw_status'] = __( 'Compression', 'snaplevel' );
        return $columns;
    }

    public function render_column( string $column, int $post_id ): void {
        if ( $column !== 'icw_status' ) {
            return;
        }
        if ( ! wp_attachment_is_image( $post_id ) ) {
            echo '<span class="icw-na">—</span>';
            return;
        }

        $processed = get_post_meta( $post_id, '_icw_processed', true );
        if ( ! $processed ) {
            echo '<button class="button button-small icw-compress-btn" data-id="' . esc_attr( $post_id ) . '">'
                . esc_html__( 'Compress', 'snaplevel' )
                . '</button>';
            return;
        }

        $orig = (int) get_post_meta( $post_id, '_icw_original_size',   true );
        $new  = (int) get_post_meta( $post_id, '_icw_compressed_size',  true );
        $webp = (int) get_post_meta( $post_id, '_icw_webp_count',       true );
        $pct  = $orig > 0 ? round( ( $orig - $new ) / $orig * 100, 1 ) : 0;

        self::render_status_badge( $post_id, $orig, $new, $pct, $webp );
    }

    public static function render_status_badge( int $id, int $orig, int $new, float $pct, int $webp ): void {
        $saved   = max( 0, $orig - $new );
        $color   = $pct >= 5 ? '#0d6efd' : ( $pct > 0 ? '#6c757d' : '#dc3545' );
        $label   = $pct > 0 ? "-{$pct}%" : ( $pct < 0 ? "+{$pct}%" : '±0%' );
        $webp_lbl = $webp > 0 ? " · WebP ×{$webp}" : '';
        ?>
        <span class="icw-badge" style="color:<?php echo esc_attr( $color ); ?>; font-weight:600;">
            <?php echo esc_html( $label ); ?>
        </span><br>
        <small class="icw-saved" style="color:#555;">
            <?php echo esc_html( size_format( $saved ) . ' saved' . $webp_lbl ); ?>
        </small><br>
        <button class="icw-recompress-btn icw-link-btn" data-id="<?php echo esc_attr( $id ); ?>">
            <?php esc_html_e( 'Re-compress', 'snaplevel' ); ?>
        </button>
        <?php if ( get_post_meta( $id, '_icw_webp_count', true ) ) : ?>
            &nbsp;|&nbsp;
            <button class="icw-delete-webp-btn icw-link-btn" data-id="<?php echo esc_attr( $id ); ?>">
                <?php esc_html_e( 'Del WebP', 'snaplevel' ); ?>
            </button>
        <?php endif; ?>
        <?php
    }

    // ── Row actions ───────────────────────────────────────────────────────────

    public function add_row_actions( array $actions, \WP_Post $post ): array {
        if ( strpos( $post->post_mime_type, 'image/' ) === false ) {
            return $actions;
        }
        $processed = get_post_meta( $post->ID, '_icw_processed', true );
        if ( $processed ) {
            $actions['icw_restore'] = sprintf(
                '<a href="#" class="icw-restore-btn" data-id="%d">%s</a>',
                $post->ID,
                esc_html__( 'Restore Original', 'snaplevel' )
            );
        }
        return $actions;
    }

    // ── Attachment edit meta-box ──────────────────────────────────────────────

    public function add_attachment_meta_box(): void {
        add_meta_box(
            'icw_attachment_info',
            __( 'Image Compression & WebP', 'snaplevel' ),
            array( $this, 'render_attachment_meta_box' ),
            'attachment',
            'side',
            'default'
        );
    }

    public function render_attachment_meta_box( \WP_Post $post ): void {
        if ( ! wp_attachment_is_image( $post->ID ) ) {
            echo '<p>' . esc_html__( 'Not a supported image type.', 'snaplevel' ) . '</p>';
            return;
        }

        $processed = get_post_meta( $post->ID, '_icw_processed', true );
        $orig      = (int) get_post_meta( $post->ID, '_icw_original_size',   true );
        $new       = (int) get_post_meta( $post->ID, '_icw_compressed_size',  true );
        $webp_cnt  = (int) get_post_meta( $post->ID, '_icw_webp_count',       true );
        $pct       = $orig > 0 ? round( ( $orig - $new ) / $orig * 100, 1 ) : 0;

        wp_nonce_field( 'icw_nonce', 'icw_metabox_nonce' );
        ?>
        <div id="icw-attachment-panel" data-id="<?php echo esc_attr( $post->ID ); ?>">
            <?php if ( $processed ) : ?>
                <table class="icw-info-table">
                    <tr><th><?php esc_html_e( 'Original size', 'snaplevel' ); ?></th><td><?php echo esc_html( size_format( $orig ) ); ?></td></tr>
                    <tr><th><?php esc_html_e( 'Compressed', 'snaplevel' ); ?></th><td><?php echo esc_html( size_format( $new ) ); ?></td></tr>
                    <tr><th><?php esc_html_e( 'Savings', 'snaplevel' ); ?></th><td><?php echo esc_html( "-{$pct}% · " . size_format( max( 0, $orig - $new ) ) ); ?></td></tr>
                    <tr><th><?php esc_html_e( 'WebP sizes', 'snaplevel' ); ?></th><td><?php echo esc_html( $webp_cnt > 0 ? $webp_cnt : __( 'none', 'snaplevel' ) ); ?></td></tr>
                </table>
                <p>
                    <button type="button" class="button button-small icw-compress-btn" data-id="<?php echo esc_attr( $post->ID ); ?>">
                        <?php esc_html_e( 'Re-compress', 'snaplevel' ); ?>
                    </button>
                    &nbsp;
                    <button type="button" class="button button-small icw-restore-btn" data-id="<?php echo esc_attr( $post->ID ); ?>">
                        <?php esc_html_e( 'Restore', 'snaplevel' ); ?>
                    </button>
                </p>
            <?php else : ?>
                <p><?php esc_html_e( 'This image has not been processed yet.', 'snaplevel' ); ?></p>
                <button type="button" class="button button-primary icw-compress-btn" data-id="<?php echo esc_attr( $post->ID ); ?>">
                    <?php esc_html_e( 'Compress & Convert', 'snaplevel' ); ?>
                </button>
            <?php endif; ?>
            <div class="icw-panel-status" style="margin-top:8px; font-style:italic; color:#555;"></div>
        </div>
        <?php
    }

    // ── Auto-compress on upload ───────────────────────────────────────────────

    /**
     * Hooked to wp_generate_attachment_metadata (priority 99) so ALL thumbnail
     * sizes exist on disk before we try to compress them.
     *
     * @param array $metadata      Attachment metadata (returned unchanged).
     * @param int   $attachment_id
     * @return array
     */
    public function maybe_auto_compress( array $metadata, int $attachment_id ): array {
        $settings = wp_parse_args(
            (array) get_option( 'icw_settings', array() ),
            ICW_Admin_Menu::default_settings()
        );
        if ( empty( $settings['auto_on_upload'] ) ) {
            return $metadata;
        }
        if ( ! wp_attachment_is_image( $attachment_id ) ) {
            return $metadata;
        }
        // Pass $metadata directly so thumbnails are processed even though the DB
        // hasn't been updated yet at this point in the wp_generate_attachment_metadata filter.
        ICW_Image_Processor::process_attachment( $attachment_id, $settings, $metadata );
        return $metadata; // must return metadata unchanged
    }

    // ── Assets ────────────────────────────────────────────────────────────────

    public function enqueue_assets( string $hook ): void {
        $media_hooks = array( 'upload.php', 'post.php', 'post-new.php' );
        if ( ! in_array( $hook, $media_hooks, true ) ) {
            return;
        }
        $this->do_enqueue();
    }

    private function do_enqueue(): void {
        wp_enqueue_style(
            'icw-admin',
            ICW_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            ICW_VERSION
        );
        wp_enqueue_script(
            'icw-admin',
            ICW_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery' ),
            ICW_VERSION,
            true
        );
        wp_localize_script( 'icw-admin', 'ICW', array(
            'nonce'   => wp_create_nonce( 'icw_nonce' ),
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'i18n'    => array(
                'compressing' => __( 'Compressing…', 'snaplevel' ),
                'restoring'   => __( 'Restoring…', 'snaplevel' ),
                'done'        => __( 'Done!', 'snaplevel' ),
                'error'       => __( 'Error', 'snaplevel' ),
            ),
        ) );
    }
}
