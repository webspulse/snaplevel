<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * ICW_Compression_Ajax — Compression Module
 * All AJAX handlers for the Compression feature live here.
 * 100% isolated — does not depend on any other module.
 */
class ICW_Compression_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_icw_bulk_compress_next',  array( $this, 'bulk_compress_next'  ) );
        add_action( 'wp_ajax_icw_get_compression_stats', array( $this, 'get_stats'         ) );
        add_action( 'wp_ajax_icw_get_detailed_scanner',  array( $this, 'get_detailed_scanner') );
        add_action( 'wp_ajax_icw_restore_image',       array( $this, 'restore_image'       ) );
    }

    /**
     * Called repeatedly by the frontend progress loop.
     * Finds the next unprocessed large image and compresses it.
     * Returns per-image savings data so the UI can show live stats.
     */
    public function bulk_compress_next(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        if ( ! current_user_can('upload_files') ) {
            wp_send_json_error('Permission denied.');
        }

        // Target images > 100KB not yet processed in this session
        $ids = get_posts( array(
            'post_type'      => 'attachment',
            'post_mime_type' => array('image/jpeg', 'image/png'),
            'post_status'    => 'inherit',
            'posts_per_page' => 200,
            'fields'         => 'ids',
        ) );

        $target_id    = 0;
        $original_size = 0;

        foreach ( $ids as $id ) {
            $file = get_attached_file( $id );
            if ( ! $file || ! file_exists( $file ) ) { continue; }
            $size = filesize( $file );
            if ( $size <= 102400 ) { continue; }

            // Skip if processed within last 10 minutes (prevents infinite loops)
            $last = (int) get_post_meta( $id, '_icw_processed', true );
            if ( time() - $last < 600 ) { continue; }

            $target_id    = $id;
            $original_size = $size;
            break;
        }

        if ( ! $target_id ) {
            wp_send_json_success( array( 'done' => true ) );
            return;
        }

        $settings = get_option('icw_settings', array());
        $result = ICW_Image_Processor::process_attachment( $target_id, $settings );
        $new_size = (int) get_post_meta( $target_id, '_icw_compressed_size', true );
        if (!$new_size) $new_size = filesize(get_attached_file($target_id));

        $filename = basename( get_attached_file( $target_id ) );
        $saved_kb = round( ( $original_size - $new_size ) / 1024, 1 );
        $saved_pct = $original_size > 0 ? round( (($original_size - $new_size) / $original_size) * 100 ) : 0;

        wp_send_json_success( array(
            'done'         => false,
            'id'           => $target_id,
            'filename'     => $filename,
            'original_kb'  => round( $original_size / 1024, 1 ),
            'new_kb'       => round( $new_size / 1024, 1 ),
            'saved_kb'     => $saved_kb,
            'saved_pct'    => $saved_pct,
        ) );
    }

    /**
     * Returns totals for the stats bar at the top of the compression page.
     */
    public function get_stats(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );

        $all = get_posts( array(
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'post_status'    => 'inherit',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ) );

        $total      = count( $all );
        $over_100kb = 0;
        $processed  = 0;
        $saved_bytes = 0;

        foreach ( $all as $id ) {
            $file = get_attached_file( $id );
            if ( ! $file || ! file_exists( $file ) ) { continue; }
            if ( get_post_meta( $id, '_icw_processed', true ) ) {
                $processed++;
                $orig  = (int) get_post_meta( $id, '_icw_original_size', true );
                $cur   = (int) get_post_meta( $id, '_icw_compressed_size', true );
                if ( $orig && $cur ) { $saved_bytes += max(0, $orig - $cur); }
            }
            if ( filesize( $file ) > 102400 ) { $over_100kb++; }
        }

        wp_send_json_success( array(
            'total'       => $total,
            'over_100kb'  => $over_100kb,
            'processed'   => $processed,
            'remaining'   => $over_100kb,
            'saved_bytes' => $saved_bytes,
            'saved_fmt'   => size_format( $saved_bytes ),
        ) );
    }

    /**
     * Restores a single image from its backup.
     */
    public function restore_image(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        if ( ! current_user_can('upload_files') ) {
            wp_send_json_error('Permission denied.');
        }
        $id = intval( $_POST['id'] ?? 0 );
        if ( ! $id ) { wp_send_json_error('Invalid image ID.'); }

        $result = ICW_Image_Processor::restore_attachment( $id );
        if ( $result['success'] ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result['message'] );
        }
    }

    public function get_detailed_scanner(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        $offset = intval( $_POST['offset'] ?? 0 );
        $limit  = intval( $_POST['limit'] ?? 30 );

        $all_ids = get_posts( array(
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'post_status'    => 'inherit',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ) );

        $total = count($all_ids);
        $slice = array_slice($all_ids, $offset, $limit);
        $items = array();

        foreach ( $slice as $id ) {
            $file = get_attached_file( $id );
            $size = ( $file && file_exists( $file ) ) ? filesize( $file ) : 0;
            $is_compressed = (bool) get_post_meta( $id, '_icw_processed', true );
            $alt_text = get_post_meta( $id, '_wp_attachment_image_alt', true );

            $items[] = array(
                'id'         => $id,
                'title'      => get_the_title($id),
                'thumb'      => wp_get_attachment_image_url($id, 'thumbnail'),
                'size'       => $size,
                'compressed' => $is_compressed,
                'has_alt'    => !empty(trim($alt_text))
            );
        }

        wp_send_json_success( array(
            'total' => $total,
            'items' => $items
        ) );
    }
}
