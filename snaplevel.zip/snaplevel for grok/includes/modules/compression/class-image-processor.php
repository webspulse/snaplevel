<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_Image_Processor {

    public static function process_attachment( int $attachment_id, array $settings, ?array $pre_meta = null ): array {
        if ( ! wp_attachment_is_image( $attachment_id ) ) {
            return self::err( 'Not an image attachment.' );
        }

        $mime = get_post_mime_type( $attachment_id );
        $allowed = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' );
        if ( ! in_array( $mime, $allowed, true ) ) {
            return self::err( "Unsupported MIME type: {$mime}" );
        }

        $full_path = get_attached_file( $attachment_id );
        if ( ! $full_path || ! file_exists( $full_path ) ) {
            return self::err( 'Source file not found on disk.' );
        }

        $raw_meta = $pre_meta !== null ? $pre_meta : wp_get_attachment_metadata( $attachment_id );
        $meta     = is_array( $raw_meta ) ? $raw_meta : array();

        $quality       = max( 1, min( 100, (int) ( $settings['quality'] ?? 82 ) ) );
        $compress_orig = ! empty( $settings['compress_originals'] );
        $convert_webp  = ! empty( $settings['convert_to_webp'] );
        $do_backup     = ! empty( $settings['backup_originals'] );

        $original_size = (int) @filesize( $full_path );
        $webp_created  = 0;

        $files = self::collect_files( $full_path, $meta );

        foreach ( $files as $file_path ) {
            if ( ! file_exists( $file_path ) ) {
                continue;
            }

            $file_mime = self::mime_from_path( $file_path );
            if ( ! $file_mime || $file_mime === 'image/webp' ) {
                continue;
            }

            if ( $do_backup ) {
                self::backup_file( $file_path );
            }

            if ( $compress_orig ) {
                // If this is the full-size original and it's > 100KB, enforce strict compression
                if ( $file_path === $full_path && @filesize($file_path) > 102400 && in_array($file_mime, ['image/jpeg', 'image/png']) ) {
                    self::compress_strict_100kb( $file_path, $file_mime, $quality );
                } else {
                    self::compress_in_place( $file_path, $file_mime, $quality );
                }
            }

            if ( $convert_webp ) {
                if ( self::create_webp( $file_path, $file_mime, $quality ) ) {
                    $webp_created++;
                }
            }
        }

        clearstatcache( true, $full_path );
        $new_size    = (int) @filesize( $full_path );
        
        // Final fallback if STILL somehow > 100kb (often WP PNG issue)
        if ( $new_size > 102400 && in_array($mime, ['image/jpeg', 'image/png']) ) {
             self::compress_strict_100kb( $full_path, $mime, 65, true );
             clearstatcache( true, $full_path );
             $new_size = (int) @filesize( $full_path );
        }

        $savings_pct = $original_size > 0
            ? round( ( $original_size - $new_size ) / $original_size * 100, 1 )
            : 0.0;

        update_post_meta( $attachment_id, '_icw_original_size',   $original_size );
        update_post_meta( $attachment_id, '_icw_compressed_size', $new_size );
        update_post_meta( $attachment_id, '_icw_webp_count',      $webp_created );
        update_post_meta( $attachment_id, '_icw_processed',       time() );

        // Update metadata if dimensions changed
        $new_dims = wp_getimagesize( $full_path );
        if ( $new_dims && isset($meta['width']) && ($meta['width'] !== $new_dims[0] || $meta['height'] !== $new_dims[1]) ) {
            $meta['width'] = $new_dims[0];
            $meta['height'] = $new_dims[1];
            wp_update_attachment_metadata( $attachment_id, $meta );
        }

        return array(
            'success'       => true,
            'message'       => 'Processed successfully.',
            'original_size' => $original_size,
            'new_size'      => $new_size,
            'savings_bytes' => $original_size - $new_size,
            'savings_pct'   => $savings_pct,
            'webp_sizes'    => $webp_created,
        );
    }

    public static function restore_attachment( int $attachment_id ): array {
        $full_path = get_attached_file( $attachment_id );
        if ( ! $full_path ) return self::err( 'File not found.' );

        $upload_dir   = wp_upload_dir();
        $uploads_base = realpath( $upload_dir['basedir'] );
        if ( ! $uploads_base || ! self::path_within_directory( $full_path, $uploads_base ) ) {
            return self::err( 'Invalid file path.' );
        }

        $raw  = wp_get_attachment_metadata( $attachment_id );
        $meta = is_array( $raw ) ? $raw : array();
        $files = self::collect_files( $full_path, $meta );
        $ok    = 0;

        foreach ( $files as $file_path ) {
            if ( ! self::path_within_directory( $file_path, $uploads_base ) ) {
                continue;
            }
            $backup = self::backup_path( $file_path );
            if ( ! self::path_within_directory( $backup, $uploads_base . '/icw-backups' ) ) {
                continue;
            }
            if ( file_exists( $backup ) && self::path_within_directory( $file_path, $uploads_base ) ) {
                if ( @copy( $backup, $file_path ) ) $ok++;
            }
        }

        delete_post_meta( $attachment_id, '_icw_original_size' );
        delete_post_meta( $attachment_id, '_icw_compressed_size' );
        delete_post_meta( $attachment_id, '_icw_webp_count' );
        delete_post_meta( $attachment_id, '_icw_processed' );

        return $ok > 0
            ? array( 'success' => true, 'message' => "Restored {$ok} file(s) from backup." )
            : self::err( 'No backup files found for this image.' );
    }

    public static function get_webp_url( string $url ): ?string {
        $upload_dir = wp_upload_dir();
        $base_url   = $upload_dir['baseurl'];
        $base_dir   = $upload_dir['basedir'];

        if ( strpos( $url, $base_url ) === false ) return null;

        $rel      = ltrim( str_replace( $base_url, '', $url ), '/' );
        $rel_webp = preg_replace( '/\.(jpe?g|png|gif)$/i', '.webp', $rel );

        if ( $rel_webp === $rel ) return null;

        $webp_path = $base_dir . '/' . $rel_webp;
        return file_exists( $webp_path ) ? $base_url . '/' . $rel_webp : null;
    }

    /** Strict <100KB Algorithm */
    private static function compress_strict_100kb( string $path, string $mime, int $initial_quality, bool $force_extreme = false ): void {
        $editor = wp_get_image_editor( $path );
        if ( is_wp_error( $editor ) ) return;

        // Step 1: Aggressive Resize
        $dims = $editor->get_size();
        if ( ! is_wp_error( $dims ) ) {
            $max_w = $force_extreme ? 800 : 1024;
            $max_h = $force_extreme ? 800 : 1024;
            if ( $dims['width'] > $max_w || $dims['height'] > $max_h ) {
                $editor->resize( $max_w, $max_h, false );
                $editor->save( $path, $mime );
            }
        }

        clearstatcache( true, $path );
        $size = filesize( $path );
        if ( $size <= 102400 ) return;

        // Step 2: Iterative quality reduction
        $q = $initial_quality;
        while ( $size > 102400 && $q >= 60 ) {
            self::compress_in_place( $path, $mime, $q );
            clearstatcache( true, $path );
            $size = filesize( $path );
            $q -= 10;
        }

        // Step 3: Extreme fallback - resize to 600px
        if ( $size > 102400 ) {
            $editor = wp_get_image_editor( $path );
            if ( ! is_wp_error( $editor ) ) {
                $editor->resize( 600, 600, false );
                $editor->set_quality( 65 );
                $editor->save( $path, $mime );
            }
        }
    }

    private static function collect_files( string $full_path, array $meta ): array {
        $files = array( $full_path );
        $dir   = dirname( $full_path );
        foreach ( ( $meta['sizes'] ?? array() ) as $size_data ) {
            if ( ! empty( $size_data['file'] ) ) $files[] = $dir . '/' . $size_data['file'];
        }
        return array_unique( $files );
    }

    private static function compress_in_place( string $path, string $mime, int $quality ): bool {
        if ( self::has_imagick() ) return self::compress_imagick( $path, $mime, $quality );
        if ( self::has_gd() ) return self::compress_gd( $path, $mime, $quality );
        return false;
    }

    private static function compress_imagick( string $path, string $mime, int $quality ): bool {
        try {
            $im = new \Imagick( $path );
            if ( $mime === 'image/jpeg' ) {
                $im->setImageCompressionQuality( $quality );
                $im->stripImage();
                $im->setInterlaceScheme( \Imagick::INTERLACE_JPEG );
                $im->setSamplingFactors( array( '2x2', '1x1', '1x1' ) );
            } elseif ( $mime === 'image/png' ) {
                $im->stripImage();
                $png_level = max( 0, (int) round( 9 - ( $quality / 100 ) * 9 ) );
                $im->setImageCompression( \Imagick::COMPRESSION_ZIP );
                $im->setImageCompressionQuality( $png_level * 10 );
            } else {
                $im->stripImage();
            }
            $result = $im->writeImage( $path );
            $im->destroy();
            return (bool) $result;
        } catch ( \Exception $e ) {
            return false;
        }
    }

    private static function compress_gd( string $path, string $mime, int $quality ): bool {
        $image = self::gd_create( $path, $mime );
        if ( ! $image ) return false;

        if ( $mime === 'image/jpeg' ) {
            $result = imagejpeg( $image, $path, $quality );
        } elseif ( $mime === 'image/png' ) {
            imagesavealpha( $image, true );
            $png_level = max( 0, (int) round( 9 - ( $quality / 100 ) * 9 ) );
            $result    = imagepng( $image, $path, $png_level );
        } else {
            $result = imagegif( $image, $path );
        }
        imagedestroy( $image );
        return (bool) $result;
    }

    private static function create_webp( string $path, string $mime, int $quality ): bool {
        $webp_path = (string) preg_replace( '/\.(jpe?g|png|gif)$/i', '.webp', $path );
        if ( $webp_path === $path ) return false;

        if ( self::has_imagick() ) return self::convert_imagick_webp( $path, $webp_path, $quality );
        if ( self::has_gd() && function_exists( 'imagewebp' ) ) return self::convert_gd_webp( $path, $mime, $webp_path, $quality );
        return false;
    }

    private static function convert_imagick_webp( string $src, string $dest, int $quality ): bool {
        try {
            $im = new \Imagick( $src );
            $im->setImageFormat( 'webp' );
            $im->setImageCompressionQuality( $quality );
            $im->stripImage();
            $result = $im->writeImage( $dest );
            $im->destroy();
            return (bool) $result;
        } catch ( \Exception $e ) {
            return false;
        }
    }

    private static function convert_gd_webp( string $src, string $mime, string $dest, int $quality ): bool {
        $image = self::gd_create( $src, $mime );
        if ( ! $image ) return false;
        if ( $mime === 'image/png' || $mime === 'image/gif' ) {
            imagepalettetotruecolor( $image );
            imagealphablending( $image, true );
            imagesavealpha( $image, true );
        }
        $result = imagewebp( $image, $dest, $quality );
        imagedestroy( $image );
        return (bool) $result;
    }

    private static function gd_create( string $path, string $mime ) {
        if ( $mime === 'image/jpeg' ) return @imagecreatefromjpeg( $path );
        if ( $mime === 'image/png' ) return @imagecreatefrompng( $path );
        if ( $mime === 'image/gif' ) return @imagecreatefromgif( $path );
        return false;
    }

    private static function backup_file( string $path ): bool {
        $backup = self::backup_path( $path );
        if ( file_exists( $backup ) ) return true;
        $dir = dirname( $backup );
        if ( ! is_dir( $dir ) ) wp_mkdir_p( $dir );
        return @copy( $path, $backup );
    }

    private static function backup_path( string $path ): string {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'];
        $rel        = ltrim( str_replace( $base_dir, '', $path ), '/\\' );
        return $base_dir . '/icw-backups/' . $rel;
    }

    /** Verify a path resolves inside an allowed directory (blocks path traversal). */
    private static function path_within_directory( string $path, string $directory ): bool {
        $base = realpath( $directory );
        if ( ! $base ) {
            return false;
        }

        $target = realpath( $path );
        if ( ! $target ) {
            $parent = realpath( dirname( $path ) );
            if ( ! $parent ) {
                return false;
            }
            $target = $parent . DIRECTORY_SEPARATOR . basename( $path );
        }

        $base   = wp_normalize_path( $base );
        $target = wp_normalize_path( $target );

        return $target === $base || 0 === strpos( trailingslashit( $target ), trailingslashit( $base ) );
    }

    private static function mime_from_path( string $path ): ?string {
        $ext = strtolower( (string) pathinfo( $path, PATHINFO_EXTENSION ) );
        if ( $ext === 'jpg' || $ext === 'jpeg' ) return 'image/jpeg';
        if ( $ext === 'png' ) return 'image/png';
        if ( $ext === 'gif' ) return 'image/gif';
        if ( $ext === 'webp' ) return 'image/webp';
        return null;
    }

    private static function has_imagick(): bool { return extension_loaded( 'imagick' ) && class_exists( 'Imagick' ); }
    private static function has_gd(): bool { return extension_loaded( 'gd' ) && function_exists( 'gd_info' ); }
    private static function err( string $msg ): array { return array( 'success' => false, 'message' => $msg ); }
}
