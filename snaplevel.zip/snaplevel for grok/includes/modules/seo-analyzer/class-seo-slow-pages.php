<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_SEO_Slow_Pages {

    public function __construct() {
        add_action( 'wp_ajax_icw_scan_slow_pages', array( $this, 'ajax_scan_slow_pages' ) );
    }

    public function ajax_scan_slow_pages(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        $urls_to_check = array( home_url('/') );
        
        $random_post = get_posts( array( 'post_type' => 'post', 'posts_per_page' => 1, 'orderby' => 'rand' ) );
        if ( !empty($random_post) ) {
            $urls_to_check[] = get_permalink( $random_post[0]->ID );
        }

        $results = array();
        foreach ( $urls_to_check as $url ) {
            $start = microtime(true);
            $res = wp_remote_get( $url );
            $end = microtime(true);
            
            $time = round( ($end - $start) * 1000 ); // ms
            $results[] = array(
                'url'  => $url,
                'time' => $time . 'ms',
                'slow' => $time > 1500
            );
        }

        wp_send_json_success( array( 'pages' => $results ) );
    }
}
