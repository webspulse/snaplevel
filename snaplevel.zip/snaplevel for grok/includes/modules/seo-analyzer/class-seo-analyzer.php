<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ICW_SEO_Scanner — SEO Analyzer Module Loader
 *
 * Loads all individual SEO audit sub-modules from the seo-analyzer directory.
 * Each sub-module is a standalone class that registers its own AJAX handler.
 */
class ICW_SEO_Scanner {

    public function __construct() {
        $this->load_dependencies();

        new ICW_SEO_Large_Images();
        new ICW_SEO_Sitemap();
        new ICW_SEO_Orphans();
        new ICW_SEO_Slow_Pages();
        new ICW_SEO_Redirects();
        new ICW_SEO_CSS();
        new ICW_SEO_Meta();
    }

    private function load_dependencies(): void {
        $dir = ICW_PLUGIN_DIR . 'includes/modules/seo-analyzer/';
        $files = array(
            'class-seo-large-images.php',
            'class-seo-sitemap.php',
            'class-seo-orphans.php',
            'class-seo-slow-pages.php',
            'class-seo-redirects.php',
            'class-seo-css.php',
            'class-seo-meta.php',
        );

        foreach ( $files as $file ) {
            require_once $dir . $file;
        }
    }

    /**
     * Creates the seo_history database table on plugin activation.
     */
    public static function create_tables(): void {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'icw_seo_history';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            meta_description text,
            is_indexable tinyint(1) NOT NULL DEFAULT 1,
            checked_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id),
            KEY post_id (post_id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }
}
