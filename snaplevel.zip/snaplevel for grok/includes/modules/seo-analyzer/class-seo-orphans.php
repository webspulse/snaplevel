<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_SEO_Orphans {

    public function __construct() {
        add_action( 'wp_ajax_icw_scan_orphans', array( $this, 'ajax_scan_orphans' ) );
    }

    public function ajax_scan_orphans(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        
        $limit  = 20; // Scan 20 at a time for performance

        $posts = get_posts( array(
            'post_type'      => array('post', 'page'),
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'fields'         => 'ids'
        ) );

        if ( empty( $posts ) ) {
            wp_send_json_success( array( 'done' => true, 'orphans' => array() ) );
        }

        global $wpdb;
        $orphans = array();

        foreach ( $posts as $id ) {
            $permalink = get_permalink( $id );
            $path = parse_url( $permalink, PHP_URL_PATH );
            
            $count = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_content LIKE %s AND ID != %d AND post_status = 'publish'",
                '%' . $wpdb->esc_like( $path ) . '%',
                $id
            ) );

            if ( $count == 0 ) {
                $orphans[] = array(
                    'id'    => $id,
                    'title' => get_the_title( $id ),
                    'url'   => $permalink
                );
            }
        }

        // Cache the result count
        set_transient( 'snap_seo_orphan_count', count( $orphans ), 86400 );

        wp_send_json_success( array(
            'done'    => true,
            'orphans' => $orphans
        ) );
    }
}
