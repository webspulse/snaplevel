<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_SEO_Sitemap {

    public function __construct() {
        add_action( 'wp_ajax_icw_scan_sitemap', array( $this, 'ajax_scan_sitemap' ) );
    }

    public function ajax_scan_sitemap(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permission denied.' );
        }

        $sitemap_url = home_url( '/wp-sitemap.xml' );
        $response = wp_remote_get( $sitemap_url );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            $sitemap_url = home_url( '/sitemap_index.xml' );
            $response = wp_remote_get( $sitemap_url );
        }

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            wp_send_json_error( 'Could not find a valid sitemap at ' . esc_url($sitemap_url) );
        }

        $body = wp_remote_retrieve_body( $response );
        preg_match_all( '/<loc>(.*?)<\/loc>/', $body, $matches );

        $urls = !empty($matches[1]) ? array_slice($matches[1], 0, 20) : array();
        $redirects = array();

        foreach ( $urls as $url ) {
            $head = wp_remote_head( $url, array( 'redirection' => 0 ) );
            if ( ! is_wp_error( $head ) ) {
                $code = wp_remote_retrieve_response_code( $head );
                if ( $code >= 300 && $code < 400 ) {
                    $redirects[] = array(
                        'url'  => $url,
                        'code' => $code,
                        'to'   => wp_remote_retrieve_header( $head, 'location' )
                    );
                }
            }
        }

        wp_send_json_success( array(
            'redirects' => $redirects,
            'scanned'   => count($urls)
        ) );
    }
}
