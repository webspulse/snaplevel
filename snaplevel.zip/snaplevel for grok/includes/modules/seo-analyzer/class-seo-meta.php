<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_SEO_Meta {

    public function __construct() {
        add_action( 'wp_ajax_icw_scan_meta', array( $this, 'ajax_scan_meta' ) );
    }

    public function ajax_scan_meta(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        global $wpdb;
        $table_name = $wpdb->prefix . 'icw_seo_history';

        $posts = get_posts( array( 'post_type' => array('post', 'page'), 'posts_per_page' => 10 ) );
        $changes = array();

        foreach ( $posts as $p ) {
            $noindex = get_post_meta( $p->ID, '_yoast_wpseo_meta-robots-noindex', true ) === '1';
            $current_desc = get_post_meta( $p->ID, '_yoast_wpseo_metadesc', true );
            
            $history = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE post_id = %d ORDER BY id DESC LIMIT 1", $p->ID ) );

            if ( $history ) {
                if ( $history->is_indexable != !$noindex ) {
                    $changes[] = "Indexability changed for {$p->post_title}";
                }
                if ( $history->meta_description != $current_desc ) {
                    $changes[] = "Meta description changed for {$p->post_title}";
                }
            }

            $wpdb->insert( $table_name, array(
                'post_id'          => $p->ID,
                'meta_description' => $current_desc ? $current_desc : '',
                'is_indexable'     => $noindex ? 0 : 1,
                'checked_at'       => current_time('mysql')
            ) );
        }

        wp_send_json_success( array( 'changes' => $changes ) );
    }
}
