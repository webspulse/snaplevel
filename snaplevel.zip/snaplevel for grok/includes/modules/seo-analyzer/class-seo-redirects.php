<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_SEO_Redirects {

    public function __construct() {
        add_action( 'wp_ajax_icw_scan_redirects', array( $this, 'ajax_scan_redirects' ) );
    }

    public function ajax_scan_redirects(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        $posts = get_posts( array( 'post_type' => array('post', 'page'), 'posts_per_page' => 10 ) );
        $redirect_links = array();

        foreach ( $posts as $p ) {
            preg_match_all( '/href=["\'](' . preg_quote(home_url(), '/') . '[^"\']+)["\']/', $p->post_content, $matches );
            if ( !empty($matches[1]) ) {
                $links = array_unique($matches[1]);
                foreach ( array_slice($links, 0, 5) as $link ) {
                    $head = wp_remote_head( $link, array( 'redirection' => 0 ) );
                    if ( ! is_wp_error( $head ) ) {
                        $code = wp_remote_retrieve_response_code( $head );
                        if ( $code >= 300 && $code < 400 ) {
                            $redirect_links[] = array(
                                'post_id' => $p->ID,
                                'title'   => get_the_title($p->ID),
                                'link'    => $link,
                                'code'    => $code
                            );
                        }
                    }
                }
            }
        }

        // Cache the result count
        set_transient( 'snap_seo_redirect_count', count( $redirect_links ), 86400 );

        wp_send_json_success( array( 'links' => $redirect_links ) );
    }
}
