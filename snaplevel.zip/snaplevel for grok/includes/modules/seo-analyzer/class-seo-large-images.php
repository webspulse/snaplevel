<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_SEO_Large_Images {

    public function __construct() {
        add_action( 'wp_ajax_icw_bulk_compress_next', array( $this, 'ajax_bulk_compress_next' ) );
    }

    public function ajax_bulk_compress_next(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        if ( ! current_user_can( 'upload_files' ) ) {
            wp_send_json_error( 'Permission denied.' );
        }

        // Find the next image > 100KB that hasn't been compressed today
        $attachments = get_posts( array(
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'post_status'    => 'inherit',
            'posts_per_page' => 50, // Get a batch
            'fields'         => 'ids',
        ) );

        $target_id = 0;
        foreach ( $attachments as $id ) {
            $file = get_attached_file( $id );
            if ( $file && file_exists( $file ) ) {
                $size = filesize( $file );
                if ( $size > 102400 ) { // 100KB
                    // Check if we just processed it recently to avoid infinite loops if it refuses to go under 100kb
                    $last_processed = (int) get_post_meta( $id, '_icw_processed', true );
                    if ( time() - $last_processed > 86400 ) { // Not processed in 24 hours
                        $target_id = $id;
                        break;
                    }
                }
            }
        }

        if ( ! $target_id ) {
            wp_send_json_success( array( 'done' => true ) );
        }

        $result = ICW_Image_Processor::compress_below_100kb( $target_id );
        if ( $result['success'] ) {
            wp_send_json_success( array( 'done' => false, 'processed_id' => $target_id ) );
        } else {
            // Force update meta so we don't infinitely retry a failing image
            update_post_meta( $target_id, '_icw_processed', time() );
            wp_send_json_success( array( 'done' => false, 'processed_id' => $target_id, 'error' => $result['message'] ) );
        }
    }
}
