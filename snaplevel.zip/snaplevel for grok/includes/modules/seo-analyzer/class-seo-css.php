<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ICW_SEO_CSS {

    public function __construct() {
        add_action( 'wp_ajax_icw_scan_css', array( $this, 'ajax_scan_css' ) );
    }

    public function ajax_scan_css(): void {
        check_ajax_referer( 'icw_nonce', 'nonce' );
        $theme_dir = get_stylesheet_directory();
        $files = glob( $theme_dir . '/*.css' );
        $large_css = array();

        if ( $files ) {
            foreach ( $files as $file ) {
                $size = filesize( $file );
                if ( $size > 51200 ) { // > 50KB
                    $large_css[] = array(
                        'file' => basename($file),
                        'size' => size_format($size)
                    );
                }
            }
        }

        wp_send_json_success( array( 'css' => $large_css ) );
    }
}
