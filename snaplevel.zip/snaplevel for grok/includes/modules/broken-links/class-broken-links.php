<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Broken_Links — site-wide link checker.
 *
 * Batched AJAX scan (never times out on large sites): first pass collects
 * every link from published content into a queue, then batches of links
 * are checked with HEAD/GET requests. Broken results land in a table with
 * one-click fix actions (edit URL, unlink, ignore). A daily cron re-checks
 * known broken links so fixed ones clear themselves.
 */
final class Snap_Broken_Links {

	const QUEUE_OPTION = 'snap_bl_queue';
	const CRON_HOOK    = 'snap_broken_links_recheck';

	public function __construct() {
		add_action( 'wp_ajax_snap_bl_collect', array( $this, 'ajax_collect' ) );
		add_action( 'wp_ajax_snap_bl_batch',   array( $this, 'ajax_batch' ) );
		add_action( 'wp_ajax_snap_bl_action',  array( $this, 'ajax_action' ) );
		add_action( self::CRON_HOOK,           array( $this, 'cron_recheck' ) );

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'snap_broken_links';
	}

	public static function create_table(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( 'CREATE TABLE ' . self::table() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			url VARCHAR(1000) NOT NULL,
			anchor VARCHAR(255) NOT NULL DEFAULT '',
			status SMALLINT NOT NULL DEFAULT 0,
			checked DATETIME NOT NULL,
			ignored TINYINT(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY post_idx (post_id)
		) " . $wpdb->get_charset_collate() . ';' );
		update_option( 'snap_bl_db', 1 );
	}

	public static function maybe_create_table(): void {
		if ( ! get_option( 'snap_bl_db' ) ) {
			self::create_table();
		}
	}

	// ── Scan: collect queue ───────────────────────────────────────────────────

	public function ajax_collect(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}
		self::maybe_create_table();

		global $wpdb;
		$posts = $wpdb->get_results(
			"SELECT ID, post_content FROM {$wpdb->posts}
			 WHERE post_status = 'publish' AND post_type NOT IN ('attachment','revision','nav_menu_item')
			 ORDER BY ID DESC LIMIT 2000",
			ARRAY_A
		);

		$queue = array();
		$seen  = array();
		foreach ( (array) $posts as $post ) {
			if ( ! preg_match_all( '~<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>~is', (string) $post['post_content'], $matches, PREG_SET_ORDER ) ) {
				continue;
			}
			foreach ( $matches as $m ) {
				$url = trim( $m[1] );
				if ( '' === $url || '#' === $url[0] || 0 === strpos( $url, 'mailto:' ) || 0 === strpos( $url, 'tel:' ) || 0 === strpos( $url, 'javascript:' ) ) {
					continue;
				}
				if ( 0 === strpos( $url, '/' ) ) {
					$url = home_url( $url );
				}
				if ( 0 !== strpos( $url, 'http' ) ) {
					continue;
				}
				$key = md5( $url );
				if ( isset( $seen[ $key ] ) ) {
					continue; // Check each unique URL once; remember one source post.
				}
				$seen[ $key ] = true;
				$queue[]      = array(
					'post_id' => (int) $post['ID'],
					'url'     => substr( $url, 0, 1000 ),
					'anchor'  => substr( wp_strip_all_tags( $m[2] ), 0, 255 ),
				);
			}
		}

		// Fresh scan: clear previous non-ignored results and store the queue.
		$wpdb->query( 'DELETE FROM ' . self::table() . ' WHERE ignored = 0' ); // phpcs:ignore
		update_option( self::QUEUE_OPTION, $queue, false );

		wp_send_json_success( array( 'total' => count( $queue ) ) );
	}

	// ── Scan: process a batch ─────────────────────────────────────────────────

	public function ajax_batch(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$queue = get_option( self::QUEUE_OPTION, array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			wp_send_json_success( array( 'done' => true, 'remaining' => 0, 'broken_found' => 0 ) );
		}

		$batch = array_splice( $queue, 0, 10 );
		update_option( self::QUEUE_OPTION, $queue, false );

		$broken = 0;
		foreach ( $batch as $item ) {
			$status = self::check_url( (string) $item['url'] );
			if ( $status >= 400 || 0 === $status ) {
				self::record_broken( (int) $item['post_id'], (string) $item['url'], (string) $item['anchor'], $status );
				$broken++;
			}
		}

		wp_send_json_success( array(
			'done'         => empty( $queue ),
			'remaining'    => count( $queue ),
			'broken_found' => $broken,
		) );
	}

	/** @return int HTTP status, 0 = unreachable. */
	public static function check_url( string $url ): int {
		$args = array(
			'timeout'     => 8,
			'redirection' => 3,
			'user-agent'  => 'Mozilla/5.0 (compatible; Snaplevel Link Checker; +' . home_url() . ')',
		);
		$response = wp_remote_head( $url, $args );
		$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );

		// Many servers reject HEAD — retry those with GET before flagging.
		if ( 0 === $code || in_array( $code, array( 403, 404, 405, 501 ), true ) ) {
			$response = wp_remote_get( $url, $args );
			$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		}
		return $code;
	}

	private static function record_broken( int $post_id, string $url, string $anchor, int $status ): void {
		global $wpdb;
		self::maybe_create_table();
		$wpdb->insert( self::table(), array(
			'post_id' => $post_id,
			'url'     => $url,
			'anchor'  => $anchor,
			'status'  => $status,
			'checked' => current_time( 'mysql' ),
			'ignored' => 0,
		), array( '%d', '%s', '%s', '%d', '%s', '%d' ) );
	}

	// ── Cron: re-check known broken links daily ───────────────────────────────

	public function cron_recheck(): void {
		if ( ! get_option( 'snap_bl_db' ) ) {
			return;
		}
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT id, url FROM ' . self::table() . ' WHERE ignored = 0 ORDER BY checked ASC LIMIT 20', ARRAY_A ); // phpcs:ignore
		foreach ( (array) $rows as $row ) {
			$status = self::check_url( (string) $row['url'] );
			if ( $status > 0 && $status < 400 ) {
				$wpdb->delete( self::table(), array( 'id' => (int) $row['id'] ), array( '%d' ) ); // Fixed → clear.
			} else {
				$wpdb->update( self::table(), array( 'status' => $status, 'checked' => current_time( 'mysql' ) ), array( 'id' => (int) $row['id'] ), array( '%d', '%s' ), array( '%d' ) );
			}
		}
	}

	// ── Fix actions ───────────────────────────────────────────────────────────

	public function ajax_action(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		global $wpdb;
		$id  = (int) ( $_POST['id'] ?? 0 );
		$do  = sanitize_key( (string) ( $_POST['do'] ?? '' ) );
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			wp_send_json_error( 'Not found.' );
		}

		if ( 'ignore' === $do ) {
			$wpdb->update( self::table(), array( 'ignored' => 1 ), array( 'id' => $id ), array( '%d' ), array( '%d' ) );
			wp_send_json_success();
		}

		if ( 'delete' === $do ) {
			$wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );
			wp_send_json_success();
		}

		if ( 'unlink' === $do || 'update' === $do ) {
			$new_url  = 'update' === $do ? esc_url_raw( (string) wp_unslash( $_POST['new_url'] ?? '' ) ) : '';
			if ( 'update' === $do && '' === $new_url ) {
				wp_send_json_error( __( 'New URL is required.', 'snaplevel' ) );
			}
			$affected = self::replace_in_posts( (string) $row['url'], $new_url, 'unlink' === $do );
			$wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );
			wp_send_json_success( array( 'affected' => $affected ) );
		}

		wp_send_json_error( 'Unknown action.' );
	}

	/** Replace or strip a link across all published content. */
	private static function replace_in_posts( string $url, string $new_url, bool $unlink ): int {
		global $wpdb;
		$like     = '%' . $wpdb->esc_like( $url ) . '%';
		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_content LIKE %s LIMIT 200",
			$like
		) );

		$count = 0;
		foreach ( $post_ids as $post_id ) {
			$post = get_post( (int) $post_id );
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			$content = $post->post_content;
			if ( $unlink ) {
				$pattern = '~<a[^>]+href=["\']' . preg_quote( $url, '~' ) . '["\'][^>]*>(.*?)</a>~is';
				$updated = (string) preg_replace( $pattern, '$1', $content );
			} else {
				$updated = str_replace( $url, $new_url, $content );
			}
			if ( $updated !== $content ) {
				wp_update_post( array( 'ID' => $post->ID, 'post_content' => $updated ) );
				$count++;
			}
		}
		return $count;
	}

	// ── Data for views ────────────────────────────────────────────────────────

	public static function get_broken( bool $include_ignored = false ): array {
		global $wpdb;
		self::maybe_create_table();
		$where = $include_ignored ? '' : ' WHERE ignored = 0';
		return (array) $wpdb->get_results( 'SELECT * FROM ' . self::table() . $where . ' ORDER BY status DESC, checked DESC LIMIT 500', ARRAY_A ); // phpcs:ignore
	}

	public static function count_broken(): int {
		global $wpdb;
		if ( ! get_option( 'snap_bl_db' ) ) {
			return 0;
		}
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE ignored = 0' ); // phpcs:ignore
	}
}
