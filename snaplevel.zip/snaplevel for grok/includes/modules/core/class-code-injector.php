<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Code_Injector — Google Analytics 4, AdSense, and custom code output.
 *
 * Always-on core feature. Outputs on the frontend only (never in admin,
 * feeds, or REST). GA4 and AdSense use the official snippets; custom
 * head/footer code is printed exactly as saved.
 */
final class Snap_Code_Injector {

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 4 );
		add_action( 'wp_head', array( $this, 'output_head' ), 4 );
		add_action( 'wp_footer', array( $this, 'output_footer' ), 99 );
	}

	private function should_output(): bool {
		return ! is_admin() && ! is_feed() && ! is_robots() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST );
	}

	public function enqueue_scripts(): void {
		if ( ! $this->should_output() ) {
			return;
		}
		$s = Snap_Settings::instance();

		// Google Analytics 4 (gtag.js).
		$ga4 = trim( (string) $s->get( 'codes.ga4_id', '' ) );
		if ( '' !== $ga4 && preg_match( '/^(G|UA|AW|GT)-[A-Z0-9-]+$/i', $ga4 ) ) {
			wp_enqueue_script( 'snap-gtag', 'https://www.googletagmanager.com/gtag/js?id=' . rawurlencode( $ga4 ), array(), null, false ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			wp_script_add_data( 'snap-gtag', 'async', true );
			wp_add_inline_script( 'snap-gtag', "window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','" . esc_js( $ga4 ) . "');" );
		}

		// Google AdSense (site-level auto ads).
		$adsense = trim( (string) $s->get( 'codes.adsense_client', '' ) );
		if ( '' !== $adsense && preg_match( '/^(ca-)?pub-\d{6,}$/i', $adsense ) ) {
			if ( 0 !== stripos( $adsense, 'ca-' ) ) {
				$adsense = 'ca-' . $adsense;
			}
			wp_enqueue_script( 'snap-adsense', 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . rawurlencode( $adsense ), array(), null, false ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			wp_script_add_data( 'snap-adsense', 'async', true );
			wp_script_add_data( 'snap-adsense', 'crossorigin', 'anonymous' );
		}
	}

	public function output_head(): void {
		if ( ! $this->should_output() ) {
			return;
		}
		// Custom header code (verification tags, pixels, extra ad code…).
		$head = (string) Snap_Settings::instance()->get( 'codes.head_code', '' );
		if ( '' !== trim( $head ) ) {
			echo "<!-- Snaplevel custom header code -->\n" . $head . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- User-supplied unfiltered HTML (requires unfiltered_html cap).
		}
	}

	public function output_footer(): void {
		if ( ! $this->should_output() ) {
			return;
		}
		$footer = (string) Snap_Settings::instance()->get( 'codes.footer_code', '' );
		if ( '' !== trim( $footer ) ) {
			echo "<!-- Snaplevel custom footer code -->\n" . $footer . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- User-supplied unfiltered HTML (requires unfiltered_html cap).
		}
	}
}
