<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ICW_Admin_Menu — Core Module
 *
 * Rank Math-clone admin shell: header bar (logo square + divider + name +
 * mode selector + help), breadcrumbs strip, page views, wizard redirect.
 * Branding is Snaplevel; structure and measurements follow the RM spec 1:1.
 */
class ICW_Admin_Menu {

	/** Pages that mount the settings app on a preset tab. */
	const APP_PAGES = array(
		'snap-titles'   => array( 'title' => 'Titles & Meta', 'tab' => 'titles' ),
		'snap-schema'   => array( 'title' => 'Schema',        'tab' => 'schema' ),
		'snap-training' => array( 'title' => 'AI Training',   'tab' => 'training' ),
		'snap-tools'    => array( 'title' => 'Tools',         'tab' => 'tools' ),
		'icw-settings'  => array( 'title' => 'Settings',      'tab' => 'modules' ),
	);

	public function __construct() {
		add_action( 'admin_menu',            array( $this, 'register_menus' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_init',            array( $this, 'maybe_redirect_wizard' ) );
		add_filter( 'admin_body_class',      array( $this, 'body_class' ) );
		add_action( 'wp_ajax_icw_toggle_module', array( $this, 'ajax_toggle_module' ) );
		add_action( 'wp_ajax_snap_set_ui_mode',  array( $this, 'ajax_set_ui_mode' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( SNAP_PLUGIN_FILE ),
					array( $this, 'plugin_action_links' ) );

		// Hide all third-party admin notices on Snaplevel pages.
		add_action( 'in_admin_header', array( $this, 'hide_foreign_notices' ), 999 );
	}

	public static function ui_mode(): string {
		// Mode selector removed from the header — everything is visible.
		return 'advanced';
	}

	public function ajax_set_ui_mode(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		$mode = isset( $_POST['mode'] ) && 'basic' === $_POST['mode'] ? 'basic' : 'advanced';
		update_user_meta( get_current_user_id(), 'snap_ui_mode', $mode );
		wp_send_json_success( array( 'mode' => $mode ) );
	}

	public function register_menus(): void {
		// Snaplevel mark: trend line + growth bars. Single fill so WP can recolor it.
		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30.462 30.461">'
			  . '<path fill="black" d="M16.109,13.997l-4.312-4.479L1.426,20.058L0,18.656L11.812,6.651l4.354,4.522l7.49-7.172l-2.146-2.145h5.603v5.601 L25.07,5.415L16.109,13.997z M4.962,28.606h6.75v-9.5h-6.75V28.606z M14.337,28.606h6.75v-12.5h-6.75V28.606z M23.712,9.856v18.75 h6.75V9.856H23.712z"/>'
			  . '</svg>';
		$icon = 'data:image/svg+xml;base64,' . base64_encode( $svg );

		add_menu_page(
			'Snaplevel', 'Snaplevel', 'upload_files',
			'icw-dashboard',
			array( $this, 'render_dashboard' ),
			$icon, 58
		);

		// Visible menu — everything grouped by job: content SEO, link health,
		// image SEO, analysis, AI, settings. Tools/Wizard/image tools moved
		// into their relevant screens instead of cluttering the menu.
		add_submenu_page( 'icw-dashboard', 'Dashboard',     __( 'Dashboard', 'snaplevel' ),     'upload_files',   'icw-dashboard',      array( $this, 'render_dashboard' ) );
		add_submenu_page( 'icw-dashboard', 'Titles & Meta', __( 'Titles & Meta', 'snaplevel' ), 'manage_options', 'snap-titles',        array( $this, 'render_app_page' ) );
		add_submenu_page( 'icw-dashboard', 'Schema',        __( 'Schema', 'snaplevel' ),        'manage_options', 'snap-schema',        array( $this, 'render_app_page' ) );
		add_submenu_page( 'icw-dashboard', 'Redirections',  __( 'Redirections', 'snaplevel' ),  'manage_options', 'snap-redirections',  array( $this, 'render_redirections' ) );
		add_submenu_page( 'icw-dashboard', 'Broken Links',  __( 'Broken Links', 'snaplevel' ),  'manage_options', 'snap-broken-links',  array( $this, 'render_broken_links' ) );
		add_submenu_page( 'icw-dashboard', 'Image SEO',     __( 'Image SEO', 'snaplevel' ),     'upload_files',   'snap-image-seo',     array( $this, 'render_image_seo' ) );
		add_submenu_page( 'icw-dashboard', 'Site Audit',    __( 'Site Audit', 'snaplevel' ),    'upload_files',   'icw-seo-audit',      array( $this, 'render_seo_audit' ) );
		add_submenu_page( 'icw-dashboard', 'AI Training',   __( 'AI Training', 'snaplevel' ),   'manage_options', 'snap-training',      array( $this, 'render_app_page' ) );
		add_submenu_page( 'icw-dashboard', 'Settings',      __( 'Settings', 'snaplevel' ),      'manage_options', 'icw-settings',       array( $this, 'render_app_page' ) );

		// Hidden pages — reachable by URL (old links, wizard redirect, Image SEO tabs)
		// but no longer menu noise.
		add_submenu_page( '', 'Tools',         'Tools',         'manage_options', 'snap-tools',        array( $this, 'render_app_page' ) );
		add_submenu_page( '', 'Setup Wizard',  'Setup Wizard',  'manage_options', 'snap-wizard',       array( $this, 'render_wizard' ) );
		add_submenu_page( '', 'Compression',   'Compression',   'upload_files',   'icw-compression',   array( $this, 'render_compression' ) );
		add_submenu_page( '', 'AI Alt Text',   'AI Alt Text',   'upload_files',   'icw-alt-text',      array( $this, 'render_alt_text' ) );
		add_submenu_page( '', 'Unused Images', 'Unused Images', 'delete_posts',   'icw-unused-images', array( $this, 'render_unused' ) );

		// Shortcut under Media menu.
		add_submenu_page( 'upload.php', 'Image Compression', __( 'Image Compression', 'snaplevel' ), 'upload_files', 'snap-media-compression', array( $this, 'redirect_media_compression' ) );
	}

	public function redirect_media_compression(): void {
		wp_safe_redirect( admin_url( 'admin.php?page=snap-image-seo&sub=compression' ) );
		exit;
	}

	// ── Shell ─────────────────────────────────────────────────────────────────

	/**
	 * Rank Math header bar (spec 1): gradient logo square + vertical divider,
	 * plugin name, optional search, Easy/Advanced selector, help button.
	 */
	public static function render_header( string $page_title, bool $show_search = false ): void {
		?>
		<div class="snap-header">
			<div class="snap-header-logo">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=icw-dashboard' ) ); ?>">
					<img class="snap-logo-img" src="<?php echo esc_url( SNAP_PLUGIN_URL . 'assets/images/logo-dark-text.svg' ); ?>" alt="Snaplevel">
				</a>
			</div>
			<h1 class="snap-logo-text"><span class="snap-logo-page"><?php echo esc_html( $page_title ); ?></span></h1>

			<?php if ( $show_search ) : ?>
				<div class="snap-search-options">
					<input type="search" id="snap-search-options" placeholder="<?php esc_attr_e( 'Search Options', 'snaplevel' ); ?>">
				</div>
			<?php endif; ?>

			<a class="snap-help-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=snap-training' ) ); ?>" title="<?php esc_attr_e( 'AI Training', 'snaplevel' ); ?>">
				<?php echo Snap_Icons::get( 'sparkle', 17, 'snap-anim-glow' ); // phpcs:ignore ?>
			</a>
			<button type="button" class="snap-help-btn" id="snap-guides-open" title="<?php esc_attr_e( 'Guides & Help', 'snaplevel' ); ?>" style="cursor:pointer;border:1px solid var(--snap-border);background:#fff;">
				<?php echo Snap_Icons::get( 'help', 17 ); // phpcs:ignore ?>
			</button>
		</div>
		<?php
		self::render_guides_panel();
	}

	/**
	 * Slide-over guides panel — every feature explained in place, no
	 * external links needed. Opened by the ? button in the header.
	 */
	public static function render_guides_panel(): void {
		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;

		$guides = array(
			array(
				'icon'  => 'zap',
				'title' => __( 'Getting Started in 3 Minutes', 'snaplevel' ),
				'body'  => __( "1. Open Settings → AI and connect a provider (Claude, ChatGPT, Gemini, DeepSeek, or Mistral) with your own API key — you pay the provider directly, usually a fraction of a cent per generation.\n2. Open Settings → Tools and import your old SEO data if you used Yoast, Rank Math, AIOSEO, SEOPress, or others. Nothing is overwritten.\n3. Open AI Training and paste what your business does, who it serves, and your brand voice. Every AI generation uses this.\n4. Edit any post — press “Fix with AI” in the Snaplevel SEO panel and approve the result. That's the whole workflow.", 'snaplevel' ),
			),
			array(
				'icon'  => 'target',
				'title' => __( 'The SEO Panel (every editor)', 'snaplevel' ),
				'body'  => __( "The Snaplevel SEO panel appears under every post — Gutenberg, Classic, WooCommerce, and custom post types. In Elementor, click the calm “Snaplevel” button (bottom left) to open a clean side panel.\n\n• General tab: focus keyword, SEO title, URL slug, meta description — with a live Google preview on the right and a score that updates as you type.\n• Social tab: how the page looks when shared on Facebook, LinkedIn, WhatsApp, and X. Empty fields inherit from General automatically.\n• Advanced tab: robots directives (hide from search, don't follow links…), canonical URL, breadcrumb title.\n• Schema tab: one click and AI reads the post and builds the right structured data — Article, Product, FAQ, Recipe, HowTo.", 'snaplevel' ),
			),
			array(
				'icon'  => 'redirect',
				'title' => __( 'Redirections & 404 Monitor', 'snaplevel' ),
				'body'  => __( "Create 301 (permanent), 302/307 (temporary), 410 (deleted), or 451 redirects. Type a source path like /old-page/ and a target.\n\n• Regex: tick the Regex box for patterns, e.g. ^/blog/(.*) → /articles/$1\n• 404 Monitor: every page visitors couldn't find is logged automatically. Click “Create redirect” next to any entry to fix it in one click.\n• URL Tester: paste any URL to check which redirect (if any) will fire before going live.\n• CSV import/export under the Import / Export tab.\n• Optional: auto-create a redirect to the homepage whenever you trash a published post.", 'snaplevel' ),
			),
			array(
				'icon'  => 'link',
				'title' => __( 'Broken Link Checker', 'snaplevel' ),
				'body'  => __( "Press “Scan Now” — Snaplevel collects every link from your published content and checks them in small batches, so it never times out even on big sites.\n\nFor each broken link you can:\n• Update URL — replaces it everywhere on the site\n• Unlink — removes the link, keeps the text\n• Ignore — hides it from future scans\n\nKnown broken links are re-checked automatically every day; links that start working again clear themselves.", 'snaplevel' ),
			),
			array(
				'icon'  => 'image',
				'title' => __( 'Image SEO', 'snaplevel' ),
				'body'  => __( "Everything image-related lives in one place with four tabs:\n\n• Automation: SEO filenames on upload, automatic alt text from the filename, attachment-page redirects.\n• Compression: compress images and convert to WebP without changing URLs. Originals are backed up.\n• AI Alt Text: AI looks at each image and writes descriptive alt text — single or bulk.\n• Unused Images: find images not used anywhere and clean them up safely.", 'snaplevel' ),
			),
			array(
				'icon'  => 'gauge',
				'title' => __( 'Site Audit, SEO History & SEO Memory', 'snaplevel' ),
				'body'  => __( "• Site Audit: runs 7 technical checks (large images, orphan pages, slow pages, redirect links, large CSS, sitemap health, meta coverage). “Fix Everything with AI” repairs what it can automatically: writes missing titles/descriptions, compresses heavy images, and rewrites internal links that point at redirects.\n• SEO History: a complete audit trail — every SEO change on every page, who made it, before → after. Perfect for agencies and for answering “why did rankings move?”\n• SEO Memory: Snaplevel studies your edits. If you always shorten titles or remove certain words from AI output, it learns those preferences and applies them to every future generation. Review and save the learned rules — they're added to every AI prompt.", 'snaplevel' ),
			),
			array(
				'icon'  => 'sitemap',
				'title' => __( 'Sitemaps, Schema & Breadcrumbs', 'snaplevel' ),
				'body'  => __( "• Sitemaps: a clean XML sitemap at /sitemap_index.xml that honors noindex, pings IndexNow on publish, and lets you choose which post types and taxonomies are included (Settings → Sitemap).\n• Schema: site-level Organization/Person markup plus per-post AI schema in the editor.\n• Breadcrumbs: add [snaplevel_breadcrumbs] in any page or snaplevel_breadcrumbs() in your theme. BreadcrumbList JSON-LD is output automatically either way.", 'snaplevel' ),
			),
			array(
				'icon'  => 'chart',
				'title' => __( 'Ads & Analytics', 'snaplevel' ),
				'body'  => __( "Settings → Ads & Analytics:\n• Google Analytics 4 — paste your G-XXXXXXXXXX Measurement ID and the official tracking snippet is added to every page. No extra plugin needed.\n• Google AdSense — paste your ca-pub-… publisher ID for site verification and Auto Ads.\n• Header / Footer code — for Facebook Pixel, verification tags, chat widgets, or any custom script.", 'snaplevel' ),
			),
			array(
				'icon'  => 'sparkle',
				'title' => __( 'AI: Providers, Models & Costs', 'snaplevel' ),
				'body'  => __( "Snaplevel works with five AI providers — pick one in Settings → AI and paste your own API key (stored encrypted, never leaves your site).\n\nModel choice is a dropdown with price tiers: 💎 Premium (best quality), ⚖️ Balanced, 🪙 Budget (fast and very cheap). Leave it on Auto and Snaplevel picks the best value model for each task.\n\nEvery generation's cost is tracked — see your monthly spend in Settings → AI. Auto mode (generate on publish) is off by default; everything requires your approval.", 'snaplevel' ),
			),
			array(
				'icon'  => 'import',
				'title' => __( 'Import, Export & Reset', 'snaplevel' ),
				'body'  => __( "Settings → Tools:\n• Import SEO data from Yoast, Rank Math, All in One SEO, SEOPress, The SEO Framework, SmartCrawl, WP Meta SEO, or Slim SEO. Template variables are translated automatically and your existing Snaplevel data is never overwritten.\n• Export/import all plugin settings as JSON (API keys are never included).\n• Reset to factory defaults — post SEO data, redirects, and AI training are kept.", 'snaplevel' ),
			),
		);
		?>
		<div id="snap-guides-overlay" style="display:none;position:fixed;inset:0;z-index:99998;background:rgba(17,24,39,.45);"></div>
		<aside id="snap-guides" style="display:none;position:fixed;top:0;right:0;bottom:0;width:520px;max-width:92vw;z-index:99999;background:#fff;box-shadow:-12px 0 48px -12px rgba(0,0,0,.25);border-radius:16px 0 0 16px;overflow:hidden;flex-direction:column;">
			<div style="display:flex;align-items:center;gap:12px;padding:18px 22px;border-bottom:1px solid var(--snap-border);">
				<img src="<?php echo esc_url( SNAP_PLUGIN_URL . 'assets/images/icon.svg' ); ?>" alt="" style="width:30px;height:30px;border-radius:8px;">
				<div style="flex:1;">
					<strong style="font-size:16px;display:block;"><?php esc_html_e( 'Guides & Help', 'snaplevel' ); ?></strong>
					<span class="snap-muted" style="font-size:12px;"><?php esc_html_e( 'Everything explained, right here — no docs site needed.', 'snaplevel' ); ?></span>
				</div>
				<button type="button" id="snap-guides-close" style="width:32px;height:32px;border-radius:50%;border:0;background:var(--snap-bg-tab-idle);cursor:pointer;font-size:15px;">✕</button>
			</div>
			<div style="flex:1;overflow-y:auto;padding:16px 22px;">
				<?php foreach ( $guides as $g ) : ?>
					<details class="snap-guide" style="border:1px solid var(--snap-border);border-radius:12px;margin-bottom:10px;background:#fff;overflow:hidden;">
						<summary style="display:flex;align-items:center;gap:12px;padding:14px 16px;cursor:pointer;font-weight:600;font-size:14px;list-style:none;">
							<span style="flex:none;width:32px;height:32px;border-radius:8px;background:var(--snap-primary-soft);color:var(--snap-primary);display:flex;align-items:center;justify-content:center;"><?php Snap_Icons::e( (string) $g['icon'], 16 ); ?></span>
							<?php echo esc_html( $g['title'] ); ?>
							<span class="snap-guide-arrow" style="margin-left:auto;color:var(--snap-text-muted);transition:transform .2s;">▾</span>
						</summary>
						<div style="padding:0 16px 16px 60px;font-size:13px;line-height:1.65;color:var(--snap-text-secondary);white-space:pre-line;"><?php echo esc_html( $g['body'] ); ?></div>
					</details>
				<?php endforeach; ?>
				<div style="text-align:center;padding:14px 0 6px;">
					<span class="snap-muted" style="font-size:12px;"><?php esc_html_e( 'Still stuck?', 'snaplevel' ); ?></span>
					<a href="https://autogencrm.com/snaplevel" target="_blank" rel="noopener" style="font-size:12px;"><?php esc_html_e( 'Contact support →', 'snaplevel' ); ?></a>
				</div>
			</div>
		</aside>
		<?php
		wp_enqueue_script( 'snap-guides-panel', SNAP_PLUGIN_URL . 'assets/js/guides-panel.js', array(), Snap_Assets::version( 'assets/js/guides-panel.js' ), true );
		?>
		<?php
	}

	/** Small hoverable info dot — used next to feature titles across screens. */
	public static function tip( string $text ): string {
		return '<span class="snap-tip" tabindex="0" data-tip="' . esc_attr( $text ) . '">?</span>';
	}

	/** Breadcrumbs strip (spec 2). */
	public static function render_breadcrumbs( string $current, string $extra_html = '' ): void {
		?>
		<div class="snap-breadcrumbs-wrap">
			<div class="snap-breadcrumbs">
				<span><?php esc_html_e( 'Dashboard', 'snaplevel' ); ?></span>
				<span class="divider">/</span>
				<span class="active"><?php echo esc_html( $current ); ?></span>
			</div>
			<?php echo $extra_html; // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>
		<?php
	}

	private function require_view( string $view, string $page_title = '' ): void {
		echo '<div class="snap-wrap snap-page-shell">';
		if ( '' !== $page_title ) {
			self::render_header( $page_title );
		}
		$file = SNAP_PLUGIN_DIR . 'admin/views/' . $view . '.php';
		if ( file_exists( $file ) ) {
			require $file;
		} else {
			echo '<div class="notice notice-error"><p>View file not found: ' . esc_html( $file ) . '</p></div>';
		}
		echo '</div>';
	}

	public function render_dashboard():   void { $this->require_view( 'dashboard', __( 'Dashboard', 'snaplevel' ) ); }
	public function render_compression(): void {
		wp_safe_redirect( admin_url( 'admin.php?page=snap-image-seo&sub=compression' ) );
		exit;
	}
	public function render_alt_text(): void {
		wp_safe_redirect( admin_url( 'admin.php?page=snap-image-seo&sub=alt-text' ) );
		exit;
	}
	public function render_unused(): void {
		wp_safe_redirect( admin_url( 'admin.php?page=snap-image-seo&sub=unused' ) );
		exit;
	}
	public function render_seo_audit():   void { $this->require_view( 'seo-audit', __( 'Site Audit', 'snaplevel' ) ); }
	public function render_wizard():      void { $this->require_view( 'wizard' ); }

	public function render_redirections(): void {
		$this->load_module_class( 'redirections/class-redirections.php', 'Snap_Redirections' );
		$this->require_view( 'redirections', __( 'Redirections', 'snaplevel' ) );
	}

	public function render_broken_links(): void {
		$this->load_module_class( 'broken-links/class-broken-links.php', 'Snap_Broken_Links' );
		$this->require_view( 'broken-links', __( 'Broken Links', 'snaplevel' ) );
	}

	public function render_image_seo(): void {
		$this->load_module_class( 'image-seo/class-image-seo.php', 'Snap_Image_SEO' );
		$this->require_view( 'image-seo', __( 'Image SEO', 'snaplevel' ) );
	}

	/** Views need module classes even when the module toggle is off. */
	private function load_module_class( string $file, string $class ): void {
		if ( ! class_exists( $class ) ) {
			require_once SNAP_PLUGIN_DIR . 'includes/modules/' . $file;
		}
	}

	/** Settings-app pages: shell + mount with a preset tab. */
	public function render_app_page(): void {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : 'icw-settings';
		$conf = self::APP_PAGES[ $page ] ?? self::APP_PAGES['icw-settings'];
		echo '<div class="snap-wrap snap-page-shell">';
		self::render_header( $conf['title'], true );
		self::render_breadcrumbs( $conf['title'] );
		echo '<div class="snap-container">';
		echo '<div id="snap-settings-app" data-tab="' . esc_attr( $conf['tab'] ) . '" data-page-title="' . esc_attr( $conf['title'] ) . '">';
		echo '<div class="snap-skeleton" style="height:220px"></div>';
		echo '</div></div></div>';
	}

	// ── Body classes / wizard redirect ────────────────────────────────────────

	public function body_class( string $classes ): string {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		$ours = array_merge(
			array( 'icw-dashboard', 'icw-compression', 'icw-seo-audit', 'icw-alt-text', 'icw-unused-images', 'snap-wizard', 'snap-redirections', 'snap-broken-links', 'snap-image-seo' ),
			array_keys( self::APP_PAGES )
		);
		if ( in_array( $page, $ours, true ) ) {
			$classes .= ' snap-page';
			$classes .= 'basic' === self::ui_mode() ? ' snap-mode-basic' : ' snap-mode-advanced';
		}
		if ( 'snap-wizard' === $page ) {
			$classes .= ' snap-fullscreen';
		}
		return $classes;
	}

	/**
	 * Remove every admin notice that isn't ours on Snaplevel screens.
	 * Runs at in_admin_header priority 999 — after all plugins have registered
	 * their notices but before WordPress renders them.
	 */
	public function hide_foreign_notices(): void {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		$ours = array_merge(
			array( 'icw-dashboard', 'icw-compression', 'icw-seo-audit', 'icw-alt-text', 'icw-unused-images', 'snap-wizard', 'snap-redirections', 'snap-broken-links', 'snap-image-seo' ),
			array_keys( self::APP_PAGES )
		);
		if ( ! in_array( $page, $ours, true ) ) {
			return;
		}
		// Remove every callback from notice hooks.
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
		remove_all_actions( 'network_admin_notices' );
		remove_all_actions( 'user_admin_notices' );
	}
	/** First-run: send admins to the onboarding wizard once. */
	public function maybe_redirect_wizard(): void {
		if ( ! get_option( 'snap_show_wizard_redirect' ) ) {
			return;
		}
		if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( isset( $_GET['activate-multi'] ) ) {
			delete_option( 'snap_show_wizard_redirect' );
			return;
		}
		delete_option( 'snap_show_wizard_redirect' );
		wp_safe_redirect( admin_url( 'admin.php?page=snap-wizard' ) );
		exit;
	}

	/**
	 * Legacy dashboard toggle — maps old flat keys onto new module ids
	 * and writes through Snap_Settings.
	 */
	public function ajax_toggle_module(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}
		$module = sanitize_key( $_POST['module'] ?? '' );
		$state  = (bool) intval( $_POST['state'] ?? 1 );

		$map = array(
			'module_seo'      => 'seo_analyzer',
			'module_alt'      => 'alt_text',
			'module_unused'   => 'unused_images',
			'module_seo_meta' => 'seo_meta',
			'module_sitemap'  => 'sitemap',
			'module_schema'   => 'schema',
		);

		$id = isset( $map[ $module ] ) ? $map[ $module ] : $module;
		if ( ! Snap_Module_Loader::instance()->exists( $id ) || Snap_Module_Loader::instance()->is_always_on( $id ) ) {
			wp_send_json_error( 'Unknown or locked module.' );
		}

		Snap_Settings::instance()->set( 'modules.' . $id, $state );

		wp_send_json_success( array( 'module' => $id, 'state' => $state ) );
	}

	public function plugin_action_links( array $links ): array {
		$custom = array(
			'dashboard' => '<a href="' . esc_url( admin_url( 'admin.php?page=icw-dashboard' ) ) . '" style="color:#4338CA;font-weight:600;">Dashboard</a>',
			'settings'  => '<a href="' . esc_url( admin_url( 'admin.php?page=icw-settings' ) ) . '">Settings</a>',
		);
		return array_merge( $custom, $links );
	}

	public function enqueue_assets( string $hook ): void {
		$pages = array(
			'toplevel_page_icw-dashboard'       => 'dashboard',
			'snaplevel_page_icw-seo-audit'      => 'legacy',
			'snaplevel_page_snap-image-seo'     => 'legacy', // Image SEO hub embeds the compression/alt-text/unused views.
			'snaplevel_page_snap-redirections'  => 'plain',
			'snaplevel_page_snap-broken-links'  => 'plain',
			'snaplevel_page_snap-titles'        => 'app',
			'snaplevel_page_snap-schema'        => 'app',
			'snaplevel_page_snap-training'      => 'app',
			'snaplevel_page_icw-settings'       => 'app',
			// Hidden pages get the admin_page_* hook prefix.
			'admin_page_snap-tools'             => 'app',
			'admin_page_snap-wizard'            => 'wizard',
			'admin_page_icw-compression'        => 'legacy',
			'admin_page_icw-alt-text'           => 'legacy',
			'admin_page_icw-unused-images'      => 'legacy',
		);
		if ( ! isset( $pages[ $hook ] ) ) {
			return;
		}

		wp_enqueue_style( 'snap-design-system' );

		if ( 'plain' === $pages[ $hook ] ) {
			return;
		}

		if ( 'app' === $pages[ $hook ] ) {
			wp_enqueue_script( 'snap-settings-app' );
			Snap_Assets::localize_app( 'snap-settings-app' );
			return;
		}

		if ( 'wizard' === $pages[ $hook ] ) {
			wp_enqueue_script( 'snap-wizard' );
			Snap_Assets::localize_app( 'snap-wizard' );
			return;
		}

		// Dashboard + tool pages: compat stylesheet + jQuery app.
		wp_enqueue_style( 'icw-admin' );
		wp_enqueue_script( 'icw-admin' );

		$has_key = class_exists( 'Snap_Settings' ) && '' !== Snap_Settings::instance()->get_api_key();

		wp_localize_script( 'icw-admin', 'ICW', array(
			'nonce'        => wp_create_nonce( 'icw_nonce' ),
			'ajaxurl'      => admin_url( 'admin-ajax.php' ),
			'currentPage'  => isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '',
			'hasOpenAIKey' => $has_key, // legacy flag name; now means "has AI key"
			'i18n'         => array(
				'compressing'   => __( 'Compressing…', 'snaplevel' ),
				'bulk_done'     => __( 'All done!', 'snaplevel' ),
				'scanning'      => __( 'Scanning…', 'snaplevel' ),
				'confirm_trash' => __( 'Move image to Trash?', 'snaplevel' ),
				'no_api_key'    => __( 'No AI API key. Add your AI key in Settings.', 'snaplevel' ),
			),
		) );

		$this->enqueue_legacy_view_scripts( $hook );
	}

	/** Enqueue page-specific scripts that were previously inline in view templates. */
	private function enqueue_legacy_view_scripts( string $hook ): void {
		$ajaxurl = admin_url( 'admin-ajax.php' );
		$nonce   = wp_create_nonce( 'icw_nonce' );

		if ( 'snaplevel_page_icw-seo-audit' === $hook ) {
			$large_images = 0;
			$attachments  = get_posts( array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			) );
			foreach ( $attachments as $aid ) {
				$file = get_attached_file( (int) $aid );
				if ( $file && file_exists( $file ) && filesize( $file ) > 102400 ) {
					$large_images++;
				}
			}

			wp_enqueue_script( 'snap-vtabs' );
			wp_enqueue_script( 'snap-seo-audit' );
			wp_localize_script( 'snap-seo-audit', 'SNAP_AUDIT', array(
				'nonce'       => $nonce,
				'ajaxurl'     => $ajaxurl,
				'restUrl'     => esc_url_raw( rest_url( 'snaplevel/v1' ) ),
				'restNonce'   => wp_create_nonce( 'wp_rest' ),
				'totalTests'  => 7,
				'largeImages' => $large_images,
				'i18n'        => array(
					'found'          => __( 'Found', 'snaplevel' ),
					'allClear'       => __( 'All Clear', 'snaplevel' ),
					'phase1'         => __( 'Phase 1/3 — writing missing SEO titles & descriptions with AI…', 'snaplevel' ),
					'phase1Progress' => __( 'Phase 1/3 — AI fixed %1$d pages… (%2$d left)', 'snaplevel' ),
					'phase2'         => __( 'Phase 2/3 — compressing large images…', 'snaplevel' ),
					'phase2Skip'     => __( 'AI meta skipped (no AI key?). Phase 2/3 — compressing large images…', 'snaplevel' ),
					'phase2Progress' => __( 'Phase 2/3 — compressed %1$d images (%2$s −%3$d%%)…', 'snaplevel' ),
					'phase3'         => __( 'Phase 3/3 — rewriting internal links that point at redirects…', 'snaplevel' ),
					'phase3Skip'     => __( 'Compression skipped. Phase 3/3 — fixing redirected links…', 'snaplevel' ),
					'phase3Progress' => __( 'Phase 3/3 — scanned %1$d / %2$d pages, %3$d links fixed…', 'snaplevel' ),
					'doneSummary'    => __( 'Done: %1$d pages got AI titles/descriptions · %2$d images compressed · %3$d redirected links rewritten. Re-running audit…', 'snaplevel' ),
					'scanning'       => __( 'Scanning…', 'snaplevel' ),
					'rescan'         => __( 'Rescan', 'snaplevel' ),
					'error'          => __( 'Error', 'snaplevel' ),
					'serverError'    => __( 'Server Error', 'snaplevel' ),
					'pageTitle'      => __( 'Page Title', 'snaplevel' ),
					'redirectsTo'    => __( 'Redirects To', 'snaplevel' ),
					'responseTime'   => __( 'Response Time', 'snaplevel' ),
					'foundOn'        => __( 'Found On', 'snaplevel' ),
					'redirectedLink' => __( 'Redirected Link', 'snaplevel' ),
					'cssFile'        => __( 'CSS File', 'snaplevel' ),
					'fileSize'       => __( 'File Size', 'snaplevel' ),
					'passed'         => __( 'Passed', 'snaplevel' ),
					'noIssues'       => __( 'No issues found.', 'snaplevel' ),
				),
			) );
			return;
		}

		if ( 'snaplevel_page_snap-image-seo' === $hook || in_array( $hook, array( 'admin_page_icw-compression', 'admin_page_icw-alt-text', 'admin_page_icw-unused-images' ), true ) ) {
			wp_enqueue_script( 'snap-vtabs' );
			wp_enqueue_script( 'snap-image-seo' );
			wp_localize_script( 'snap-image-seo', 'SNAP_IMAGE_SEO', array(
				'restUrl' => esc_url_raw( rest_url( 'snaplevel/v1' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'saved' => __( 'Saved. Applies to new uploads.', 'snaplevel' ),
				),
			) );
			wp_enqueue_script( 'snap-compression' );
			wp_localize_script( 'snap-compression', 'SNAP_COMPRESSION', array(
				'nonce'   => $nonce,
				'ajaxurl' => $ajaxurl,
				'btnHtml' => '<span class="snap-icon">' . Snap_Icons::get( 'zap', 15 ) . '</span> ' . __( 'Compress All Large Images', 'snaplevel' ),
				'i18n'    => array(
					'refreshing'  => __( 'Refreshing…', 'snaplevel' ),
					'noLarge'     => __( 'Great news! No images over 100KB found.', 'snaplevel' ),
					'running'     => __( 'Running…', 'snaplevel' ),
					'stopping'    => __( 'Stopping…', 'snaplevel' ),
					'halted'      => __( 'Compression halted by user.', 'snaplevel' ),
					'allDone'     => __( 'All images compressed successfully!', 'snaplevel' ),
					'compressing' => __( 'Compressing image', 'snaplevel' ),
					'stop'        => __( 'Stop Process', 'snaplevel' ),
					'loading'     => __( 'Loading…', 'snaplevel' ),
					'compressed'  => __( 'Compressed', 'snaplevel' ),
					'original'    => __( 'Original', 'snaplevel' ),
					'added'       => __( 'Added', 'snaplevel' ),
					'missing'     => __( 'Missing', 'snaplevel' ),
					'loadMore'    => __( 'Load More', 'snaplevel' ),
				),
			) );
			wp_enqueue_script( 'snap-unused-images' );
			wp_localize_script( 'snap-unused-images', 'SNAP_UNUSED', array(
				'nonce'       => $nonce,
				'ajaxurl'     => $ajaxurl,
				'limit'       => 24,
				'scanBtnHtml' => '<span class="snap-icon">' . Snap_Icons::get( 'search', 15 ) . '</span> ' . __( 'Rescan', 'snaplevel' ),
				'i18n'        => array(
					'scanning'    => __( 'Scanning…', 'snaplevel' ),
					'loading'     => __( 'Loading…', 'snaplevel' ),
					'loadMore'    => __( 'Load More Images', 'snaplevel' ),
					'confirmOne'  => __( 'Move this image to trash?', 'snaplevel' ),
					'confirmBulk' => __( 'Move selected images to trash?', 'snaplevel' ),
					'trashing'    => __( 'Trashing…', 'snaplevel' ),
				),
			) );
		}
	}

	/**
	 * Legacy defaults — kept because old views/JS reference this.
	 * New code uses Snap_Settings::defaults().
	 */
	public static function default_settings(): array {
		return array(
			'quality'            => 82,
			'compress_originals' => true,
			'convert_to_webp'    => true,
			'backup_originals'   => true,
			'auto_on_upload'     => false,
			'openai_api_key'     => '',
			'ai_keywords'        => '',
			'module_seo'         => true,
			'module_alt'         => true,
			'module_unused'      => true,
		);
	}
}
