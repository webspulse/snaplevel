<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Webmasters — search engine site-verification meta tags.
 *
 * The user pastes either the bare code or the full <meta> tag from each
 * search console; we extract the code and print the authentic meta tag
 * in <head> on every page (the standard verification implementation).
 */
final class Snap_Webmasters {

	/** engine id => meta name attribute (the official verification names). */
	const ENGINES = array(
		'google'    => 'google-site-verification',
		'bing'      => 'msvalidate.01',
		'yandex'    => 'yandex-verification',
		'baidu'     => 'baidu-site-verification',
		'pinterest' => 'p:domain_verify',
		'norton'    => 'norton-safeweb-site-verification',
	);

	public function __construct() {
		add_action( 'wp_head', array( $this, 'output' ), 1 );
	}

	public function output(): void {
		$codes = (array) Snap_Settings::instance()->get( 'webmasters', array() );
		foreach ( self::ENGINES as $id => $meta_name ) {
			$code = isset( $codes[ $id ] ) ? trim( (string) $codes[ $id ] ) : '';
			if ( '' === $code ) {
				continue;
			}
			printf(
				'<meta name="%s" content="%s" />' . "\n",
				esc_attr( $meta_name ),
				esc_attr( $code )
			);
		}
	}

	/**
	 * Accepts a bare code or a pasted full meta tag and returns the code.
	 */
	public static function sanitize_code( string $value ): string {
		$value = trim( wp_unslash( $value ) );
		if ( preg_match( '/content=["\']([^"\']+)["\']/', $value, $m ) ) {
			$value = $m[1];
		}
		$value = wp_strip_all_tags( $value );
		return sanitize_text_field( $value );
	}
}
