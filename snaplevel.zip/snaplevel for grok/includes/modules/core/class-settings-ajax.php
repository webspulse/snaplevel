<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * ICW_Settings_Ajax — legacy AJAX save endpoint.
 *
 * The settings UI now talks REST (snaplevel/v1/settings). This handler
 * stays for back-compat and routes legacy flat keys through Snap_Settings
 * so there is still only one source of truth.
 */
class ICW_Settings_Ajax {

	public function __construct() {
		add_action( 'wp_ajax_icw_save_settings', array( $this, 'save_settings' ) );
	}

	public function save_settings(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$quality = max( 50, min( 100, intval( $_POST['quality'] ?? 82 ) ) );

		Snap_Settings::instance()->update( array(
			'compression' => array(
				'quality'          => $quality,
				'convert_to_webp'  => (bool) intval( $_POST['convert_to_webp'] ?? 1 ),
				'backup_originals' => (bool) intval( $_POST['backup_originals'] ?? 1 ),
				'auto_on_upload'   => (bool) intval( $_POST['auto_on_upload'] ?? 0 ),
			),
			'ai'          => array(
				'keywords' => sanitize_text_field( $_POST['ai_keywords'] ?? '' ),
			),
			'modules'     => array(
				'seo_analyzer'  => (bool) intval( $_POST['module_seo'] ?? 1 ),
				'alt_text'      => (bool) intval( $_POST['module_alt'] ?? 1 ),
				'unused_images' => (bool) intval( $_POST['module_unused'] ?? 1 ),
			),
		) );

		wp_send_json_success( array( 'message' => 'Settings saved.' ) );
	}
}
