<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Breadcrumbs — accessible breadcrumb trail + BreadcrumbList JSON-LD.
 *
 * Usage:  [snaplevel_breadcrumbs]  shortcode
 *         snaplevel_breadcrumbs()  template function
 * JSON-LD is printed automatically in <head> on every page.
 * Honors the per-post _snap_breadcrumb_title override and the
 * breadcrumbs.separator setting. A11Y: nav[aria-label] + aria-current.
 */
final class Snap_Breadcrumbs {

	public function __construct() {
		add_shortcode( 'snaplevel_breadcrumbs', array( $this, 'shortcode' ) );
		add_action( 'wp_head', array( $this, 'output_jsonld' ), 5 );
	}

	/** @return array<int, array{label:string, url:string}> */
	public static function get_trail(): array {
		$trail   = array();
		$trail[] = array( 'label' => __( 'Home', 'snaplevel' ), 'url' => home_url( '/' ) );

		if ( is_front_page() ) {
			return $trail;
		}

		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				// WooCommerce shop page for products.
				if ( 'product' === $post->post_type && function_exists( 'wc_get_page_id' ) ) {
					$shop = (int) wc_get_page_id( 'shop' );
					if ( $shop > 0 ) {
						$trail[] = array( 'label' => get_the_title( $shop ), 'url' => (string) get_permalink( $shop ) );
					}
				} elseif ( 'post' === $post->post_type ) {
					$cats = get_the_category( $post->ID );
					if ( ! empty( $cats[0] ) ) {
						$trail[] = array( 'label' => $cats[0]->name, 'url' => (string) get_category_link( $cats[0] ) );
					}
				} elseif ( $post->post_parent ) {
					foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor_id ) {
						$trail[] = array( 'label' => self::post_label( (int) $ancestor_id ), 'url' => (string) get_permalink( $ancestor_id ) );
					}
				}
				$trail[] = array( 'label' => self::post_label( $post->ID ), 'url' => '' );
			}
			return $trail;
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term instanceof WP_Term ) {
				if ( $term->parent ) {
					foreach ( array_reverse( get_ancestors( $term->term_id, $term->taxonomy, 'taxonomy' ) ) as $ancestor_id ) {
						$ancestor = get_term( $ancestor_id, $term->taxonomy );
						if ( $ancestor instanceof WP_Term ) {
							$link    = get_term_link( $ancestor );
							$trail[] = array( 'label' => $ancestor->name, 'url' => is_wp_error( $link ) ? '' : (string) $link );
						}
					}
				}
				$trail[] = array( 'label' => $term->name, 'url' => '' );
			}
			return $trail;
		}

		if ( is_post_type_archive() ) {
			$trail[] = array( 'label' => (string) post_type_archive_title( '', false ), 'url' => '' );
		} elseif ( is_author() ) {
			$trail[] = array( 'label' => (string) get_the_author(), 'url' => '' );
		} elseif ( is_date() ) {
			$trail[] = array( 'label' => (string) get_the_date( is_day() ? '' : ( is_month() ? 'F Y' : 'Y' ) ), 'url' => '' );
		} elseif ( is_search() ) {
			/* translators: %s: search query */
			$trail[] = array( 'label' => sprintf( __( 'Search: %s', 'snaplevel' ), get_search_query() ), 'url' => '' );
		} elseif ( is_404() ) {
			$trail[] = array( 'label' => __( 'Page not found', 'snaplevel' ), 'url' => '' );
		} elseif ( is_home() ) {
			$page_for_posts = (int) get_option( 'page_for_posts' );
			$trail[]        = array( 'label' => $page_for_posts ? get_the_title( $page_for_posts ) : __( 'Blog', 'snaplevel' ), 'url' => '' );
		}

		return $trail;
	}

	private static function post_label( int $post_id ): string {
		$custom = (string) get_post_meta( $post_id, '_snap_breadcrumb_title', true );
		return '' !== $custom ? $custom : (string) get_the_title( $post_id );
	}

	// ── HTML ──────────────────────────────────────────────────────────────────

	public static function render(): string {
		$trail = self::get_trail();
		$sep   = (string) Snap_Settings::instance()->get( 'breadcrumbs.separator', '›' );
		$last  = count( $trail ) - 1;

		$html = '<nav class="snap-breadcrumb-trail" aria-label="' . esc_attr__( 'Breadcrumb', 'snaplevel' ) . '"><ol style="display:flex;flex-wrap:wrap;gap:.4em;list-style:none;margin:0;padding:0;">';
		foreach ( $trail as $i => $crumb ) {
			$html .= '<li style="display:flex;gap:.4em;align-items:center;">';
			if ( $i === $last || '' === $crumb['url'] ) {
				$html .= '<span aria-current="page">' . esc_html( $crumb['label'] ) . '</span>';
			} else {
				$html .= '<a href="' . esc_url( $crumb['url'] ) . '">' . esc_html( $crumb['label'] ) . '</a>';
				$html .= '<span aria-hidden="true">' . esc_html( $sep ) . '</span>';
			}
			$html .= '</li>';
		}
		$html .= '</ol></nav>';

		return $html;
	}

	public function shortcode(): string {
		return self::render();
	}

	// ── JSON-LD ───────────────────────────────────────────────────────────────

	public function output_jsonld(): void {
		if ( is_admin() || is_front_page() ) {
			return;
		}
		$trail = self::get_trail();
		if ( count( $trail ) < 2 ) {
			return;
		}

		$items = array();
		foreach ( $trail as $i => $crumb ) {
			$item = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'name'     => $crumb['label'],
			);
			if ( '' !== $crumb['url'] ) {
				$item['item'] = $crumb['url'];
			}
			$items[] = $item;
		}

		echo '<script type="application/ld+json">' . wp_json_encode( array(
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $items,
		) ) . '</script>' . "\n";
	}
}

if ( ! function_exists( 'snaplevel_breadcrumbs' ) ) {
	/** Theme template function: echo the Snaplevel breadcrumb trail. */
	function snaplevel_breadcrumbs(): void {
		if ( class_exists( 'Snap_Breadcrumbs' ) ) {
			echo Snap_Breadcrumbs::render(); // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}
}
