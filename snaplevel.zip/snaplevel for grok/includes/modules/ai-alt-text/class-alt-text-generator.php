<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ICW_Alt_Text_Generator — AI Alt Text module.
 *
 * 2.0: migrated onto the central Snap_AI engine (Anthropic vision via the
 * provider abstraction). This module no longer owns any API plumbing.
 * AJAX contract is unchanged so the existing admin UI keeps working.
 */
class ICW_Alt_Text_Generator {

	public function __construct() {
		add_action( 'wp_ajax_icw_get_images_for_alt', array( $this, 'ajax_get_images' ) );
		add_action( 'wp_ajax_icw_generate_alt_text',  array( $this, 'ajax_generate' ) );
		add_action( 'wp_ajax_icw_save_image_meta',    array( $this, 'ajax_save_meta' ) );
	}

	// ── Public API ────────────────────────────────────────────────────────────

	/**
	 * Generate metadata for one image through the central AI engine.
	 *
	 * @param int    $attachment_id
	 * @param string $keywords Comma-separated context keywords.
	 * @return array { success, alt, title, caption, description } | { success=false, message }
	 */
	public static function generate( int $attachment_id, string $keywords = '' ): array {
		if ( ! $attachment_id ) {
			return self::err( 'Missing attachment ID.' );
		}

		$image_url = wp_get_attachment_url( $attachment_id );
		if ( ! $image_url ) {
			return self::err( 'Could not resolve image URL.' );
		}

		$result = Snap_AI::generate( 'alt_text', array(
			'image_url' => $image_url,
			'keywords'  => $keywords,
		) );

		if ( is_wp_error( $result ) ) {
			return self::err( $result->get_error_message() );
		}

		$data = $result['data'];

		return array(
			'success'       => true,
			'attachment_id' => $attachment_id,
			'alt'           => sanitize_text_field( (string) ( $data['alt'] ?? '' ) ),
			'title'         => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			'caption'       => sanitize_textarea_field( (string) ( $data['caption'] ?? '' ) ),
			'description'   => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'cached'        => ! empty( $result['cached'] ),
		);
	}

	/**
	 * Write generated data into WordPress attachment fields and post meta.
	 */
	public static function apply( int $id, array $data ): bool {
		$post_data = array( 'ID' => $id );

		if ( ! empty( $data['title'] ) ) {
			$post_data['post_title'] = $data['title'];
		}
		if ( ! empty( $data['caption'] ) ) {
			$post_data['post_excerpt'] = $data['caption'];
		}
		if ( ! empty( $data['description'] ) ) {
			$post_data['post_content'] = $data['description'];
		}

		$result = wp_update_post( $post_data, true );
		if ( is_wp_error( $result ) ) {
			return false;
		}

		if ( ! empty( $data['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', $data['alt'] );
		}
		update_post_meta( $id, '_icw_alt_generated', time() );

		return true;
	}

	/**
	 * Queue alt text generation for many images via the shared AI queue.
	 *
	 * @param int[] $attachment_ids
	 * @return int Number of jobs queued.
	 */
	public static function queue_bulk( array $attachment_ids ): int {
		$keywords = (string) Snap_Settings::instance()->get( 'ai.keywords', '' );
		$queued   = 0;

		foreach ( $attachment_ids as $id ) {
			$id  = (int) $id;
			$url = wp_get_attachment_url( $id );
			if ( ! $url ) {
				continue;
			}
			Snap_AI_Queue::instance()->push( 'alt_text', array(
				'image_url'     => $url,
				'keywords'      => $keywords,
				'attachment_id' => $id,
			), 'bulk_alt_text' );
			$queued++;
		}

		return $queued;
	}

	// ── AJAX handlers ─────────────────────────────────────────────────────────

	/** Return a paginated list of images with their current alt text. */
	public function ajax_get_images(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$offset       = max( 0, (int) ( isset( $_POST['offset'] ) ? $_POST['offset'] : 0 ) );
		$limit        = min( 48, max( 1, (int) ( isset( $_POST['limit'] ) ? $_POST['limit'] : 12 ) ) );
		$only_missing = ! empty( $_POST['only_missing'] );

		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' ),
			'posts_per_page' => $limit,
			'offset'         => $offset,
			'fields'         => 'ids',
		);

		if ( $only_missing ) {
			$args['meta_query'] = array(
				array(
					'key'     => '_wp_attachment_image_alt',
					'compare' => 'NOT EXISTS',
				),
			);
		}

		$query = new WP_Query( $args );
		$ids   = $query->posts;
		$total = $query->found_posts;

		$items = array();
		foreach ( $ids as $id ) {
			$items[] = array(
				'id'          => (int) $id,
				'thumb'       => wp_get_attachment_image_url( $id, 'thumbnail' ) ?: '',
				'title'       => get_the_title( $id ),
				'current_alt' => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
				'generated'   => (bool) get_post_meta( $id, '_icw_alt_generated', true ),
			);
		}

		wp_send_json_success( array( 'items' => $items, 'total' => (int) $total ) );
	}

	/** Generate alt text for one image (does NOT auto-save — user reviews first). */
	public function ajax_generate(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'upload_files' ) || ! Snap_Capabilities::can_use_ai() ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$id = (int) ( isset( $_POST['attachment_id'] ) ? $_POST['attachment_id'] : 0 );
		if ( $id <= 0 ) {
			wp_send_json_error( 'Invalid attachment ID.' );
		}

		if ( '' === Snap_Settings::instance()->get_api_key() ) {
			wp_send_json_error( 'No AI API key set. Connect Claude or ChatGPT in Snaplevel → Settings → AI.' );
		}

		$keywords = (string) Snap_Settings::instance()->get( 'ai.keywords', '' );
		$result   = self::generate( $id, $keywords );

		if ( $result['success'] ) {
			// Bulk mode: auto_save flag saves immediately.
			if ( ! empty( $_POST['auto_save'] ) ) {
				self::apply( $id, $result );
				$result['saved'] = true;
			}
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result['message'] );
		}
	}

	/** Save (possibly edited) metadata back to the attachment. */
	public function ajax_save_meta(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$id = (int) ( isset( $_POST['attachment_id'] ) ? $_POST['attachment_id'] : 0 );
		if ( $id <= 0 ) {
			wp_send_json_error( 'Invalid attachment ID.' );
		}

		$data = array(
			'alt'         => sanitize_text_field( isset( $_POST['alt'] ) ? (string) $_POST['alt'] : '' ),
			'title'       => sanitize_text_field( isset( $_POST['title'] ) ? (string) $_POST['title'] : '' ),
			'caption'     => sanitize_textarea_field( isset( $_POST['caption'] ) ? (string) $_POST['caption'] : '' ),
			'description' => sanitize_textarea_field( isset( $_POST['description'] ) ? (string) $_POST['description'] : '' ),
		);

		$ok = self::apply( $id, $data );
		if ( $ok ) {
			wp_send_json_success( 'Saved.' );
		} else {
			wp_send_json_error( 'Could not save metadata.' );
		}
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private static function err( string $msg ): array {
		return array( 'success' => false, 'message' => $msg );
	}
}

// Apply queued bulk alt-text results as they complete.
add_action( 'snap_ai_job_complete', static function ( $job, $result ) {
	if ( 'alt_text' !== ( $job['task'] ?? '' ) || 'bulk_alt_text' !== ( $job['group'] ?? '' ) ) {
		return;
	}
	$attachment_id = (int) ( $job['context']['attachment_id'] ?? 0 );
	if ( $attachment_id > 0 && is_array( $result ) && ! empty( $result['data'] ) ) {
		ICW_Alt_Text_Generator::apply( $attachment_id, (array) $result['data'] );
	}
}, 10, 2 );
