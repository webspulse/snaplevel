<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Redirections — redirect manager + 404 monitor.
 *
 * 301/302/307/410/451 redirects with optional regex, hit counting,
 * CSV export/import, a live 404 log with one-click redirect creation,
 * and optional auto-redirect of deleted posts.
 */
final class Snap_Redirections {

	const TYPES = array( 301, 302, 307, 410, 451 );

	public function __construct() {
		add_action( 'template_redirect', array( $this, 'maybe_redirect' ), 1 );
		add_action( 'template_redirect', array( $this, 'maybe_log_404' ), 9999 );
		add_action( 'wp_trash_post', array( $this, 'capture_deleted_post' ) );

		add_action( 'wp_ajax_snap_redirect_save',   array( $this, 'ajax_save' ) );
		add_action( 'wp_ajax_snap_redirect_delete', array( $this, 'ajax_delete' ) );
		add_action( 'wp_ajax_snap_redirect_test',   array( $this, 'ajax_test' ) );
		add_action( 'wp_ajax_snap_404_clear',       array( $this, 'ajax_404_clear' ) );
		add_action( 'wp_ajax_snap_404_dismiss',     array( $this, 'ajax_404_dismiss' ) );
		add_action( 'admin_post_snap_redirects_export', array( $this, 'export_csv' ) );
		add_action( 'admin_post_snap_redirects_import', array( $this, 'import_csv' ) );
	}

	// ── Tables ────────────────────────────────────────────────────────────────

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'snap_redirects';
	}

	public static function table_404(): string {
		global $wpdb;
		return $wpdb->prefix . 'snap_404_log';
	}

	public static function create_tables(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		dbDelta( 'CREATE TABLE ' . self::table() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source VARCHAR(500) NOT NULL,
			target VARCHAR(500) NOT NULL DEFAULT '',
			type SMALLINT UNSIGNED NOT NULL DEFAULT 301,
			is_regex TINYINT(1) NOT NULL DEFAULT 0,
			hits BIGINT UNSIGNED NOT NULL DEFAULT 0,
			last_hit DATETIME NULL DEFAULT NULL,
			created DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY source_idx (source(191))
		) {$charset};" );

		dbDelta( 'CREATE TABLE ' . self::table_404() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			url VARCHAR(500) NOT NULL,
			url_hash CHAR(32) NOT NULL,
			referer VARCHAR(500) NOT NULL DEFAULT '',
			hits BIGINT UNSIGNED NOT NULL DEFAULT 1,
			last_seen DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY url_hash (url_hash)
		) {$charset};" );

		update_option( 'snap_redirects_db', 1 );
	}

	public static function maybe_create_tables(): void {
		if ( ! get_option( 'snap_redirects_db' ) ) {
			self::create_tables();
		}
	}

	// ── Frontend matching ─────────────────────────────────────────────────────

	/** Normalize a path: leading slash, no trailing slash, no query, decoded, lowercase. */
	public static function normalize_path( string $url ): string {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		// Strip the site's own subdirectory so saved paths match requests.
		$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( '/' !== $home_path && '' !== $home_path && 0 === stripos( $path, $home_path ) ) {
			$path = substr( $path, strlen( $home_path ) - 1 );
		}
		$path = rawurldecode( $path );
		$path = '/' . ltrim( $path, '/' );
		if ( strlen( $path ) > 1 ) {
			$path = rtrim( $path, '/' );
		}
		return strtolower( $path );
	}

	private static function all_redirects(): array {
		$cached = get_transient( 'snap_redirects_all' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		global $wpdb;
		if ( ! get_option( 'snap_redirects_db' ) ) {
			return array();
		}
		$rows = $wpdb->get_results( 'SELECT id, source, target, type, is_regex FROM ' . self::table(), ARRAY_A ); // phpcs:ignore
		$rows = is_array( $rows ) ? $rows : array();
		set_transient( 'snap_redirects_all', $rows, HOUR_IN_SECONDS );
		return $rows;
	}

	public static function flush_cache(): void {
		delete_transient( 'snap_redirects_all' );
	}

	public function maybe_redirect(): void {
		if ( is_admin() ) {
			return;
		}
		$request = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		if ( '' === $request ) {
			return;
		}
		$path  = self::normalize_path( $request );
		$match = self::match( $path );
		if ( null === $match ) {
			return;
		}

		global $wpdb;
		$wpdb->query( $wpdb->prepare( // phpcs:ignore
			'UPDATE ' . self::table() . ' SET hits = hits + 1, last_hit = %s WHERE id = %d',
			current_time( 'mysql' ),
			(int) $match['id']
		) );

		$type = (int) $match['type'];
		if ( 410 === $type || 451 === $type ) {
			status_header( $type );
			nocache_headers();
			wp_die(
				410 === $type
					? esc_html__( 'This content has been permanently removed.', 'snaplevel' )
					: esc_html__( 'This content is unavailable for legal reasons.', 'snaplevel' ),
				'',
				array( 'response' => $type )
			);
		}

		$target = (string) $match['resolved_target'];
		if ( '' === $target ) {
			return;
		}
		if ( 0 !== strpos( $target, 'http' ) ) {
			$target = home_url( $target );
		}
		wp_redirect( $target, $type ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}

	/** @return array|null matched row + resolved_target */
	public static function match( string $path ) {
		foreach ( self::all_redirects() as $row ) {
			if ( ! empty( $row['is_regex'] ) ) {
				$pattern = '~' . str_replace( '~', '\~', (string) $row['source'] ) . '~i';
				$result  = @preg_replace( $pattern, (string) $row['target'], $path, 1, $count );
				if ( null !== $result && $count > 0 ) {
					$row['resolved_target'] = $result;
					return $row;
				}
			} elseif ( self::normalize_path( (string) $row['source'] ) === $path ) {
				$row['resolved_target'] = (string) $row['target'];
				return $row;
			}
		}
		return null;
	}

	// ── 404 monitor ───────────────────────────────────────────────────────────

	public function maybe_log_404(): void {
		if ( ! is_404() || is_admin() || ! get_option( 'snap_redirects_db' ) ) {
			return;
		}
		$request = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		$path    = self::normalize_path( $request );
		// Skip obvious bot probing noise.
		if ( preg_match( '~\.(php|env|sql|bak|asp|cgi)$|wp-content/uploads.*\.(jpe?g|png|webp|gif)$~i', $path ) ) {
			return;
		}

		global $wpdb;
		$hash    = md5( $path );
		$referer = esc_url_raw( (string) wp_get_referer() );

		$wpdb->query( $wpdb->prepare( // phpcs:ignore
			'INSERT INTO ' . self::table_404() . ' (url, url_hash, referer, hits, last_seen)
			 VALUES (%s, %s, %s, 1, %s)
			 ON DUPLICATE KEY UPDATE hits = hits + 1, last_seen = VALUES(last_seen), referer = VALUES(referer)',
			substr( $path, 0, 500 ),
			$hash,
			substr( $referer, 0, 500 ),
			current_time( 'mysql' )
		) );

		// Cap the log at 2000 rows.
		$count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table_404() ); // phpcs:ignore
		if ( $count > 2000 ) {
			$wpdb->query( 'DELETE FROM ' . self::table_404() . ' ORDER BY last_seen ASC LIMIT 200' ); // phpcs:ignore
		}
	}

	// ── Auto-redirect deleted posts ───────────────────────────────────────────

	public function capture_deleted_post( int $post_id ): void {
		if ( ! Snap_Settings::instance()->get( 'redirections.auto_deleted', false ) ) {
			return;
		}
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
			return;
		}
		if ( ! in_array( $post->post_type, get_post_types( array( 'public' => true ) ), true ) ) {
			return;
		}
		$source = self::normalize_path( (string) get_permalink( $post ) );
		if ( '/' === $source || null !== self::match( $source ) ) {
			return;
		}
		self::insert( array(
			'source'   => $source,
			'target'   => home_url( '/' ),
			'type'     => 301,
			'is_regex' => 0,
		) );
	}

	// ── CRUD ──────────────────────────────────────────────────────────────────

	public static function insert( array $data ): int {
		global $wpdb;
		self::maybe_create_tables();
		$wpdb->insert( self::table(), array(
			'source'   => substr( (string) $data['source'], 0, 500 ),
			'target'   => substr( (string) $data['target'], 0, 500 ),
			'type'     => in_array( (int) $data['type'], self::TYPES, true ) ? (int) $data['type'] : 301,
			'is_regex' => empty( $data['is_regex'] ) ? 0 : 1,
			'created'  => current_time( 'mysql' ),
		), array( '%s', '%s', '%d', '%d', '%s' ) );
		self::flush_cache();
		return (int) $wpdb->insert_id;
	}

	public function ajax_save(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$id       = (int) ( $_POST['id'] ?? 0 );
		$source   = trim( sanitize_text_field( (string) wp_unslash( $_POST['source'] ?? '' ) ) );
		$target   = trim( sanitize_text_field( (string) wp_unslash( $_POST['target'] ?? '' ) ) );
		$type     = (int) ( $_POST['type'] ?? 301 );
		$is_regex = ! empty( $_POST['is_regex'] ) ? 1 : 0;

		if ( '' === $source ) {
			wp_send_json_error( __( 'Source URL is required.', 'snaplevel' ) );
		}
		if ( ! in_array( $type, self::TYPES, true ) ) {
			$type = 301;
		}
		if ( '' === $target && 410 !== $type && 451 !== $type ) {
			wp_send_json_error( __( 'Target URL is required for this redirect type.', 'snaplevel' ) );
		}
		if ( $is_regex && false === @preg_match( '~' . str_replace( '~', '\~', $source ) . '~i', '' ) ) {
			wp_send_json_error( __( 'Invalid regular expression.', 'snaplevel' ) );
		}
		if ( ! $is_regex ) {
			$source = self::normalize_path( $source );
			if ( '/' === $source ) {
				wp_send_json_error( __( 'You cannot redirect the homepage from here.', 'snaplevel' ) );
			}
		}

		global $wpdb;
		self::maybe_create_tables();

		if ( $id > 0 ) {
			$wpdb->update( self::table(), array(
				'source'   => substr( $source, 0, 500 ),
				'target'   => substr( $target, 0, 500 ),
				'type'     => $type,
				'is_regex' => $is_regex,
			), array( 'id' => $id ), array( '%s', '%s', '%d', '%d' ), array( '%d' ) );
			self::flush_cache();
			wp_send_json_success( array( 'id' => $id ) );
		}

		$new_id = self::insert( array( 'source' => $source, 'target' => $target, 'type' => $type, 'is_regex' => $is_regex ) );

		// One-click from the 404 monitor: clear the matching log row.
		if ( ! empty( $_POST['from_404'] ) ) {
			$wpdb->delete( self::table_404(), array( 'url_hash' => md5( $source ) ), array( '%s' ) );
		}

		wp_send_json_success( array( 'id' => $new_id ) );
	}

	public function ajax_delete(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}
		global $wpdb;
		$wpdb->delete( self::table(), array( 'id' => (int) ( $_POST['id'] ?? 0 ) ), array( '%d' ) );
		self::flush_cache();
		wp_send_json_success();
	}

	/** URL tester: run a URL through the live matcher. */
	public function ajax_test(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}
		$url   = (string) wp_unslash( $_POST['url'] ?? '' );
		$path  = self::normalize_path( $url );
		$match = self::match( $path );
		if ( null === $match ) {
			wp_send_json_success( array( 'matched' => false, 'path' => $path ) );
		}
		wp_send_json_success( array(
			'matched' => true,
			'path'    => $path,
			'type'    => (int) $match['type'],
			'target'  => (string) $match['resolved_target'],
			'regex'   => ! empty( $match['is_regex'] ),
		) );
	}

	public function ajax_404_clear(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}
		global $wpdb;
		$wpdb->query( 'TRUNCATE TABLE ' . self::table_404() ); // phpcs:ignore
		wp_send_json_success();
	}

	public function ajax_404_dismiss(): void {
		check_ajax_referer( 'icw_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}
		global $wpdb;
		$wpdb->delete( self::table_404(), array( 'id' => (int) ( $_POST['id'] ?? 0 ) ), array( '%d' ) );
		wp_send_json_success();
	}

	// ── CSV export / import ───────────────────────────────────────────────────

	public function export_csv(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'snap_redirects_export' ) ) {
			wp_die( 'Permission denied.' );
		}
		global $wpdb;
		self::maybe_create_tables();
		$rows = $wpdb->get_results( 'SELECT source, target, type, is_regex, hits FROM ' . self::table() . ' ORDER BY id ASC', ARRAY_A ); // phpcs:ignore

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=snaplevel-redirects-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'source', 'target', 'type', 'is_regex', 'hits' ) );
		foreach ( (array) $rows as $row ) {
			fputcsv( $out, $row );
		}
		fclose( $out ); // phpcs:ignore
		exit;
	}

	public function import_csv(): void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'snap_redirects_import' ) ) {
			wp_die( 'Permission denied.' );
		}
		$redirect_back = admin_url( 'admin.php?page=snap-redirections' );

		if ( empty( $_FILES['csv']['tmp_name'] ) ) {
			wp_safe_redirect( add_query_arg( 'imported', 'error', $redirect_back ) );
			exit;
		}

		$handle = fopen( (string) $_FILES['csv']['tmp_name'], 'r' ); // phpcs:ignore
		if ( ! $handle ) {
			wp_safe_redirect( add_query_arg( 'imported', 'error', $redirect_back ) );
			exit;
		}

		self::maybe_create_tables();
		$imported = 0;
		$header   = null;
		while ( false !== ( $row = fgetcsv( $handle ) ) ) {
			if ( null === $header ) {
				$header = array_map( 'strtolower', array_map( 'trim', $row ) );
				continue;
			}
			$data = array_combine( $header, array_pad( $row, count( $header ), '' ) );
			if ( empty( $data['source'] ) ) {
				continue;
			}
			self::insert( array(
				'source'   => sanitize_text_field( (string) $data['source'] ),
				'target'   => sanitize_text_field( (string) ( $data['target'] ?? '' ) ),
				'type'     => (int) ( $data['type'] ?? 301 ),
				'is_regex' => (int) ( $data['is_regex'] ?? 0 ),
			) );
			$imported++;
		}
		fclose( $handle ); // phpcs:ignore

		wp_safe_redirect( add_query_arg( 'imported', (string) $imported, $redirect_back ) );
		exit;
	}

	// ── Data for the admin view ───────────────────────────────────────────────

	public static function get_redirects( string $search = '' ): array {
		global $wpdb;
		self::maybe_create_tables();
		if ( '' !== $search ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			return (array) $wpdb->get_results( $wpdb->prepare( // phpcs:ignore
				'SELECT * FROM ' . self::table() . ' WHERE source LIKE %s OR target LIKE %s ORDER BY id DESC LIMIT 500',
				$like,
				$like
			), ARRAY_A );
		}
		return (array) $wpdb->get_results( 'SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT 500', ARRAY_A ); // phpcs:ignore
	}

	public static function get_404s(): array {
		global $wpdb;
		self::maybe_create_tables();
		return (array) $wpdb->get_results( 'SELECT * FROM ' . self::table_404() . ' ORDER BY hits DESC, last_seen DESC LIMIT 300', ARRAY_A ); // phpcs:ignore
	}

	public static function count_active(): int {
		global $wpdb;
		if ( ! get_option( 'snap_redirects_db' ) ) {
			return 0;
		}
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() ); // phpcs:ignore
	}

	public static function count_404s(): int {
		global $wpdb;
		if ( ! get_option( 'snap_redirects_db' ) ) {
			return 0;
		}
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table_404() ); // phpcs:ignore
	}
}
