<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Importer_Extra — one engine, many sources.
 *
 * Meta-key based importers for AIOSEO (custom table), SEOPress,
 * The SEO Framework, SmartCrawl, WP Meta SEO, and Slim SEO.
 * Same contract as the Yoast/RankMath importers: detect() + run_batch(),
 * never overwrites existing _snap_* values.
 */
final class Snap_Importer_Extra {

	/**
	 * Meta-key sources. detect_like = LIKE pattern proving data exists.
	 * map = source meta key → snap key. noindex/nofollow = key whose
	 * truthy value adds the directive.
	 */
	private static function sources(): array {
		return array(
			'seopress'      => array(
				'name'        => 'SEOPress',
				'active'      => defined( 'SEOPRESS_VERSION' ),
				'detect_like' => '\_seopress\_%',
				'map'         => array(
					'_seopress_titles_title'        => '_snap_title',
					'_seopress_titles_desc'         => '_snap_desc',
					'_seopress_analysis_target_kw'  => '_snap_focus_kw',
					'_seopress_robots_canonical'    => '_snap_canonical',
					'_seopress_social_fb_title'     => '_snap_og_title',
					'_seopress_social_fb_desc'      => '_snap_og_desc',
					'_seopress_social_fb_img'       => '_snap_og_image',
					'_seopress_social_twitter_title' => '_snap_tw_title',
					'_seopress_social_twitter_desc' => '_snap_tw_desc',
					'_seopress_social_twitter_img'  => '_snap_tw_image',
				),
				'noindex'     => '_seopress_robots_index',
				'nofollow'    => '_seopress_robots_follow',
			),
			'seoframework'  => array(
				'name'        => 'The SEO Framework',
				'active'      => defined( 'THE_SEO_FRAMEWORK_VERSION' ),
				'detect_like' => '\_genesis\_title',
				'map'         => array(
					'_genesis_title'         => '_snap_title',
					'_genesis_description'   => '_snap_desc',
					'_genesis_canonical_uri' => '_snap_canonical',
					'_open_graph_title'      => '_snap_og_title',
					'_open_graph_description' => '_snap_og_desc',
					'_social_image_url'      => '_snap_og_image',
					'_twitter_title'         => '_snap_tw_title',
					'_twitter_description'   => '_snap_tw_desc',
				),
				'noindex'     => '_genesis_noindex',
				'nofollow'    => '_genesis_nofollow',
			),
			'smartcrawl'    => array(
				'name'        => 'SmartCrawl',
				'active'      => defined( 'SMARTCRAWL_VERSION' ),
				'detect_like' => '\_wds\_%',
				'map'         => array(
					'_wds_title'          => '_snap_title',
					'_wds_metadesc'       => '_snap_desc',
					'_wds_focus-keywords' => '_snap_focus_kw',
					'_wds_canonical'      => '_snap_canonical',
					'_wds_og-title'       => '_snap_og_title',
					'_wds_og-description' => '_snap_og_desc',
					'_wds_twitter-title'  => '_snap_tw_title',
					'_wds_twitter-description' => '_snap_tw_desc',
				),
				'noindex'     => '_wds_meta-robots-noindex',
				'nofollow'    => '_wds_meta-robots-nofollow',
			),
			'wpmetaseo'     => array(
				'name'        => 'WP Meta SEO',
				'active'      => defined( 'WPMSEO_VERSION' ),
				'detect_like' => '\_metaseo\_%',
				'map'         => array(
					'_metaseo_metatitle' => '_snap_title',
					'_metaseo_metadesc'  => '_snap_desc',
					'_metaseo_metaopengraph-title' => '_snap_og_title',
					'_metaseo_metaopengraph-desc'  => '_snap_og_desc',
					'_metaseo_metatwitter-title'   => '_snap_tw_title',
					'_metaseo_metatwitter-desc'    => '_snap_tw_desc',
				),
			),
		);
	}

	public static function source_ids(): array {
		return array_merge( array_keys( self::sources() ), array( 'aioseo', 'slimseo' ) );
	}

	// ── Detection ─────────────────────────────────────────────────────────────

	public static function detect_all(): array {
		$out = array();
		foreach ( self::sources() as $id => $conf ) {
			$count = self::count_meta_posts( $conf['detect_like'] );
			$out[ $id ] = array(
				'available' => $count > 0,
				'active'    => (bool) $conf['active'],
				'posts'     => $count,
				'name'      => $conf['name'],
			);
		}
		$out['aioseo']  = self::detect_aioseo();
		$out['slimseo'] = self::detect_slimseo();
		return $out;
	}

	private static function count_meta_posts( string $like ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
			$like
		) );
	}

	private static function detect_aioseo(): array {
		global $wpdb;
		$table  = $wpdb->prefix . 'aioseo_posts';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
		$count  = $exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE title IS NOT NULL OR description IS NOT NULL" ) : 0;
		return array(
			'available' => $count > 0,
			'active'    => defined( 'AIOSEO_VERSION' ),
			'posts'     => $count,
			'name'      => 'All in One SEO',
		);
	}

	private static function detect_slimseo(): array {
		$count = self::count_meta_posts( 'slim\_seo' );
		return array(
			'available' => $count > 0,
			'active'    => defined( 'SLIM_SEO_VER' ),
			'posts'     => $count,
			'name'      => 'Slim SEO',
		);
	}

	// ── Batch runner ──────────────────────────────────────────────────────────

	public static function run_batch( string $source, int $offset, int $limit = 200 ): array {
		if ( 'aioseo' === $source ) {
			return self::run_aioseo( $offset, $limit );
		}
		if ( 'slimseo' === $source ) {
			return self::run_slimseo( $offset, $limit );
		}

		$sources = self::sources();
		if ( ! isset( $sources[ $source ] ) ) {
			return array( 'source' => $source, 'imported' => 0, 'scanned' => 0, 'total' => 0, 'done' => true, 'next_offset' => $offset );
		}
		$conf = $sources[ $source ];

		global $wpdb;
		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key LIKE %s ORDER BY post_id ASC LIMIT %d OFFSET %d",
			$conf['detect_like'],
			$limit,
			$offset
		) );
		$total = self::count_meta_posts( $conf['detect_like'] );

		$imported = 0;
		foreach ( $post_ids as $post_id ) {
			if ( self::import_mapped( (int) $post_id, $conf ) ) {
				$imported++;
			}
		}

		$scanned = count( $post_ids );
		return array(
			'source'      => $source,
			'imported'    => $imported,
			'scanned'     => $scanned,
			'total'       => $total,
			'done'        => ( $offset + $scanned ) >= $total || 0 === $scanned,
			'next_offset' => $offset + $scanned,
		);
	}

	private static function import_mapped( int $post_id, array $conf ): bool {
		$did = false;

		foreach ( $conf['map'] as $from => $to ) {
			$value = get_post_meta( $post_id, $from, true );
			if ( ! is_string( $value ) || '' === $value ) {
				continue;
			}
			if ( '' !== (string) get_post_meta( $post_id, $to, true ) ) {
				continue; // Never overwrite Snaplevel data.
			}
			update_post_meta( $post_id, $to, self::convert_vars( $value ) );
			$did = true;
		}

		if ( '' === (string) get_post_meta( $post_id, '_snap_robots', true ) ) {
			$directives = array();
			if ( ! empty( $conf['noindex'] ) && self::is_truthy_directive( (string) get_post_meta( $post_id, $conf['noindex'], true ), 'noindex' ) ) {
				$directives[] = 'noindex';
			}
			if ( ! empty( $conf['nofollow'] ) && self::is_truthy_directive( (string) get_post_meta( $post_id, $conf['nofollow'], true ), 'nofollow' ) ) {
				$directives[] = 'nofollow';
			}
			if ( $directives ) {
				update_post_meta( $post_id, '_snap_robots', implode( ',', $directives ) );
				$did = true;
			}
		}

		return $did;
	}

	/** Plugins store directives as '1', 'yes', 'on', or the directive itself. */
	private static function is_truthy_directive( string $value, string $directive ): bool {
		return in_array( strtolower( $value ), array( '1', 'yes', 'on', 'true', $directive ), true );
	}

	// ── AIOSEO (custom table) ─────────────────────────────────────────────────

	private static function run_aioseo( int $offset, int $limit ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'aioseo_posts';

		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			return array( 'source' => 'aioseo', 'imported' => 0, 'scanned' => 0, 'total' => 0, 'done' => true, 'next_offset' => $offset );
		}

		$rows  = $wpdb->get_results( $wpdb->prepare(
			"SELECT post_id, title, description, keywords, canonical_url, robots_noindex, robots_nofollow,
			        og_title, og_description, og_image_custom_url, twitter_title, twitter_description, twitter_image_custom_url
			 FROM {$table} ORDER BY post_id ASC LIMIT %d OFFSET %d",
			$limit,
			$offset
		), ARRAY_A );
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		$imported = 0;
		foreach ( (array) $rows as $row ) {
			$post_id = (int) $row['post_id'];
			$pairs   = array(
				'_snap_title'     => (string) ( $row['title'] ?? '' ),
				'_snap_desc'      => (string) ( $row['description'] ?? '' ),
				'_snap_canonical' => (string) ( $row['canonical_url'] ?? '' ),
				'_snap_og_title'  => (string) ( $row['og_title'] ?? '' ),
				'_snap_og_desc'   => (string) ( $row['og_description'] ?? '' ),
				'_snap_og_image'  => (string) ( $row['og_image_custom_url'] ?? '' ),
				'_snap_tw_title'  => (string) ( $row['twitter_title'] ?? '' ),
				'_snap_tw_desc'   => (string) ( $row['twitter_description'] ?? '' ),
				'_snap_tw_image'  => (string) ( $row['twitter_image_custom_url'] ?? '' ),
			);
			// AIOSEO keywords is a JSON array of {label,value}.
			$kw = json_decode( (string) ( $row['keywords'] ?? '' ), true );
			if ( is_array( $kw ) && ! empty( $kw[0]['value'] ) ) {
				$pairs['_snap_focus_kw'] = (string) $kw[0]['value'];
			}

			$did = false;
			foreach ( $pairs as $to => $value ) {
				if ( '' === $value || '' !== (string) get_post_meta( $post_id, $to, true ) ) {
					continue;
				}
				update_post_meta( $post_id, $to, self::convert_vars( $value ) );
				$did = true;
			}

			if ( '' === (string) get_post_meta( $post_id, '_snap_robots', true ) ) {
				$directives = array();
				if ( ! empty( $row['robots_noindex'] ) ) {
					$directives[] = 'noindex';
				}
				if ( ! empty( $row['robots_nofollow'] ) ) {
					$directives[] = 'nofollow';
				}
				if ( $directives ) {
					update_post_meta( $post_id, '_snap_robots', implode( ',', $directives ) );
					$did = true;
				}
			}

			if ( $did ) {
				$imported++;
			}
		}

		$scanned = count( (array) $rows );
		return array(
			'source'      => 'aioseo',
			'imported'    => $imported,
			'scanned'     => $scanned,
			'total'       => $total,
			'done'        => ( $offset + $scanned ) >= $total || 0 === $scanned,
			'next_offset' => $offset + $scanned,
		);
	}

	// ── Slim SEO (single serialized meta) ─────────────────────────────────────

	private static function run_slimseo( int $offset, int $limit ): array {
		global $wpdb;

		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'slim_seo' ORDER BY post_id ASC LIMIT %d OFFSET %d",
			$limit,
			$offset
		) );
		$total = self::count_meta_posts( 'slim\_seo' );

		$imported = 0;
		foreach ( $post_ids as $post_id ) {
			$post_id = (int) $post_id;
			$data    = get_post_meta( $post_id, 'slim_seo', true );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$pairs = array(
				'_snap_title'    => (string) ( $data['title'] ?? '' ),
				'_snap_desc'     => (string) ( $data['description'] ?? '' ),
				'_snap_og_image' => (string) ( $data['facebook_image'] ?? '' ),
				'_snap_tw_image' => (string) ( $data['twitter_image'] ?? '' ),
			);
			$did = false;
			foreach ( $pairs as $to => $value ) {
				if ( '' === $value || '' !== (string) get_post_meta( $post_id, $to, true ) ) {
					continue;
				}
				update_post_meta( $post_id, $to, $value );
				$did = true;
			}
			if ( ! empty( $data['noindex'] ) && '' === (string) get_post_meta( $post_id, '_snap_robots', true ) ) {
				update_post_meta( $post_id, '_snap_robots', 'noindex' );
				$did = true;
			}
			if ( $did ) {
				$imported++;
			}
		}

		$scanned = count( $post_ids );
		return array(
			'source'      => 'slimseo',
			'imported'    => $imported,
			'scanned'     => $scanned,
			'total'       => $total,
			'done'        => ( $offset + $scanned ) >= $total || 0 === $scanned,
			'next_offset' => $offset + $scanned,
		);
	}

	/** Convert %%var%% (Yoast-style) and {{var}} (SEOPress/AIOSEO) syntax to %var%. */
	public static function convert_vars( string $value ): string {
		$map = array(
			'%%title%%'       => '%title%',
			'%%sitename%%'    => '%sitename%',
			'%%sep%%'         => '%sep%',
			'%%excerpt%%'     => '%excerpt%',
			'#post_title'     => '%title%',
			'#site_title'     => '%sitename%',
			'#separator_sa'   => '%sep%',
			'%%sitetitle%%'   => '%sitename%',
		);
		$value = strtr( $value, $map );
		$value = (string) preg_replace( '/\{\{\s*post_title\s*\}\}/i', '%title%', $value );
		$value = (string) preg_replace( '/\{\{\s*site_title\s*\}\}/i', '%sitename%', $value );
		$value = (string) preg_replace( '/\{\{\s*sep(arator)?\s*\}\}/i', '%sep%', $value );
		$value = (string) preg_replace( '/\{\{[a-z_ ]+\}\}/i', '', $value );
		$value = (string) preg_replace( '/%%[a-z_]+%%/i', '', $value );
		return trim( $value );
	}
}
