<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Conflict_Guard — detects active SEO plugins.
 *
 * When another SEO plugin is active, Snaplevel hard-disables its own
 * frontend meta output (see Snap_Meta_Output) and shows an admin notice
 * offering one-click import.
 */
final class Snap_Conflict_Guard {

	public function __construct() {
		add_action( 'admin_notices', array( $this, 'notice' ) );
	}

	/** @return array<string,string> plugin id => human name, for each active conflicting plugin. */
	public static function active_conflicts(): array {
		$conflicts = array();

		if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Frontend' ) ) {
			$conflicts['yoast'] = 'Yoast SEO';
		}
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
			$conflicts['rankmath'] = 'Rank Math';
		}
		if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
			$conflicts['aioseo'] = 'All in One SEO';
		}
		if ( defined( 'SEOPRESS_VERSION' ) || function_exists( 'seopress_init' ) ) {
			$conflicts['seopress'] = 'SEOPress';
		}

		return $conflicts;
	}

	public static function has_conflict(): bool {
		return ! empty( self::active_conflicts() );
	}

	public function notice(): void {
		if ( ! Snap_Capabilities::can_manage() ) {
			return;
		}
		$conflicts = self::active_conflicts();
		if ( empty( $conflicts ) ) {
			return;
		}

		$names      = implode( ', ', $conflicts );
		$import_url = admin_url( 'admin.php?page=snap-tools' );
		?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'Snaplevel:', 'snaplevel' ); ?></strong>
				<?php
				printf(
					/* translators: %s: list of plugin names */
					esc_html__( '%s is active, so Snaplevel has disabled its own SEO meta output to prevent duplicate tags. Import your SEO data into Snaplevel, then deactivate the other plugin to switch over.', 'snaplevel' ),
					esc_html( $names )
				);
				?>
				<a href="<?php echo esc_url( $import_url ); ?>"><?php esc_html_e( 'Open the importer', 'snaplevel' ); ?></a>
			</p>
		</div>
		<?php
	}
}
