<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Importer_Yoast — imports Yoast SEO post meta into _snap_* fields.
 *
 * Imports: titles, descriptions, focus keywords, robots, canonical.
 * Existing _snap_* values are never overwritten.
 */
final class Snap_Importer_Yoast {

	const MAP = array(
		'_yoast_wpseo_title'     => '_snap_title',
		'_yoast_wpseo_metadesc'  => '_snap_desc',
		'_yoast_wpseo_focuskw'   => '_snap_focus_kw',
		'_yoast_wpseo_canonical' => '_snap_canonical',
	);

	/** Detect whether Yoast data exists on this site. */
	public static function detect(): array {
		global $wpdb;

		$count = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE '\_yoast\_wpseo\_%'"
		);

		return array(
			'available' => $count > 0,
			'active'    => defined( 'WPSEO_VERSION' ),
			'posts'     => $count,
			'name'      => 'Yoast SEO',
		);
	}

	/**
	 * Import one batch.
	 *
	 * @return array { imported, scanned, total, done, next_offset }
	 */
	public static function run_batch( int $offset, int $limit = 200 ): array {
		global $wpdb;

		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT post_id FROM {$wpdb->postmeta}
			 WHERE meta_key LIKE '\_yoast\_wpseo\_%'
			 ORDER BY post_id ASC LIMIT %d OFFSET %d",
			$limit,
			$offset
		) );

		$total = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE '\_yoast\_wpseo\_%'"
		);

		$imported = 0;
		foreach ( $post_ids as $post_id ) {
			$post_id = (int) $post_id;
			if ( self::import_post( $post_id ) ) {
				$imported++;
			}
		}

		$scanned = count( $post_ids );

		return array(
			'source'      => 'yoast',
			'imported'    => $imported,
			'scanned'     => $scanned,
			'total'       => $total,
			'done'        => ( $offset + $scanned ) >= $total || 0 === $scanned,
			'next_offset' => $offset + $scanned,
		);
	}

	private static function import_post( int $post_id ): bool {
		$did = false;

		foreach ( self::MAP as $from => $to ) {
			$value = (string) get_post_meta( $post_id, $from, true );
			if ( '' === $value ) {
				continue;
			}
			if ( '' !== (string) get_post_meta( $post_id, $to, true ) ) {
				continue; // Never overwrite existing Snaplevel data.
			}
			update_post_meta( $post_id, $to, self::convert_vars( $value ) );
			$did = true;
		}

		// Robots: Yoast stores noindex as '1' in a dedicated key.
		if ( '' === (string) get_post_meta( $post_id, '_snap_robots', true ) ) {
			$directives = array();
			if ( '1' === (string) get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true ) ) {
				$directives[] = 'noindex';
			}
			if ( '1' === (string) get_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', true ) ) {
				$directives[] = 'nofollow';
			}
			if ( ! empty( $directives ) ) {
				update_post_meta( $post_id, '_snap_robots', implode( ',', $directives ) );
				$did = true;
			}
		}

		return $did;
	}

	/** Convert Yoast %%var%% syntax to Snaplevel %var%. */
	public static function convert_vars( string $value ): string {
		$map = array(
			'%%title%%'        => '%title%',
			'%%sitename%%'     => '%sitename%',
			'%%sitedesc%%'     => '%sitedesc%',
			'%%sep%%'          => '%sep%',
			'%%excerpt%%'      => '%excerpt%',
			'%%excerpt_only%%' => '%excerpt%',
			'%%category%%'     => '%category%',
			'%%currentdate%%'  => '%currentdate%',
			'%%currentyear%%'  => '%currentyear%',
			'%%date%%'         => '%date%',
			'%%name%%'         => '%name%',
			'%%searchphrase%%' => '%term%',
			'%%term_title%%'   => '%term%',
			'%%page%%'         => '%page%',
			'%%primary_category%%' => '%category%',
		);
		$value = strtr( $value, $map );
		// Drop any leftover unknown %%vars%%.
		return trim( (string) preg_replace( '/%%[a-z_]+%%/i', '', $value ) );
	}
}
