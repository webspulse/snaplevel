<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_Importer_RankMath — imports Rank Math post meta into _snap_* fields.
 *
 * Imports: titles, descriptions, focus keywords, robots, canonical.
 * Existing _snap_* values are never overwritten.
 */
final class Snap_Importer_RankMath {

	const MAP = array(
		'rank_math_title'         => '_snap_title',
		'rank_math_description'   => '_snap_desc',
		'rank_math_focus_keyword' => '_snap_focus_kw',
		'rank_math_canonical_url' => '_snap_canonical',
	);

	public static function detect(): array {
		global $wpdb;

		$count = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE 'rank\_math\_%'"
		);

		return array(
			'available' => $count > 0,
			'active'    => defined( 'RANK_MATH_VERSION' ),
			'posts'     => $count,
			'name'      => 'Rank Math',
		);
	}

	/**
	 * Import one batch.
	 *
	 * @return array { imported, scanned, total, done, next_offset }
	 */
	public static function run_batch( int $offset, int $limit = 200 ): array {
		global $wpdb;

		$post_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT post_id FROM {$wpdb->postmeta}
			 WHERE meta_key LIKE 'rank\_math\_%'
			 ORDER BY post_id ASC LIMIT %d OFFSET %d",
			$limit,
			$offset
		) );

		$total = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE 'rank\_math\_%'"
		);

		$imported = 0;
		foreach ( $post_ids as $post_id ) {
			$post_id = (int) $post_id;
			if ( self::import_post( $post_id ) ) {
				$imported++;
			}
		}

		$scanned = count( $post_ids );

		return array(
			'source'      => 'rankmath',
			'imported'    => $imported,
			'scanned'     => $scanned,
			'total'       => $total,
			'done'        => ( $offset + $scanned ) >= $total || 0 === $scanned,
			'next_offset' => $offset + $scanned,
		);
	}

	private static function import_post( int $post_id ): bool {
		$did = false;

		foreach ( self::MAP as $from => $to ) {
			$value = get_post_meta( $post_id, $from, true );
			// Rank Math stores multiple focus keywords comma-separated; take the first.
			if ( 'rank_math_focus_keyword' === $from && is_string( $value ) && false !== strpos( $value, ',' ) ) {
				$parts = explode( ',', $value );
				$value = trim( $parts[0] );
			}
			if ( ! is_string( $value ) || '' === $value ) {
				continue;
			}
			if ( '' !== (string) get_post_meta( $post_id, $to, true ) ) {
				continue; // Never overwrite existing Snaplevel data.
			}
			update_post_meta( $post_id, $to, self::convert_vars( $value ) );
			$did = true;
		}

		// Robots: Rank Math stores an array like [ 'index' ] or [ 'noindex', 'nofollow' ].
		if ( '' === (string) get_post_meta( $post_id, '_snap_robots', true ) ) {
			$robots = get_post_meta( $post_id, 'rank_math_robots', true );
			if ( is_array( $robots ) ) {
				$directives = array_values( array_intersect( array( 'noindex', 'nofollow' ), $robots ) );
				if ( ! empty( $directives ) ) {
					update_post_meta( $post_id, '_snap_robots', implode( ',', $directives ) );
					$did = true;
				}
			}
		}

		return $did;
	}

	/** Rank Math uses the same %var% syntax as Snaplevel; map the divergent ones. */
	public static function convert_vars( string $value ): string {
		$map = array(
			'%seo_title%'       => '%title%',
			'%seo_description%' => '%excerpt%',
			'%post_title%'      => '%title%',
			'%blog_title%'      => '%sitename%',
			'%blog_description%' => '%sitedesc%',
			'%primary_category%' => '%category%',
			'%search_query%'    => '%term%',
			'%author_name%'     => '%name%',
		);
		$value = strtr( $value, $map );

		$known = array( '%title%', '%sitename%', '%sitedesc%', '%sep%', '%excerpt%', '%category%', '%currentdate%', '%currentyear%', '%date%', '%name%', '%term%', '%page%', '%postname%' );

		// Drop unknown %vars% (Rank Math has many we don't support).
		return trim( (string) preg_replace_callback( '/%[a-z_]+%/i', static function ( $m ) use ( $known ) {
			return in_array( $m[0], $known, true ) ? $m[0] : '';
		}, $value ) );
	}
}
