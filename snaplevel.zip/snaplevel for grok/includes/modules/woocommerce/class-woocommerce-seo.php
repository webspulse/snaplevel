<?php
declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Snap_WooCommerce_SEO — store-specific SEO fixes.
 *
 * Active only when WooCommerce is running:
 * - noindex for cart, checkout, and my-account (thin/duplicate pages)
 * - product Open Graph price, currency, and availability tags
 * - removes the WooCommerce generator meta tag
 */
final class Snap_WooCommerce_SEO {

	public function __construct() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_filter( 'wp_robots', array( $this, 'noindex_store_pages' ), 30 );
		add_action( 'wp_head', array( $this, 'product_og_tags' ), 6 );
		remove_action( 'wp_head', 'wc_generator_tag' );
		add_filter( 'the_generator', array( $this, 'strip_wc_generator' ), 10, 2 );
	}

	public function noindex_store_pages( array $robots ): array {
		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) {
			$robots['noindex'] = true;
			unset( $robots['index'] );
		}
		return $robots;
	}

	public function product_og_tags(): void {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( get_queried_object_id() ) : null;
		if ( ! $product ) {
			return;
		}
		$price = $product->get_price();
		if ( '' !== $price && null !== $price ) {
			echo '<meta property="product:price:amount" content="' . esc_attr( (string) $price ) . '">' . "\n";
			echo '<meta property="product:price:currency" content="' . esc_attr( get_woocommerce_currency() ) . '">' . "\n";
		}
		echo '<meta property="product:availability" content="' . esc_attr( $product->is_in_stock() ? 'in stock' : 'out of stock' ) . '">' . "\n";
	}

	public function strip_wc_generator( string $generator, string $type ): string {
		return false !== stripos( $generator, 'woocommerce' ) ? '' : $generator;
	}
}
