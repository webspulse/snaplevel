<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$snap  = Snap_Settings::instance();
$stats = class_exists( 'Snap_Image_SEO' ) ? Snap_Image_SEO::stats() : array( 'total' => 0, 'with_alt' => 0, 'no_alt' => 0, 'webp' => 0 );

ICW_Admin_Menu::render_breadcrumbs( __( 'Image SEO', 'snaplevel' ) );
?>
<div class="snap-container">

	<?php
	$tab = isset( $_GET['sub'] ) ? sanitize_key( $_GET['sub'] ) : 'automation';
	?>
	<div class="snap-vtabs" style="margin-top: 20px;">
		<div class="snap-vtabs-nav">
			<button class="snap-vtab<?php echo 'automation' === $tab ? ' is-active' : ''; ?>" data-tab="automation"><?php Snap_Icons::e( 'image' ); ?> Automation</button>
			<button class="snap-vtab<?php echo 'compression' === $tab ? ' is-active' : ''; ?>" data-tab="compression"><?php Snap_Icons::e( 'compress' ); ?> Compression</button>
			<button class="snap-vtab<?php echo 'alt-text' === $tab ? ' is-active' : ''; ?>" data-tab="alt-text"><?php Snap_Icons::e( 'sparkle' ); ?> AI Alt Text</button>
			<button class="snap-vtab<?php echo 'unused' === $tab ? ' is-active' : ''; ?>" data-tab="unused"><?php Snap_Icons::e( 'broom' ); ?> Unused Images</button>
		</div>
		<div class="snap-vtabs-panel" style="flex:1;min-width:0;">
			
			<!-- AUTOMATION TAB -->
			<div id="tab-automation" class="snap-tab-pane" style="<?php echo 'automation' !== $tab ? 'display:none;' : ''; ?>">
				<!-- Stats -->
				<div class="snap-stats-grid">
					<div class="snap-stat-card">
						<div class="snap-stat-icon"><?php Snap_Icons::e( 'image', 22 ); ?></div>
						<div>
							<div class="snap-stat-value"><?php echo esc_html( number_format_i18n( (int) $stats['total'] ) ); ?></div>
							<div class="snap-stat-label"><?php esc_html_e( 'Images in library', 'snaplevel' ); ?></div>
						</div>
					</div>
					<div class="snap-stat-card">
						<div class="snap-stat-icon is-good"><?php Snap_Icons::e( 'check-circle', 22 ); ?></div>
						<div>
							<div class="snap-stat-value"><?php echo esc_html( number_format_i18n( (int) $stats['with_alt'] ) ); ?></div>
							<div class="snap-stat-label"><?php esc_html_e( 'With alt text', 'snaplevel' ); ?></div>
						</div>
					</div>
					<div class="snap-stat-card">
						<div class="snap-stat-icon is-warn"><?php Snap_Icons::e( 'alert', 22 ); ?></div>
						<div>
							<div class="snap-stat-value"><?php echo esc_html( number_format_i18n( (int) $stats['no_alt'] ) ); ?></div>
							<div class="snap-stat-label"><?php esc_html_e( 'Missing alt text', 'snaplevel' ); ?></div>
						</div>
					</div>
					<div class="snap-stat-card">
						<div class="snap-stat-icon"><?php Snap_Icons::e( 'compress', 22 ); ?></div>
						<div>
							<div class="snap-stat-value"><?php echo esc_html( number_format_i18n( (int) $stats['webp'] ) ); ?></div>
							<div class="snap-stat-label"><?php esc_html_e( 'Optimized / WebP', 'snaplevel' ); ?></div>
						</div>
					</div>
				</div>

				<!-- Upload-time options -->
				<div class="snap-box" style="margin-bottom:20px;">
					<div class="snap-box-title"><?php esc_html_e( 'Automatic Image SEO on Upload', 'snaplevel' ); ?></div>
					<?php
					$snap_img_options = array(
						'clean_filenames'      => array( __( 'SEO filenames', 'snaplevel' ), __( 'Rename files on upload: lowercase, hyphens, no accents (My Photo (1).JPG → my-photo-1.jpg).', 'snaplevel' ) ),
						'auto_alt_on_upload'   => array( __( 'Auto alt text from filename', 'snaplevel' ), __( 'Sets alt text and title from a readable filename the moment an image is uploaded.', 'snaplevel' ) ),
						'redirect_attachments' => array( __( 'Redirect attachment pages', 'snaplevel' ), __( 'Attachment pages are thin content — 301 them to the parent post.', 'snaplevel' ) ),
					);
					foreach ( $snap_img_options as $key => $labels ) :
						$on = (bool) $snap->get( 'image_seo.' . $key, true );
						?>
						<div class="snap-flex-between" style="padding:12px 0;border-bottom:1px solid var(--snap-border-subtle);">
							<div>
								<strong><?php echo esc_html( $labels[0] ); ?></strong>
								<p class="snap-muted" style="margin:2px 0 0;"><?php echo esc_html( $labels[1] ); ?></p>
							</div>
							<label class="snap-toggle" style="flex:none;">
								<input type="checkbox" class="snap-imgseo-toggle" data-key="<?php echo esc_attr( $key ); ?>" <?php checked( $on ); ?>>
								<span class="snap-slider"><span class="toggle_on"><?php esc_html_e( 'On', 'snaplevel' ); ?></span><span class="toggle_off"><?php esc_html_e( 'Off', 'snaplevel' ); ?></span></span>
							</label>
						</div>
					<?php endforeach; ?>
					<p class="snap-help" id="snap-imgseo-msg" style="margin:10px 0 0;"></p>
				</div>
			</div>

			<!-- COMPRESSION TAB -->
			<div id="tab-compression" class="snap-tab-pane" style="<?php echo 'compression' !== $tab ? 'display:none;' : ''; ?>">
				<?php require SNAP_PLUGIN_DIR . 'admin/views/compression.php'; ?>
			</div>

			<!-- ALT TEXT TAB -->
			<div id="tab-alt-text" class="snap-tab-pane" style="<?php echo 'alt-text' !== $tab ? 'display:none;' : ''; ?>">
				<?php require SNAP_PLUGIN_DIR . 'admin/views/alt-text.php'; ?>
			</div>

			<!-- UNUSED IMAGES TAB -->
			<div id="tab-unused" class="snap-tab-pane" style="<?php echo 'unused' !== $tab ? 'display:none;' : ''; ?>">
				<?php require SNAP_PLUGIN_DIR . 'admin/views/unused-images.php'; ?>
			</div>

		</div>
	</div>
</div>
