<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$attachments  = get_posts( array( 'post_type' => 'attachment', 'post_mime_type' => 'image', 'post_status' => 'inherit', 'posts_per_page' => -1, 'fields' => 'ids' ) );
$large_images = 0;
foreach ( $attachments as $aid ) {
	$f = get_attached_file( $aid );
	if ( $f && file_exists( $f ) && filesize( $f ) > 102400 ) {
		$large_images++;
	}
}
$orphan_count     = get_transient( 'snap_seo_orphan_count' );
$redirect_count   = get_transient( 'snap_seo_redirect_count' );
$orphan_display   = ( false !== $orphan_count ) ? $orphan_count : '?';
$redirect_display = ( false !== $redirect_count ) ? $redirect_count : '?';

ICW_Admin_Menu::render_breadcrumbs(
	__( 'Site Audit', 'snaplevel' ),
	'<a href="#" id="icw-restart-audit" class="snap-btn snap-btn-tertiary snap-btn-sm"><span class="snap-icon">' . Snap_Icons::get( 'refresh', 14 ) . '</span> ' . esc_html__( 'Restart Analyzer', 'snaplevel' ) . '</a>'
);
?>
<div class="snap-container">

	<?php
	$tab = isset( $_GET['sub'] ) ? sanitize_key( $_GET['sub'] ) : 'audit';
	?>
	<div class="snap-vtabs" style="margin-top: 20px;">
		<div class="snap-vtabs-nav">
			<button class="snap-vtab<?php echo 'audit' === $tab ? ' is-active' : ''; ?>" data-tab="audit"><?php Snap_Icons::e( 'search' ); ?> Site Audit</button>
			<button class="snap-vtab<?php echo 'memory' === $tab ? ' is-active' : ''; ?>" data-tab="memory"><?php Snap_Icons::e( 'clock' ); ?> SEO Memory</button>
		</div>
		<div class="snap-vtabs-panel" style="flex:1;min-width:0;">
			
			<!-- SITE AUDIT TAB -->
			<div id="tab-audit" class="snap-tab-pane" style="<?php echo 'audit' !== $tab ? 'display:none;' : ''; ?>">
				<!-- Score row -->
				<div style="display:grid;grid-template-columns:260px 1fr 240px;gap:15px;margin-bottom:15px;">

					<!-- Score ring -->
					<div class="snap-box" style="display:flex;align-items:center;justify-content:center;margin-bottom:0;">
						<div class="snap-score-ring-wrap">
							<svg width="160" height="160" viewBox="0 0 160 160">
								<circle cx="80" cy="80" r="64" fill="none" stroke="#f0f2f4" stroke-width="14"/>
								<circle id="icw-gauge-arc" cx="80" cy="80" r="64" fill="none"
									stroke="var(--snap-score-good)" stroke-width="14"
									stroke-dasharray="402" stroke-dashoffset="402"
									stroke-linecap="round"
									style="transform:rotate(-90deg);transform-origin:50% 50%;transition:stroke-dashoffset 1s ease-out, stroke 1s ease;"/>
							</svg>
							<div class="snap-score-ring-num">
								<div class="num"><span id="icw-gauge-score">0</span>/100</div>
								<div class="lbl"><?php esc_html_e( 'Health Score', 'snaplevel' ); ?></div>
							</div>
						</div>
					</div>

					<!-- AI Fix everything card -->
					<div class="snap-box" style="margin-bottom:0;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;">
						<h2 class="snap-box-title" style="font-size:18px;margin-bottom:6px;">
							<?php Snap_Icons::e( 'sparkle', 18 ); ?> <?php esc_html_e( 'Fix everything with AI', 'snaplevel' ); ?>
						</h2>
						<p class="snap-muted" style="margin:0 0 16px;max-width:440px;line-height:1.5;">
							<?php esc_html_e( 'One click triggers a 3-stage operation: AI writes missing titles/descriptions, images >100KB are compressed, and broken links are repointed.', 'snaplevel' ); ?>
						</p>
						<button id="snap-ai-fix" class="snap-btn snap-btn-ai">
							<?php Snap_Icons::e( 'play', 14 ); ?> <?php esc_html_e( 'Start AI SEO Fixer', 'snaplevel' ); ?>
						</button>
						<div id="snap-ai-fix-status" class="snap-muted" style="font-size:12px;margin-top:10px;font-family:Consolas,monospace;"></div>
					</div>

					<!-- Mini totals -->
					<div class="snap-box" style="margin-bottom:0;display:flex;flex-direction:column;justify-content:center;">
						<div class="snap-flex-between" style="margin-bottom:8px;">
							<span style="font-size:13px;font-weight:600;color:var(--snap-score-good);"><?php esc_html_e( 'Passed', 'snaplevel' ); ?></span>
							<span id="count-passed" style="font-weight:700;">0</span>
						</div>
						<div class="snap-progress" style="margin-bottom:14px;"><div id="bar-passed" class="snap-progress-bar" style="background:var(--snap-score-good);width:0;"></div></div>

						<div class="snap-flex-between" style="margin-bottom:8px;">
							<span style="font-size:13px;font-weight:600;color:var(--snap-score-ok);"><?php esc_html_e( 'Warnings', 'snaplevel' ); ?></span>
							<span id="count-warnings" style="font-weight:700;">0</span>
						</div>
						<div class="snap-progress" style="margin-bottom:14px;"><div id="bar-warnings" class="snap-progress-bar" style="background:var(--snap-score-ok);width:0;"></div></div>

						<div class="snap-flex-between" style="margin-bottom:8px;">
							<span style="font-size:13px;font-weight:600;color:var(--snap-score-bad);"><?php esc_html_e( 'Failed', 'snaplevel' ); ?></span>
							<span id="count-failed" style="font-weight:700;">0</span>
						</div>
						<div class="snap-progress"><div id="bar-failed" class="snap-progress-bar" style="background:var(--snap-score-bad);width:0;"></div></div>
					</div>

				</div>

				<div class="snap-box" style="padding:0;overflow:hidden;">
					<div style="padding:15px 20px;border-bottom:1px solid var(--snap-border);background:var(--snap-bg-page);display:flex;gap:15px;">
						<a href="#" class="icw-audit-tab is-active" data-filter="all" style="text-decoration:none;font-weight:600;color:var(--snap-text-dark);font-size:13px;"><?php esc_html_e( 'All Tests', 'snaplevel' ); ?></a>
						<a href="#" class="icw-audit-tab" data-filter="passed" style="text-decoration:none;font-weight:600;color:var(--snap-score-good);font-size:13px;"><?php esc_html_e( 'Passed', 'snaplevel' ); ?></a>
						<a href="#" class="icw-audit-tab" data-filter="warning" style="text-decoration:none;font-weight:600;color:var(--snap-score-ok);font-size:13px;"><?php esc_html_e( 'Warnings', 'snaplevel' ); ?></a>
						<a href="#" class="icw-audit-tab" data-filter="failed" style="text-decoration:none;font-weight:600;color:var(--snap-score-bad);font-size:13px;"><?php esc_html_e( 'Failed', 'snaplevel' ); ?></a>
					</div>
					
					<div class="snap-checklist-items" style="padding:0;">
						<?php
						$tests = array(
							'meta-titles'  => array( __( 'Titles & Meta', 'snaplevel' ), __( 'Are SEO titles set?', 'snaplevel' ) ),
							'meta-desc'    => array( __( 'Descriptions', 'snaplevel' ), __( 'Are descriptions under 160 chars?', 'snaplevel' ) ),
							'large-images' => array( __( 'Image Sizes', 'snaplevel' ), __( 'Are there images over 100KB slowing down the site?', 'snaplevel' ) ),
							'missing-alt'  => array( __( 'Alt Text', 'snaplevel' ), __( 'Do all images have descriptive alt text?', 'snaplevel' ) ),
							'schema'       => array( __( 'Structured Data', 'snaplevel' ), __( 'Is Google-friendly Schema JSON-LD active?', 'snaplevel' ) ),
							'redirects'    => array( __( 'Redirections', 'snaplevel' ), __( 'Are 404s being tracked and 301s processed?', 'snaplevel' ) ),
							'orphans'      => array( __( 'Orphan Content', 'snaplevel' ), __( 'Are there posts with no internal links pointing to them?', 'snaplevel' ) ),
						);
						foreach ( $bars as $key => $bar ) :
							?>
							<div style="display:grid;grid-template-columns:110px 1fr 36px;gap:14px;align-items:center;margin-bottom:16px;">
								<span style="font-size:13px;font-weight:600;"><?php echo esc_html( $bar[0] ); ?></span>
								<div class="snap-progress"><div id="bar-<?php echo esc_attr( $key ); ?>" class="snap-progress-bar" style="width:0%;background:<?php echo esc_attr( $bar[1] ); ?>;"></div></div>
								<span id="count-<?php echo esc_attr( $key ); ?>" style="font-size:15px;font-weight:600;text-align:right;">—</span>
							</div>
						<?php endforeach; ?>
						<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
							<button class="snap-btn snap-btn-primary" id="icw-run-full-audit">
								<span class="snap-icon"><?php echo Snap_Icons::get( 'search', 15 ); // phpcs:ignore ?></span>
								<?php esc_html_e( 'Run Full Audit', 'snaplevel' ); ?>
							</button>
							<button class="snap-btn snap-btn-ai" id="snap-ai-fix">
								<span class="snap-icon"><?php echo Snap_Icons::get( 'sparkle', 15, 'snap-anim-glow' ); // phpcs:ignore ?></span>
								<?php esc_html_e( 'Fix Everything with AI', 'snaplevel' ); ?>
							</button>
						</div>
						<p class="snap-help" id="snap-ai-fix-status" style="margin:8px 0 0;"></p>
					</div>

					<!-- Quick stats -->
					<div class="snap-box" style="margin-bottom:0;display:flex;flex-direction:column;justify-content:center;gap:14px;">
						<div class="snap-flex-between" style="padding-bottom:12px;border-bottom:1px solid var(--snap-border-subtle);">
							<span style="font-size:22px;font-weight:600;color:<?php echo $large_images > 0 ? 'var(--snap-score-bad)' : 'var(--snap-score-good)'; ?>;"><?php echo esc_html( $large_images ); ?></span>
							<span class="snap-muted" style="font-size:13px;"><?php esc_html_e( 'Images > 100KB', 'snaplevel' ); ?></span>
						</div>
						<div class="snap-flex-between" style="padding-bottom:12px;border-bottom:1px solid var(--snap-border-subtle);">
							<span style="font-size:22px;font-weight:600;"><?php echo esc_html( $orphan_display ); ?></span>
							<span class="snap-muted" style="font-size:13px;"><?php esc_html_e( 'Orphan Pages', 'snaplevel' ); ?></span>
						</div>
						<div class="snap-flex-between">
							<span style="font-size:22px;font-weight:600;"><?php echo esc_html( $redirect_display ); ?></span>
							<span class="snap-muted" style="font-size:13px;"><?php esc_html_e( 'Redirect Links', 'snaplevel' ); ?></span>
						</div>
					</div>
				</div>

				<!-- Filter tabs (Rank Math horizontal tab nav) -->
				<div class="snap-tab-nav">
					<a class="snap-tab icw-audit-tab is-active" data-filter="all"><?php esc_html_e( 'All', 'snaplevel' ); ?></a>
					<a class="snap-tab icw-audit-tab" data-filter="passed"><?php esc_html_e( 'Passed', 'snaplevel' ); ?></a>
					<a class="snap-tab icw-audit-tab" data-filter="warning"><?php esc_html_e( 'Warnings', 'snaplevel' ); ?></a>
					<a class="snap-tab icw-audit-tab" data-filter="failed"><?php esc_html_e( 'Failed', 'snaplevel' ); ?></a>
				</div>

				<div class="snap-box no-padding" style="border-radius:0 6px 6px 6px;overflow:hidden;">
					<?php
					$tests = array(
						array( 'large-images', __( 'Large Images (> 100KB)', 'snaplevel' ), __( 'Images over 100KB slow down page load and hurt Core Web Vitals scores.', 'snaplevel' ), false ),
						array( 'orphans', __( 'Orphan Pages', 'snaplevel' ), __( 'Published pages with no internal links. Search engines may never find them.', 'snaplevel' ), 'icw_scan_orphans' ),
						array( 'sitemap', __( 'Sitemap 3XX Redirects', 'snaplevel' ), __( 'Redirect URLs in your sitemap waste crawl budget.', 'snaplevel' ), 'icw_scan_sitemap' ),
						array( 'slow', __( 'Slow Pages (> 1500ms TTFB)', 'snaplevel' ), __( 'Server response time is a ranking factor. Pages over 1.5s are flagged.', 'snaplevel' ), 'icw_scan_slow_pages' ),
						array( 'redirects', __( 'Pages Linking to Redirects', 'snaplevel' ), __( 'Internal links that redirect lose link equity and slow the user experience.', 'snaplevel' ), 'icw_scan_redirects' ),
						array( 'css', __( 'Large CSS Files (> 50KB)', 'snaplevel' ), __( 'Unminified theme CSS files block rendering and directly hurt Largest Contentful Paint (LCP).', 'snaplevel' ), 'icw_scan_css' ),
						array( 'meta', __( 'Meta Description & Indexability', 'snaplevel' ), __( 'Tracks pages that became non-indexable or had their meta description changed recently.', 'snaplevel' ), 'icw_scan_meta' ),
					);
					$last = count( $tests ) - 1;
					foreach ( $tests as $i => $test ) :
						list( $key, $label, $desc, $action ) = $test;
						?>
						<div class="icw-audit-item" id="audit-<?php echo esc_attr( $key ); ?>" data-status="loading" <?php echo $i < $last ? 'style="border-bottom:1px solid var(--snap-border-subtle);"' : ''; ?>>
							<div style="display:flex;align-items:center;gap:18px;padding:20px 25px;">
								<div class="icw-audit-status-dot loading"></div>
								<div style="flex:1;">
									<strong style="display:block;font-size:14px;font-weight:600;color:var(--snap-text-dark);margin-bottom:3px;"><?php echo esc_html( $label ); ?></strong>
									<span style="font-size:13px;color:var(--snap-text-secondary);"><?php echo esc_html( $desc ); ?></span>
								</div>
								<div id="badge-<?php echo esc_attr( $key ); ?>" style="margin-right:14px;"><span class="snap-pill snap-pill-gray"><?php esc_html_e( 'Pending', 'snaplevel' ); ?></span></div>
								<div>
									<?php if ( 'large-images' === $key ) : ?>
										<?php if ( $large_images > 0 ) : ?>
											<a href="<?php echo esc_url( admin_url( 'admin.php?page=icw-compression' ) ); ?>" class="snap-btn snap-btn-primary snap-btn-sm"><?php esc_html_e( 'Fix Now →', 'snaplevel' ); ?></a>
										<?php endif; ?>
									<?php else : ?>
										<button class="snap-btn snap-btn-secondary snap-btn-sm icw-btn-scan" data-action="<?php echo esc_attr( (string) $action ); ?>" data-target="<?php echo esc_attr( $key ); ?>"><?php esc_html_e( 'Scan', 'snaplevel' ); ?></button>
									<?php endif; ?>
								</div>
							</div>
							<?php if ( 'large-images' !== $key ) : ?>
								<div class="icw-audit-item-body" id="result-<?php echo esc_attr( $key ); ?>" style="display:none;padding:0 25px 25px 60px;"></div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- SEO MEMORY TAB -->
			<div id="tab-memory" class="snap-tab-pane" style="<?php echo 'memory' !== $tab ? 'display:none;' : ''; ?>">
				<div class="snap-box" style="padding:40px;">
					<div class="snap-box-title" style="font-size:20px;margin-bottom:16px;"><?php Snap_Icons::e( 'clock', 24 ); ?> SEO Memory</div>
					<p class="snap-muted" style="font-size:16px;line-height:1.6;margin-bottom:20px;max-width:800px;">SEO Memory correlates changes in your titles, descriptions, and content with your ranking drops or gains. Because we're now tracking the SEO Changelog, we'll map your edits against search performance over time.</p>
					<div class="snap-notice snap-notice-info">
						<?php Snap_Icons::e( 'chart', 20 ); ?>
						<span style="font-size:15px;"><strong>We're gathering data.</strong> The foundation is being tracked. Historical diffs and algorithmic correlations will appear here.</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
