<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Snap_Broken_Links::maybe_create_table();
$broken = Snap_Broken_Links::get_broken();

ICW_Admin_Menu::render_breadcrumbs( __( 'Broken Links', 'snaplevel' ) );
?>
<div class="snap-container">

	<div class="snap-box" style="margin-bottom:20px;">
		<div class="snap-flex-between">
			<div>
				<div class="snap-box-title"><?php esc_html_e( 'Broken Link Checker', 'snaplevel' ); ?></div>
				<p class="snap-muted" style="margin:4px 0 0;"><?php esc_html_e( 'Scans every link in your published content in small batches — it will not time out on large sites. Broken links can be fixed, unlinked, or ignored in one click. Known broken links are re-checked daily.', 'snaplevel' ); ?></p>
			</div>
			<button type="button" class="snap-btn snap-btn-primary" id="snap-bl-scan" style="flex:none;"><?php esc_html_e( 'Scan Now', 'snaplevel' ); ?></button>
		</div>
		<div id="snap-bl-progress" style="display:none;margin-top:14px;">
			<div class="snap-progress"><div class="snap-progress-bar" id="snap-bl-bar" style="width:0%;"></div></div>
			<p class="snap-help" id="snap-bl-status" style="margin:6px 0 0;"></p>
		</div>
	</div>

	<div class="snap-box">
		<div class="snap-box-title"><?php esc_html_e( 'Opportunities found', 'snaplevel' ); ?> <span class="snap-badge <?php echo count( $broken ) ? 'snap-badge-amber' : 'snap-badge-green'; ?>"><?php echo esc_html( (string) count( $broken ) ); ?></span></div>
		<table class="snap-table widefat" style="border:0;">
			<thead>
				<tr>
					<th><?php esc_html_e( 'URL', 'snaplevel' ); ?></th>
					<th style="width:90px;"><?php esc_html_e( 'Status', 'snaplevel' ); ?></th>
					<th><?php esc_html_e( 'Anchor Text', 'snaplevel' ); ?></th>
					<th style="width:160px;"><?php esc_html_e( 'Found In', 'snaplevel' ); ?></th>
					<th style="width:280px;"></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $broken ) ) : ?>
					<tr><td colspan="5" class="snap-muted" style="text-align:center;padding:32px;"><?php esc_html_e( 'No broken links found. Run a scan to check your site.', 'snaplevel' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $broken as $row ) : ?>
					<tr data-blid="<?php echo esc_attr( (string) $row['id'] ); ?>">
						<td style="word-break:break-all;"><a href="<?php echo esc_url( (string) $row['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( (string) $row['url'] ); ?></a></td>
						<td><span class="snap-badge snap-badge-red"><?php echo 0 === (int) $row['status'] ? esc_html__( 'Unreachable', 'snaplevel' ) : esc_html( (string) $row['status'] ); ?></span></td>
						<td><?php echo esc_html( (string) $row['anchor'] ?: '—' ); ?></td>
						<td><a href="<?php echo esc_url( (string) get_edit_post_link( (int) $row['post_id'] ) ); ?>"><?php echo esc_html( get_the_title( (int) $row['post_id'] ) ?: '#' . (int) $row['post_id'] ); ?></a></td>
						<td>
							<button type="button" class="snap-btn snap-btn-primary snap-btn-sm snap-bl-act" data-do="update" data-id="<?php echo esc_attr( (string) $row['id'] ); ?>"><?php esc_html_e( 'Update URL', 'snaplevel' ); ?></button>
							<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-bl-act" data-do="unlink" data-id="<?php echo esc_attr( (string) $row['id'] ); ?>"><?php esc_html_e( 'Unlink', 'snaplevel' ); ?></button>
							<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-bl-act" data-do="ignore" data-id="<?php echo esc_attr( (string) $row['id'] ); ?>"><?php esc_html_e( 'Ignore', 'snaplevel' ); ?></button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>

<?php
wp_enqueue_script( 'snap-broken-links', SNAP_PLUGIN_URL . 'assets/js/broken-links.js', array(), Snap_Assets::version( 'assets/js/broken-links.js' ), true );
wp_localize_script( 'snap-broken-links', 'SNAP_BROKEN_LINKS', array(
	'nonce'   => wp_create_nonce( 'icw_nonce' ),
	'ajaxurl' => admin_url( 'admin-ajax.php' ),
	'i18n'    => array(
		'collecting'     => __( 'Collecting links from your content…', 'snaplevel' ),
		'noLinks'        => __( 'No links found in published content.', 'snaplevel' ),
		'linksChecked'   => __( 'links checked', 'snaplevel' ),
		'broken'         => __( 'broken', 'snaplevel' ),
		'replaceWith'    => __( 'Replace this link everywhere with:', 'snaplevel' ),
		'confirmUnlink'  => __( 'Remove this link from all posts (keeps the text)?', 'snaplevel' ),
	),
) );
?>
