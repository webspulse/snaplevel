<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$snap     = Snap_Settings::instance();
$modules  = Snap_Module_Loader::instance()->list_modules();
$has_key  = '' !== $snap->get_api_key();

// Use tiered-cache class for all dashboard metrics.
$posts_count      = Snap_Dashboard_Stats::posts_count();
$missing_meta     = Snap_Dashboard_Stats::missing_meta();
$with_schema      = Snap_Dashboard_Stats::schema_coverage();
$total_images     = Snap_Dashboard_Stats::images_total();
$images_alt       = Snap_Dashboard_Stats::images_with_alt();
$ai_usage         = Snap_Dashboard_Stats::ai_usage();
$redirects_active = Snap_Dashboard_Stats::redirects_active();
$count_404        = Snap_Dashboard_Stats::count_404s();
$broken_links     = Snap_Dashboard_Stats::broken_links();

// Health score (computed from cached components).
$health_data  = Snap_Dashboard_Stats::health_score();
$health       = $health_data['score'];
$health_state = $health_data['state'];
$health_color = $health >= 81 ? 'var(--snap-score-good)' : ( $health >= 51 ? 'var(--snap-score-ok)' : 'var(--snap-score-bad)' );
$schema_cov   = $posts_count > 0 ? min( 1, $with_schema / $posts_count ) : 0;

// Safe review queue (from existing AI queue, no new logic)
$review_queue = [];
if ( class_exists( 'Snap_AI_Queue' ) ) {
	$raw_jobs = get_option( Snap_AI_Queue::OPTION, array() );
	if ( is_array( $raw_jobs ) ) {
		foreach ( $raw_jobs as $jid => $job ) {
			if ( ( $job['status'] ?? '' ) === 'pending' ) {
				$review_queue[] = $job;
				if ( count( $review_queue ) >= 5 ) break;
			}
		}
	}
}

// ── Get Started checklist ─────────────────────────────────────────────────
$wizard_done  = (bool) get_option( 'snap_wizard_done', false ) || (bool) $snap->get( 'wizard.done', false );
$import_done  = (bool) get_option( 'snap_import_done', false ) || $missing_meta < $posts_count;
$trained      = class_exists( 'Snap_AI_Training' ) && Snap_AI_Training::total_chars() > 0;
$checklist    = array(
	array( 'done' => $wizard_done, 'label' => __( 'Run the setup wizard', 'snaplevel' ), 'url' => admin_url( 'admin.php?page=snap-wizard' ) ),
	array( 'done' => $has_key, 'label' => __( 'Connect AI (Claude, ChatGPT, Gemini, DeepSeek, or Mistral)', 'snaplevel' ), 'url' => admin_url( 'admin.php?page=icw-settings&tab=ai' ) ),
	array( 'done' => $trained, 'label' => __( 'Train the AI on your business', 'snaplevel' ), 'url' => admin_url( 'admin.php?page=snap-training' ) ),
	array( 'done' => $posts_count > 0 && $missing_meta < $posts_count, 'label' => __( 'Optimize your first post (title + description)', 'snaplevel' ), 'url' => admin_url( 'edit.php' ) ),
	array( 'done' => ! empty( $modules['sitemap']['enabled'] ), 'label' => __( 'Enable XML sitemaps', 'snaplevel' ), 'url' => admin_url( 'admin.php?page=icw-dashboard#snap-modules' ) ),
);
$steps_done = count( array_filter( array_column( $checklist, 'done' ) ) );

// ── Quick Access (premium elements) ───────────────────────────────────────
$quick_links = array(
	array( 'icon' => 'target',   'title' => __( 'Titles & Meta', 'snaplevel' ),  'desc' => __( 'Templates for every post type', 'snaplevel' ),  'url' => admin_url( 'admin.php?page=snap-titles' ) ),
	array( 'icon' => 'schema',   'title' => __( 'Schema', 'snaplevel' ),         'desc' => __( 'Structured data for rich results', 'snaplevel' ), 'url' => admin_url( 'admin.php?page=snap-schema' ) ),
	array( 'icon' => 'redirect', 'title' => __( 'Redirections', 'snaplevel' ),   'desc' => __( 'Redirects + live 404 monitor', 'snaplevel' ),    'url' => admin_url( 'admin.php?page=snap-redirections' ) ),
	array( 'icon' => 'link',     'title' => __( 'Broken Links', 'snaplevel' ),   'desc' => __( 'Find and fix dead links', 'snaplevel' ),          'url' => admin_url( 'admin.php?page=snap-broken-links' ) ),
	array( 'icon' => 'image',    'title' => __( 'Image SEO', 'snaplevel' ),      'desc' => __( 'Alt text, WebP, clean filenames', 'snaplevel' ),  'url' => admin_url( 'admin.php?page=snap-image-seo' ) ),
	array( 'icon' => 'sitemap',  'title' => __( 'Sitemaps', 'snaplevel' ),       'desc' => __( 'XML sitemap + IndexNow', 'snaplevel' ),           'url' => home_url( '/sitemap_index.xml' ) ),
	array( 'icon' => 'gauge',    'title' => __( 'Site Audit', 'snaplevel' ),     'desc' => __( 'Full technical SEO scan', 'snaplevel' ),          'url' => admin_url( 'admin.php?page=icw-seo-audit' ) ),
	array( 'icon' => 'import',   'title' => __( 'Import / Export', 'snaplevel' ),'desc' => __( 'Migrate from 8 SEO plugins', 'snaplevel' ),       'url' => admin_url( 'admin.php?page=snap-tools' ) ),
);

// ── Recent activity ────────────────────────────────────────────────────────
$recent = get_posts( array(
	'post_type'      => array( 'post', 'page' ),
	'post_status'    => 'publish',
	'posts_per_page' => 8,
	'orderby'        => 'modified',
	'order'          => 'DESC',
) );

ICW_Admin_Menu::render_breadcrumbs( __( 'Dashboard', 'snaplevel' ) );
?>
<div class="snap-container snap-dashboard">

	<?php if ( ! $has_key ) : ?>
		<div class="snap-notice snap-notice-info">
			<?php Snap_Icons::e( 'sparkle', 18, 'snap-anim-pulse' ); ?>
			<span><strong><?php esc_html_e( 'Connect your AI provider to unlock the full assistant.', 'snaplevel' ); ?></strong>
			<?php esc_html_e( 'Copilot works best with your own key (Claude, OpenAI, Gemini, etc.). It will surface opportunities and offer to fix them for you.', 'snaplevel' ); ?></span>
			<a class="snap-btn snap-btn-ai-soft snap-btn-sm" style="flex:none; margin-top: 6px;" href="<?php echo esc_url( admin_url( 'admin.php?page=icw-settings&tab=ai' ) ); ?>"><?php esc_html_e( 'Connect AI', 'snaplevel' ); ?></a>
		</div>
	<?php endif; ?>

	<!-- New top-notch hero -->
	<div class="snap-hero" style="padding: 24px 28px; margin-bottom: 18px;">
		<div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 20px;">
			<div>
				<div style="font-size: 23px; font-weight: 600; display: flex; align-items: center; gap: 10px;">
					<?php Snap_Icons::e( 'sparkle', 26, 'snap-anim-glow' ); ?>
					<?php esc_html_e( 'Your AI Teammate is watching over your site', 'snaplevel' ); ?>
				</div>
				<div style="margin-top: 6px; font-size: 13.5px; color: var(--snap-text-secondary); max-width: 540px;">
					<?php
					$opportunity_count = max( 0, (int) $missing_meta ) + max( 0, (int) $broken_links ) + max( 0, (int) $count_404 );
					if ( $opportunity_count > 0 ) {
						printf( esc_html__( '%d clear opportunities are ready. Copilot has already prepared the fixes — you just approve.', 'snaplevel' ), $opportunity_count );
					} else {
						esc_html_e( 'Your site is in good shape. Copilot will automatically analyze new and changed content.', 'snaplevel' );
					}
					?>
				</div>
			</div>

			<div style="display: flex; align-items: center; gap: 28px; flex-wrap: wrap;">
				<!-- Big Health Score -->
				<div style="text-align: center; min-width: 92px;">
					<div style="font-size: 10px; font-weight: 700; letter-spacing: .6px; color: var(--snap-text-secondary);">AI HEALTH SCORE</div>
					<div style="font-size: 48px; font-weight: 700; line-height: .9; color: <?php echo esc_attr( $health_color ); ?>;"><?php echo esc_html( $health ); ?></div>
					<div style="font-size: 11px; margin-top: -4px; color: var(--snap-text-muted);"><?php echo esc_html( ucfirst( $health_state ) ); ?></div>
				</div>

				<div style="display: flex; gap: 10px; flex-wrap: wrap;">
					<a class="snap-btn snap-btn-primary snap-btn-lg" href="<?php echo esc_url( admin_url( 'edit.php' ) ); ?>">
						<?php Snap_Icons::e( 'edit', 16 ); ?> <?php esc_html_e( 'Open Editor', 'snaplevel' ); ?>
					</a>
					<a class="snap-btn snap-btn-secondary snap-btn-lg" href="<?php echo esc_url( admin_url( 'admin.php?page=icw-seo-audit' ) ); ?>">
						<?php esc_html_e( 'Full Site Audit', 'snaplevel' ); ?>
					</a>
				</div>
			</div>
		</div>
	</div>

	<!-- Clean, top-notch dashboard layout (new revamp) -->
	<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(168px, 1fr)); gap: 12px; margin-bottom: 20px;">
		<div class="snap-card" style="padding: 13px 16px;">
			<div style="font-size: 10px; color: var(--snap-text-secondary); font-weight: 600; letter-spacing: .4px;">PUBLISHED</div>
			<div style="font-size: 28px; font-weight: 700; line-height: 1; margin-top: 2px;"><?php echo esc_html( number_format_i18n( $posts_count ) ); ?></div>
		</div>
		<div class="snap-card" style="padding: 13px 16px;">
			<div style="font-size: 10px; color: var(--snap-text-secondary); font-weight: 600; letter-spacing: .4px;">OPPORTUNITIES</div>
			<div style="font-size: 28px; font-weight: 700; line-height: 1; margin-top: 2px; color: #f9ab00;"><?php echo esc_html( number_format_i18n( $opportunity_count ) ); ?></div>
		</div>
		<div class="snap-card" style="padding: 13px 16px;">
			<div style="font-size: 10px; color: var(--snap-text-secondary); font-weight: 600; letter-spacing: .4px;">AI ACTIONS THIS MONTH</div>
			<div style="font-size: 28px; font-weight: 700; line-height: 1; margin-top: 2px;"><?php echo esc_html( number_format_i18n( (int)$ai_usage['month']['calls'] ) ); ?></div>
		</div>
		<div class="snap-card" style="padding: 13px 16px;">
			<div style="font-size: 10px; color: var(--snap-text-secondary); font-weight: 600; letter-spacing: .4px;">IN REVIEW QUEUE</div>
			<div style="font-size: 28px; font-weight: 700; line-height: 1; margin-top: 2px;"><?php echo esc_html( (int)( $queue_status['pending'] ?? 0 ) ); ?></div>
		</div>
	</div>

	<!-- Main two-column layout -->
	<div style="display: grid; grid-template-columns: 1.65fr 1fr; gap: 18px; margin-bottom: 22px;">
		<!-- Opportunities -->
		<div>
			<div class="snap-section-title" style="margin-bottom: 8px;"><?php Snap_Icons::e( 'target', 15 ); ?> <?php esc_html_e( 'Opportunities', 'snaplevel' ); ?></div>
			<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(235px, 1fr)); gap: 10px;">
				<?php if ( $missing_meta > 0 ) : ?>
					<div class="snap-opportunity-card">
						<div style="display:flex; justify-content:space-between; align-items:center;">
							<div style="font-weight:600;"><?php esc_html_e( 'Missing meta descriptions', 'snaplevel' ); ?></div>
							<span class="snap-badge snap-badge-amber"><?php echo esc_html( number_format_i18n( $missing_meta ) ); ?></span>
						</div>
						<p style="font-size:12px; margin:6px 0 10px; color:var(--snap-text-secondary);">Copilot writes descriptions in your exact brand voice.</p>
						<a class="snap-btn snap-btn-ai-soft snap-btn-sm" href="<?php echo esc_url( admin_url( 'admin.php?page=snap-titles' ) ); ?>">Fix with AI →</a>
					</div>
				<?php endif; ?>

				<?php if ( $broken_links > 0 ) : ?>
					<div class="snap-opportunity-card">
						<div style="display:flex; justify-content:space-between; align-items:center;">
							<div style="font-weight:600;"><?php esc_html_e( 'Broken links', 'snaplevel' ); ?></div>
							<span class="snap-badge snap-badge-amber"><?php echo esc_html( number_format_i18n( $broken_links ) ); ?></span>
						</div>
						<p style="font-size:12px; margin:6px 0 10px; color:var(--snap-text-secondary);">Copilot suggests or creates the right redirects.</p>
						<a class="snap-btn snap-btn-ai-soft snap-btn-sm" href="<?php echo esc_url( admin_url( 'admin.php?page=snap-broken-links' ) ); ?>">Review & fix →</a>
					</div>
				<?php endif; ?>

				<?php if ( $count_404 > 0 ) : ?>
					<div class="snap-opportunity-card">
						<div style="display:flex; justify-content:space-between; align-items:center;">
							<div style="font-weight:600;"><?php esc_html_e( '404s logged', 'snaplevel' ); ?></div>
							<span class="snap-badge snap-badge-amber"><?php echo esc_html( number_format_i18n( $count_404 ) ); ?></span>
						</div>
						<p style="font-size:12px; margin:6px 0 10px; color:var(--snap-text-secondary);">Turn visitor dead-ends into clean redirects.</p>
						<a class="snap-btn snap-btn-secondary snap-btn-sm" href="<?php echo esc_url( admin_url( 'admin.php?page=snap-redirections' ) ); ?>">Open monitor →</a>
					</div>
				<?php endif; ?>

				<?php if ( $missing_meta === 0 && $broken_links === 0 && $count_404 === 0 ) : ?>
					<div class="snap-opportunity-card" style="border-left-color: var(--snap-success);">
						<div style="color: var(--snap-success); font-weight:600; display:flex; align-items:center; gap:8px;">
							<?php Snap_Icons::e( 'check-circle', 17 ); ?> <?php esc_html_e( 'No major opportunities right now. Great work.', 'snaplevel' ); ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<!-- Queue + Activity -->
		<div>
			<div class="snap-section-title" style="margin-bottom: 8px;"><?php Snap_Icons::e( 'list', 15 ); ?> <?php esc_html_e( 'Review Queue', 'snaplevel' ); ?></div>
			<div class="snap-card" style="padding: 12px 14px; margin-bottom: 16px; font-size: 12.5px;">
				<?php if ( ! empty( $review_queue ) ) : ?>
					<?php foreach ( array_slice($review_queue, 0, 3) as $job ): ?>
						<div style="display:flex; justify-content:space-between; padding: 3px 0; border-bottom: 1px solid #f1f3f4;">
							<span><?php echo esc_html( ucwords(str_replace('_',' ',$job['task']??'')) ); ?> • <?php echo esc_html( $job['context']['post_title'] ?? 'post' ); ?></span>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=icw-seo-audit' ) ); ?>" style="font-size:11px;">Review →</a>
						</div>
					<?php endforeach; ?>
				<?php else: ?>
					<div style="color: var(--snap-text-secondary);">Queue clear. New suggestions will land here for your approval.</div>
				<?php endif; ?>
			</div>

			<div class="snap-section-title" style="margin-bottom: 8px;"><?php Snap_Icons::e( 'feed', 15 ); ?> <?php esc_html_e( 'AI Teammate Activity', 'snaplevel' ); ?></div>
			<div class="snap-card" style="padding: 12px 14px; font-size: 12px; color: var(--snap-text-secondary);">
				<?php if ( (int)$ai_usage['month']['calls'] > 0 ) : ?>
					<?php printf( esc_html__( '%s generations this month.' , 'snaplevel' ), number_format_i18n( (int)$ai_usage['month']['calls'] ) ); ?>
					<?php if ( $ai_usage['month']['cost'] > 0 ) echo ' Cost ≈ $' . number_format( (float)$ai_usage['month']['cost'], 2 ); ?>
				<?php else : ?>
					<?php esc_html_e( 'No generations yet this month.', 'snaplevel' ); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<!-- Premium Quick Actions -->
	<div>
		<div class="snap-section-title" style="margin-bottom: 10px;"><?php Snap_Icons::e( 'rocket', 15 ); ?> <?php esc_html_e( 'Quick Actions', 'snaplevel' ); ?></div>
		<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(178px, 1fr)); gap: 10px;">
			<a class="snap-card" href="<?php echo esc_url( admin_url( 'admin.php?page=snap-training' ) ); ?>" style="padding: 13px 15px; text-decoration: none;">
				<div style="font-weight: 600; display: flex; align-items: center; gap: 7px;"><?php Snap_Icons::e( 'brain', 15 ); ?> Train AI Teammate</div>
				<div style="font-size: 11px; color: var(--snap-text-secondary); margin-top: 3px;">Teach it your voice so every suggestion sounds like you wrote it.</div>
			</a>
			<a class="snap-card" href="<?php echo esc_url( admin_url( 'admin.php?page=icw-alt-text' ) ); ?>" style="padding: 13px 15px; text-decoration: none;">
				<div style="font-weight: 600; display: flex; align-items: center; gap: 7px;"><?php Snap_Icons::e( 'image', 15 ); ?> Bulk Alt Text</div>
				<div style="font-size: 11px; color: var(--snap-text-secondary); margin-top: 3px;">Generate perfect alt text for hundreds of images in one review pass.</div>
			</a>
			<a class="snap-card" href="<?php echo esc_url( admin_url( 'admin.php?page=snap-redirections' ) ); ?>" style="padding: 13px 15px; text-decoration: none;">
				<div style="font-weight: 600; display: flex; align-items: center; gap: 7px;"><?php Snap_Icons::e( 'link', 15 ); ?> Redirects & 404 Monitor</div>
				<div style="font-size: 11px; color: var(--snap-text-secondary); margin-top: 3px;">Manage every redirect and turn live 404s into clean fixes.</div>
			</a>
			<a class="snap-card" href="<?php echo esc_url( admin_url( 'admin.php?page=icw-seo-audit' ) ); ?>" style="padding: 13px 15px; text-decoration: none;">
				<div style="font-weight: 600; display: flex; align-items: center; gap: 7px;"><?php Snap_Icons::e( 'gauge', 15 ); ?> Full Technical Audit</div>
				<div style="font-size: 11px; color: var(--snap-text-secondary); margin-top: 3px;">Deep scan of orphans, speed, images, redirects and more.</div>
			</a>
		</div>
	</div>

</div>

