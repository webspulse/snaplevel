<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="snap-container">

	<!-- Stats row -->
	<div class="snap-stats-grid" id="icw-compression-stats">
		<div class="snap-stat-card">
			<div class="snap-stat-icon" style="background:#f1f1f1;color:var(--snap-text-secondary);"><?php Snap_Icons::e( 'image', 22 ); ?></div>
			<div>
				<div class="snap-stat-value" id="stat-total">—</div>
				<div class="snap-stat-label"><?php esc_html_e( 'Total Images', 'snaplevel' ); ?></div>
			</div>
		</div>
		<div class="snap-stat-card">
			<div class="snap-stat-icon is-warn"><?php Snap_Icons::e( 'alert', 22 ); ?></div>
			<div>
				<div class="snap-stat-value" id="stat-over100" style="color:var(--snap-score-ok);">—</div>
				<div class="snap-stat-label"><?php esc_html_e( 'Over 100KB', 'snaplevel' ); ?></div>
			</div>
		</div>
		<div class="snap-stat-card">
			<div class="snap-stat-icon is-good"><?php Snap_Icons::e( 'check', 22 ); ?></div>
			<div>
				<div class="snap-stat-value" id="stat-processed" style="color:var(--snap-score-good);">—</div>
				<div class="snap-stat-label"><?php esc_html_e( 'Processed', 'snaplevel' ); ?></div>
			</div>
		</div>
		<div class="snap-stat-card">
			<div class="snap-stat-icon"><?php Snap_Icons::e( 'download', 22 ); ?></div>
			<div>
				<div class="snap-stat-value" id="stat-saved" style="color:var(--snap-primary);">—</div>
				<div class="snap-stat-label"><?php esc_html_e( 'Space Saved', 'snaplevel' ); ?></div>
			</div>
		</div>
	</div>

	<!-- Safety notice -->
	<div class="snap-notice snap-notice-info">
		<?php Snap_Icons::e( 'shield', 18 ); ?>
		<span><strong><?php esc_html_e( '100% Safe:', 'snaplevel' ); ?></strong>
		<?php esc_html_e( 'Original file paths and URLs are never changed. Images are resized to max 1024px if needed, then compressed iteratively to guarantee under 100KB without destroying quality. A backup is created before every compression so you can restore anytime.', 'snaplevel' ); ?></span>
	</div>

	<!-- Bulk compression box -->
	<div class="snap-box">
		<div class="snap-flex-between" style="align-items:flex-start;margin-bottom:6px;">
			<div>
				<h2 class="snap-box-title"><?php Snap_Icons::e( 'compress', 18 ); ?> <?php esc_html_e( 'Bulk Compress All Images Over 100KB', 'snaplevel' ); ?></h2>
				<p class="snap-description" style="margin:0;max-width:640px;"><?php esc_html_e( 'The strict algorithm targets images over 100KB. It resizes massively oversized photos and reduces quality progressively until each file verifies as under 100KB.', 'snaplevel' ); ?></p>
			</div>
			<div style="flex:none;display:flex;gap:10px;">
				<button class="snap-btn snap-btn-secondary" id="icw-scan-stats-btn">
					<span class="snap-icon"><?php echo Snap_Icons::get( 'refresh', 14 ); // phpcs:ignore ?></span>
					<?php esc_html_e( 'Refresh Stats', 'snaplevel' ); ?>
				</button>
				<button class="snap-btn snap-btn-primary" id="icw-start-compress">
					<span class="snap-icon"><?php echo Snap_Icons::get( 'zap', 15 ); // phpcs:ignore ?></span>
					<?php esc_html_e( 'Compress All Large Images', 'snaplevel' ); ?>
				</button>
			</div>
		</div>

		<!-- Live progress terminal -->
		<div class="snap-terminal" id="icw-progress-wrap" style="display:none;">
			<div class="snap-terminal-header">
				<span id="icw-progress-label"><?php esc_html_e( 'Initializing…', 'snaplevel' ); ?></span>
				<div style="display:flex;gap:15px;align-items:center;">
					<a href="#" id="icw-stop-compress" style="color:#ee6a5e;text-decoration:none;font-weight:600;display:none;"><?php esc_html_e( 'Stop Process', 'snaplevel' ); ?></a>
					<span id="icw-progress-fraction" style="background:rgba(255,255,255,.1);padding:3px 10px;border-radius:3px;">0 / <span id="icw-total-count">0</span></span>
				</div>
			</div>
			<div class="snap-terminal-bar-bg">
				<div class="snap-terminal-bar-fill" id="icw-progress-bar"></div>
			</div>
			<div class="snap-terminal-log" id="icw-progress-log">
				<div style="color:rgba(255,255,255,.4);"><?php esc_html_e( 'Waiting to start…', 'snaplevel' ); ?></div>
			</div>
		</div>
	</div>

	<!-- Detailed scanner -->
	<div class="snap-box">
		<div class="snap-flex-between" style="margin-bottom:18px;">
			<div>
				<h2 class="snap-box-title"><?php Snap_Icons::e( 'search', 18 ); ?> <?php esc_html_e( 'Detailed Image Scanner', 'snaplevel' ); ?></h2>
				<p class="snap-description" style="margin:0;"><?php esc_html_e( 'Scan and view the exact compression and alt text status of every image in your library.', 'snaplevel' ); ?></p>
			</div>
			<button class="snap-btn snap-btn-secondary" id="icw-detailed-scan-btn">
				<span class="snap-icon"><?php echo Snap_Icons::get( 'search', 14 ); // phpcs:ignore ?></span>
				<?php esc_html_e( 'Scan Library Status', 'snaplevel' ); ?>
			</button>
		</div>

		<div id="icw-detailed-scanner-status" style="display:none;text-align:center;padding:40px;color:var(--snap-text-secondary);">
			<span class="snap-eq" style="margin-right:10px;"><span></span><span></span><span></span></span>
			<span style="font-size:14px;font-weight:600;"><?php esc_html_e( 'Scanning… Please wait.', 'snaplevel' ); ?></span>
		</div>

		<div id="icw-detailed-scanner-results" style="display:none;">
			<div class="snap-table-wrap" style="border:1px solid var(--snap-border-light);border-radius:6px;overflow:hidden;">
				<table class="snap-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Image', 'snaplevel' ); ?></th>
							<th><?php esc_html_e( 'File Size', 'snaplevel' ); ?></th>
							<th><?php esc_html_e( 'Optimization Status', 'snaplevel' ); ?></th>
							<th><?php esc_html_e( 'Alt Text Status', 'snaplevel' ); ?></th>
						</tr>
					</thead>
					<tbody id="icw-detailed-scanner-tbody"></tbody>
				</table>
			</div>
			<div style="margin-top:16px;text-align:center;">
				<button class="snap-btn snap-btn-secondary snap-btn-sm" id="icw-detailed-load-more" style="display:none;"><?php esc_html_e( 'Load More', 'snaplevel' ); ?></button>
			</div>
		</div>
	</div>
</div>
