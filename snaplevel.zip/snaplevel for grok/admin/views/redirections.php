<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Snap_Redirections::maybe_create_tables();

$snap_search = isset( $_GET['s'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['s'] ) ) : '';
$redirects   = Snap_Redirections::get_redirects( $snap_search );
$log_404     = Snap_Redirections::get_404s();
$auto_del    = (bool) Snap_Settings::instance()->get( 'redirections.auto_deleted', false );
$imported    = isset( $_GET['imported'] ) ? sanitize_text_field( (string) $_GET['imported'] ) : '';

ICW_Admin_Menu::render_breadcrumbs( __( 'Redirections', 'snaplevel' ) );
?>
<div class="snap-container">

	<?php if ( '' !== $imported ) : ?>
		<div class="snap-notice <?php echo 'error' === $imported ? 'snap-notice-error' : 'snap-notice-success'; ?>">
			<?php
			if ( 'error' === $imported ) {
				esc_html_e( 'Import failed — please upload a valid CSV file.', 'snaplevel' );
			} else {
				/* translators: %s: number of redirects */
				printf( esc_html__( 'Imported %s redirects.', 'snaplevel' ), esc_html( $imported ) );
			}
			?>
		</div>
	<?php endif; ?>

	<div class="snap-tab-nav" role="tablist">
		<button type="button" class="snap-tab is-active" data-rtab="redirects"><?php esc_html_e( 'Redirects', 'snaplevel' ); ?> <span class="snap-badge snap-badge-gray"><?php echo esc_html( (string) count( $redirects ) ); ?></span></button>
		<button type="button" class="snap-tab" data-rtab="monitor"><?php esc_html_e( '404 Monitor', 'snaplevel' ); ?> <span class="snap-badge <?php echo count( $log_404 ) > 0 ? 'snap-badge-red' : 'snap-badge-gray'; ?>"><?php echo esc_html( (string) count( $log_404 ) ); ?></span></button>
		<button type="button" class="snap-tab" data-rtab="tools"><?php esc_html_e( 'Import / Export', 'snaplevel' ); ?></button>
	</div>

	<!-- ── Redirects tab ─────────────────────────────────────────────── -->
	<div class="snap-tab-panel" data-rtab-panel="redirects">

		<div class="snap-box" style="margin-bottom:20px;">
			<div class="snap-box-title"><?php esc_html_e( 'Add Redirect', 'snaplevel' ); ?></div>
			<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
				<div style="flex:2;min-width:220px;">
					<label class="snap-field-label" for="snap-r-source"><?php esc_html_e( 'Source URL (path)', 'snaplevel' ); ?></label>
					<input type="text" id="snap-r-source" class="snap-input" placeholder="/old-page/">
				</div>
				<div style="flex:2;min-width:220px;">
					<label class="snap-field-label" for="snap-r-target"><?php esc_html_e( 'Target URL', 'snaplevel' ); ?></label>
					<input type="text" id="snap-r-target" class="snap-input" placeholder="/new-page/ <?php esc_attr_e( 'or full URL', 'snaplevel' ); ?>">
				</div>
				<div style="flex:none;">
					<label class="snap-field-label" for="snap-r-type"><?php esc_html_e( 'Type', 'snaplevel' ); ?></label>
					<select id="snap-r-type" class="snap-select">
						<option value="301">301 — <?php esc_html_e( 'Permanent', 'snaplevel' ); ?></option>
						<option value="302">302 — <?php esc_html_e( 'Temporary', 'snaplevel' ); ?></option>
						<option value="307">307 — <?php esc_html_e( 'Temporary (strict)', 'snaplevel' ); ?></option>
						<option value="410">410 — <?php esc_html_e( 'Content deleted', 'snaplevel' ); ?></option>
						<option value="451">451 — <?php esc_html_e( 'Legal removal', 'snaplevel' ); ?></option>
					</select>
				</div>
				<label style="display:flex;align-items:center;gap:6px;padding-bottom:8px;cursor:pointer;">
					<input type="checkbox" id="snap-r-regex"> <?php esc_html_e( 'Regex', 'snaplevel' ); ?>
				</label>
				<button type="button" class="snap-btn snap-btn-primary" id="snap-r-add"><?php esc_html_e( 'Add Redirect', 'snaplevel' ); ?></button>
			</div>
			<p class="snap-help" id="snap-r-msg" style="margin:8px 0 0;"></p>
		</div>

		<div class="snap-box">
			<div class="snap-flex-between" style="margin-bottom:12px;">
				<div class="snap-box-title" style="margin:0;"><?php esc_html_e( 'Active Redirects', 'snaplevel' ); ?></div>
				<div style="display:flex;gap:8px;">
					<form method="get" style="display:flex;gap:6px;">
						<input type="hidden" name="page" value="snap-redirections">
						<input type="search" name="s" class="snap-input" style="width:220px;" placeholder="<?php esc_attr_e( 'Search source or target…', 'snaplevel' ); ?>" value="<?php echo esc_attr( $snap_search ); ?>">
						<button class="snap-btn snap-btn-secondary snap-btn-sm"><?php esc_html_e( 'Search', 'snaplevel' ); ?></button>
					</form>
					<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm" id="snap-r-tester-btn"><?php esc_html_e( 'URL Tester', 'snaplevel' ); ?></button>
				</div>
			</div>

			<div id="snap-r-tester" style="display:none;background:var(--snap-alt-gray);border:1px solid var(--snap-border);border-radius:8px;padding:14px;margin-bottom:14px;">
				<div style="display:flex;gap:10px;">
					<input type="text" id="snap-r-tester-url" class="snap-input" placeholder="<?php esc_attr_e( 'Paste any URL or path to test against your redirects…', 'snaplevel' ); ?>">
					<button type="button" class="snap-btn snap-btn-primary snap-btn-sm" id="snap-r-tester-run"><?php esc_html_e( 'Test', 'snaplevel' ); ?></button>
				</div>
				<p class="snap-help" id="snap-r-tester-result" style="margin:8px 0 0;"></p>
			</div>

			<table class="snap-table widefat" style="border:0;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Source', 'snaplevel' ); ?></th>
						<th><?php esc_html_e( 'Target', 'snaplevel' ); ?></th>
						<th style="width:70px;"><?php esc_html_e( 'Type', 'snaplevel' ); ?></th>
						<th style="width:70px;"><?php esc_html_e( 'Hits', 'snaplevel' ); ?></th>
						<th style="width:130px;"><?php esc_html_e( 'Last Hit', 'snaplevel' ); ?></th>
						<th style="width:80px;"></th>
					</tr>
				</thead>
				<tbody id="snap-r-rows">
					<?php if ( empty( $redirects ) ) : ?>
						<tr><td colspan="6" class="snap-muted" style="text-align:center;padding:32px;"><?php esc_html_e( 'No redirects yet. Add your first one above, or create them from the 404 Monitor.', 'snaplevel' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( $redirects as $r ) : ?>
						<tr data-rid="<?php echo esc_attr( (string) $r['id'] ); ?>">
							<td><code><?php echo esc_html( (string) $r['source'] ); ?></code><?php echo ! empty( $r['is_regex'] ) ? ' <span class="snap-badge snap-badge-gray">regex</span>' : ''; ?></td>
							<td style="word-break:break-all;"><?php echo esc_html( (string) $r['target'] ); ?></td>
							<td><span class="snap-badge <?php echo in_array( (int) $r['type'], array( 410, 451 ), true ) ? 'snap-badge-red' : 'snap-badge-green'; ?>"><?php echo esc_html( (string) $r['type'] ); ?></span></td>
							<td><?php echo esc_html( number_format_i18n( (int) $r['hits'] ) ); ?></td>
							<td class="snap-muted"><?php echo $r['last_hit'] ? esc_html( mysql2date( 'M j, Y', (string) $r['last_hit'] ) ) : '—'; ?></td>
							<td><button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-r-del" data-id="<?php echo esc_attr( (string) $r['id'] ); ?>"><?php esc_html_e( 'Delete', 'snaplevel' ); ?></button></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>

	<!-- ── 404 Monitor tab ───────────────────────────────────────────── -->
	<div class="snap-tab-panel" data-rtab-panel="monitor" style="display:none;">
		<div class="snap-box">
			<div class="snap-flex-between" style="margin-bottom:12px;">
				<div>
					<div class="snap-box-title" style="margin:0;"><?php esc_html_e( '404 Monitor', 'snaplevel' ); ?></div>
					<p class="snap-muted" style="margin:4px 0 0;"><?php esc_html_e( 'Live log of pages visitors and crawlers could not find. Create a redirect in one click.', 'snaplevel' ); ?></p>
				</div>
				<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm" id="snap-404-clear"><?php esc_html_e( 'Clear log', 'snaplevel' ); ?></button>
			</div>

			<label style="display:flex;align-items:center;gap:8px;margin-bottom:14px;cursor:pointer;">
				<input type="checkbox" id="snap-auto-deleted" <?php checked( $auto_del ); ?>>
				<span><?php esc_html_e( 'Auto-create a 301 redirect to the homepage when a published post is trashed', 'snaplevel' ); ?></span>
			</label>

			<table class="snap-table widefat" style="border:0;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'URL', 'snaplevel' ); ?></th>
						<th style="width:70px;"><?php esc_html_e( 'Hits', 'snaplevel' ); ?></th>
						<th style="width:140px;"><?php esc_html_e( 'Last Seen', 'snaplevel' ); ?></th>
						<th><?php esc_html_e( 'Referer', 'snaplevel' ); ?></th>
						<th style="width:230px;"></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $log_404 ) ) : ?>
						<tr><td colspan="5" class="snap-muted" style="text-align:center;padding:32px;"><?php esc_html_e( 'No 404s logged yet — that is a good sign.', 'snaplevel' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( $log_404 as $row ) : ?>
						<tr data-lid="<?php echo esc_attr( (string) $row['id'] ); ?>">
							<td><code><?php echo esc_html( (string) $row['url'] ); ?></code></td>
							<td><?php echo esc_html( number_format_i18n( (int) $row['hits'] ) ); ?></td>
							<td class="snap-muted"><?php echo esc_html( mysql2date( 'M j, Y H:i', (string) $row['last_seen'] ) ); ?></td>
							<td class="snap-muted" style="word-break:break-all;"><?php echo esc_html( (string) $row['referer'] ?: '—' ); ?></td>
							<td>
								<button type="button" class="snap-btn snap-btn-primary snap-btn-sm snap-404-redirect" data-url="<?php echo esc_attr( (string) $row['url'] ); ?>"><?php esc_html_e( 'Create redirect', 'snaplevel' ); ?></button>
								<button type="button" class="snap-btn snap-btn-secondary snap-btn-sm snap-404-dismiss" data-id="<?php echo esc_attr( (string) $row['id'] ); ?>"><?php esc_html_e( 'Dismiss', 'snaplevel' ); ?></button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>

	<!-- ── Import / Export tab ───────────────────────────────────────── -->
	<div class="snap-tab-panel" data-rtab-panel="tools" style="display:none;">
		<div class="snap-grid snap-grid-2">
			<div class="snap-box">
				<div class="snap-box-title"><?php esc_html_e( 'Export Redirects', 'snaplevel' ); ?></div>
				<p class="snap-muted"><?php esc_html_e( 'Download all redirects as CSV — compatible with Rank Math and Redirection plugin formats.', 'snaplevel' ); ?></p>
				<a class="snap-btn snap-btn-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=snap_redirects_export' ), 'snap_redirects_export' ) ); ?>"><?php esc_html_e( 'Download CSV', 'snaplevel' ); ?></a>
			</div>
			<div class="snap-box">
				<div class="snap-box-title"><?php esc_html_e( 'Import Redirects', 'snaplevel' ); ?></div>
				<p class="snap-muted"><?php esc_html_e( 'CSV with columns: source, target, type, is_regex.', 'snaplevel' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
					<input type="hidden" name="action" value="snap_redirects_import">
					<?php wp_nonce_field( 'snap_redirects_import' ); ?>
					<input type="file" name="csv" accept=".csv" required style="margin-bottom:10px;">
					<br><button class="snap-btn snap-btn-primary"><?php esc_html_e( 'Import CSV', 'snaplevel' ); ?></button>
				</form>
			</div>
		</div>
	</div>
</div>

<?php
wp_enqueue_script( 'snap-redirections', SNAP_PLUGIN_URL . 'assets/js/redirections.js', array(), Snap_Assets::version( 'assets/js/redirections.js' ), true );
wp_localize_script( 'snap-redirections', 'SNAP_REDIRECTIONS', array(
	'nonce'     => wp_create_nonce( 'icw_nonce' ),
	'ajaxurl'   => admin_url( 'admin-ajax.php' ),
	'restUrl'   => esc_url_raw( rest_url( 'snaplevel/v1' ) ),
	'restNonce' => wp_create_nonce( 'wp_rest' ),
	'i18n'      => array(
		'confirmDelete' => __( 'Delete this redirect?', 'snaplevel' ),
		'noMatch'       => __( 'No redirect matches', 'snaplevel' ),
		'redirectTo'    => __( 'Redirect this URL to:', 'snaplevel' ),
		'confirmClear'  => __( 'Clear the entire 404 log?', 'snaplevel' ),
	),
) );
?>
