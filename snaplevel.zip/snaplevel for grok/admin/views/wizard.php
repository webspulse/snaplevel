<?php
/**
 * Onboarding wizard — full-screen shell. Real UI is assets/js/wizard.js.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="snap-wizard-screen">
	<div class="snap-wizard-logo">
		<img src="<?php echo esc_url( SNAP_PLUGIN_URL . 'assets/images/logo-dark-text.svg' ); ?>" alt="Snaplevel">
	</div>
	<div id="snap-wizard-app">
		<div class="snap-wizard"><div class="snap-skeleton" style="height:320px;border-radius:12px;"></div></div>
	</div>
	<p style="text-align:center;margin-top:24px;">
		<a class="snap-muted" style="text-decoration:none;font-size:12px;" href="<?php echo esc_url( admin_url( 'admin.php?page=icw-dashboard' ) ); ?>">← <?php esc_html_e( 'Go back to the dashboard', 'snaplevel' ); ?></a>
	</p>
</div>
