<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$has_api_key = class_exists( 'Snap_Settings' ) && '' !== Snap_Settings::instance()->get_api_key();
$provider    = class_exists( 'Snap_Settings' ) ? (string) Snap_Settings::instance()->get( 'ai.provider', 'anthropic' ) : 'anthropic';
$provider_lb = 'openai' === $provider ? 'ChatGPT' : 'Claude';

?>
<div class="snap-container" id="icw-alt-page">

	<?php if ( ! $has_api_key ) : ?>
		<div class="snap-notice snap-notice-error">
			<?php Snap_Icons::e( 'alert', 18 ); ?>
			<span><strong><?php esc_html_e( 'No AI key found.', 'snaplevel' ); ?></strong>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=icw-settings&tab=ai' ) ); ?>" style="color:inherit;text-decoration:underline;"><?php esc_html_e( 'Connect Claude or ChatGPT in Settings →', 'snaplevel' ); ?></a></span>
		</div>
	<?php endif; ?>

	<!-- Controls bar -->
	<div class="snap-box">
		<div class="snap-flex-between">
			<div style="display:flex;gap:10px;">
				<button id="icw-load-images-btn" class="snap-btn snap-btn-primary" <?php disabled( ! $has_api_key ); ?>>
					<span class="snap-icon"><?php echo Snap_Icons::get( 'image', 15 ); // phpcs:ignore ?></span>
					<?php esc_html_e( 'Load Images', 'snaplevel' ); ?>
				</button>
				<button id="icw-bulk-generate-btn" class="snap-btn snap-btn-ai-soft hidden" <?php disabled( ! $has_api_key ); ?>>
					<span class="snap-icon"><?php echo Snap_Icons::get( 'sparkle', 15, 'snap-anim-glow' ); // phpcs:ignore ?></span>
					<?php esc_html_e( 'Bulk Generate All', 'snaplevel' ); ?>
				</button>
			</div>

			<label id="icw-only-missing-wrap" class="snap-flex" style="cursor:pointer;">
				<span class="snap-toggle">
					<input type="checkbox" id="icw-only-missing" checked>
					<span class="snap-slider">
						<span class="toggle_on"><?php esc_html_e( 'On', 'snaplevel' ); ?></span>
						<span class="toggle_off"><?php esc_html_e( 'Off', 'snaplevel' ); ?></span>
					</span>
				</span>
				<span style="font-size:13px;font-weight:500;color:var(--snap-text-muted);"><?php esc_html_e( 'Only images missing alt text', 'snaplevel' ); ?></span>
			</label>
		</div>

		<!-- Bulk progress -->
		<div id="icw-alt-bulk-progress" class="hidden" style="margin-top:20px;">
			<div class="snap-flex-between" style="font-size:13px;color:var(--snap-text-secondary);margin-bottom:8px;">
				<span id="icw-alt-bulk-label"><?php esc_html_e( 'Initializing…', 'snaplevel' ); ?></span>
				<a href="#" id="icw-alt-bulk-stop-btn" style="color:var(--snap-error);text-decoration:none;font-weight:600;"><?php esc_html_e( 'Stop Generator', 'snaplevel' ); ?></a>
			</div>
			<div class="snap-progress">
				<div id="icw-alt-bulk-bar" class="snap-progress-bar" style="width:0%;"></div>
			</div>
		</div>
	</div>

	<!-- Results -->
	<div id="icw-alt-results" class="hidden">
		<div class="snap-breadcrumbs-wrap" style="margin-bottom:12px;">
			<span class="snap-muted" style="font-size:13px;">
				<?php esc_html_e( 'Showing', 'snaplevel' ); ?> <strong id="icw-alt-showing" style="color:var(--snap-text-dark);">0</strong>
				<?php esc_html_e( 'of', 'snaplevel' ); ?> <strong id="icw-alt-total" style="color:var(--snap-text-dark);">0</strong>
				<?php esc_html_e( 'images', 'snaplevel' ); ?>
			</span>
		</div>

		<div class="icw-alt-grid" id="icw-alt-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:15px;"></div>

		<div id="icw-alt-load-more-wrap" class="hidden" style="text-align:center;margin-top:24px;">
			<button id="icw-alt-load-more-btn" class="snap-btn snap-btn-secondary"><?php esc_html_e( 'Load More Images', 'snaplevel' ); ?></button>
		</div>

		<div id="icw-alt-empty" class="hidden snap-box snap-empty">
			<span class="snap-empty-icon" style="color:#10b981;"><?php echo Snap_Icons::get( 'check-circle', 44 ); // phpcs:ignore ?></span>
			<strong><?php esc_html_e( 'All images have alt text!', 'snaplevel' ); ?></strong>
			<p style="margin:0;"><?php esc_html_e( 'Every image in your library already has alt text. Turn off the filter to view all images.', 'snaplevel' ); ?></p>
		</div>
	</div>

	<!-- Alt text item template (hidden, cloned by JS) -->
	<script type="text/template" id="icw-alt-item-tpl">
		<div class="snap-box icw-alt-item" id="icw-alt-item-{{id}}" data-id="{{id}}" style="padding:0;overflow:hidden;display:flex;flex-direction:column;margin-bottom:0;">
			<div style="position:relative;height:160px;background:var(--snap-alt-gray);border-bottom:1px solid var(--snap-border-light);">
				<img src="{{thumb}}" alt="" style="width:100%;height:100%;object-fit:cover;" loading="lazy">
				<div style="position:absolute;top:10px;right:10px;">
					<span class="snap-pill icw-alt-pill icw-badge-{{status_class}}">{{status_label}}</span>
				</div>
			</div>
			<div style="padding:20px;flex:1;display:flex;flex-direction:column;gap:12px;">
				<div style="font-weight:600;font-size:14px;color:var(--snap-text-dark);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="{{title}}">{{title}}</div>

				<div>
					<div class="snap-flex-between" style="font-size:12px;margin-bottom:5px;color:var(--snap-text-secondary);">
						<label style="font-weight:600;"><?php esc_html_e( 'Alt Text', 'snaplevel' ); ?></label>
						<span style="opacity:.7;"><?php esc_html_e( 'max 125 chars', 'snaplevel' ); ?></span>
					</div>
					<input type="text" class="icw-field-alt icw-alt-input snap-input" maxlength="125" value="{{current_alt}}" placeholder="<?php esc_attr_e( 'Click Generate to write using AI…', 'snaplevel' ); ?>" style="max-width:none;font-size:13px;">
				</div>

				<div style="display:flex;gap:10px;margin-top:auto;padding-top:4px;">
					<button class="snap-btn snap-btn-ai snap-btn-sm icw-generate-btn" data-id="{{id}}" style="flex:1;">
						<span class="snap-icon"><?php echo Snap_Icons::get( 'sparkle', 13 ); // phpcs:ignore ?></span>
						<?php esc_html_e( 'Generate', 'snaplevel' ); ?>
					</button>
					<button class="snap-btn snap-btn-secondary snap-btn-sm icw-save-alt-btn" data-id="{{id}}" disabled style="flex:1;">
						<?php esc_html_e( 'Save Edit', 'snaplevel' ); ?>
					</button>
				</div>
			</div>
		</div>
	</script>

</div>
