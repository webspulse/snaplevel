<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="snap-container" id="icw-unused-page">

	<!-- Actions bar -->
	<div class="snap-box">
		<div class="snap-flex-between">
			<div style="display:flex;gap:10px;">
				<button id="icw-scan-btn" class="snap-btn snap-btn-primary">
					<span class="snap-icon"><?php echo Snap_Icons::get( 'search', 15 ); // phpcs:ignore ?></span>
					<?php esc_html_e( 'Scan for Unused Images', 'snaplevel' ); ?>
				</button>
				<button id="icw-bulk-trash-btn" class="snap-btn snap-btn-danger" style="display:none;" disabled>
					<span class="snap-icon"><?php echo Snap_Icons::get( 'trash', 15 ); // phpcs:ignore ?></span>
					<?php esc_html_e( 'Trash Selected', 'snaplevel' ); ?>
					<span id="icw-selected-count" class="snap-badge snap-badge-red">0</span>
				</button>
			</div>

			<label id="icw-select-all-wrap" class="snap-flex" style="display:none;cursor:pointer;">
				<input type="checkbox" id="icw-select-all" style="margin:0;">
				<span style="font-size:13px;font-weight:500;color:var(--snap-text-muted);"><?php esc_html_e( 'Select all', 'snaplevel' ); ?></span>
			</label>
		</div>

		<div class="snap-notice snap-notice-warning" style="margin:18px 0 0;">
			<?php Snap_Icons::e( 'shield', 18 ); ?>
			<span><strong><?php esc_html_e( 'Safe Deletion:', 'snaplevel' ); ?></strong>
			<?php esc_html_e( 'Images are moved to Trash — never permanently deleted. You can restore them from Media › Trash at any time.', 'snaplevel' ); ?></span>
		</div>
	</div>

	<!-- Scan status -->
	<div id="icw-scan-status" style="display:none;text-align:center;padding:50px;color:var(--snap-text-secondary);">
		<span class="snap-eq" style="margin-right:10px;"><span></span><span></span><span></span></span>
		<span style="font-size:15px;font-weight:600;"><?php esc_html_e( 'Scanning your media library…', 'snaplevel' ); ?></span>
	</div>

	<!-- Results -->
	<div id="icw-unused-results" style="display:none;">
		<div style="margin-bottom:12px;font-size:13px;color:var(--snap-text-secondary);">
			<?php esc_html_e( 'Found', 'snaplevel' ); ?>
			<strong id="icw-unused-total" style="color:var(--snap-score-bad);font-size:16px;">0</strong>
			<?php esc_html_e( 'unused image(s)', 'snaplevel' ); ?>
		</div>

		<div class="icw-unused-grid" id="icw-unused-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:15px;"></div>

		<div id="icw-load-more-wrap" style="display:none;text-align:center;margin-top:24px;">
			<button id="icw-load-more-btn" class="snap-btn snap-btn-secondary"><?php esc_html_e( 'Load More Images', 'snaplevel' ); ?></button>
		</div>

		<div id="icw-unused-empty" class="snap-box snap-empty" style="display:none;">
			<span class="snap-empty-icon" style="color:var(--snap-score-good);"><?php echo Snap_Icons::get( 'check-circle', 44 ); // phpcs:ignore ?></span>
			<strong><?php esc_html_e( 'All Clear!', 'snaplevel' ); ?></strong>
			<p style="margin:0;"><?php esc_html_e( 'No unused images found. Every image in your library is referenced somewhere on your site.', 'snaplevel' ); ?></p>
		</div>
	</div>

	<!-- Image card template (hidden, cloned by JS) -->
	<script type="text/template" id="icw-unused-item-tpl">
		<div class="snap-box icw-unused-item" data-id="{{id}}" style="padding:16px 20px;margin-bottom:0;">
			<div style="display:flex;gap:14px;align-items:center;">
				<input type="checkbox" class="icw-unused-check" data-id="{{id}}" style="margin:0;">
				<div style="width:64px;height:64px;flex-shrink:0;border-radius:3px;overflow:hidden;background:var(--snap-alt-gray);border:1px solid var(--snap-border-light);">
					<img src="{{thumb}}" alt="" style="width:100%;height:100%;object-fit:cover;" loading="lazy">
				</div>
				<div style="flex:1;min-width:0;">
					<div style="font-weight:600;color:var(--snap-text-dark);font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:4px;" title="{{title}}">{{title}}</div>
					<div style="font-size:12px;color:var(--snap-text-secondary);margin-bottom:3px;">{{mime}} &middot; {{filesize}}</div>
					<div style="font-size:11px;color:var(--snap-text-secondary);opacity:.8;">{{date}}</div>
				</div>
				<div style="display:flex;flex-direction:column;gap:6px;">
					<a href="{{url}}" target="_blank" class="snap-btn snap-btn-tertiary snap-btn-sm" title="<?php esc_attr_e( 'View image', 'snaplevel' ); ?>" style="padding:0 8px;">
						<span class="snap-icon"><?php echo Snap_Icons::get( 'external', 13 ); // phpcs:ignore ?></span>
					</a>
					<button class="snap-btn snap-btn-danger snap-btn-sm icw-trash-one-btn" data-id="{{id}}" title="<?php esc_attr_e( 'Move to Trash', 'snaplevel' ); ?>" style="padding:0 8px;">
						<span class="snap-icon"><?php echo Snap_Icons::get( 'trash', 13 ); // phpcs:ignore ?></span>
					</button>
				</div>
			</div>
		</div>
	</script>

</div>
