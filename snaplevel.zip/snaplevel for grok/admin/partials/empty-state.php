<?php
/**
 * Reusable empty state component.
 *
 * @param string $icon        Snap_Icons icon name (e.g. 'redirect', 'link', 'image').
 * @param string $heading     Main heading text.
 * @param string $description Supporting description text.
 * @param string $cta_text    (Optional) Button label.
 * @param string $cta_url     (Optional) Button URL.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="snap-empty-state" role="status" aria-live="polite">
	<?php if ( ! empty( $icon ) ) : ?>
		<div class="snap-empty-state-icon" aria-hidden="true">
			<?php Snap_Icons::e( $icon, 40 ); ?>
		</div>
	<?php endif; ?>
	<h3 class="snap-empty-state-heading"><?php echo esc_html( $heading ); ?></h3>
	<p class="snap-empty-state-desc"><?php echo esc_html( $description ); ?></p>
	<?php if ( ! empty( $cta_url ) && ! empty( $cta_text ) ) : ?>
		<a href="<?php echo esc_url( $cta_url ); ?>" class="snap-btn snap-btn-primary snap-btn-sm"><?php echo esc_html( $cta_text ); ?></a>
	<?php endif; ?>
</div>
