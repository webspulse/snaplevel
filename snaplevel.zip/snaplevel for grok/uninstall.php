<?php
/**
 * Runs when the plugin is deleted (not just deactivated).
 * Removes .htaccess rules, options, custom tables, caps, and plugin meta.
 * Image files and backups are intentionally preserved.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Remove .htaccess WebP rules.
require_once plugin_dir_path( __FILE__ ) . 'includes/class-htaccess-manager.php';
ICW_Htaccess_Manager::remove_webp_rules();

// Remove options.
delete_option( 'icw_settings' );
delete_option( 'snap_settings' );
delete_option( 'snap_ai_queue' );
delete_option( 'snap_indexnow_key' );
delete_option( 'snap_wizard_done' );
delete_option( 'snap_wizard_skipped' );
delete_option( 'snap_show_wizard_redirect' );
delete_option( 'snap_flush_rewrites' );

// Remove custom capabilities.
foreach ( array( 'administrator', 'editor' ) as $role_id ) {
	$role = get_role( $role_id );
	if ( $role ) {
		$role->remove_cap( 'snap_manage_seo' );
		$role->remove_cap( 'snap_use_ai' );
	}
}

global $wpdb;

// Drop custom tables.
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}snap_ai_log" );      // phpcs:ignore
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}snap_ai_training" ); // phpcs:ignore

// Remove post meta rows for both prefixes.
// esc_like() escapes _ and % so they are treated as literals, not wildcards.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
		$wpdb->esc_like( '_icw_' ) . '%'
	)
);
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
		$wpdb->esc_like( '_snap_' ) . '%'
	)
);

// Remove AI response transients.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_snap_ai_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_snap_ai_' ) . '%'
	)
);

// Clear scheduled events.
wp_clear_scheduled_hook( 'snap_ai_queue_run' );
