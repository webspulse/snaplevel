# Snaplevel Copilot: Design & Architecture

---

## Part 1: Copilot Experience Design

### What Copilot Is NOT

- Not a score that judges you
- Not traffic lights that make you feel inadequate
- Not a checklist of things YOU have to fix
- Not a readability analyzer that counts syllables

### What Copilot IS

A quiet assistant that finds opportunities and offers to fix them for you. It speaks in plain language, surfaces only what matters, and does the work when you say go.

### Core Principle

"AI does the work. You stay in control."

This means: Copilot never shows a problem without offering to solve it. Every suggestion has a "Fix" button, not just a warning label.

---

### Sidebar Panel: "Copilot"

The panel sits in the Gutenberg sidebar (and in the Classic metabox under a "Copilot" tab). It has three states:

#### State 1: Not Yet Analyzed (first load, no cached analysis)

```
┌─────────────────────────────────────┐
│  ✦ Snaplevel Copilot                │
│                                     │
│  Save this post and Copilot will    │
│  find opportunities to improve      │
│  your SEO automatically.            │
│                                     │
│  Or: [Analyze Now]                  │
└─────────────────────────────────────┘
```

#### State 2: Opportunities Found

```
┌─────────────────────────────────────┐
│  ✦ Copilot found 4 opportunities    │
│                                     │
│  ┌─────────────────────────────────┐│
│  │ ○ Write a meta description      ││
│  │   This post has no description. ││
│  │   Google will auto-generate one.││
│  │   [Fix with AI]                 ││
│  └─────────────────────────────────┘│
│  ┌─────────────────────────────────┐│
│  │ ○ Add internal links            ││
│  │   No links to other posts.      ││
│  │   2 related posts found.        ││
│  │   [Show suggestions]            ││
│  └─────────────────────────────────┘│
│  ┌─────────────────────────────────┐│
│  │ ○ Add FAQ schema                ││
│  │   This content answers 3        ││
│  │   questions. FAQ rich results    ││
│  │   could show in Google.         ││
│  │   [Generate FAQ]                ││
│  └─────────────────────────────────┘│
│  ┌─────────────────────────────────┐│
│  │ ○ Break up paragraph 4          ││
│  │   138 words without a break.    ││
│  │   Readers skim on mobile.       ││
│  │   [Why this matters]            ││
│  └─────────────────────────────────┘│
│                                     │
│  [Fix All with AI]                  │
│                                     │
│  ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  │
│  SEO readiness: Good                │
│  (details for nerds, collapsed)     │
└─────────────────────────────────────┘
```

#### State 3: All Clear

```
┌─────────────────────────────────────┐
│  ✦ Copilot: Looking good            │
│                                     │
│  No opportunities found.            │
│  This post is well-optimized.       │
│                                     │
│  Last checked: 2 minutes ago        │
└─────────────────────────────────────┘
```

### Design Decisions

**No numeric score visible by default.** The "SEO readiness" label at the bottom uses words (Good / Needs work / Not started). If a user expands the collapsed section, they can see a breakdown. But the primary experience is opportunity cards, not a number.

**Every opportunity card has exactly one CTA.** Either:
- `[Fix with AI]` -- Copilot generates the fix, shows it inline for approval
- `[Show suggestions]` -- Copilot shows internal link options to insert
- `[Generate FAQ]` -- Copilot writes FAQ pairs and previews them
- `[Why this matters]` -- Expands a 1-sentence explanation (for structural suggestions AI can't auto-fix like paragraph length)

**"Fix All with AI" button** -- runs all fixable suggestions in sequence. Shows a progress indicator. Each fix requires one final "Save" to commit. Nothing changes until the user saves the post.

**Suggestion categories (internal, not shown to user):**
- `meta` -- missing/weak title or description
- `links` -- no internal links, no external links
- `schema` -- FAQ/HowTo opportunity detected
- `structure` -- long paragraphs, no headings, no images
- `keyword` -- focus keyword not in title/H1/first paragraph

### What Copilot Does NOT Surface

- Keyword density numbers
- Flesch reading scores
- Passive voice percentages
- Word count warnings
- "Your title is X characters" counters (these exist elsewhere in the metabox)

Copilot surfaces opportunities, not metrics.

---

### AI Task Definition: `copilot_analyze`

```php
'copilot_analyze' => array(
    'tier'       => 'fast',
    'max_tokens' => 1500,
    'training'   => true,
    'system'     => <<<PROMPT
You are Snaplevel Copilot, an SEO assistant for WordPress content creators.

Your job: find actionable SEO opportunities in the user's content. Only flag things that genuinely matter and that can be improved. Never invent problems.

Rules:
- Maximum 7 opportunities, minimum 0.
- Each opportunity must be specific to THIS content (never generic advice).
- Each opportunity must include a clear one-sentence "why" that a non-SEO person would understand.
- If the content is well-optimized, return zero opportunities.
- Never mention scores, percentages, or density numbers.
- Focus on: missing meta, missing internal links, schema opportunities (FAQ, HowTo), structural issues (walls of text, missing headings), keyword placement gaps.
- Do NOT suggest things the user cannot control (like backlinks or domain authority).
- Be honest. If a 300-word post doesn't need internal links, don't suggest them.
PROMPT,
    'user' => function($ctx) {
        // Builds context with: content, title, existing meta, focus keyword,
        // existing internal links count, word count, heading structure
    },
    'schema' => array(
        'type' => 'object',
        'properties' => array(
            'opportunities' => array(
                'type' => 'array',
                'maxItems' => 7,
                'items' => array(
                    'type' => 'object',
                    'properties' => array(
                        'id'       => array('type' => 'string'),
                        'category' => array('type' => 'string', 'enum' => ['meta','links','schema','structure','keyword']),
                        'title'    => array('type' => 'string', 'maxLength' => 60),
                        'reason'   => array('type' => 'string', 'maxLength' => 120),
                        'fixable'  => array('type' => 'boolean'),
                        'fix_task' => array('type' => 'string', 'enum' => ['generate_meta_desc','generate_title','generate_faq','suggest_links','none']),
                    ),
                    'required' => ['id','category','title','reason','fixable'],
                ),
            ),
            'readiness' => array('type' => 'string', 'enum' => ['good','needs_work','not_started']),
        ),
        'required' => ['opportunities','readiness'],
    ),
),
```

---

## Part 2: Analysis Trigger Architecture

### Three Approaches Compared

| Approach | Delight | Trust | API Cost | Complexity |
|----------|---------|-------|----------|------------|
| Manual "Analyze" button | Low (user must remember) | High (explicit action) | Low (only when clicked) | Low |
| Auto-analyze on save | High (feels magical) | Medium (needs opt-in) | Medium (every save) | Medium |
| Background cron analysis | Medium (delayed magic) | Medium (happens "behind the scenes") | Medium (batched) | High |

### Recommendation: Auto-Analyze on Save (with smart guards)

This is the approach that maximizes delight while respecting trust and cost.

**Flow:**

```
1. User enables Copilot during onboarding (or in Settings > AI > Copilot toggle)
2. User edits a post and clicks "Save Draft" or "Publish" or "Update"
3. After successful save, a background AJAX call fires (not blocking the save)
4. AI analyzes the content (fast tier, ~0.1 cent per call)
5. Result is cached in post meta: `_snap_copilot_analysis`
6. On next editor load (or immediately if still on page), sidebar shows opportunities
```

**Smart Guards (prevent cost runaway):**

| Guard | Rule |
|-------|------|
| Content hash check | Don't re-analyze if content hasn't changed since last analysis |
| Debounce | Minimum 60 seconds between analyses for the same post |
| Daily cap per site | Max 50 analyses per day (configurable in settings, default 50) |
| Min content length | Don't analyze posts under 100 words (nothing useful to say) |
| Opt-in only | Copilot is OFF by default. Enabled during onboarding or in settings. |
| Draft threshold | Only analyze posts that are "draft" or "publish" status, not "auto-draft" |

**Why auto-save wins over manual button:**

The manual button requires the user to remember Copilot exists. Most users will forget within a week. Auto-save means every time they open a post, suggestions are already waiting. The experience goes from "click button, wait 3 seconds" to "open post, suggestions are there." That's the difference between a tool and a copilot.

**Why auto-save wins over background cron:**

Cron runs on a schedule (hourly, daily). This means the first time a user publishes, they don't see suggestions until the next cron run. The magic moment is lost. Auto-save means suggestions appear within seconds of the save that triggered them.

**API cost reality:**

- Fast tier (Claude Haiku / GPT-4o-mini): ~$0.001 per analysis
- 50 analyses/day = ~$0.05/day = ~$1.50/month
- This is less than one manual generation of a meta description on the smart tier

### Technical Implementation

**Hook:** `save_post` (priority 99, after all meta is saved)

```php
add_action('save_post', array($this, 'maybe_trigger_copilot'), 99, 2);

public function maybe_trigger_copilot(int $post_id, WP_Post $post): void {
    // Guards
    if (!Snap_Settings::instance()->get('copilot.enabled', false)) return;
    if (wp_is_post_autosave($post_id)) return;
    if (wp_is_post_revision($post_id)) return;
    if (!in_array($post->post_status, ['publish', 'draft', 'pending'], true)) return;
    if (str_word_count(strip_tags($post->post_content)) < 100) return;

    // Content hash check
    $hash = md5($post->post_title . $post->post_content);
    $last_hash = get_post_meta($post_id, '_snap_copilot_hash', true);
    if ($hash === $last_hash) return;

    // Debounce (60s)
    $last_run = (int) get_post_meta($post_id, '_snap_copilot_time', true);
    if (time() - $last_run < 60) return;

    // Daily cap
    $today_count = (int) get_transient('snap_copilot_daily_count');
    $daily_limit = (int) Snap_Settings::instance()->get('copilot.daily_limit', 50);
    if ($today_count >= $daily_limit) return;

    // Schedule immediate background analysis (non-blocking)
    wp_schedule_single_event(time(), 'snap_copilot_analyze', array($post_id, $hash));
}
```

**Background handler:**

```php
add_action('snap_copilot_analyze', array($this, 'run_analysis'), 10, 2);

public function run_analysis(int $post_id, string $hash): void {
    $post = get_post($post_id);
    if (!$post) return;

    $result = Snap_AI::generate('copilot_analyze', array(
        'content'       => $post->post_content,
        'post_title'    => $post->post_title,
        'focus_keyword' => get_post_meta($post_id, '_snap_focus_kw', true),
        'has_meta_desc' => '' !== get_post_meta($post_id, '_snap_desc', true),
        'internal_links'=> self::count_internal_links($post->post_content),
        'word_count'    => str_word_count(strip_tags($post->post_content)),
    ));

    if (!is_wp_error($result)) {
        update_post_meta($post_id, '_snap_copilot_analysis', $result['data']);
        update_post_meta($post_id, '_snap_copilot_hash', $hash);
        update_post_meta($post_id, '_snap_copilot_time', time());
        set_transient('snap_copilot_daily_count', $today_count + 1, DAY_IN_SECONDS);
    }
}
```

**Editor sidebar reads cached analysis on load:**

The sidebar already gets post meta via `wp.data.select('core/editor').getEditedPostAttribute('meta')`. Since `_snap_copilot_analysis` is registered as post meta with `show_in_rest => true`, the sidebar has it immediately on load. Zero additional API calls.

### Fallback: Manual "Analyze Now" Button

Always available as a secondary option for:
- Posts that haven't been saved yet (new drafts)
- Users who want to re-check after making changes without saving
- When the daily cap is reached

---

## Part 3: Dashboard Caching -- Tiered TTL Strategy

### Challenge to Uniform 5-Minute Cache

Not all metrics have the same staleness tolerance. A user who just published a post expects the "Published pages" count to update immediately. A user checking broken links doesn't expect real-time accuracy (the scan ran hours ago anyway).

### Metric Classification

| Metric | Current Source | Staleness Tolerance | Recommended TTL | Rationale |
|--------|---------------|--------------------:|-----------------|-----------|
| Published pages count | `wp_count_posts()` | 0 seconds | **Real-time** | WordPress caches this internally. It's already fast (~1ms). No transient needed. |
| Missing descriptions | Custom SQL join | 30 seconds | **1-minute** | User who just added a description expects it to reflect quickly. |
| Schema coverage % | Custom SQL count | 60 seconds | **1-minute** | Same reasoning. |
| AI generations this month | Custom table count | 5 minutes | **5-minute** | Not time-sensitive. User won't notice a 5-min delay on a monthly counter. |
| Redirects active | Table count | 5 minutes | **5-minute** | Changes rarely. |
| 404s logged | Table count | 5 minutes | **5-minute** | 404s accumulate slowly. |
| Broken links count | Table count | 1 hour | **1-hour** | Only changes when a scan runs (daily cron). Checking more often is pointless. |
| Health score | Computed from above | Derived | **Recompute from cached components** | Not cached independently. Computed from the other metrics. Always fresh relative to its inputs. |

### Implementation: Split Transients

Instead of one `snap_dashboard_stats` transient, use granular keys:

```php
final class Snap_Dashboard_Stats {

    // Real-time (no cache, already fast)
    public static function posts_count(): int {
        return (int) wp_count_posts('post')->publish + (int) wp_count_posts('page')->publish;
    }

    // 1-minute cache
    public static function missing_meta(): int {
        return self::cached('snap_dash_missing_meta', 60, function() {
            global $wpdb;
            return (int) $wpdb->get_var("...");
        });
    }

    public static function schema_coverage(): float {
        return self::cached('snap_dash_schema_cov', 60, function() {
            global $wpdb;
            // ...
        });
    }

    // 5-minute cache
    public static function ai_usage(): array {
        return self::cached('snap_dash_ai_usage', 300, function() {
            return Snap_AI_Usage::summary();
        });
    }

    public static function redirects_active(): int {
        return self::cached('snap_dash_redirects', 300, function() {
            return Snap_Redirections::count_active();
        });
    }

    // 1-hour cache
    public static function broken_links(): int {
        return self::cached('snap_dash_broken', 3600, function() {
            return Snap_Broken_Links::count_broken();
        });
    }

    // Health score: always fresh (computed from components)
    public static function health_score(): array {
        $posts = self::posts_count();
        $missing = self::missing_meta();
        // ... compute from live component values
    }

    // Targeted invalidation
    public static function invalidate_meta(): void {
        delete_transient('snap_dash_missing_meta');
        delete_transient('snap_dash_schema_cov');
    }

    public static function invalidate_redirects(): void {
        delete_transient('snap_dash_redirects');
    }

    public static function invalidate_links(): void {
        delete_transient('snap_dash_broken');
    }

    private static function cached(string $key, int $ttl, callable $compute) {
        $val = get_transient($key);
        if (false !== $val) return $val;
        $val = $compute();
        set_transient($key, $val, $ttl);
        return $val;
    }
}
```

### Invalidation Hooks (Targeted)

| Hook | Invalidates |
|------|-------------|
| `save_post` | `missing_meta`, `schema_coverage` |
| `updated_post_meta` (for `_snap_desc`, `_snap_schema`) | `missing_meta`, `schema_coverage` |
| `snap_redirect_saved` | `redirects_active` |
| `snap_broken_links_scan_complete` | `broken_links` |
| `snap_ai_generation_complete` | `ai_usage` |

### Performance Result

**Before:** 6 SQL queries, every dashboard load. On a site with 10,000 posts: ~400ms.

**After:**
- Real-time metrics: 1ms (WordPress internal cache)
- Cached metrics: 1 `get_transient()` call each = ~5ms total
- Total dashboard load: ~10ms for stats (vs ~400ms before)
- Fresh data within 60 seconds for things users notice, 5+ minutes for things they don't

---

## Part 4: The 30-Second Magic Moment

### The Problem

New user installs Snaplevel. They land on the dashboard. They see a health score, a checklist, some links. Same as every other SEO plugin. Nothing happens. They think "I'll configure this later" and never come back.

### The Magic Moment

**Trigger:** User activates Snaplevel for the first time.

**What happens in 30 seconds:**

#### Second 0-3: Wizard opens automatically

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  Welcome to Snaplevel                           │
│                                                 │
│  Let's see what AI can do for your site.        │
│  This takes about 10 seconds.                   │
│                                                 │
│  [Show me →]                                    │
│                                                 │
└─────────────────────────────────────────────────┘
```

One button. No fields. No configuration. No API key required yet.

#### Second 3-5: User clicks "Show me"

Snaplevel instantly (no API call) scans the site for quick wins using LOCAL data only:

```php
// No AI needed for this scan. Pure SQL + PHP.
$quick_scan = array(
    'posts_without_meta' => count of posts missing meta descriptions,
    'images_without_alt' => count of images missing alt text,
    'sample_post'        => most recent published post (title + excerpt),
    'has_sitemap'        => whether XML sitemap exists,
    'incoming_seo'       => detect Yoast/Rank Math data to import,
);
```

#### Second 5-12: Results appear with animated counter

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  Here's what Snaplevel found:                   │
│                                                 │
│  📝  47 posts without meta descriptions         │
│  🖼️  123 images without alt text                │
│  🔗  No XML sitemap active                      │
│                                                 │
│  Let me show you what AI can do.                │
│                                                 │
│  Your most recent post:                         │
│  "How to Choose the Right CRM for..."          │
│                                                 │
│  [Generate a meta description for this →]       │
│                                                 │
└─────────────────────────────────────────────────┘
```

This is where the magic starts. The user sees their own content. Their own post title. A concrete, personal offer.

#### Second 12-15: User clicks "Generate a meta description"

Now we need an API key. BUT -- instead of interrupting with a settings page, we do this inline:

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  To generate, connect an AI provider.           │
│  (You pay pennies directly to them.)            │
│                                                 │
│  Fastest setup:                                 │
│  [Paste your OpenAI key] _______________        │
│                                                 │
│  Or choose: Claude | Gemini | DeepSeek | Mistral│
│                                                 │
│  Don't have a key? [Get one free →]             │
│                                                 │
└─────────────────────────────────────────────────┘
```

#### Second 15-25: User pastes key

Key is validated instantly (test API call). Green checkmark.

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  ✓ Connected to OpenAI                          │
│                                                 │
│  Generating meta description for:              │
│  "How to Choose the Right CRM for..."          │
│                                                 │
│  ████████████░░░░ Thinking...                   │
│                                                 │
└─────────────────────────────────────────────────┘
```

#### Second 25-28: AI result appears

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  ✦ Here's your meta description:                │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │ Learn how to evaluate CRM platforms     │   │
│  │ based on team size, budget, and growth   │   │
│  │ goals. Compare 5 top options for 2026.   │   │
│  │                                   143 ch │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  [Save this] [Try again] [Edit manually]        │
│                                                 │
└─────────────────────────────────────────────────┘
```

#### Second 28-30: User clicks "Save this"

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  ✓ Saved!                                       │
│                                                 │
│  That took 3 seconds instead of 3 minutes.      │
│  You have 46 more posts to optimize.            │
│                                                 │
│  [Set up Copilot to do this automatically]      │
│  [Take me to my dashboard]                      │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Why This Beats Yoast/Rank Math in 30 Seconds

**Yoast first 30 seconds:** Configuration wizard asking about organization type, social profiles, search appearance preferences. Zero value delivered. User configured something but got nothing back.

**Rank Math first 30 seconds:** Setup wizard with 6 steps, asking about site type, business name, social URLs, role settings. Ends with "You're all set!" but user has no idea what changed.

**Snaplevel first 30 seconds:** User SAW their own data, SAW a problem they didn't know they had (47 posts without descriptions), and WATCHED AI fix one of them in 3 seconds. They experienced the core value proposition before they even finished setup.

The difference: Yoast and Rank Math ask you to configure. Snaplevel shows you what it can do with YOUR content, right now.

### Technical Implementation

#### New file: `includes/core/class-first-run.php`

```php
final class Snap_First_Run {
    public function __construct() {
        add_action('admin_init', array($this, 'maybe_redirect'));
    }

    public function maybe_redirect(): void {
        if (!get_option('snap_show_wizard_redirect')) return;
        delete_option('snap_show_wizard_redirect');
        wp_safe_redirect(admin_url('admin.php?page=snap-wizard'));
        exit;
    }
}
```

#### Modified wizard flow (`admin/views/wizard.php` + `assets/js/wizard.js`)

The wizard currently has multi-step configuration. Replace Step 1 with the "Show me" experience described above. The remaining steps (import, AI training, modules) become optional follow-ups AFTER the magic moment.

#### Quick scan endpoint (no AI required)

```php
// New REST endpoint
register_rest_route('snaplevel/v1', '/wizard/quick-scan', array(
    'methods'  => 'GET',
    'callback' => function() {
        global $wpdb;
        $posts_count = wp_count_posts('post')->publish + wp_count_posts('page')->publish;
        $missing_meta = $wpdb->get_var("...");
        $missing_alt = $wpdb->get_var("...");
        $sample_post = get_posts(array('numberposts' => 1, 'post_status' => 'publish', 'orderby' => 'date'));

        return array(
            'posts_without_meta' => (int) $missing_meta,
            'images_without_alt' => (int) $missing_alt,
            'total_posts'        => (int) $posts_count,
            'sample_post'        => $sample_post ? array(
                'id'    => $sample_post[0]->ID,
                'title' => $sample_post[0]->post_title,
            ) : null,
            'detected_plugin'    => self::detect_seo_plugin(),
        );
    },
    'permission_callback' => array('Snap_Capabilities', 'can_manage'),
));
```

#### API cost of the magic moment

- Quick scan: $0 (local SQL)
- Key validation: ~$0.0001 (tiny test prompt)
- Meta description generation: ~$0.001 (fast tier, ~200 tokens)

**Total cost of first impression: less than $0.002.**

For comparison, Rank Math's "Content AI" charges credits for this. Snaplevel does it for a fraction of a cent on the user's own key.

### What If the User Has No Posts?

Edge case: brand new WordPress install, zero published content.

```
┌─────────────────────────────────────────────────┐
│                                                 │
│  Your site is brand new -- nothing to scan yet. │
│                                                 │
│  Here's what Snaplevel will do once you start   │
│  publishing:                                    │
│                                                 │
│  • Generate meta descriptions automatically     │
│  • Find internal linking opportunities          │
│  • Create schema markup for rich results        │
│  • Monitor for broken links and 404s            │
│                                                 │
│  [Enable Copilot] [Skip for now]                │
│                                                 │
└─────────────────────────────────────────────────┘
```

No fake demo. No dummy data. Honest about having nothing to show yet, but sets expectations for what will happen.

### What If the User Has No API Key and Doesn't Want One?

The "Show me" scan works without a key. The generation step simply won't fire. Instead:

```
"47 posts without meta descriptions. Connect an AI provider
 to fix them in seconds, or write them manually in each post."

[Connect AI later -- take me to the dashboard]
```

The user still got value: they learned something about their site they didn't know. That's enough to keep the plugin installed.

---

## Updated Blueprint Entry: Initiative 1 (Copilot)

### Files to Create

| File | Purpose |
|------|---------|
| `includes/core/class-copilot.php` | Copilot enable/disable, save_post hook, analysis trigger, daily cap |
| (task in `class-ai-prompts.php`) | `copilot_analyze` task definition |

### Files to Modify

| File | Change |
|------|--------|
| `includes/ai/class-ai-prompts.php` | Add `copilot_analyze` task |
| `assets/js/editor-sidebar.js` | Add Copilot panel with opportunity cards |
| `assets/js/wizard.js` | Replace step 1 with "Show me" quick-scan experience |
| `admin/views/wizard.php` | Restructure for magic-moment-first flow |
| `includes/core/class-assets.php` | Add `copilotEnabled` and `copilotAnalysis` to `SNAP_SIDEBAR` localization |
| `includes/core/class-rest-api.php` | Add `/wizard/quick-scan` endpoint |
| `snaplevel.php` | Require `class-copilot.php` in `load_core()` |
| `assets/css/design-system.css` | Add `.snap-copilot-*` component styles |

### Post Meta Added

| Key | Type | Purpose |
|-----|------|---------|
| `_snap_copilot_analysis` | JSON string | Cached analysis result (opportunities array + readiness) |
| `_snap_copilot_hash` | string | MD5 of title+content at last analysis (change detection) |
| `_snap_copilot_time` | integer | Unix timestamp of last analysis (debounce) |

All registered with `show_in_rest => true` so the block editor sidebar has them on load.

### Options Added

| Key | Default | Purpose |
|-----|---------|---------|
| `snap_copilot_enabled` | `false` | Global Copilot toggle (opt-in during onboarding) |
| `snap_copilot_daily_limit` | `50` | Max analyses per day |

### Transient Added

| Key | TTL | Purpose |
|-----|-----|---------|
| `snap_copilot_daily_count` | 24h | Today's analysis count (resets daily) |

---

## Summary: What Changed from the Original Blueprint

| Original | Now |
|----------|-----|
| "AI Content Score" with numeric score as primary | "Copilot" with opportunity cards as primary |
| Manual "Analyze" button | Auto-analyze on save + manual fallback |
| Single 5-min transient for all dashboard stats | Tiered TTLs (real-time / 1-min / 5-min / 1-hour) |
| Wizard leads with configuration | Wizard leads with "Show me what AI can do" |
| Score visible by default | Score hidden, readiness word only |
| User does the work | AI offers to do the work, user approves |
