# Snaplevel Competitive Analysis & Roadmap

## WordPress.org Review Fixes Summary (DONE)

All blocking issues from the WordPress.org pre-review have been fixed:

| Issue | Fix Applied |
|-------|-------------|
| Nonce sanitization | `wp_unslash()` + `sanitize_text_field()` before `wp_verify_nonce()` |
| `$_SERVER` sanitization | All `$_SERVER['REQUEST_URI']` and `$_SERVER['SERVER_SOFTWARE']` now sanitized |
| Schema JSON-LD escaping | Switched to `JSON_HEX_TAG` flag to prevent `</script>` breakout |
| Image processor path traversal | Added `realpath()` validation against uploads directory |
| Inline `<style>` in seo-audit | Moved to `admin.css` |
| Inline `<style>` in builder-integration | Converted to `wp_add_inline_style()` |
| GA4/AdSense `<script>` tags | Converted to `wp_enqueue_script()` + `wp_add_inline_script()` |
| `load_plugin_textdomain` | Removed (not needed for .org hosted plugins since WP 4.6) |
| Plugin URI 404 | Changed to working URL |
| readme.txt inconsistencies | Fixed AI provider description, removed comparative wording |
| External services undocumented | Added full `== External services ==` section with TOS/privacy links |
| wporg-assets in zip | **YOU MUST DELETE** the `wporg-assets/` folder before re-uploading |

### Still Required (Manual Steps)

1. **Delete `wporg-assets/` folder** from the plugin zip before uploading.
2. **Delete `test.php`** from the plugin root.
3. **Email ownership**: Either change your WordPress.org email to an `@autogencrm.com` address, OR add a DNS TXT record `wordpressorg-autogencrm-verification` at the root of `autogencrm.com`.
4. **Create the page** at `https://autogencrm.com/snaplevel` (or keep it removed from Plugin URI as already done).
5. **WordPress 7.0 AI Client**: The reviewer noted you should consider migrating to the WP 7.0 AI Client. This is a recommendation, not a blocker. Add a note in your reply that you plan to add WP AI Client support in a future update while maintaining BYOK as a fallback for sites on older WP versions.

---

## Competitive Feature Analysis

### Current Snaplevel vs Yoast Free vs Rank Math Free

| Feature | Snaplevel 1.0 | Yoast Free | Rank Math Free |
|---------|--------------|------------|----------------|
| AI title/desc generation | Yes (5 providers) | No (Premium only) | No (paid Content AI) |
| Schema types | AI-generated, any type | Basic only | 15+ types |
| Redirections | Yes + 404 monitor | No (Premium) | Yes |
| Broken link checker | Yes | No | No |
| Image compression | Yes (WebP) | No | No |
| AI alt text | Yes | No | No |
| Content analysis | Basic score | Advanced readability | Advanced score |
| Internal linking suggestions | No | Premium only | Yes (limited) |
| Keyword tracking | No | No | Yes (Rank Tracker) |
| Local SEO | No | Premium add-on | Yes |
| WooCommerce SEO | Basic | Premium add-on | Yes |
| Google Search Console | No | Limited | Yes |
| AI Training/brand voice | Yes (100k words) | No | No |
| IndexNow | Yes | Premium only | Yes |
| llms.txt | Yes | No | Yes (2026) |
| Importers | 8 plugins | N/A | 5+ plugins |

### Weak Implementations in Snaplevel 1.0

| Weakness | Why Users Care | Priority |
|----------|---------------|----------|
| Content analysis is basic (just meta presence) | Users expect Yoast-level readability + keyword density scoring | 9/10 |
| No keyword research/suggestions | Users need to know WHAT to optimize for | 8/10 |
| No internal linking suggestions | Critical for SEO; both competitors offer this | 8/10 |
| No Google Search Console integration | Users want to see real ranking data inside WP | 7/10 |
| No Local SEO schema | Large market segment needs this | 6/10 |
| REST API permission too broad for AI endpoint | Any editor can invoke any AI task | 5/10 |
| No content AI beyond meta fields | Users want full-article AI assistance | 7/10 |
| No multi-keyword support per post | Rank Math allows 5 keywords free | 7/10 |
| No sitemap news/video extensions | News sites need this | 4/10 |
| No role-based access control UI | Agencies need per-role permissions | 5/10 |

---

## Roadmap

### Phase 1: WordPress.org Launch Essentials (Week 1-2)

These are non-negotiable for approval and first impressions.

**1.1 Fix all review issues (DONE)**
- Sanitization, escaping, enqueue, external services docs

**1.2 Content Analysis Engine (Real-time)**
- Problem: Current "score" only checks if meta fields exist. Users expect Yoast-level feedback.
- Why users care: This is the #1 reason people install SEO plugins. Without it, no one sticks around.
- Implementation: Real-time JS analyzer in the editor sidebar checking: keyword in title, keyword in first paragraph, keyword density (1-3%), heading usage, paragraph length, passive voice %, transition words, internal/external link count, image alt keyword presence, meta length.
- Difficulty: Medium (3-4 days)
- WordPress.org impact: HIGH. This is what gets 5-star reviews.
- Priority: 10/10

**1.3 Multi-keyword support (up to 5 focus keywords)**
- Problem: Only one keyword per post currently.
- Why users care: Rank Math gives 5 free. Users switching from RM will feel downgraded.
- Implementation: Array field in post meta, score each keyword independently, show per-keyword breakdown.
- Difficulty: Low-Medium (2 days)
- Priority: 8/10

**1.4 Performance audit**
- Problem: Dashboard runs raw SQL queries on every load.
- Why users care: Slow admin = bad reviews.
- Implementation: Cache dashboard stats with transients (5-min TTL), lazy-load audit scans.
- Difficulty: Low (1 day)
- Priority: 7/10

---

### Phase 2: Features That Outperform Yoast (Week 3-6)

**2.1 Advanced Readability Analysis**
- Problem: Yoast's readability is its moat. Users expect Flesch score, sentence length, paragraph length, passive voice detection.
- Why users care: Writers and content teams rely on this daily.
- Implementation: Port proven readability algorithms to JS. Show traffic-light scoring per check.
- Difficulty: Medium (4 days)
- Priority: 9/10

**2.2 AI Content Assistant (beyond meta)**
- Problem: Snaplevel only AI-generates meta fields. Yoast Premium has "AI Generate" but it's limited.
- Why users care: Users want AI help INSIDE the post editor, not just on SEO fields.
- Implementation: "Improve this paragraph" button, AI outline generator, AI FAQ generator from content, AI internal link suggestions.
- Difficulty: Medium (5 days, uses existing AI engine)
- Priority: 8/10

**2.3 Google Search Console Integration**
- Problem: No real search data inside WordPress.
- Why users care: Users want to see which keywords they actually rank for without leaving WP.
- Implementation: OAuth2 connection to GSC API, dashboard widget showing top queries, per-post "ranking keywords" in the editor sidebar, click/impression trends.
- Difficulty: High (7 days)
- Priority: 7/10

**2.4 WP 7.0 AI Client Support**
- Problem: WordPress.org reviewer explicitly flagged this. WP 7.0 ships a built-in AI Client.
- Why users care: Site owners configure AI once, all plugins use it. Less setup friction.
- Implementation: Add a provider class that wraps `wp_ai_generate()`. Auto-detect WP 7.0+ and offer "Use site AI" option alongside BYOK.
- Difficulty: Low (1-2 days)
- Priority: 7/10 (future-proofing + reviewer goodwill)

---

### Phase 3: Features That Outperform Rank Math (Week 7-12)

**3.1 AI-Powered Internal Linking**
- Problem: Rank Math has basic "link suggestions." It's static keyword matching.
- Why users care: Internal linking is critical for SEO. Manual linking is tedious.
- Implementation: On save, AI analyzes content and suggests 3-5 internal links with anchor text. One-click insert. Background job builds a site-wide content graph for relevance scoring.
- Difficulty: High (7 days)
- Priority: 9/10

**3.2 AI Keyword Research (built-in)**
- Problem: Rank Math has a "Keyword Research" tool tied to their paid API. Yoast has none.
- Why users care: Finding the right keyword is step 1 of SEO. Most users can't afford Ahrefs/SEMrush.
- Implementation: Use the existing AI engine to suggest keywords based on content + topic. Show estimated difficulty, search intent classification, related long-tails. No external API needed (AI inference only).
- Difficulty: Medium (4 days)
- Priority: 8/10

**3.3 Local SEO Module**
- Problem: Rank Math Free has Local SEO schema. Yoast charges for it. Snaplevel has none.
- Why users care: Huge market. Every local business needs LocalBusiness schema, opening hours, multiple locations.
- Implementation: Settings page for business info, auto-generate LocalBusiness JSON-LD, Google Maps embed shortcode, multi-location support.
- Difficulty: Medium (4 days)
- Priority: 7/10

**3.4 Advanced WooCommerce SEO**
- Problem: Current WooCommerce module only does noindex + basic OG.
- Why users care: eCommerce sites need Product schema with price/availability/reviews, category SEO, product-feed readiness.
- Implementation: Auto-generate Product schema from WC data, category title/desc templates, structured data for reviews, breadcrumb integration with WC categories.
- Difficulty: Medium (5 days)
- Priority: 7/10

**3.5 Role-Based Access Control**
- Problem: No UI to control which roles can access which features.
- Why users care: Agencies managing client sites need this. Editors shouldn't access redirections.
- Implementation: Settings page with role/capability matrix. Stored in options, checked at capability gates.
- Difficulty: Low (2 days)
- Priority: 6/10

---

### Phase 4: Features No SEO Plugin Currently Offers (Week 13+)

**4.1 AI SEO Autopilot (Scheduled Optimization)**
- Problem: No SEO plugin automatically optimizes a site over time without manual intervention.
- Why users care: Most site owners never touch their SEO plugin after initial setup. Content goes stale.
- Implementation: Weekly cron job that: (1) finds posts with no meta and generates it, (2) finds posts with outdated schema and refreshes, (3) finds broken links and queues fixes, (4) suggests content updates for posts losing traffic (requires GSC). All changes go to a "Pending Review" queue.
- Difficulty: High (10 days)
- Priority: 9/10 (this IS the differentiator)

**4.2 AI Search Visibility Monitor**
- Problem: No plugin tracks how your content appears in AI-powered search (ChatGPT, Perplexity, Google AI Overviews).
- Why users care: AI search is eating traditional clicks. Sites need to know if they're being cited.
- Implementation: Scheduled task that queries AI search APIs (where available) or uses the existing Ahrefs Brand Radar data. Dashboard showing "AI citations this week" and which pages are being referenced.
- Difficulty: High (7 days, depends on available APIs)
- Priority: 8/10

**4.3 Competitor Content Gap Analysis**
- Problem: No SEO plugin shows what topics competitors cover that you don't.
- Why users care: Content planning is the hardest part of SEO.
- Implementation: User inputs 3 competitor URLs. AI crawls their sitemap, categorizes topics, compares against user's content, suggests missing topics with keyword targets and outline drafts.
- Difficulty: High (8 days)
- Priority: 7/10

**4.4 AI-Generated FAQ Schema from Comments/Support**
- Problem: No plugin auto-generates FAQ schema from real user questions.
- Why users care: FAQ rich results drive significant CTR improvement.
- Implementation: Scan post comments, support tickets (via integration), and AI chat logs. Extract common questions. AI writes concise answers. Auto-add FAQ schema to relevant posts.
- Difficulty: Medium (5 days)
- Priority: 7/10

**4.5 SEO A/B Testing**
- Problem: No free SEO plugin lets you A/B test titles/descriptions in search results.
- Why users care: Even small CTR improvements compound across thousands of impressions.
- Implementation: Store 2 title variants per post. Rotate output based on a cookie-free split (odd/even minute). Track CTR from GSC data per variant. Auto-select winner after significance threshold.
- Difficulty: High (8 days)
- Priority: 6/10

---

## UX Improvements (Before Adding Features)

| Problem | Fix | Impact |
|---------|-----|--------|
| Dashboard is data-heavy but not actionable | Add "Top 3 actions to take now" section at the top | Retention |
| Setup wizard doesn't explain WHY each step matters | Add microcopy explaining benefit of each action | Activation |
| AI generation has no loading state feedback | Add streaming-style text reveal or progress indicator | Perceived speed |
| No onboarding for users coming from Yoast/RM | Add "Welcome from [plugin]" flow after import detecting which plugin was active | Trust |
| Score circle means nothing without context | Add "What this means" tooltip and breakdown | Education |
| No success celebration | Add confetti/checkmark when score reaches 80+ | 5-star reviews |
| Module toggles buried in dashboard | Move to a dedicated "Modules" settings tab with clear descriptions | Discoverability |

---

## Key Metrics to Track

- **Activation-to-retention**: % of users who open a post editor within 7 days of activation
- **AI adoption**: % of active installs that have connected an AI key
- **Import completion**: % of users who finish the import wizard (vs. abandon)
- **Score improvement**: Average site health score change in first 30 days
- **Review sentiment**: Track "easy" and "AI" mentions in reviews

---

## Reply Template for WordPress.org Reviewer

When replying to the reviewer, keep it short. Here's the gist:

> Fixed all flagged issues: sanitization (nonce, $_SERVER), escaping (JSON-LD with JSON_HEX_TAG), enqueue (GA4/AdSense now use wp_enqueue_script, inline styles moved to wp_add_inline_style or admin.css), path validation in image restore, removed load_plugin_textdomain, removed wporg-assets from zip, updated readme with External Services section including TOS/privacy links for all providers and IndexNow.
>
> Regarding ownership: [choose your method - email change or DNS TXT record].
>
> Regarding WP 7.0 AI Client: We plan to add support in a future update while maintaining BYOK as fallback for sites on WP < 7.0.
>
> Regarding the REST API permission_callback note: The `can_use_ai` check requires `snap_use_ai` capability (granted to editors+) OR `edit_posts`. This is intentional - AI generation only writes to post meta the user already has permission to edit, and each call additionally checks `current_user_can('edit_post', $post_id)` for the specific post.

---

## Summary

Snaplevel's unfair advantage is AI-native design. Yoast and Rank Math bolted AI on as an upsell. Snaplevel was built around it.

The winning strategy:
1. **Phase 1**: Pass review, ship with a content analysis engine that matches Yoast's UX quality
2. **Phase 2**: Beat Yoast on AI features and real data (GSC integration)
3. **Phase 3**: Beat Rank Math on intelligence (AI internal linking, AI keyword research)
4. **Phase 4**: Create a new category (AI SEO Autopilot) that neither competitor has

The single most important thing for WordPress.org adoption: **the content analysis score in the editor sidebar must feel as polished and useful as Yoast's traffic light system on day one.** Everything else is secondary to that first impression.
