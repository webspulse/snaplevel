# Snaplevel Final Roadmap — Critically Reviewed

## Challenge Review of Every Item

### Phase 1 Items

**1.1 Fix all review issues**
- Should we build? YES, non-negotiable.
- Category: **MUST BUILD**

**1.2 Content Analysis Engine (Real-time)**
- Should we build? YES. But here's the honest problem: building a content analysis engine that matches Yoast's quality is NOT a 3-4 day job. Yoast has iterated on theirs for 10+ years. A rushed, shallow version will get us worse reviews than having none at all ("Snaplevel's analysis is useless compared to Yoast" = 1-star).
- Will users notice? Absolutely. This is the first thing people compare.
- Will it improve reviews? Only if it's GOOD. A bad one hurts more than none.
- Support burden? High if buggy. Medium if solid.
- Performance? JS-only, no server impact. But a bloated analyzer slows the editor.
- Lower-effort alternative with 80% impact? **YES. Instead of building a full readability analyzer, build an AI-powered content score.** When the user clicks "Analyze," AI reads the content and returns 5-7 actionable suggestions. This is 10x easier to build (you already have the AI engine), 10x more useful than keyword density math, and perfectly aligned with "AI does the work." No one else does this.
- Does it strengthen core promise? The traditional analyzer doesn't (it's "you do the work, we show traffic lights"). The AI version DOES.
- Category: **MUST BUILD — but as AI Content Score, not a Yoast clone.**

**1.3 Multi-keyword support (5 keywords)**
- Should we build? Not for launch. Here's why: if your content analysis is AI-powered, keywords become less central. The AI already knows what the content is about. Adding 5 keyword fields is copying Rank Math's homework from 2019.
- Will users notice? Some power users will. Most won't use more than 1.
- Lower-effort alternative? Let AI suggest related keywords after analyzing content. Show them as tags, not as input fields the user has to fill.
- Does it strengthen core promise? No. It's "the user does more work."
- Category: **NICE TO HAVE** (add later if users request it)

**1.4 Performance audit (transient caching for dashboard)**
- Should we build? Yes but it's a 2-hour fix, not a "roadmap item."
- Category: **MUST BUILD** (just do it, don't roadmap it)

---

### Phase 2 Items

**2.1 Advanced Readability Analysis**
- Should we build? NO as a standalone feature. If we build the AI Content Score (1.2 revised), this is redundant. AI can assess readability better than Flesch-Kincaid ever could. And it can explain WHY in plain language instead of showing a number.
- Is Yoast already better? Yes, at the traditional approach. We can't out-Yoast Yoast on their own game. We CAN out-AI them.
- Category: **DO NOT BUILD** (subsumed by AI Content Score)

**2.2 AI Content Assistant (beyond meta)**
- Should we build? YES, but scope it tightly. "Improve this paragraph" is scope creep into Grammarly/Jetpack AI territory. But "Generate FAQ schema from this content" and "Suggest internal links" are SEO-specific and high-value.
- Support burden? Low if results are good. High if AI hallucinates links to non-existent pages.
- Lower-effort alternative? Ship just 2 features: (1) AI FAQ generator (generates FAQ schema from content), (2) AI internal link finder (scans existing posts, suggests links).
- Category: **SHOULD BUILD** (scoped to SEO-specific AI actions only)

**2.3 Google Search Console Integration**
- Should we build? Not in the first 90 days. Here's why: OAuth2 setup is painful for users ("why does this plugin need access to my Google account?"). It creates support tickets. It requires ongoing maintenance as Google changes their API. And Rank Math already does this well.
- Will it improve reviews? Marginally. Users who want GSC data already have Rank Math or Site Kit.
- Support burden? HIGH. OAuth flows break, tokens expire, users get confused.
- Performance? Adds cron jobs, stores data, increases DB size.
- Category: **NICE TO HAVE** (Phase 3+, after 10k installs)

**2.4 WP 7.0 AI Client Support**
- Should we build? YES but not urgently. WP 7.0 just shipped (May 2026). Adoption is maybe 30% of sites. Most hosts haven't auto-updated yet. But mentioning it in your reviewer reply shows good faith.
- Lower-effort alternative? Add detection for WP 7.0 AI Client availability. If present, offer as a provider option in settings. Takes 1 day.
- Category: **SHOULD BUILD** (1-day effort, good PR with reviewer)

---

### Phase 3 Items

**3.1 AI-Powered Internal Linking**
- Should we build? YES. This is the killer feature. No plugin does this well. Rank Math's "link suggestions" are static keyword matches from their API. Snaplevel can do this with the AI engine that's ALREADY BUILT. Low additional infrastructure, high perceived value.
- Will users notice? YES. Every SEO guide says "build internal links." Nobody actually does it because it's tedious.
- Support burden? Low. Suggestions are non-destructive (user clicks to insert).
- Performance? Background indexing of posts needed. But can run during low-traffic cron.
- Category: **SHOULD BUILD** (this could be THE reason people choose Snaplevel)

**3.2 AI Keyword Research**
- Should we build? Partially. Full keyword research (volumes, difficulty) requires external data that AI alone can't provide accurately. AI CAN suggest related topics and long-tail variations, but it can't tell you search volume. Claiming it can would be dishonest.
- Lower-effort alternative? "AI Topic Suggestions" — not keyword research, but content gap ideas based on your existing content + training data. More honest, still useful.
- Does it strengthen core promise? The honest version does. The fake-volume version doesn't.
- Category: **NICE TO HAVE** (reframe as topic suggestions, not keyword research)

**3.3 Local SEO Module**
- Should we build? Not in the first 90 days. It's a whole product surface (multi-location, opening hours, maps). The market is served by dedicated plugins. Adding a half-baked version weakens trust.
- Category: **DO NOT BUILD** (until 50k+ installs create demand)

**3.4 Advanced WooCommerce SEO**
- Should we build? YES, but keep it to auto-generated Product schema from WC data. That's the #1 gap. Don't build a full WooCommerce SEO suite.
- Lower-effort: Auto-detect WooCommerce, auto-output Product schema with price/availability/reviews from existing WC data. No UI needed. Just works.
- Category: **SHOULD BUILD** (auto-schema only, no UI bloat)

**3.5 Role-Based Access Control**
- Should we build? Not yet. At <10k installs, you don't have agency users. This is a feature for scale.
- Category: **DO NOT BUILD** (until agencies request it)

---

### Phase 4 Items

**4.1 AI SEO Autopilot**
- Should we build? THIS IS THE PRODUCT. But not as a "Phase 4" thing. This should be your core narrative from day 1, shipped incrementally. The current "Fix with AI" button on the audit page IS version 0.1 of autopilot. Frame it that way.
- Risks: Users afraid of AI changing things without permission. Solution: everything goes to a review queue. Nothing is live until approved.
- Lower-effort MVP: Weekly email digest: "Snaplevel found 12 posts missing descriptions and 3 broken links. Click here to review AI-generated fixes." That's autopilot without the scary part.
- Category: **SHOULD BUILD** (as weekly digest MVP, not full automation)

**4.2 AI Search Visibility Monitor**
- Should we build? Not now. There's no reliable API for this. It would be vaporware. The Ahrefs Brand Radar integration in your toolset could provide this eventually, but it's a premium positioning play for later.
- Category: **DO NOT BUILD** (no reliable data source exists yet)

**4.3 Competitor Content Gap Analysis**
- Should we build? Cool idea, terrible execution risk. Crawling competitor sitemaps is brittle, AI analysis of hundreds of pages is expensive, and the output is subjective.
- Category: **DO NOT BUILD** (too fragile, too expensive per-user)

**4.4 AI FAQ Schema from Comments**
- Should we build? YES. Brilliant low-effort feature. Scan post comments, extract questions, AI writes answers, generate FAQ schema. Completely aligned with "AI does the work."
- Lower-effort alternative? Even simpler: AI reads the post content and generates 3-5 FAQ pairs that could earn rich results. No comment scanning needed.
- Category: **SHOULD BUILD** (as "Generate FAQ" button on posts)

**4.5 SEO A/B Testing**
- Should we build? NO. This requires GSC integration (which we deferred), statistical significance calculations, and a long time horizon. The support burden of explaining statistics to non-technical users is enormous.
- Category: **DO NOT BUILD**

---

## Final Roadmap: 15 Highest-Impact Initiatives

### TIER 1: Before WordPress.org Launch (Week 1-2)

#### 1. AI Content Score (replaces traditional content analysis)
- **Why it matters**: This is your first-impression feature. When a user opens the editor, this is what they see. It must be impressive.
- **What it is**: User writes content → clicks "Analyze with AI" → AI returns 5-7 specific, actionable suggestions (e.g., "Your opening paragraph doesn't mention your topic. Add it within the first 50 words." or "This post has no internal links. Link to [Post X] in paragraph 3.")
- **Effort**: 3 days (AI prompt engineering + UI for suggestion cards)
- **User impact**: HIGH — nothing else in the market does this
- **Review impact**: HIGH — "this plugin actually tells me what to fix, not just shows a score"
- **Support burden**: Low (AI suggestions are advisory, not destructive)
- **Performance**: One API call per analysis, cached per post revision
- **Success metric**: % of users who click "Analyze" within first session

#### 2. Dashboard Performance (transient caching)
- **Why it matters**: First screen users see. If it's slow, they uninstall.
- **Effort**: 3 hours
- **User impact**: Medium
- **Review impact**: Prevents negative reviews about slowness
- **Support burden**: Prevents "why is my admin slow" tickets
- **Performance**: Eliminates 6+ SQL queries per dashboard load
- **Success metric**: Dashboard load time <500ms

#### 3. Onboarding Success Path
- **Why it matters**: The gap between "activate" and "first value" determines retention.
- **What it is**: After wizard, redirect to a post editor with a guided tooltip: "Click ✦ Generate to write your first AI-powered meta description." One successful generation = user is hooked.
- **Effort**: 1 day
- **User impact**: HIGH — converts activation to retention
- **Review impact**: HIGH — users who experience value leave good reviews
- **Support burden**: Reduces "I installed it, now what?" tickets
- **Performance**: Zero
- **Success metric**: % of users who complete first AI generation within 10 min of activation

#### 4. Fix remaining inline scripts (reviewer compliance)
- **Why it matters**: Reviewer may re-flag remaining inline `<script>` tags in view files.
- **What it is**: Convert the remaining admin view inline scripts to use `wp_add_inline_script()` attached to the `icw-admin` handle.
- **Effort**: 1 day
- **User impact**: None (invisible)
- **Review impact**: Removes potential re-flag
- **Support burden**: None
- **Performance**: None
- **Success metric**: Zero inline script/style flags from Plugin Check

#### 5. Error states and empty states
- **Why it matters**: Every screen needs to handle "nothing here yet" gracefully. A blank table with no guidance = confused user = uninstall.
- **What it is**: Add helpful empty states to Redirections ("No redirects yet. Redirects are created automatically when you change a URL, or add one manually."), Broken Links ("Run your first scan to find dead links."), etc.
- **Effort**: 1 day
- **User impact**: Medium — reduces confusion
- **Review impact**: Prevents "I don't know what to do" reviews
- **Support burden**: Reduces basic support tickets significantly
- **Performance**: Zero
- **Success metric**: Reduction in "how do I use this" support emails

---

### TIER 2: First 90 Days Post-Launch (Week 3-10)

#### 6. AI Internal Link Suggestions
- **Why it matters**: Internal linking is the #1 most-recommended SEO tactic that nobody actually does. If Snaplevel makes it effortless, that's a reason to switch.
- **What it is**: In the editor sidebar, after AI analysis: "Suggested internal links:" with 3-5 contextual links the user can insert with one click. AI finds relevant existing posts and suggests natural anchor text.
- **Effort**: 5 days (content indexing + AI matching + insertion UI)
- **User impact**: VERY HIGH — saves 10+ minutes per post
- **Review impact**: HIGH — "this feature alone is worth it"
- **Support burden**: Low (suggestions only, user controls insertion)
- **Performance**: Background post index (one-time build, incremental updates)
- **Success metric**: Average links inserted per post via suggestions

#### 7. AI FAQ Generator (with schema)
- **Why it matters**: FAQ rich results are the easiest schema win. Most users don't know how to write FAQ schema. Snaplevel generates it from content in one click.
- **What it is**: "Generate FAQ" button on posts. AI reads content, generates 3-5 Q&A pairs, outputs FAQ schema. User reviews and saves.
- **Effort**: 2 days (AI prompt + schema output + UI)
- **User impact**: HIGH — visible rich results in Google
- **Review impact**: HIGH — tangible Google result users can screenshot
- **Support burden**: Low
- **Performance**: One AI call per generation
- **Success metric**: % of posts with FAQ schema after 30 days

#### 8. Weekly SEO Digest Email
- **Why it matters**: Most users forget about SEO plugins after day 1. A weekly email keeps them engaged and demonstrates ongoing value without them opening the admin.
- **What it is**: Weekly email: "Your site health: 73/100. 5 posts missing descriptions. 2 new broken links found. 1 redirect created automatically. [Review AI suggestions →]"
- **Effort**: 3 days (cron job + email template + opt-in setting)
- **User impact**: HIGH — ongoing engagement without effort
- **Review impact**: Medium — drives users back to plugin, reminds them to review
- **Support burden**: Low (opt-in, unsubscribe link)
- **Performance**: Weekly cron, minimal
- **Success metric**: Email open rate, click-through to admin

#### 9. WP 7.0 AI Client Integration
- **Why it matters**: Shows forward-thinking. Reduces setup friction for WP 7.0 users. Reviewer explicitly asked for it.
- **What it is**: Detect WP 7.0+. If AI Client is configured, offer "Use site AI" as a provider option. Falls back to BYOK on older installs.
- **Effort**: 1-2 days
- **User impact**: Medium (only WP 7.0 users benefit now, growing over time)
- **Review impact**: HIGH — directly addresses reviewer feedback
- **Support burden**: Reduces "how do I get an API key" tickets
- **Performance**: Zero
- **Success metric**: % of WP 7.0 users choosing site AI vs BYOK

#### 10. Auto-WooCommerce Product Schema
- **Why it matters**: WooCommerce is on 30%+ of WordPress sites. Product rich results (price, availability, reviews in Google) drive clicks. Currently requires paid plugins or manual schema.
- **What it is**: If WooCommerce is active, auto-generate Product schema from WC product data. Zero configuration. Just works.
- **Effort**: 2 days
- **User impact**: HIGH for WooCommerce users
- **Review impact**: Medium — WooCommerce users leave enthusiastic reviews
- **Support burden**: Low (automatic, no config)
- **Performance**: Minimal (reads existing WC data on frontend)
- **Success metric**: % of WC products with valid Product schema

#### 11. "Why this score" breakdown
- **Why it matters**: The health score circle means nothing without explanation. Users see 63/100 and don't know what to do.
- **What it is**: Click the score → modal showing each factor, its weight, current value, and one-click fix. "Meta descriptions: 71% coverage (worth 40 points). [Fix with AI →]"
- **Effort**: 1 day
- **User impact**: HIGH — converts confusion into action
- **Review impact**: HIGH — "the plugin tells me exactly what to fix"
- **Support burden**: Reduces "how do I improve my score" tickets
- **Performance**: Zero (data already computed)
- **Success metric**: Click-through rate from score to fix actions

---

### TIER 3: 90-180 Days (Building Moat)

#### 12. AI SEO Autopilot (Review Queue MVP)
- **Why it matters**: This is Snaplevel's long-term differentiator. No other plugin optimizes your site while you sleep.
- **What it is**: Background job finds posts with missing/weak meta, generates suggestions, queues them for review. User sees: "Snaplevel prepared 8 improvements for your review." One click approves all, or review individually.
- **Effort**: 7 days
- **User impact**: VERY HIGH — the plugin works FOR you
- **Review impact**: VERY HIGH — "I installed it and my SEO improved without doing anything"
- **Support burden**: Medium (users may not understand the queue at first)
- **Performance**: Background cron, batched AI calls during low traffic
- **Success metric**: % of queued suggestions approved by users

#### 13. Import-and-improve flow
- **Why it matters**: When users import from Yoast/Rank Math, their existing meta stays unchanged. Snaplevel should immediately show them what AI can improve.
- **What it is**: After import: "Imported 247 posts from Yoast. AI found 89 posts with weak meta descriptions (under 120 chars or generic). [Let AI improve them →]"
- **Effort**: 2 days
- **User impact**: HIGH — immediate demonstration of AI value over previous plugin
- **Review impact**: HIGH — "switched from Yoast, Snaplevel immediately found things to fix"
- **Support burden**: Low
- **Performance**: One scan query after import
- **Success metric**: % of importers who click "Let AI improve"

#### 14. AI Topic Suggestions (lightweight keyword alternative)
- **Why it matters**: Users don't know what to write about next. This doesn't require external APIs or fake search volume data.
- **What it is**: Based on existing content + AI training data: "You've written about [topic A, B, C] but haven't covered [D, E, F]. Here's a suggested outline for [D]."
- **Effort**: 3 days
- **User impact**: Medium-High for content creators
- **Review impact**: Medium
- **Support burden**: Low
- **Performance**: AI call on demand only
- **Success metric**: % of suggestions that result in a new draft

#### 15. Success celebrations + review prompt
- **Why it matters**: Happy moments = 5-star reviews. Most plugins never ask.
- **What it is**: When health score crosses 80, or when user's first AI generation is saved, or after first week with zero 404s: show a brief celebration and a gentle "Enjoying Snaplevel? A review helps us grow. [Leave a review →]"
- **Effort**: 1 day
- **User impact**: Emotional — makes users feel accomplished
- **Review impact**: VERY HIGH — directly drives review volume
- **Support burden**: Zero
- **Performance**: Zero
- **Success metric**: Reviews per 1000 active installs

---

## Honest Answers

### If Snaplevel launched tomorrow, why would someone choose it over Yoast?

**One reason: AI generates everything with one click.**

Yoast shows you a checklist and makes YOU do the work. Snaplevel does the work and asks you to approve. For the 80% of WordPress users who don't understand SEO terminology, this is transformative. They don't know what a "focus keyphrase" is. They don't know what "meta description" means. But they CAN click "Generate" and approve good output.

The honest weakness: if the AI output isn't noticeably good on first try, they'll switch back to Yoast because at least Yoast is familiar.

### Why would someone choose it over Rank Math?

**Rank Math is feature-rich but complex. Snaplevel is AI-simple.**

Rank Math's free tier is incredible, but its settings page has 100+ options. Their "Content AI" is a paid add-on with credits. Snaplevel's pitch: bring your own AI key (pay pennies), get unlimited generations, and the plugin handles complexity for you.

The honest weakness: Rank Math has years of trust, a massive community, and features Snaplevel doesn't have yet (GSC integration, local SEO, analytics). Users comparing feature lists will choose Rank Math. Users comparing the editing experience might choose Snaplevel.

### Three biggest reasons users would uninstall Snaplevel:

1. **"I added my API key but the AI suggestions weren't good."** If the AI Training isn't set up, outputs are generic. First-run experience without training data is weak. Fix: better defaults, detect site content automatically for training context.

2. **"I don't know what this plugin is doing for me."** No ongoing visibility after setup. If the user doesn't open posts regularly, they never see the AI features. Fix: weekly digest email, admin dashboard that shows value delivered.

3. **"It doesn't have [feature X] that Rank Math has."** Feature-list shoppers will always find gaps. Fix: don't compete on feature count. Compete on experience quality. Make the features you HAVE feel magical.

### If you had to cut 50% of the current feature set, what would you remove?

**Remove:**
- **Unused Images cleanup** — Nice utility but not core SEO. Plenty of dedicated plugins do this. It distracts from the AI story.
- **Image compression (WebP)** — Same reasoning. ShortPixel, Imagify, Smush all do this better. It's maintenance burden with no AI differentiation.
- **Site Audit (full scan)** — The individual checks are useful, but the "run full audit" flow is heavy, slow, and duplicates what the Health Score already shows. Replace with the actionable "Why this score" breakdown.
- **SEO Analyzer legacy module** (orphan pages, slow pages) — Brittle, makes HTTP requests to own site, creates support tickets. The health score + specific issue counts on the dashboard are enough.
- **Code Injector (GA4/AdSense)** — Every caching plugin and 50 other tools do this. It's not SEO. Remove to reduce attack surface and reviewer scrutiny.

**Keep (the 50% that matters):**
- AI Engine + Training (core differentiator)
- SEO Metabox + Editor Sidebar (daily touchpoint)
- Titles & Meta templates (foundational SEO)
- Schema generation (AI-powered, unique)
- Redirections + 404 Monitor (essential, well-built)
- Broken Link Checker (practical value)
- Breadcrumbs (simple, useful)
- XML Sitemaps + IndexNow (expected)
- Importers (acquisition channel)
- WooCommerce auto-schema (high-value, low-effort)

### What single feature could make Snaplevel famous?

**AI SEO Autopilot with the weekly review queue.**

The pitch that spreads: "I installed Snaplevel and every Monday it shows me what it improved. I just click Approve. My organic traffic went up 30% in 3 months and I didn't write a single meta description manually."

No other SEO plugin does ongoing, proactive optimization. They all require the user to remember to do SEO. Snaplevel should be the plugin that does SEO FOR you and just asks permission.

This is the "set it and forget it" promise that WordPress users dream about. It's the reason people pay for managed WordPress hosting. Apply the same principle to SEO.

The tagline shouldn't be "The SEO plugin where AI does the work."
It should be: **"The SEO plugin that improves your site every week."**

---

## Summary: What to Ship

| Priority | Initiative | Effort | Ship by |
|----------|-----------|--------|---------|
| 1 | WordPress.org fixes (DONE) | Done | Now |
| 2 | AI Content Score | 3 days | Before resubmit |
| 3 | Dashboard caching | 3 hours | Before resubmit |
| 4 | Onboarding success path | 1 day | Before resubmit |
| 5 | Empty states | 1 day | Before resubmit |
| 6 | Remaining inline script fixes | 1 day | Before resubmit |
| 7 | AI Internal Link Suggestions | 5 days | Week 4 |
| 8 | AI FAQ Generator | 2 days | Week 4 |
| 9 | Weekly SEO Digest | 3 days | Week 5 |
| 10 | WP 7.0 AI Client | 1 day | Week 3 |
| 11 | Auto WooCommerce Schema | 2 days | Week 5 |
| 12 | "Why this score" breakdown | 1 day | Week 3 |
| 13 | AI Autopilot Review Queue | 7 days | Week 8 |
| 14 | Import-and-improve flow | 2 days | Week 6 |
| 15 | Success celebrations + review prompt | 1 day | Week 3 |

**Total to launch: ~7 days of work.**
**Total to full roadmap: ~30 days of focused development.**

That's how you get to 100k installs: ship less, but make every feature feel like magic.
